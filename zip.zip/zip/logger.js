var winston = require('winston');
require('winston-daily-rotate-file');
// winston.emitErrs = true;
mkdirp.sync('./logs')
const tsFormat = () => (new Date()).toLocaleTimeString();
var logger = new winston.Logger({
    transports: [
        new winston.transports.DailyRotateFile({
            level: env === 'development' ? 'verbose' : 'info',
            filename: './logs/all-logs_',
            handleExceptions: true,
            timestamp: tsFormat,
            json: true,
            localTime:true,
            datePattern: 'dd-MM-yyyy_',
            // maxsize: 1,           
            maxsize: 2621440, //2MB
            maxFiles: 10,
            maxDays: 15,
            prepend:true,
            json: false,
            colorize: true,
            prettyPrint:true
        }),
        new winston.transports.Console({
            level: 'debug',
            handleExceptions: true,
            json: false,
            colorize: true
        })
    ],
    exitOnError: false
});

module.exports = logger;
module.exports.stream = {
    write: function(message, encoding){
        logger.info(message);
    }
};