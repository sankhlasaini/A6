var express = require('express');
var helmet = require('helmet');
var CryptoJS = require("crypto-js");
var xss = require("xss");

app = express();

// var compression = require('compression')
// var expressSanitizer = require('express-sanitizer');

// var sqlinjection = require('sql-injection');

// app.use(sqlinjection);

//OWASP (Web Application Penetration Protection)
app.use(helmet.frameguard('deny'));
app.use(helmet.xssFilter());
app.use(helmet.xssFilter({
  setOnOldIE: true
}));
app.use(helmet.noSniff());
var t = 5184000;
app.use(helmet.hsts({
  maxAge: t
}));
app.use(helmet.contentSecurityPolicy({
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", 'maps.google.com', 'maps.googleapis.com'],
    styleSrc: ["'self'", "'unsafe-inline'", 'fonts.googleapis.com'],
    imgSrc: ["'self'", 'maps.gstatic.com', 'maps.googleapis.com', 'maps.google.com', 'data:', 'khms0.googleapis.com', 'khms1.googleapis.com'],
    connectSrc: ["'self'", 'maps.googleapis.com'],
    fontSrc: ["'self'", 'fonts.gstatic.com'],
    objectSrc: ["'none'"],
    mediaSrc: ["'self'"],
    frameSrc: ["'none'"]
  }
}));


constants = require('./server/utils/constants');
dependencies = require('./server/configuration/index');
multerSetup = require('./server/utils/multer');

multerSetup.setupMulter();
app.use(bodyParser.json({
  limit: '50mb'
}));
app.use(bodyParser.urlencoded({
  limit: '50mb',
  extended: true
}));
app.use(cookieParser());

console.log('proxyFlag:', proxyFlag, 'typeof proxyFlag: ', typeof (proxyFlag));


endpoints = require('./server/configuration/endpoints');
routes = require('./server/utils/routes');

app.post('/orgIdCheck', function (req, res) {
  console.log('\n\n\n\n\nORG : ', req.body, '\n\n\n\n\n');
  res.send({
    success: true
  });
})

app.get('/getSecret', function (req, res) {
  res.send({
    secret: CryptoJS.enc.Utf8.parse(AES_KEY)
  });
})

// This is to Send Compressed Modules
// This code is only for Production Mode
//----------------------------------------------

// app.get('*.js', function (req, res, next) {
//   req.url = req.url + '.gz';
//   res.set('Content-Encoding', 'gzip');
//   res.set('Content-Type', 'text/javascript');
//   next();
// });

// app.get('*.css', function (req, res, next) {
//   req.url = req.url + '.gz';
//   res.set('Content-Encoding', 'gzip');
//   res.set('Content-Type', 'text/css');
//   next();
// });

// app.get('*.svg', function (req, res, next) {
//   req.url = req.url + '.gz';
//   res.set('Content-Encoding', 'gzip');
//   res.set('Content-Type', 'image/svg+xml');
//   next();
// });


// Point static path to dist
app.use(express.static(path.join(__dirname, 'dist')));

// Winston Logger Config
// logger = require('./logger');
// logger.debug("Overriding 'Express' logger");
// app.use(morgan('combined', {
//   "stream": logger.stream
// }));
// app.use(compression())
// Catch all other routes and return the index file
app.get('*', (req, res) => {
  console.log('******************************************', req.url);
  switch (req.url) {
    case '/swiper':
      res.sendFile(path.join(__dirname, './node_modules/swiper/dist/js/swiper.js'));
      break;
    default:
      res.sendFile(path.join(__dirname, 'dist/index.html'));
      break;
  }
});

if (cluster.isMaster && !module.parent) {
  console.log('if block');
  console.log('Master' + process.pid + 'is running');
  // Fork workers.
  for (var i = 0; i < numCPUs; i++) {
    cluster.fork();
  }
  cluster.on('online', function (worker) {
    console.log('Worker ' + worker.process.pid + ' is online');
  });
  cluster.on('exit', (worker, code, signal) => {
    console.log('worker' + worker.process.pid + 'died');
    cluster.fork();
  });
} else {
  console.log('is running');
  var port = process.env.PORT || '3000';
  app.set('port', port);
  var server = http.createServer(app);
  if (!module.parent) {
    server.listen(port, () => console.log('API running on localhost:', port));
    console.log('Worker' + process.pid + 'started');
  }
}

global.setHeaders = function (headers) {
  return {
    'Content-Type': 'application/json',
    'tenantToken': headers.tenanttoken,
    'Authorization': headers.authorization,
    'user_details': headers.user_details
  };
}

global.sanitizeRequest = function (body) {
  return JSON.parse(xss(JSON.stringify(body)));
}


// console.log("\n\n\n\n")

// let pass = "password";

// var ciphertext = CryptoJS.AES.encrypt(pass, 'secret key 123');

// console.log('BEFORE  ::::: ', pass);
// // console.log('ciphertext  ::::: ',ciphertext);


// var bytes = CryptoJS.AES.decrypt(ciphertext.toString(), 'secret key 123');
// var plaintext = bytes.toString(CryptoJS.enc.Utf8);

// console.log('bytes  ::::: ', bytes, typeof (bytes));
// console.log('AFTER  ::::: ', plaintext);



// var key = CryptoJS.enc.Utf8.parse('7061737323313233');
// var iv = CryptoJS.enc.Utf8.parse('7061737323313233');
// var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse("It works"), key,
//     {
//         keySize: 128 / 8,
//         iv: iv,
//         mode: CryptoJS.mode.CBC,
//         padding: CryptoJS.pad.Pkcs7
//     });

// var decrypted = CryptoJS.AES.decrypt(encrypted, key, {
//     keySize: 128 / 8,
//     iv: iv,
//     mode: CryptoJS.mode.CBC,
//     padding: CryptoJS.pad.Pkcs7
// });

// console.log('Encrypted :' + encrypted);
// console.log('Key :' + encrypted.key);
// console.log('Salt :' + encrypted.salt);
// console.log('iv :' + encrypted.iv);
// console.log('Decrypted : ' + decrypted);
// console.log('utf8 = ' + decrypted.toString(CryptoJS.enc.Utf8));

// var xss = require("xss");
// var obj = {
//   name: '<script>alert("xss");</script>',
//   pass: '<script>alert("passsword");</script>'
// }
// var html = xss('');
// console.log('\n\n\n\n\n\n');
// console.log(obj);
// console.log(xss(JSON.stringify(obj)));
// console.log(JSON.parse(xss(JSON.stringify(obj))));

// var mysql = require('mysql');
// var connection = mysql.createConnection();

// var user = connection.escape('testUser');
// var pass = connection.escape('testPass');

// var sql  = "SELECT * FROM users WHERE user = '" + user + "' AND pass = '" + pass + "'";


// console.log(sql);

module.exports = app;
