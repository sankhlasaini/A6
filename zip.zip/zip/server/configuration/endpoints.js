var endpoints = module.exports;
var servicePaths = {
  'ecosystem': 'ecosystem',
  'territory': 'setup',
  'productCatalogue': 'products',
  'productCategory': 'products',
  'partner': 'panm',
  'catalog': 'catalog',
  'isam': 'isam',
  'asset': 'asset',
  'beat': 'beat',
  'apiGateway': 'apig',
  'apiGatewayEntry': '/api/v1.0.0/',
  'businessData': 'panm',
  'userSetup': ''
}
// var env_test='-deltaverge-dev';
// var initialURL_test='.apps.ocp.deltaverge.com';

//******************************************* */
if (proxyFlag === 'false') {
  // FOR LOCAL
  endpoints.Host = {
    Ecosystems: proto + servicePaths.apiGateway + env + initialURL + servicePaths.apiGatewayEntry + servicePaths.ecosystem,
    territory: proto + servicePaths.apiGateway + env + initialURL + servicePaths.apiGatewayEntry + servicePaths.territory,
    productCatalogue: proto + servicePaths.apiGateway + env + initialURL + servicePaths.apiGatewayEntry + servicePaths.productCatalogue,
    partner: proto + servicePaths.apiGateway + env + initialURL + servicePaths.apiGatewayEntry + servicePaths.partner,
    businessData: proto + servicePaths.apiGateway + env + initialURL + servicePaths.apiGatewayEntry + servicePaths.businessData,
    isam: proto + servicePaths.apiGateway + env + initialURL + servicePaths.apiGatewayEntry + servicePaths.isam,
    ProductCategory: proto + servicePaths.apiGateway + env + initialURL + servicePaths.apiGatewayEntry + servicePaths.productCategory,
    userSetup: proto + servicePaths.apiGateway + env + initialURL + servicePaths.apiGatewayEntry + servicePaths.userSetup,
    catalog: proto + servicePaths.apiGateway + env + initialURL + servicePaths.apiGatewayEntry + servicePaths.catalog,
    asset: proto + servicePaths.apiGateway + env + initialURL + servicePaths.apiGatewayEntry + servicePaths.asset,
    beat: proto + servicePaths.apiGateway + env + initialURL + servicePaths.apiGatewayEntry + servicePaths.beat,
  };
} else {
  // FOR WEB DEPOLYMENT. This Work for all ENV (QA,Dev,Production)
  // SAMPLE URL : 'http://apig/api/v1.0.0/isam/oauth/token'
  endpoints.Host = {
    Ecosystems: proto + servicePaths.apiGateway + servicePaths.apiGatewayEntry + servicePaths.ecosystem,
    territory: proto + servicePaths.apiGateway + servicePaths.apiGatewayEntry + servicePaths.territory,
    productCatalogue: proto + servicePaths.apiGateway + servicePaths.apiGatewayEntry + servicePaths.productCatalogue,
    partner: proto + servicePaths.apiGateway + servicePaths.apiGatewayEntry + servicePaths.partner,
    businessData: proto + servicePaths.apiGateway + servicePaths.apiGatewayEntry + servicePaths.businessData,
    isam: proto + servicePaths.apiGateway + servicePaths.apiGatewayEntry + servicePaths.isam,
    ProductCategory: proto + servicePaths.apiGateway + servicePaths.apiGatewayEntry + servicePaths.productCategory,
    userSetup: proto + servicePaths.apiGateway + servicePaths.apiGatewayEntry + servicePaths.userSetup,
    catalog: proto + servicePaths.apiGateway + servicePaths.apiGatewayEntry + servicePaths.catalog,
    asset: proto + servicePaths.apiGateway + servicePaths.apiGatewayEntry + servicePaths.asset,
    beat: proto + servicePaths.apiGateway + servicePaths.apiGatewayEntry + servicePaths.beat,
  };
}




//******************************************* */
endpoints.Paths = {
  Isam: {
    login: "/oauth/token"
  },

  PasswordReset: {
    generateOTP: '/private/panm.genotp/v0.1',
    verifyOTP: '/private/panm.valotp/v0.1',
    resetPassword: '/private/panm.resetpasswd/v0.1',
    verifyUser: '/private/panm.verifyusrlogn/v0.1'
  },

  Ecosystems: {
    getGlobalModulesAction: '/private/ess.gbl.sch.acts/v0.1',
    createEcosystem: '/private/ess.gbl.eco.crt/v1.0',
    getEcosystemListCount: '/private/ess.gbl.eco.cnt/v1.0',
    getEcosystemList: '/private/ess.gbl.eco.getall/v1.0',
    getEcosystemById: '/protected/ess.eco.get.byid/v1.0',
    copyEcosystem: '/protected/ess.eco.cpy/v1.0',
    cloneEcosystem: '/protected/ess.eco.cln/v1.0',
    updateEcosystem: '/protected/ess.eco.mdfy.byid/v1.0',
    createProfile: '/private/ess.prf.crt/v1.0',
    cloneProfile: '/protected/ess.prf.cln/v1.0',
    getProfiles: '/protected/ess.prf.get.byecoid/v1.0',
    updateProfile: '/protected/ess.prf.mdfy.byid/v1.0',
    createRole: '/private/ess.rol.crt/v1.0',
    cloneRole: '/protected/ess.rol.cln/v1.0',
    getRoles: '/protected/ess.rol.getbyprfid/v1.0',
    updateRole: '/protected/ess.rol.mdfy.byid/v1.0',
    createItem: '/private/ess.itm.crt/v1.0',
    cloneItem: '/protected/ess.itm.cln/v1.0',
    getItems: '/protected/ess.itm.get.byecoid/v1.0',
    updateItem: '/protected/ess.itm.mdfy.byid/v1.0',

    createBusinessDocs: '/protected/ess.createdata.businessdocs.create/v1.3',
    updateBusinessDocs: '/protected/ess.createdata.businessdocs.create/v1.3',
    getBusinessDocsByRoleId: '/private/ess.retrievedata.ecosystemnew.retrievebusinessdocsbyroleids/v1.3',
    getBusinessDocsByEcoId: '/private/ess.retrievedata.ecosystemnew.retrievebusinessdocsbyecosystemids/v1.3',
    maintenance: '/protected/ess.main.win/v1.0'
  },

  Account: {
    createAccount: '/protected/panm.addptyacct.create/v0.1',
    findAccount: '/private/panm.fndacct.find/v0.1',
  },

  Org: {
    createOrg: '/protected/panm.addpty.create/v0.1',
    findOrg: '/private/panm.fndorg.find/v0.1',
    updateOrg: '/protected/panm.updtorg.update/v0.1',
    findOrgProfile: '/private/panm.fndorgprfl.find/v0.1',
    addNetwork: '/protected/panm.addntwk.create/v0.1',
    updateNetwork: '/protected/panm.updtntwk.update/v0.1',
    findNetwork: '/private/panm.fndntwk.find/v0.1',
    findNotConnectedOrg: '/private/panm.fndnotcnctdorg.find/v0.1',
    findConnectedOrg: '/private/panm.fndcnctdorg.find/v0.1',
  },

  Territory: {
    getAllTerritories: '/private/tsm.retrievedata.territory.master.retrieveallterritories/v1.0',
    getTerritoriesNameByIds: '/private/tsm.trty.getnames.byids/v1.0',
    // createTerritory: '/protected/tsm.createdata.territory.create/v1.0',
    retrieveByTownIdListOrPincodeList: '/private/tsm.retrievedata.pincode.master.retrievebytownidlistorpincodelist/v1.0',
    getStateListByCountryId: '/private/tsm.retrievedata.state.master.retrievebycountryid/v1.0',
    getDistrictListByStateId: '/private/tsm.retrievedata.district.master.retrievebystateidlist/v1.0',
    getTownListByDistrictId: '/private/tsm.retrievedata.town.master.retrievebydistrictidlist/v1.0',
    getTerritoryForPartnerId: '/private/tsm.retrievedata.territory.retrievebypartner/v1.0',
    brandsForGivenTerritoryAndPartnerId: '/private/tsm.retrievedata.brands.retrievebyterritoryandpartner/v1.0',
    retrieveAllCountries: '/private/tsm.retrievedata.country.master.retrieveallcountries/v1.0',
    getTerritories: '/private/tsm.retrievedata.location.master.retrieve/v1.0',
    territoriesCount: '/private/tsm.retrievedata.territory.retrieveterritoriescount/v1.0',
    populateTerritoryMasterData: '/protected/tsm.savemasterdata.master.savemasterdataforpincodes/v1.0',
    unprocessedTerritoryMasterData: '/protected/tsm.createrawdata.territory.createrawpincodedata/v1.0',
    // retrieveTerritoriesByOrgIds: '/private/tsm.retrievedata.territory.retrieveterritoriesbyorgids/v1.0',
    retrieveByCountryCode: '/private/tsm.createdata.countrydetails.retrievebycountrycode/v1.0',
    retrieveTerritoriesCountByOrgIds: '/private/tsm.retrievedata.territory.retrieveterritoriescountbyorgids/v1.0',
    retrieveCurrencyAndTimezoneByCountryCode: '/private/tsm.retrievedata.countrydetails.by.cntry.code/v1.0',
    checkPincodeExists: '/private/tsm.createrawdata.territory.checkpincodeexists/v1.0',
    createMasterTerritory: '/protected/tsm.createdata.custom.master.create/v1.0',
    retrieveMasterTerritory: '/private/tsm.retrievedata.custom.master.retrieve/v1.0',
    updateMasterTerritory: '/private/tsm.retrievedata.custom.master.update/v1.0',
    createTerritory: '/protected/tsm.trty.crt/v1.0',
    createTerritories: '/protected/tsm.trtys.crt/v1.0',
    updateTerritory: '/private/tsm.trty.mdfy.byid/v1.0',
    retrieveTerritoriesByOrgId: '/private/tsm.trty.get.lst.nd.cnt/v1.0',
    getTerritoryById: '/private/tsm.trty.get.byid/v1.0',
    duplicateTerritoryNameCheck: '/private/tsm.trty.chk/v1.0',
    getNodeNamesByIds: '/private/tsm.retrievedata.territories.by.ids.retrieve/v1.0',
    deleteTerritories: '/protected/tsm.delete.territories/v1.0',
  },

  ProductCatalogue: {
    getProductsOfOrg: '/protected/pcm.findall.products.by.org/v1.3/findAll',
    addProductToCatalouge: '/protected/pcm.add.products/v1.3/add',
    updateProductToCatalouge: '/protected/pcm.update.products/v1.3/updateProduct',
    getProductByID: '/private/pcm.get.product/v1.3',
    uploadImage: '/protected/pcm.add.image/v1.3/addImage',
    getFile: '/private/pcm.get.file/v1.3/getFile',
    uploadDocument: '/protected/pcm.add.documents/v1.3/addDocument',
    duplicateNameCheck: '/private/pcm.duplicate.name.check/v1.3/duplicateNameCheck',
    duplicateProductCode: '/private/pcm.duplicate.productcode.check/v1.3/duplicateProductCodeCheck',
    excelUpload: '/protected/pcm.upload.product.by.org/v1.3/upload',
    selectedProductRetrieval: '/protected/pcm.find.product.by.ids/v1.3/findAllByproductIds',
  },

  ProductTemplate: {
    createProductTemplateService: '/protected/ess.createdata.products.create/v1.3',
    getProductTemplates: '/private/ess.retrievedata.products.getproducttemplate/v1.3',
    updateProduct: '/protected/ess.updatedata.product.updateproduct/v1.3',
    getProductTemplatesList: '/private/ess.retrievedata.products.getproducttemplates/v1.3'
  },

  Brands: {
    retrieveBrand: '/private/tsm.retrievedata.brand.retrieve/v1.3',
    createBrand: '/protected/tsm.createdata.brand.create/v1.3',
    retrieveBrandsList: '/private/tsm.retrievedata.brands.master.retrieveallbrands/v1.3',
    retrieveBrandsByOrgIds: '/private/tsm.retrievedata.brands.retrievebrandsbyorgids/v1.3',
    createBrandsDiscount: '/protected/tsm.createdata.branddiscounts.create/v1.3',
    retrieveBrandsByRetailerIdsAndBrandIds: '/private/tsm.retrievedata.branddiscounts.retrievebrandsbyretaileridsandbrandids/v1.3',
    retrieveBrandsCountByRetailerIdsAndBrandIds: '/private/tsm.retrievedata.branddiscounts.retrievebrandscountbyretaileridsandbrandids/v1.3',
    retrieveRetailersByBrandIds: '/private/tsm.retrievedata.branddiscounts.retrieveretailersbybrandids/v1.3',
    allBrandOrg: '/private/tsm.retrievedata.brandorg.retrieveall/v1.3',
    allBrands: '/private/tsm.retrievedata.brandname.retrieve/v1.3',
    createBrandOrg: '/protected/tsm.createdata.brandorg.create/v1.3',
    getBrandOrgImage: '/private/tsm.brandorgattachment.brandorg.findattachmentdata/v1.3',
    brandOrgImageUpload: '/protected/tsm.createdata.brandorg.addattachement/v1.3',
    getBrandOrgById: '/private/tsm.retrievedata.brandorg.retrieve/v1.3'
  },

  BusinessData: {
    createPartysetup: '/protected/panm.subpartyregister.party.create/v0.1',
    retievePartyData: '/private/panm.subpartylist.party.findprofiles/v0.1',
    uploadProduct: '/upload',
    retieveWholePartyData: '/private/panm.subpartylist.party.findsuborganisationprofile/v0.1',
    bulkInvite: '/protected/panm.partyinvitation.party.bulkinvite/v0.1',
    updateParty: '/protected/panm.subpartylist.party.updatesuborganisationprofile/v0.1',
    uploadExcelParty: '/protected/panm.subpartyregister.party.upload/v0.1',
    getProductList: '/findAll',
    findAllOrganizations: '/private/panm.partylist.party.findallorganizations/v0.1',
  },

  ProductCategory: {
    getCategory: '/private/pcm.find.category.categories/v1.3/getCategory/',
    getBricks: '/private/pcm.find.category.bricks/v1.3/getBricks/',
    getClasses: '/private/pcm.find.category.classes/v1.3/getClasses/',
    getFamilies: '/private/pcm.find.category.segments/v1.3/getSegments/',
    getSegments: '/getCategoryByLevel/0'
  },

  Partner: {
    partyProfileInformation: '/private/panm.partylist.party.findprofile/v0.1',
    registeringParty: '/private/panm.partyonboarding.partyregistration.create/v0.1',
    updatePartyProfile: '/protected/panm.partyregister.updateparty.updateadditionaldata/v0.1',
    sendInviteToParty: '/protected/panm.partyinvitation.party.invite/v0.1',
    sendReminderInviteToParty: '/protected/panm.partyinvitation.party.sendreminder/v0.1',
    findAllInvitationOfParty: '/private/panm.partyinvitation.party.findallinvitation/v0.1',
    findAllUsersAccordingToOrgId: '/private/panm.organizationuserlist.party.findall/v0.1',
    findProfileByName: '/private/panm.partylist.party.findprofilebyname/v0.1',
    notConnectedWithParty: '/private/panm.findpartynetwork.notconnected.withparty/v0.1',
    findAllPartners: '/private/panm.partynetwork.party.findallpartners/v0.1',
    findAllPartnersWithStatus: '/private/panm.partynetwork.party.findallpartnerswithstatus/v0.1',
    createNetwork: '/private/panm.partynetwork.party.createnetwork/v0.1',
    updateNetwork: '/protected/panm.partynetwork.party.updatenetwork/v0.1',
    findAllPartnersInMasterDB: '/private/panm.partynetwork.party.findallpartnersinmasterdb/v0.1',
    findUniqueCheckInPartner: '/private/panm.likesearch.partybyparameter.typeahead/v0.1',
    inviteAParty: '/protected/panm.partyinvitation.party.invite/v0.1',
    uploadFile: '/protected/panm.upldimganddocfrmfile.create/v0.1',
    downloadFile: '/private/panm.dnldimganddoc.find/v0.1',
    findAllOrganizations: '/private/panm.partylist.party.findallorganizations/v0.1'
  },

  UserSetup: {
    inviteUser: '/protected/panm.addusr.create/v0.1',
    getUser: '/protected/panm.fndusr.find/v0.1',
    getBeatList: '/bfs.get.operator.today.upcoming.beat/v0.1',
    updateUser: '/protected/panm.updtusr.update/v0.1'
  },

  Service: {
    addService: '/protected/cms.add.service/v0.1/addService',
    getService: '/private/cms.find.service.by.id/v0.1/getService',
    updateService: '/protected/cms.update.service/v0.1/updateService',
    checkDuplicateServiceByName: '/private/cms.duplicate.service.name.check/v0.1/checkDuplicateServiceByName',
    checkDuplicateServiceByCode: '/private/cms.duplicate.service.code.check/v0.1/checkDuplicateServiceByCode',
    getMasterListServices: '/private/cms.find.all.services/v0.1/getMasterListServices',
    getServicesByTerritoryId: '/private/cms.find.service.lines.by.territoryIds/v0.1/findServicesByTerritoryId',
    uploadImages: '/protected/cms.add.image/v0.1/addImage',
    uploadDocuments: '/protected/cms.add.documents/v0.1/addDocument',
    downloadFile: '/private/cms.get.file/v0.1/getFile'
  },

  Asset: {
    addAssetType: '/protected/cms.add.asset.type/v0.1/add',
    checkAssetTypeByCode: '/private/cms.duplicate.asset.type.code.check/v0.1/duplicateAssetTypeCodeCheck',
    checkAssetTypeByName: '/private/cms.duplicate.asset.type.name.check/v0.1/duplicateNameCheck',
    getMasterListAssetTypes: '/private/cms.find.all.asset.types/v0.1/findAll',
    getAssetType: '',
    updateAssetType: '',
    getGetCategoryByLevel: '/private/cms.find.category.by.level/v0.1/getCategoryByLevel',
    addCategory: '/protected/cms.add.category/v0.1/addCategory',
    getAllAsset: '/ias.get.all.asset/v0.1',
    saveAsset: '/ias.save.asset/v0.1/',
    getAssetById: '/ias.find.asset/v0.1/asset'
  }
}
