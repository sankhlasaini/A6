morgan = require('morgan');
path = require('path');
http = require('http');
https = require('https');
url = require('url');
bodyParser = require('body-parser');
NodeCache = require("node-cache");
myCache = new NodeCache();
cookieParser = require('cookie-parser');
request = require('request');
mkdirp = require('mkdirp');
fs = require('fs');
cluster = require('cluster');
numCPUs = require('os').cpus().length;
multer = require('multer');
yaml = require('js-yaml');



