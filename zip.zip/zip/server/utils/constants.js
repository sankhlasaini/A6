env = process.env.NODE_ENV || '-deltaverge-dev';
proxyFlag = process.env.proxyFlag || 'false';
proto = process.env.PROTO || 'http://';
configFile = './configuration/development.yml';


CLIENT_SECRET = 'TrustedClient@2017';
CLIENT_ID = 'Isam_Trusted_Client';
AES_KEY = 'secret key 123';

proxyAddress =  'http://10.201.51.101:8080';
geocodeKey = 'AIzaSyC7RNJwlz7i-o6ytGNhYoYsc-6s4wqmRtY';

//Check for the base domain in environment variable as INITIAL_URL else take value from yaml
initialURL = process.env.INITIAL_URL || '.apps.ocp.deltaverge.com';


fileNotFound: "Please check the file you are trying to download as the file with specified filename does not exist"
