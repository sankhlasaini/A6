module.exports = {
    setupMulter : function () {
        multer = require('multer');
        storage = multer.diskStorage({
            destination: function (req, file, cb) {
                var dest = './src/assets/';
                mkdirp.sync(dest);
                cb(null, dest)
            },
            filename: function (req, file, cb) {
                cb(null, Date.now() + path.extname(file.originalname));
            }
        })
        upload = multer({ storage: storage });

    }
}