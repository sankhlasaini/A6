var express = require('express');
// var expressSanitized = require('express-sanitize-escape');
var routes = express.Router();
// expressSanitized.sanitizeParams(routes, ['id','name']);

ecosystem = require('../api/EcosystemAPI/ecosystemController');
businessData = require('../api/BusinessData/businessData');
brands = require('../api/BrandsAPI/brands');
productCatalogue = require('../api/ProductCatalogueAPI/productCatalogue');
user = require('../api/UserAuthenticationAPI/user');
territory = require('../api/territoryAPI/territory');
partner = require('../api/partnerInvitation');
territoryMaster = require('../api/masterLocation/territoryMaster');
userSetup = require('../api/UserSetupAPI/userSetup');
service = require('../api/ServiceAPI/service');
asset = require('../api/AssetAPI/asset');
account = require('../api/AccountAPI/account');
org = require('../api/OrgAPI/org');

//ecosystem routes
app.use('/ecosystem', ecosystem);

//account routes
app.use('/account', account);

//Org routes
app.use('/org', org);

//product catalogue routes
app.use('/productCatalogue', productCatalogue);

//User Routes
app.use('/user', user);

//userSetup Routes
app.use('/userSetup', userSetup);
//Service Routes
app.use('/service', service);

//Asset Routes
app.use('/asset', asset);

//territory routes
app.use('/territory', territory);

//brands routes
app.use('/brands', brands);

// territory Master data routes
app.use('/territoryMaster', territoryMaster);

// businessData routes
app.use('/businessData', businessData);

module.exports = routes;
