var express = require('express');
var partner = express.Router();

// api for Inviting a  Party
partner.post('/inviteAParty', function (req, res) {

  var requestBody = JSON.stringify(req.body);
  req.body = sanitizeRequest(req.body);
  var options = {
    url: endpoints.Host.partner + endpoints.Paths.Partner.inviteAParty,
    method: 'POST',
    'headers': setHeaders(req.headers),
    body: requestBody
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options- inviteAParty:', options);
  request(options, function (error, response, body) {
    console.log('BODY ::: ', body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'error': error,
      });
    }
  });

});

module.exports = partner;
