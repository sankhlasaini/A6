var express = require('express');
var Service = express.Router();
var postHead = JSON.parse(JSON.stringify(postHeaders));
var cmfHost = 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com';

Service.post('/addService', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Service.addService,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addService : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Service.post('/updateService', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Service.updateService,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addService : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Service.post('/getService', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Service.getService,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addCategory : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});


Service.post('/checkDuplicateServiceByName', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Service.checkDuplicateServiceByName,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addCategory : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Service.post('/checkDuplicateServiceByCode', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Service.checkDuplicateServiceByCode,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addCategory : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});


Service.post('/getMasterListServices', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Service.getMasterListServices,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addCategory : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Service.post('/getMasterListServices', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Service.getMasterListServices,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addCategory : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Service.post('/getServicesByTerritoryId', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Service.getServicesByTerritoryId,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addCategory : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});


Service.post('/uploadImages', upload.array('file'), function (req, res) {
  console.log('inside body', req.body);
  console.log('inside headers', req.headers);
  console.log('files :', req.files);

  var formData = {
    images: []
  };

  for (var i = 0; i < req.files.length; i++) {
    fs.renameSync('./src/assets/' + req.files[i].filename, './src/assets/' + req.files[i].originalname, function (err) {
      if (err) {
        console.log("error is", err);
      }
    });
    formData.images.push(fs.createReadStream('./src/assets/' + req.files[i].originalname));
  }

  console.log('==========FORM DATA===========');
  console.log(formData);

  // fs.createReadStream('./src/assets/' + req.file.originalname)
  req.body = sanitizeRequest(req.body);
  var options = {
    'url' : endpoints.Host.catalog + endpoints.Paths.Service.uploadImages,
    'method' : 'POST',
    'formData': formData,
    'headers' : {
      'Content-Type': 'application/json',
      'tenantToken': req.body.tenantToken,
      'Authorization': req.body.Authorization
    }
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options for uploadImage: ', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      console.log(body);
      res.send(body);
    } else if (error) {
      console.log('\n\n\n ERROR :: ', error);
      res.send(error);
    } else {
      var error = JSON.parse(body);
      res.send({
        'messageCode': error.status,
        "message": error.message
      });
    }

    for (var i = 0; i < req.files.length; i++) {
      if (req.files[i].originalname != undefined || req.files[i].filename != undefined) {
        fs.unlink('./src/assets/' + req.files[i].originalname, function (err) {
          if (err) {
            if (err.code == 'ENOENT') {
              console.log('originalName', 'fileNotFound');
            }
          }
        });
        fs.unlink('./src/assets/' + req.files[i].filename, function (err) {
          if (err) {
            if (err.code == 'ENOENT') {
              console.log('filename', 'fileNotFound');
            }
          }
        });
      }
    }
  });
});


Service.post('/uploadDocuments', upload.array('file'), function (req, res) {
  console.log('inside body', req.body);
  console.log('inside headers', req.headers);
  console.log('files :', req.files);

  var formData = {
    documents: []
  };

  for (var i = 0; i < req.files.length; i++) {
    fs.renameSync('./src/assets/' + req.files[i].filename, './src/assets/' + req.files[i].originalname, function (err) {
      if (err) {
        console.log("error is", err);
      }
    });
    formData.documents.push(fs.createReadStream('./src/assets/' + req.files[i].originalname));
  }

  console.log('==========FORM DATA===========');
  console.log(formData);

  // fs.createReadStream('./src/assets/' + req.file.originalname)
  req.body = sanitizeRequest(req.body);
  var options = {
    'url' : endpoints.Host.catalog + endpoints.Paths.Service.uploadDocuments,
    'method' : 'POST',
    'formData': formData,
    'headers' : {
      'Content-Type': 'application/json',
      'tenantToken': req.body.tenantToken,
      'Authorization': req.body.Authorization
    }
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options for uploadImage: ', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      console.log(body);
      res.send(body);
    } else if (error) {
      console.log('\n\n\n ERROR :: ', error);
      res.send(error);
    } else {
      var error = JSON.parse(body);
      res.send({
        'messageCode': error.status,
        "message": error.message
      });
    }

    for (var i = 0; i < req.files.length; i++) {
      if (req.files[i].originalname != undefined || req.files[i].filename != undefined) {
        fs.unlink('./src/assets/' + req.files[i].originalname, function (err) {
          if (err) {
            if (err.code == 'ENOENT') {
              console.log('originalName', 'fileNotFound');
            }
          }
        });
        fs.unlink('./src/assets/' + req.files[i].filename, function (err) {
          if (err) {
            if (err.code == 'ENOENT') {
              console.log('filename', 'fileNotFound');
            }
          }
        });
      }
    }
  });
});

// Service.get('/downloadFile', function (req, res) {
//   console.log('\n\n\n', req.query);
//   req.body = sanitizeRequest(req.body);  var options = {
//     'url': endpoints.Host.catalog + endpoints.Paths.Service.downloadFile,
//     'method': 'POST',
//     'body': JSON.stringify({
//       "dmsReferenceId": req.query.gridFSid,
//       "orgId": ""
//     }),
//     'headers': {
//       'Content-Type': 'application/json',
//       'Authorization': req.query.authorization,
//       'tenantToken': req.query.tenantToken
//     }
//   };

//   console.log('in downloadFile : ', options);
//   if (proxyFlag === 'false') {
//     options.proxy = proxyAddress;
//   }
//   res.setHeader("content-disposition", "attachment; filename=file.png");
//   request(options).pipe(res);
// });


Service.post('/downloadFile', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Service.downloadFile,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in downloadFile : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});





module.exports = Service;
