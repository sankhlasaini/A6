var express = require('express');
var territory = express.Router();

//api for territorymaster data
territory.post('/createMasterTerritory', (req, res) => {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.createMasterTerritory,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body)
  }
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options in create Master territory', options)
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});

//  api for retrieve masterterritoryData
territory.post('/retrieveMasterTerritory', (req, res) => {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.retrieveMasterTerritory,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body)
  }
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options in retrieve Master territory', options)
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});

//  api for Delete Territories
territory.post('/deleteTerritories', (req, res) => {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.deleteTerritories,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body)
  }
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options in retrieve Master territory', options)
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});

//  api for update masterterritoryData
territory.post('/updateMasterTerritory', (req, res) => {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.updateMasterTerritory,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body)
  }
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options in update Master territory', options)
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});


territory.post('/createTerritory', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.createTerritory,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body)
  }
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options in create territory', options)
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});

territory.post('/createTerritories', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.createTerritories,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body)
  }
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options in create territory', options)
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});

territory.post('/getTerritoriesNameByIds', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.getTerritoriesNameByIds,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body)
  }
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options in getTerritoriesNameByIds', options)
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});

territory.post('/updateTerritory', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.updateTerritory,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body)
  }
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options in update territory', options)
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});

//  api for getting brands by organisation id's
territory.post('/retrieveTerritoriesByOrgId', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.retrieveTerritoriesByOrgId,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body),

  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of retrieveTerritoriesByOrgId ', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

territory.post('/getTerritoryById', function (req, res) {
  console.log('body in 123 ', req.body);
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.getTerritoryById,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body),

  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of getTerritoryById ', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

territory.post('/duplicateTerritoryNameCheck', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.duplicateTerritoryNameCheck,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body),
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of duplicateTerritoryNameCheck ', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// api for getting all countries
territory.post('/retrieveAllCountries', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.retrieveAllCountries,
    'headers': setHeaders(req.headers),
    'method': 'GET'
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  var responseFromService = "";
  console.log('options for retrieveAllCountries: ', options)
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// api for getting all territories
territory.post('/getAllTerritories', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.getAllTerritories,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of getAllTerritories ', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// api for getting count of territories
territory.post('/territoriesCount', function (req, res) {
  console.log('inside territoriesCount');
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.territoriesCount,
    'method': 'GET',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of territoriesCount ', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// api for getting getStateListByCountryId
territory.post('/getStateListByCountryId', function (req, res) {

  console.log('inside getStateListByCountryId');
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.getStateListByCountryId,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body),

  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of getStateListByCountryId ', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

//  api for getting districts by stateId
territory.post('/getDistrictListByStateId', function (req, res) {

  console.log('inside getDistrictListByStateId');
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.getDistrictListByStateId,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body),

  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of getDistrictListByStateId ', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

//  api for getting town by districtId
territory.post('/getTownListByDistrictId', function (req, res) {
  // console.log('inside getTownListByDistrictId');
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.getTownListByDistrictId,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body),

  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of getTownListByDistrictId ', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

//  api for getting pincodes by townId
territory.post('/retrieveByTownIdListOrPincodeList', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.retrieveByTownIdListOrPincodeList,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body),

  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of retrieveByTownIdListOrPincodeList ', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

//  api for getting currency and timezone by country code
territory.post('/retrieveByCountryCode', function (req, res) {

  console.log('inside getTownListByDistrictId');
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.retrieveByCountryCode,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body),

  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of retrieveByCountryCode ', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

//  api for getting Territory Count by partnerId's
territory.post('/retrieveTerritoriesCountByOrgIds', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.retrieveTerritoriesCountByOrgIds,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body),

  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of retrieveTerritoriesCountByOrgIds  ', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

//  api for getting Currency and timezone based on country code.
territory.post('/retrieveCurrencyAndTimezoneByCountryCode', function (req, res) {
  console.log('inside retrieveCurrencyAndTimezoneByCountryCode', req.body);
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.retrieveCurrencyAndTimezoneByCountryCode,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body),

  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of retrieveCurrencyAndTimezoneByCountryCode', options);

  request(options, function (error, response, body) {
    console.log(' retrieveCurrencyAndTimezoneByCountryCode : BODY :', body)
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

//  api for getting Currency and timezone based on country code.
territory.post('/getNodeNamesByIds', function (req, res) {
  console.log('inside getNodeNamesByIds', req.headers);
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.getNodeNamesByIds,
    'method': 'POST',
    'body': JSON.stringify(req.body),
    'headers': setHeaders(req.headers),
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of getNodeNamesByIds', options);

  request(options, function (error, response, body) {
    console.log(' getNodeNamesByIds : BODY :', body)
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

//  api for confirming pincode exists or not.
territory.post('/checkPincodeExists', function (req, res) {

  console.log('inside checkPincodeExists', req.body);
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Territory.checkPincodeExists,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body), // { "pincode":563114 }


  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of checkPincodeExists', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

module.exports = territory;
