var express = require('express');
var ProductCatalogue = express.Router();

var fileNotFound = "Please check the file you are trying to download as the file with specified filename does not exist";

ProductCatalogue.post('/getProductCatalogueOfOrg', function (req, res) {

  var productCount = 0;
  var finalProductList = [];
  var selectedBrand;
  var totalProductCount;

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.productCatalogue + endpoints.Paths.BusinessData.getProductList,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/product/findAll',
    'body': JSON.stringify({
      "enablePagination": true,
      "orgId": "string",
      "pageSize": req.body.indexData.pageSize,
      "pageStartIndex": req.body.indexData.pageStartIdx
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }

  // console.log('get Product List', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      // console.log('-----------------------------------', JSON.parse(body));
      totalProductCount = JSON.parse(body).totalProductsCount;
      JSON.parse(body).product.forEach((product) => {
        if (product.referenceIds.brandCode != null && product.referenceIds.categoryCode != null &&
          product.referenceIds.brandCode != '' && product.referenceIds.categoryCode != '' &&
          product.referenceIds.brandCode != 'string' && product.referenceIds.categoryCode != 'string') {
          productCount++;
          var brandOptions = {
            // 'url': endpoints.Host.territory + endpoints.Paths.Brands.retrieveBrand,
            'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/brandOrg/getBrandOrgByCode',
            'body': JSON.stringify({
              "code": product.referenceIds.brandCode
            }),
            'method': 'POST',
            'headers': setHeaders(req.headers)
          };

          // console.log('brandOptions', brandOptions);

          if (proxyFlag === 'false') {
            brandOptions.proxy = proxyAddress;
          }
          request(brandOptions, function (error, response, body) {
            console.log('RESPONSE BODY : ', body);
            console.log('RESPONSE ERROR : ', error);
            if (!error && response.statusCode == 200) {
              var brandOrgObject = JSON.parse(body);
              brandOrgObject.brandOrg.brands.forEach((brand) => {
                if (brand.code === product.referenceIds.brandCode) {
                  selectedBrand = brand;
                }
              });
              product['brandOrgName'] = brandOrgObject.brandOrg.name;
              product['brandName'] = selectedBrand.name;

              var categoryOptions = {
                // 'url': endpoints.Host.territory + endpoints.Paths.Brands.retrieveBrand,
                'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/productCategory/getCategoryTree',
                'body': JSON.stringify({
                  "suppliedCode": product.referenceIds.categoryCode
                }),
                'method': 'POST',
                'headers': setHeaders(req.headers)
              };

              // console.log('categoryOptions', categoryOptions);

              if (proxyFlag === 'false') {
                categoryOptions.proxy = proxyAddress;
              }

              request(categoryOptions, function (error, response, body) {
                console.log('RESPONSE BODY : ', body);
                console.log('RESPONSE ERROR : ', error);
                if (!error && response.statusCode == 200) {
                  var categoryTree = JSON.parse(body);
                  categoryTree.categories.forEach((category) => {
                    if (category.level === 3) {
                      product['productType'] = category.displayName;
                    }
                  });
                  finalProductList.push(product);
                  if (finalProductList.length == productCount) {
                    finalProductList = finalProductList.sort((a, b) => (a.lastModified < b.lastModified) ? 1 : ((b.lastModified < a.lastModified) ? -1 : 0));
                    var finalProduct = {
                      "messageCode": null,
                      "totalProductsCount": {
                        "count": totalProductCount
                      },
                      "product": finalProductList
                    };
                    res.send(finalProduct);
                  }
                } else {
                  res.send({
                    'messageCode': '400',
                    'errorIn': 'categoryService',
                    "message": JSON.parse(body).message
                  });
                }
              });
            } else {
              res.send({
                'messageCode': '400',
                'errorIn': 'brandService',
                "message": JSON.parse(body).message
              });
            }
          });
        }
      });
    } else {
      res.send({
        'messageCode': '400',
        'errorIn': 'productService',
        "message": JSON.parse(body).message
      });
    }
  });
});


ProductCatalogue.post('/getProductByID', function (req, res) {


  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.productCatalogue + endpoints.Paths.ProductCatalogue.getProductByID + '/' + bodyParam.productId,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/product/getProduct',
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify({
      "productId": req.body.productId
    })
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('getProductByID', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      var responsejson = "";
      res.send(body);
    } else if (error) {
      res.send(error);
    } else {
      var error = JSON.parse(body)
      res.send({
        'messageCode': error.status,
        "message": error.message
      });
    }
  });
});

ProductCatalogue.get('/downloadFile', function (req, res) {
  postHead.Authorization = req.query.accessToken;
  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.productCatalogue + endpoints.Paths.ProductCatalogue.getFile + '/' + req.query.fileId,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/product/getFile',
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify({
      "dmsReferenceId": req.query.fileId,
      "orgId": "string"
    })
  };
  console.log('download file ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  res.setHeader("content-disposition", "attachment; filename=file.png");
  request(options).pipe(res);
});


ProductCatalogue.post('/addProductToCatalouge', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.productCatalogue + endpoints.Paths.ProductCatalogue.addProductToCatalouge,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/product/add',
    'body': JSON.stringify(req.body.newProduct),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('addProduct options', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      console.log(body);
      res.send(body);
    } else if (error) {
      res.send(error);
    } else {
      console.log(body);
      var error = JSON.parse(body)
      res.send({
        'messageCode': error.status,
        "message": error.message
      });
    }
  });
});


ProductCatalogue.post('/updateProductToCatalouge', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.productCatalogue + endpoints.Paths.ProductCatalogue.updateProductToCatalouge,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/product/updateProduct',
    'body': JSON.stringify(req.body.updatedProduct),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('updateProductToCatalouge', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      console.log(body);
      res.send(body);
    } else if (error) {
      res.send(error);
    } else {
      var error = JSON.parse(body)
      res.send({
        'messageCode': error.status,
        "message": error.message
      });
    }
  });
});


// Upload Image
ProductCatalogue.post('/uploadImage', upload.array('images'), function (req, res) {
  postHead.Authorization = req.headers.authorization;
  postHead.tenantToken = req.headers.tenanttoken;
  console.log('images :', req.files);

  var formData = {
    images: []
  };

  for (var i = 0; i < req.files.length; i++) {
    fs.renameSync('./src/assets/' + req.files[i].filename, './src/assets/' + req.files[i].originalname, function (err) {
      if (err) {
        console.log("error is", err);
      }
    });

    formData.images.push(fs.createReadStream('./src/assets/' + req.files[i].originalname));
  }

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url' : endpoints.Host.productCatalogue + endpoints.Paths.ProductCatalogue.uploadImage,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/product/addImage',
    'method' : 'POST',
    'formData': formData,
    'headers' : postHead
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      console.log(body);
      res.send(body);
    } else if (error) {
      res.send(error);
    } else {
      var error = JSON.parse(body);
      res.send({
        'messageCode': error.status,
        "message": error.message
      });
    }
  });

  for (var i = 0; i < req.files.length; i++) {
    if (req.files[i].originalname != undefined || req.files[i].filename != undefined) {
      fs.unlink('./src/assets/' + req.files[i].originalname, function (err) {
        if (err) {
          if (err.code == 'ENOENT') {
            console.log(fileNotFound);
          }
        }
      });
      fs.unlink('./src/assets/' + req.files[i].filename, function (err) {
        if (err) {
          if (err.code == 'ENOENT') {
            console.log(fileNotFound);
          }
        }
      });
    }
  }
});

// Upload Document
ProductCatalogue.post('/uploadDocument', upload.array('files'), function (req, res) {
  postHead.Authorization = req.headers.authorization;
  postHead.tenantToken = req.headers.tenanttoken;
  console.log('documents :', req.files);

  var formData = {
    documents: []
  };

  for (var i = 0; i < req.files.length; i++) {
    fs.renameSync('./src/assets/' + req.files[i].filename, './src/assets/' + req.files[i].originalname, function (err) {
      if (err) {
        console.log("error is", err);
      }
    });

    formData.documents.push(fs.createReadStream('./src/assets/' + req.files[i].originalname));
  }

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url' : endpoints.Host.productCatalogue + endpoints.Paths.ProductCatalogue.uploadDocument,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/product/addDocument',
    'method' : 'POST',
    'formData': formData,
    'headers' : postHead
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      console.log(body);
      res.send(body);
    } else if (error) {
      res.send(error);
    } else {
      var error = JSON.parse(body);
      res.send({
        'messageCode': error.status,
        "message": error.message
      });
    }
  });

  for (var i = 0; i < req.files.length; i++) {
    if (req.files[i].originalname != undefined || req.files[i].filename != undefined) {
      fs.unlink('./src/assets/' + req.files[i].originalname, function (err) {
        if (err) {
          if (err.code == 'ENOENT') {
            console.log(fileNotFound);
          }
        }
      });
      fs.unlink('./src/assets/' + req.files[i].filename, function (err) {
        if (err) {
          if (err.code == 'ENOENT') {
            console.log(fileNotFound);
          }
        }
      });
    }
  }
});



// Duplicate Product Name Check
ProductCatalogue.post('/duplicateProductNameCheck', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.productCatalogue + endpoints.Paths.ProductCatalogue.duplicateNameCheck,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/product/duplicateNameCheck',
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify({
      "ecosystemId": "string",
      "orgId": "string",
      "productName": req.body.productName
    })
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of duplicateNameCheck', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Duplicate Product Code Check
ProductCatalogue.post('/duplicateProductCodeCheck', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.productCatalogue + endpoints.Paths.ProductCatalogue.duplicateNameCheck,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/product/duplicateProductCodeCheck',
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify({
      "orgId": "string",
      "productCode": req.body.productCode
    })
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of duplicateNameCheck', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

//  api for duplicate product code.
ProductCatalogue.post('/duplicateProductCodeCheck', function (req, res) {
  console.log('inside duplicateProductCode', req.body);
  // console.log('postHead.tenantToken', postHead.tenantToken)
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.productCatalogue + endpoints.Paths.ProductCatalogue.duplicateProductCode,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body.paramBody)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options of duplicateProductCode', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});


//api to upload excel
ProductCatalogue.post('/excelUpload', upload.single('file'), function (req, res) {
  console.log('bodyParam', req.file.originalname);
  console.log('bodyParam', req.body.companyId);
  fs.renameSync('./src/assets/' + req.file.filename, './src/assets/' + req.file.originalname, function (err) {
    if (err) {
      console.log("error is", err);
    }
  });
  var formData = {
    file: fs.createReadStream('./src/assets/' + req.file.originalname)
  };

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.productCatalogue + endpoints.Paths.ProductCatalogue.excelUpload + '/' + req.body.companyId + '?userId=' + req.body.userId,
    'formData': formData,
    'method': 'POST',
    'headers': {
      'Content-Type': 'multipart/form-data',
      'tenantToken': postHead.tenantToken,
    }
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('excelUpload', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      var responsejson = "";
      res.send(body);
    } else if (error) {
      res.send(error);
    } else {
      var error = JSON.parse(body)
      res.send({
        'messageCode': error.status,
        "message": error.message
      });
    }
  });

  fs.unlink('./src/assets/' + req.file.originalname, function (err) {
    if (err) {
      if (err.code == 'ENOENT') {
        console.log(fileNotFound);
      }
    }
  });
});

module.exports = ProductCatalogue;
