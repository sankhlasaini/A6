var express = require('express');
var BusinessData = express.Router();

BusinessData.post('/create', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.businessData + endpoints.Paths.BusinessData.createPartysetup,
    'body': JSON.stringify(req.body.paramBody),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('create option in businessData.js', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Get Party List by ParentOrgID
BusinessData.post('/findAllParty', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.businessData + endpoints.Paths.BusinessData.retieveWholePartyData,
    'body': JSON.stringify(req.body.paramBody),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('findAllParty option in businessData.js', options);
  request(options, function (error, response, body) {
    console.log('find all party : ', body)
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Retrive PartyData for Multiple UUID of Party as Array of UUID
BusinessData.post('/retievePartyData', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.businessData + endpoints.Paths.BusinessData.retievePartyData,
    'body': JSON.stringify(req.body.paramBody),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('create option in businessData.js', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});


BusinessData.post('/updateParty', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.businessData + endpoints.Paths.BusinessData.updateParty,
    'body': JSON.stringify(req.body.paramBody),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('create option in businessData.js', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// bulInvite
BusinessData.post('/bulkInvite', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.businessData + endpoints.Paths.BusinessData.bulkInvite,
    'body': JSON.stringify(req.body.paramBody),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('create option in businessData.js=> bulkInvite', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// add potential Partner
BusinessData.post('/findAllOrganizations', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.businessData + endpoints.Paths.BusinessData.findAllOrganizations,
    'body': JSON.stringify(req.body.paramBody),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('create option in businessData.js=> findAllOrganizations', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});



BusinessData.post('/uploadExcelParty', upload.single('file'), function (req, res) {
  fs.renameSync('./src/assets/' + req.file.filename, './src/assets/' + req.file.originalname, function (err) {
    if (err) {
      console.log("error is", err);
    }
  });
  var formData = {
    file: fs.createReadStream('./src/assets/' + req.file.originalname)
  };
  postHead.Authorization = req.headers.authorization;
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.businessData + endpoints.Paths.BusinessData.uploadExcelParty + "?user=" + req.body.userId,
    'formData': formData,
    'method': 'POST',
    'headers': {
      'tenantToken': req.headers.tenanttoken
    }
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('uploadExcelParty option in businessData.js', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
    fs.unlink('./src/assets/' + req.file.originalname, function (err) {
      if (err) {
        if (err.code == 'ENOENT') {
          console.log(fileNotFound);
        }
      }
    });
  });
});


// get Segments

BusinessData.post('/getSegments', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.ProductCategory + endpoints.Paths.ProductCategory.getSegments,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/productCategory/getCategoryByLevel',
    'body': JSON.stringify({
      "level": 0
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('getsegments option in businessData.js', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// get families

BusinessData.post('/getFamilies', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.ProductCategory + endpoints.Paths.ProductCategory.getFamilies + req.body.segmentCode,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/productCategory/getCategoryByParentId/',
    'body': JSON.stringify({
      "parentId": req.body.segmentCode
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Get Classes
BusinessData.post('/getClasses', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.ProductCategory + endpoints.Paths.ProductCategory.getClasses + req.body.familyCode,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/productCategory/getCategoryByParentId/',
    'body': JSON.stringify({
      "parentId": req.body.familyCode
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Get Bricks

BusinessData.post('/getBricks', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.ProductCategory + endpoints.Paths.ProductCategory.getBricks + req.body.classCode,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/productCategory/getCategoryByParentId/',
    'body': JSON.stringify({
      "parentId": req.body.classCode
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('brickOptions', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      console.log(body);
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}.error_description
      });
    }
  });
});

// Get Category

BusinessData.post('/getCategory', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.ProductCategory + endpoints.Paths.ProductCategory.getCategory + req.body.brickCode,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/productCategory/getCategoryTree',
    'body': JSON.stringify({
      "suppliedCode": req.body.brickCode
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Excel Upload for Product Master List
BusinessData.post('/uploadExcelProduct', upload.single('file'), function (req, res) {
  postHead.Authorization = req.headers.authorization;
  console.log(req);
  fs.renameSync('./src/assets/' + req.file.filename, './src/assets/' + req.file.originalname, function (err) {
    if (err) {
      console.log("error is", err);
    }
  });
  var formData = {
    file: fs.createReadStream('./src/assets/' + req.file.originalname)
  };
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.businessData + endpoints.Paths.BusinessData.uploadProduct,
    'formData': formData,
    'method': 'POST',
    'headers': {
      'tenantToken': req.headers.tenanttoken
    }
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('create option in businessData.js', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
    fs.unlink('./src/assets/' + req.file.originalname, function (err) {
      if (err) {
        if (err.code == 'ENOENT') {
          console.log(fileNotFound);
        }
      }
    });
  });
});

BusinessData.post('/selectedProductRetrieval', function (req, res) {
  console.log('body in selectedProductRetrieval', req.body)

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.productCatalogue + endpoints.Paths.ProductCatalogue.selectedProductRetrieval +
      '?pageStartIdx=' + req.body.paramBody.pageStartIdx + '&pageSize=' + req.body.paramBody.pageSize,
    'body': JSON.stringify(req.body.paramBody.productIds),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('selectedProductRetrieval option in businessData.js', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      console.log('\n\n\n\n\n :::::::::::::', body);
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Get Product List
BusinessData.post('/getProductListByPageIndex', function (req, res) {

  var productCount = 0;
  var finalProductList = [];
  var selectedBrand;
  var totalProductCount;

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.productCatalogue + endpoints.Paths.BusinessData.getProductList,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/product/findAll',
    'body': JSON.stringify({
      "enablePagination": true,
      "orgId": "string",
      "pageSize": req.body.pageIndex.endIndex,
      "pageStartIndex": req.body.pageIndex.startIndex
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }

  console.log('get Product List', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      console.log('-----------------------------------', JSON.parse(body));
      totalProductCount = JSON.parse(body).totalProductsCount;
      JSON.parse(body).product.forEach((product) => {
        if (product.referenceIds.brandCode != null && product.referenceIds.categoryCode != null &&
          product.referenceIds.brandCode != '' && product.referenceIds.categoryCode != '' &&
          product.referenceIds.brandCode != 'string' && product.referenceIds.categoryCode != 'string') {
          productCount++;
          var productObject = {};
          productObject['Image'] = product.images[0].id;
          productObject['Product Name'] = product.displayName;
          var brandOptions = {
            // 'url': endpoints.Host.territory + endpoints.Paths.Brands.retrieveBrand,
            'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/brandOrg/getBrandOrgByCode',
            'body': JSON.stringify({
              "code": product.referenceIds.brandCode
            }),
            'method': 'POST',
            'headers': setHeaders(req.headers)
          };

          console.log('brandOptions', brandOptions);

          if (proxyFlag === 'false') {
            brandOptions.proxy = proxyAddress;
          }
          request(brandOptions, function (error, response, body) {
            console.log('RESPONSE BODY : ', body);
            console.log('RESPONSE ERROR : ', error);
            if (!error && response.statusCode == 200) {
              var brandOrgObject = JSON.parse(body);
              brandOrgObject.brandOrg.brands.forEach((brand) => {
                if (brand.code === product.referenceIds.brandCode) {
                  selectedBrand = brand;
                }
              });
              productObject['Brand Org Name'] = brandOrgObject.brandOrg.name;
              productObject['Brand Name'] = selectedBrand.name;

              var categoryOptions = {
                // 'url': endpoints.Host.territory + endpoints.Paths.Brands.retrieveBrand,
                'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/productCategory/getCategoryTree',
                'body': JSON.stringify({
                  "suppliedCode": product.referenceIds.categoryCode
                }),
                'method': 'POST',
                'headers': setHeaders(req.headers)
              };

              console.log('categoryOptions', categoryOptions);

              if (proxyFlag === 'false') {
                categoryOptions.proxy = proxyAddress;
              }

              request(categoryOptions, function (error, response, body) {
                console.log('RESPONSE BODY : ', body);
                console.log('RESPONSE ERROR : ', error);
                if (!error && response.statusCode == 200) {
                  var categoryTree = JSON.parse(body);
                  categoryTree.categories.forEach((category) => {
                    if (category.level === 3) {
                      productObject['Product Type'] = category.displayName;
                      productObject['Product Id'] = product.id;
                      productObject['lastModified'] = product.lastModified;
                    }
                  });
                  finalProductList.push(productObject);
                  if (finalProductList.length == productCount) {
                    finalProductList = finalProductList.sort((a, b) => (a.lastModified < b.lastModified) ? 1 : ((b.lastModified < a.lastModified) ? -1 : 0));
                    var finalProduct = {
                      "messageCode": null,
                      "totalProductsCount": {
                        "count": totalProductCount
                      },
                      "product": finalProductList
                    };
                    res.send(finalProduct);
                  }
                } else {
                  res.send({
                    'messageCode': '400',
                    'errorIn': 'categoryService',
                    "message": JSON.parse(body).message
                  });
                }
              });
            } else {
              res.send({
                'messageCode': '400',
                'errorIn': 'brandService',
                "message": JSON.parse(body).message
              });
            }
          });
        }
      });
    } else {
      res.send({
        'messageCode': '400',
        'errorIn': 'productService',
        "message": JSON.parse(body).message
      });
    }
  });
});

module.exports = BusinessData;
