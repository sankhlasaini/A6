var express = require('express');
var territoryMaster = express.Router();
var postHeaders = {
  'Content-Type': 'application/json',
  'tenantToken': 'system'
};

var request = require('request');

// creating client object
var GoogleMapsAPI = require('googlemaps');


var publicConfig = {
  key: geocodeKey,
  // proxy: proxyAddress, // optional, set a proxy for HTTP requests
};
if (proxyFlag === 'false') {
  publicConfig.proxy = proxyAddress;
}
// console.log('publicConfig', publicConfig);
var googleMaps = new GoogleMapsAPI(publicConfig);

territoryMaster.post('/populateTerritoryData', function (req, res) {
  console.log('territory master data called');
  // console.log('req.body', req.body.pincode);
  var pinInput = req.body.pincode;
  rejectedPincodes = [],
    zeroResultsPincode = [],
    pincodeNotProcessedCompletely = [],
    pinArr = [],
    itr = 0,
    locationData = {}, // holds data recieved against a particular pincode
    tempData = {}, // for holding temporary data to be pushed in final array
    finalArray = [],
    tempDataProUnpro = {}, // which will contain final objects to be saved
    processUnprocess = [];


  // console.log('pinInput: ', pinInput);

  // input should be valid pincodes seperated by comma, validating input.
  if (pinInput) {
    pinArr = pinInput.split(',');
    console.log('pinArr before', pinArr.length);
    pinArr = uniq(pinArr);
    console.log('pinArr after: ', pinArr.length, "itr:", itr);
    fetchCompleteData(pinArr[itr]);
  }

  function uniq(pinArr) {
    return Array.from(new Set(pinArr));
  }

  // basic retrieval of complete data with pincode as the only input.
  function fetchCompleteData(pincode) {
    console.log('pincode as input for complete data: ', pincode, 'itr value: ', itr);
    var geocodeParams = {
      "address": pincode,
      "components": "country:IN",
    };
    googleMaps.geocode(geocodeParams, function (err, response) {
      console.log(response);
      console.log('response: ', response.status);
      if (!err && response.status === "OK") {
        for (var a = 0; a < response.results[0].address_components.length; a++) {
          var component = response.results[0].address_components[a];

          switch (component.types[0]) {
            case 'country':
              locationData.country = component.long_name;
              locationData.registered_country_iso_code = component.short_name;
              break;

            case 'administrative_area_level_1':
              locationData.state = component.long_name;
              break;

            case 'administrative_area_level_2':
              locationData.district = component.long_name;
              break;

            case 'locality':
              locationData.town = component.long_name;
              break;

            case 'postal_code':
              locationData.postal_code = component.long_name;
              break;
          }
        }
        if (locationData.country && locationData.state && locationData.district && locationData.town) {
          console.log('locationData at begining:', JSON.stringify(locationData));
          tempDataProUnpro = {};
          tempDataProUnpro.pincode = locationData.postal_code;
          tempDataProUnpro.processed = true;
          tempDataProUnpro.rawData = response;
          processUnprocess.push(tempDataProUnpro);
          // console.log('processUnprocess', processUnprocess);
          getAndUpdateCountry();
        } else {
          // pincodes for which data upto LOCALITY is recieved are processed
          // rest of them will be rejected
          tempDataProUnpro = {};
          tempDataProUnpro.pincode = locationData.postal_code;
          tempDataProUnpro.processed = false;
          tempDataProUnpro.rawData = response;
          processUnprocess.push(tempDataProUnpro);
          // console.log('processUnprocess', processUnprocess);
          console.log('pincode rejected due to Rules applied', locationData.postal_code);
          rejectedPincodes.push({
            pincode: response
          });
          processNextPincode();
        }
      } else if (!err && response.status === "ZERO_RESULTS") {
        zeroResultsPincode.push(pincode);
        processNextPincode();
      } else if (!err && response.status === "OVER_QUERY_LIMIT") {
        console.log('Daily limit of 2500, exceeded', pincode);
        processNextPincode();
        res.send('Daily limit of 2500, exceeded');
      }
    });
  }

  function getAndUpdateCountry() {
    var countryName = locationData.country;
    var geocodeParams = {
      "address": countryName,
      "components": "country:IN",
    };
    console.log('inside getAndUpdateCountry function, countryName:', typeof (countryName));
    googleMaps.geocode(geocodeParams, function (err, response) {
      if (!err && response.status == "OK") {
        for (var a = 0; a < response.results[0].address_components.length; a++) {
          if (response.results[0].address_components[a].types[0] === 'country') {
            // console.log('inside if condition');
            var tempCountry = response.results[0].address_components[a];
            // console.log('tempCountry:', tempCountry);
            tempData.countryName = tempCountry.long_name;
            tempData.code = tempCountry.short_name;
          }
        }
        tempData.placeId = response.results[0].place_id;
        tempData.latLng = response.results[0].geometry.location;
        locationData.country_place_id = response.results[0].place_id; // saving placeId of country
        // finalArray.push(tempData);
        // console.log('finalArray:', JSON.stringify(finalArray, null, 2));
        getAndUpdateState();
      } else {
        pincodeNotProcessedCompletely.push(locationData.postal_code);
        processNextPincode();
      }
    });
  }

  function getAndUpdateState() {
    var stateName = locationData.state;
    console.log('inside getAndUpdateState function, stateName:', stateName);
    var geocodeParams = {
      "address": stateName,
      "components": "country:IN",
    };
    googleMaps.geocode(geocodeParams, function (err, response) {
      // console.log('status:', response.status);
      if (!err && response.status == "OK") {
        console.log('inside if condition');
        for (var a = 0; a < response.results[0].address_components.length; a++) {
          if (response.results[0].address_components[a].types[0] === 'administrative_area_level_1') {
            var tempState = response.results[0].address_components[a];
            // console.log('tempState:', tempState);
            tempData.stateDetails = {
              "stateName": tempState.long_name,
              "code": tempState.short_name
            };
          }
        }
        tempData.stateDetails.placeId = response.results[0].place_id;

        tempData.stateDetails.countryId = locationData.country_place_id;
        tempData.stateDetails.latLng = response.results[0].geometry.location;
        locationData.state_place_id = response.results[0].place_id;
        // console.log('countryData:', countryData);
        // finalArray.push(tempData);
        // console.log('finalArray: ', JSON.stringify(finalArray, null, 2));
        getAndUpdateDistrict();
      } else {
        pincodeNotProcessedCompletely.push(locationData.postal_code);
        processNextPincode();
      }
    });

  }

  function getAndUpdateDistrict() {
    var districtName = locationData.district;
    console.log('inside getAndUpdateDistrict function, districtName:', districtName);
    var geocodeParams = {
      "address": districtName,
      "components": "country:IN",
    };
    googleMaps.geocode(geocodeParams, function (err, response) {
      console.log('response: ', response.status);
      console.log('response data: ', response.results[0].types);
      if (!err && response.status == "OK") {
        var tempDistrict;
        for (var a = 0; a < response.results[0].address_components.length; a++) {
          if (response.results[0].address_components[a].types[0] === 'administrative_area_level_2') {
            tempDistrict = response.results[0].address_components[a];
            tempData.stateDetails.districtDetails = {
              "districtName": tempDistrict.long_name
            };
            break;
          } else if (response.results[0].address_components[a].types[0] === 'locality') {
            tempDistrict = response.results[0].address_components[a];
            tempData.stateDetails.districtDetails = {
              "districtName": tempDistrict.long_name
            };
          }
        }
        tempData.stateDetails.districtDetails.placeId = response.results[0].place_id;
        tempData.stateDetails.districtDetails.countryId = locationData.country_place_id;
        tempData.stateDetails.districtDetails.stateId = locationData.state_place_id;
        tempData.stateDetails.districtDetails.latLng = response.results[0].geometry.location;
        locationData.district_place_id = response.results[0].place_id;
        // finalArray.push(tempData);
        // console.log('finalArray: ', JSON.stringify(finalArray, null, 2));
        getAndUpdateTown();
      } else {
        pincodeNotProcessedCompletely.push(locationData.postal_code);
        processNextPincode();
      }
    });
  }

  function getAndUpdateTown() {
    var townName = locationData.town;
    console.log('inside getAndUpdateTown function, townName:', townName);
    var geocodeParams = {
      "address": townName,
      "components": "country:IN",
    };
    googleMaps.geocode(geocodeParams, function (err, response) {
      if (!err && response.status == "OK") {
        for (var a = 0; a < response.results[0].address_components.length; a++) {
          if (response.results[0].address_components[a].types[0] === 'locality') {
            tempTown = response.results[0].address_components[a];
            // console.log('tempTown:', tempTown);
            tempData.stateDetails.districtDetails.townDetails = {
              'townName': tempTown.long_name
            };
          }
        }
        tempData.stateDetails.districtDetails.townDetails.placeId = response.results[0].place_id;
        tempData.stateDetails.districtDetails.townDetails.countryId = locationData.country_place_id;
        tempData.stateDetails.districtDetails.townDetails.stateId = locationData.state_place_id;
        tempData.stateDetails.districtDetails.townDetails.districtId = locationData.district_place_id;
        tempData.stateDetails.districtDetails.townDetails.latLng = response.results[0].geometry.location;
        locationData.town_place_id = response.results[0].place_id;
        // console.log('townData:', townData);
        // finalArray.push(tempData);
        // console.log('finalArray: ', JSON.stringify(finalArray, null, 2));
        getAndUpdatePostalCode();
      } else {
        pincodeNotProcessedCompletely.push(locationData.postal_code);
        processNextPincode();
      }
    });

  }

  function getAndUpdatePostalCode() {
    var postalCode;
    if (locationData.postal_code) {
      postalCode = locationData.postal_code.toString();
    }
    console.log('inside getAndUdatePostalCode function, postalCode:', postalCode);
    var geocodeParams = {
      "address": postalCode,
      "components": "country:IN",
    };
    googleMaps.geocode(geocodeParams, function (err, response) {
      if (!err && response.status == "OK") {
        for (var a = 0; a < response.results[0].address_components.length; a++) {
          if (response.results[0].address_components[a].types[0] === 'postal_code') {
            var tempPostalCode = response.results[0].address_components[a];
            // console.log('tempPostalCode:', tempPostalCode);
            tempData.stateDetails.districtDetails.townDetails.pincodeDetails = {
              'pincode': tempPostalCode.long_name
            };
          }
        }
        tempData.stateDetails.districtDetails.townDetails.pincodeDetails.placeId = response.results[0].place_id;
        tempData.stateDetails.districtDetails.townDetails.pincodeDetails.countryId = locationData.country_place_id;
        tempData.stateDetails.districtDetails.townDetails.pincodeDetails.stateId = locationData.state_place_id;
        tempData.stateDetails.districtDetails.townDetails.pincodeDetails.districtId = locationData.district_place_id;
        tempData.stateDetails.districtDetails.townDetails.pincodeDetails.townId = locationData.town_place_id;
        tempData.stateDetails.districtDetails.townDetails.pincodeDetails.latLng = response.results[0].geometry.location;
        finalArray.push(tempData);
        // console.log('finalArray: ', JSON.stringify(finalArray, null, 2));

        // increasing count to pick next pincode from array of pincodes.
        processNextPincode();
      } else {
        pincodeNotProcessedCompletely.push(locationData.postal_code);
        processNextPincode();
      }
    });
  }

  function writeToFile() {
    req.body = sanitizeRequest(req.body);
    var options = {
      'url': endpoints.Host.territory + endpoints.Paths.Territory.unprocessedTerritoryMasterData,
      'method': 'POST',
      'headers': postHeaders,
      'body': JSON.stringify(processUnprocess),
    };

    if (proxyFlag === 'false') {
      options.proxy = proxyAddress;
    }
    console.log('options of processUnprocess ', options);

    request(options, function (error, response, body) {
      console.log('status:', response.statusCode);
      if (!error && response.statusCode == "200") {
        console.log('response:', body);
        res.send(body);
      } else {
        res.send({
          'messageCode': '400',
          'message': body ? (JSON.parse(body)) : {}
        });
      }
    });
    // for writting data to file
    // var fs = require('fs');
    // fs.writeFile("/test.txt", JSON.stringify(finalArray), function(err) {
    //     if(err) {
    //         return console.log(err);
    //     }
    //     console.log("The file was saved!");
    // });
  }

  function processNextPincode() {
    locationData = {};
    tempData = {};
    itr = itr + 1;

    if (pinArr.length >= itr + 1) {
      // pincode list not yet completed, processing next pincode from the array.
      fetchCompleteData(pinArr[itr]);
    } else {
      if (finalArray.length || processUnprocess.length) {
        // console.log('processunprocess: ', JSON.stringify(processUnprocess, null, 1));
        // console.log('processUnprocess.length: ', processUnprocess.length);
        //  api for saving pincodes in territory masterData
        if (finalArray.length) {
          // console.log('finalArray: ', finalArray);
          req.body = sanitizeRequest(req.body);
          var options = {
            'url': endpoints.Host.territory + endpoints.Paths.Territory.populateTerritoryMasterData,
            'method': 'POST',
            'headers': postHeaders,
            'body': JSON.stringify(finalArray),
          };

          if (proxyFlag === 'false') {
            options.proxy = proxyAddress;
          }
          console.log('options of retrieveByTownIdListOrPincodeList ', options);

          request(options, function (error, response, body) {
            console.log('status:', response.statusCode);
            if (!error && response.statusCode == "200") {
              // console.log('response:', body);
              if (processUnprocess.length) {
                writeToFile();
              }
              // res.send(body);

            } else {
              console.log('service not called');
              res.send({
                'messageCode': '400',
                'message': body ? (JSON.parse(body)) : {}
              });
            }
          });
        } else if (processUnprocess.length) {
          writeToFile();
        }

      } else {
        console.log("no data available to be sent to service");
        res.send('No Data Saved');
      }
    }
  }
});

// service for processing pincode for creating a list in excel.
/* territoryMaster.post('/excelPincodeData', function (req, res) {
  console.log('excelPincodeData master data called');
  var pinInput = req.body.pincode;
  zeroResultsPincode = [],
    pinArr = [],
    itr = 0,
    locationData = {}, // holds data recieved against a particular pincode
    dataArray = [];

  if (pinInput) {
    pinArr = pinInput.split(',');
    console.log('pinArr before', pinArr.length);
    pinArr = uniq(pinArr);
    console.log('pinArr after: ', pinArr.length, "itr:", itr);
    fetchCompleteData(pinArr[itr]);
  }

  function uniq(pinArr) {
    return Array.from(new Set(pinArr));
  }

  // basic retrieval of complete data with pincode as the only input.
  function fetchCompleteData(pincode) {
    console.log('pincode as input for complete data: ', pincode, 'itr value: ', itr);
    var geocodeParams = {
      "address": pincode,
      "components": "country:IN",
    };
    googleMaps.geocode(geocodeParams, function (err, response) {
      // console.log(response);
      // console.log('response: ', response.status);
      if (!err && response.status === "OK") {
        for (var a = 0; a < response.results[0].address_components.length; a++) {
          var component = response.results[0].address_components[a];

          switch (component.types[0]) {
            case 'country':
              locationData.country = component.long_name;
              locationData.registered_country_iso_code = component.short_name;
              break;

            case 'administrative_area_level_1':
              locationData.state = component.long_name;
              break;

            case 'administrative_area_level_2':
              locationData.district = component.long_name;
              break;

            case 'locality':
              locationData.town = component.long_name;
              break;

            case 'postal_code':
              locationData.postalCode = component.long_name;
              break;
          }
        }
        locationData.country = locationData.country ? locationData.country : locationData.country = '';
        locationData.state = locationData.state ? locationData.state : locationData.state = '';
        locationData.district = locationData.district ? locationData.district : locationData.district = '';
        locationData.town = locationData.town ? locationData.town : locationData.town = '';
        locationData.postalCode = locationData.postalCode ? locationData.postalCode : locationData.postalCode = '';
        locationData.placeId = response.results[0].place_id ? response.results[0].place_id : locationData.placeId = "";
        if (locationData) {
          var client = createConnection();
          client.open(function (err, db) {
            if (err) {
              console.log('unable to connect to mongodb server');
              client.close();
            }
            var collection = db.collection('pincodeExcelData');
            collection.insertOne(locationData, function () {
              nextPincode();
            });
          });
        }
        // console.log('locationData at begining:', JSON.stringify(locationData, null, 2));

      } else if (!err && response.status === "ZERO_RESULTS") {
        zeroResultsPincode.push(pincode);
        nextPincode();
      } else if (!err && response.status === "OVER_QUERY_LIMIT") {
        console.log('Daily limit of 2500, exceeded', pincode);
        res.send('Daily limit of 2500, exceeded');
      }
    });
  }

  function nextPincode() {
    locationData = {};
    itr = itr + 1;
    if (pinArr.length >= itr + 1) {
      // pincode list not yet completed, processing next pincode from the array.
      fetchCompleteData(pinArr[itr]);
    } else {
      res.send('data processed!');
    }
  }

  function createConnection() {
    var Db = require('mongodb').Db,
      MongoClient = require('mongodb').MongoClient,
      Server = require('mongodb').Server,
      ObjectID = require('mongodb').ObjectID,
      Assert = require('mongodb').Assert;


    var client = new Db('excelPincodeMasterdata', new Server('localendpoints.Host., 27017));
    return client;
  }
}); */
module.exports = territoryMaster;
