var express = require('express');
var users = express.Router();

users.post('/inviteUser', (req, res) => {
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.UserSetup.inviteUser,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body)
  }
  console.log("options in userSetup++++++++++", options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});

users.post('/getUser', (req, res) => {
  console.log("body in getUser", req.body);
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.UserSetup.getUser,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body)
  }
  console.log("options in getUser", options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});

users.post('/getBeatList', (req, res) => {
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.beat + endpoints.Paths.UserSetup.getBeatList + '/' + req.body.partyId,
    'method': 'GET',
    'headers': setHeaders(req.headers),
    // 'body': JSON.stringify(req.body.orgId)
  }
  console.log("options in getBeat", options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});

// update User
users.post('/updateUser', (req, res) => {
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.UserSetup.updateUser,
    'method': 'POST',
    'headers': setHeaders(req.headers),
    'body': JSON.stringify(req.body)
  }
  console.log("options in updateUser", options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      })
    }
  });
});

module.exports = users;
