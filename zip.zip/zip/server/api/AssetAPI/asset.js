var express = require('express');
var Asset = express.Router();

Asset.post('/getMasterListAssetTypes', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Asset.getMasterListAssetTypes,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in getMasterListAssetTypes : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Asset.post('/getGetCategoryByLevel', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Asset.getGetCategoryByLevel,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in getGetCategoryByLevel : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log(error);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Asset.post('/addCategory', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Asset.addCategory,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addCategory : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Asset.post('/addAssetType', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Asset.addAssetType,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addCategory : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Asset.post('/checkAssetTypeByName', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Asset.checkAssetTypeByName,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addCategory : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Asset.post('/checkAssetTypeByCode', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.catalog + endpoints.Paths.Asset.checkAssetTypeByCode,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in addCategory : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// get all asset
Asset.post('/getAllAsset', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.asset + endpoints.Paths.Asset.getAllAsset,
    'method': 'GET',
    'headers': setHeaders(req.headers),
    'qs': req.body.paramObject
  };

  console.log('in getAllAsset : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// get particular asset
Asset.post('/getAssetById', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.asset + endpoints.Paths.Asset.getAssetById + '/' + req.body.assetId,
    'body': '',
    'method': 'GET',
    'headers': setHeaders(req.headers)
  };

  console.log('in getAssetById : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      try {
        res.send({
          'messageCode': '400',
          'message': body
        });
      } catch (e) {
        console.log(e);
      }
    }
  });
});

// save an asset
Asset.post('/saveAsset', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.asset + endpoints.Paths.Asset.saveAsset,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in saveAsset : ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send({
        body
      });
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});


module.exports = Asset;
