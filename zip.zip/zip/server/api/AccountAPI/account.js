var express = require('express');
var Account = express.Router();
// var postHead = JSON.parse(JSON.stringify(postHeaders));
var panmHost = 'http://panm-deltaverge-dev.apps.ocp.deltaverge.com';

Account.post('/findAccount', function (req, res) {

  req.body = sanitizeRequest(req.body); 
   var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Account.findAccount,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in findAccount : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Account.post('/createAccount', function (req, res) {

  req.body = sanitizeRequest(req.body);  
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Account.createAccount,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in createAccount : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log(body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

module.exports = Account;
