var express = require('express');
var Org = express.Router();

// var postHead = JSON.parse(JSON.stringify(postHeaders));
var panmHost = 'http://panm-deltaverge-dev.apps.ocp.deltaverge.com';

Org.post('/findOrg', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Org.findOrg,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in findOrg : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log(body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Org.post('/findOrgProfile', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Org.findOrgProfile,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in findOrgProfile : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log(body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Org.post('/createOrg', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Org.createOrg,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in createOrg : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log(body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Org.post('/updateOrg', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Org.updateOrg,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in updateOrg : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log(body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Org.post('/addNetwork', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Org.addNetwork,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in findAccount : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log(body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Org.post('/updateNetwork', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Org.updateNetwork,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in findAccount : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log(body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Org.post('/findNetwork', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Org.findNetwork,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in findAccount : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log(body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Org.post('/findNotConnectedOrg', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Org.findNotConnectedOrg,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in findAccount : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log(body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Org.post('/findConnectedOrg', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Org.findConnectedOrg,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('in findAccount : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log(body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});


Org.post('/uploadFile', upload.array('file'), function (req, res) {
  console.log('inside body', req.body);
  console.log('inside headers', req.headers);
  console.log('files :', req.files);

  var formData = {
    attachment: []
  };

  for (var i = 0; i < req.files.length; i++) {
    fs.renameSync('./src/assets/' + req.files[i].filename, './src/assets/' + req.files[i].originalname, function (err) {
      if (err) {
        console.log("error is", err);
      }
    });
    formData.attachment.push(fs.createReadStream('./src/assets/' + req.files[i].originalname));
  }

  console.log('==========FORM DATA===========');
  console.log(formData);

  // fs.createReadStream('./src/assets/' + req.file.originalname)
  req.body = sanitizeRequest(req.body);
  var options = {
    'url' : endpoints.Host.partner + endpoints.Paths.Partner.uploadFile,
    'method' : 'POST',
    'formData': formData,
    'headers' : {
      'Content-Type': 'application/json',
      'tenantToken': req.body.tenantToken,
      'Authorization': req.body.Authorization
    }
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options for uploadImage: ', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      console.log(body);
      res.send(body);
    } else if (error) {
      console.log('\n\n\n ERROR :: ', error);
      res.send(error);
    } else {
      var error = JSON.parse(body);
      res.send({
        'messageCode': error.status,
        "message": error.message
      });
    }

    for (var i = 0; i < req.files.length; i++) {
      if (req.files[i].originalname != undefined || req.files[i].filename != undefined) {
        fs.unlink('./src/assets/' + req.files[i].originalname, function (err) {
          if (err) {
            if (err.code == 'ENOENT') {
              console.log('originalName', 'fileNotFound');
            }
          }
        });
        fs.unlink('./src/assets/' + req.files[i].filename, function (err) {
          if (err) {
            if (err.code == 'ENOENT') {
              console.log('filename', 'fileNotFound');
            }
          }
        });
      }
    }
  });
});

Org.get('/downloadFile', function (req, res) {
  console.log('\n\n\n', req.query);
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.Partner.downloadFile + '/' + req.query.gridFSid,
    'method': 'GET',
    'headers': {
      'Content-Type': 'application/json',
      'Authorization': req.query.authorization,
      'tenantToken': req.query.tenantToken
    }
  };

  console.log('in downloadFile : ', options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  res.setHeader("content-disposition", "attachment; filename=file.png");
  request(options).pipe(res);
});


module.exports = Org;
