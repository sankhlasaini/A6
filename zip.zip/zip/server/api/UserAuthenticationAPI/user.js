var express = require('express');
var user = express.Router();
var CryptoJS = require("crypto-js");
// var sanitize = require("mongo-sanitize");

// var data = {"asd":{'$gt':"asd"},dskj:'s'}

// console.log('-> ',sanitize(data));

var postHeaders = {
  'Content-Type': 'application/x-www-form-urlencoded',
  'Authorization': "Basic " + new Buffer(CLIENT_ID + ":" + CLIENT_SECRET).toString("base64")
};

user.post('/login', function (req, res) {
  // console.log(req.body);

  req.body = sanitizeRequest(req.body);

  var bytes = CryptoJS.AES.decrypt(req.body.password, AES_KEY);
  var password = bytes.toString(CryptoJS.enc.Utf8);

  console.log('AFTER Password Decrypt ::::: ', password);

  //account Id has to come from Client Side and then paired with username.
  var json = "password=" +
    password +
    "&username=" +
    req.body.username +
    "&grant_type=password" +
    "&client_secret=" + CLIENT_SECRET +
    "&client_id=" + CLIENT_ID +
    "&scope=Write";
  console.log(json)
  var options = {
    'url': endpoints.Host.isam + endpoints.Paths.Isam.login,
    'body': json,
    'method': 'POST',
    'headers': postHeaders
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log(options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

user.post('/clientLogin', function (req, res) {
  req.body = sanitizeRequest(req.body);
  var json = "client_secret=" +
    req.body.password +
    "&client_id=" +
    req.body.username +
    "&grant_type=client_credentials"
  console.log(json)
  var options = {
    'url': endpoints.Host.isam + endpoints.Paths.Isam.login,
    'body': json,
    'method': 'POST',
    'headers': postHeaders
  };
  console.log(options);
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log(options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

user.post('/refreshAccessToken', function (req, res) {
  req.body = sanitizeRequest(req.body);

  var json =
    "&grant_type=refresh_token" +
    "&client_secret=" + CLIENT_SECRET +
    "&client_id=" + CLIENT_ID +
    "&refresh_token=" + req.body.refreshToken;

  var options = {
    'url': endpoints.Host.isam + endpoints.Paths.Isam.login,
    'body': json,
    'method': 'POST',
    'headers': postHeaders
  };

  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }

  console.log(options);
  request(options, function (error, response, body) {
    console.log(body);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': JSON.parse(body)
      });
    }
  });
});

user.post('/clientAccessToken', function (req, res) {
  req.body = sanitizeRequest(req.body);
  var body = "grant_type=client_credentials" +
    "&client_secret=" + CLIENT_SECRET +
    "&client_id=" + CLIENT_ID +
    "&scope=Write";

  var options = {
    'url': endpoints.Host.isam + endpoints.Paths.Isam.login,
    // 'url': 'http://isam-deltaverge-dev.apps.ocp.deltaverge.com/oauth/token',
    'body': body,
    'method': 'POST',
    'headers': postHeaders
  };

  console.log('Options for getAccessToken', options);

  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});


// PANM

user.post('/generateOTP', function (req, res) {
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.PasswordReset.generateOTP,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('Options for GenerateOTP', options);

  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

user.post('/verifyOTP', function (req, res) {
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.PasswordReset.verifyOTP,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('Options for VerifyOTP', options);

  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

user.post('/resetPassword', function (req, res) {
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.PasswordReset.resetPassword,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('Options for ResetPassword', options);

  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

user.post('/verifyUser', function (req, res) {
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.partner + endpoints.Paths.PasswordReset.verifyUser,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };

  console.log('Options for VerifyUser', options);

  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

module.exports = user;
