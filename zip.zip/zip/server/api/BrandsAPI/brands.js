var express = require('express');
var Brands = express.Router();

Brands.post('/create', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Brands.createBrand,
    'body': JSON.stringify(req.body.paramBody),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('create option in brand.js', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Brands.post('/getBrand', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Brands.retrieveBrand,
    'body': JSON.stringify({
      "id": req.body.brandId
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('getBrand options:', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Brands.post('/getBrandsList', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Brands.retrieveBrandsList,
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }

  console.log('getBrandsList option in brand.js', options);

  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// retrieve brands for particular org id in product
Brands.post('/retrieveBrandsByOrgIds', function (req, res) {

  console.log('retrieveBrandsByOrgIds', req.body.bandOrgId);
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Brands.retrieveBrandsByOrgIds,
    'body': JSON.stringify({
      "brandOrgId": req.body.bandOrgId
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('body of retrieveBrandsByOrgIds: ', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      console.log('body of retrieve brands by org id:', body);
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// api for creating Brand discounts
Brands.post('/createBrandsDiscount', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Brands.createBrandsDiscount,
    'body': JSON.stringify([{
      "brandId": "brandId",
      "marginDiscount": "7",
      "addtionalCashDiscount": "9",
      "retailerId": "retailerId"
    }]),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('option for createBrandsDiscount', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// api for Retrieving Brand Discounts along with Brands details by brandIds and/or retailerIds array
Brands.post('/retrieveBrandsByRetailerIdsAndBrandIds', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Brands.retrieveBrandsByRetailerIdsAndBrandIds,
    'body': JSON.stringify({
      "brandIds": ["c0f330c5-506f-4b3e-966f-469a634b6ec3", "4474ce85-037d-4b02-8942-048ca937e5b8"],
      "retailerIds": ["retailerId", "retailerId2"],
      "startIndex": 0,
      "endIndex": 10
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('option for retrieveBrandsByRetailerIdsAndBrandIds', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

//api for Retrieving COUNT of Brand Discounts by brandIds and/or retailerIds array
Brands.post('/retrieveBrandsCountByRetailerIdsAndBrandIds', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Brands.retrieveBrandsCountByRetailerIdsAndBrandIds,
    'body': JSON.stringify({
      "brandIds": ["c0f330c5-506f-4b3e-966f-469a634b6ec3", "4474ce85-037d-4b02-8942-048ca937e5b8"],
      "retailerIds": ["retailerId", "retailerId2"]
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('option for retrieveBrandsCountByRetailerIdsAndBrandIds', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

//api for Retrieving Retailers by brandIds
Brands.post('/retrieveRetailersByBrandIds', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Brands.retrieveRetailersByBrandIds,
    'body': JSON.stringify({
      "brandIds": ["c0f330c5-506f-4b3e-966f-469a634b6ec3", "4474ce85-037d-4b02-8942-048ca937e5b8"]
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('option for retrieveRetailersByBrandIds', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Get BrandOrg By Id
Brands.post('/getBrandOrgByCode', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.territory + endpoints.Paths.Brands.getBrandOrgById,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/brandOrg/getBrandOrgByCode',
    'body': JSON.stringify({
      "code": req.body.brandCode
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('option for getBrandOrgById', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Get AllBrandOrg
Brands.post('/allBrandOrg', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.territory + endpoints.Paths.Brands.allBrandOrg,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/brandOrg/getAllBrandOrgs',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('option for allBrandOrg', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Get AllBrand By BrandOrgID
Brands.post('/allBrands', function (req, res) {
  postHead.Authorization = req.headers.authorization;
  console.log('user', req.body.brandOrgId);
  console.log('path', endpoints.Host.territory + endpoints.Paths.Brands.allBrands);
  postHead.tenantToken = req.body.tenantToken;
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Brands.allBrands,
    'body': JSON.stringify({
      "brandOrgId": req.body.brandOrgId
    }),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('option for allBrands', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Create Brandorg
Brands.post('/createBrandOrg', function (req, res) {
  console.log('--------------------------', req.body.newBrandOrg);

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.territory + endpoints.Paths.Brands.createBrandOrg,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/brandOrg/addBrandOrg',
    'body': JSON.stringify(req.body.newBrandOrg),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('option for createBrandOrg', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Update Brandorg
Brands.post('/updateBrandOrg', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.territory + endpoints.Paths.Brands.updateBrandOrg,
    'url': 'http://cmf-deltaverge-dev.apps.ocp.deltaverge.com/api/brandOrg/addBrands',
    'body': JSON.stringify(req.body.newBrand),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('option for updateBrandOrg', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

// Get BrandOrgImage by Id 
Brands.get('/getBrandOrgImage', function (req, res) {
  postHead.Authorization = req.headers.authorization;
  console.log('param', req.query.fileId);
  console.log('path', endpoints.Host.territory + endpoints.Paths.Brands.getBrandOrgImage + '/{referenceId}/?referenceId=' + req.query.fileId);
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.territory + endpoints.Paths.Brands.getBrandOrgImage + '/{referenceId}/?referenceId=' + req.query.fileId,
  };
  console.log('download file ', options)
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  res.setHeader("content-disposition", "attachment; filename=file.png");
  request(options).pipe(res);
});

// Upload BrandOrg Images
Brands.post('/brandOrgImageUpload', upload.array('attachment'), function (req, res) {
  var tenantToken = req.body.tenantToken;
  postHead.Authorization = req.headers.authorization;
  console.log('tenantToken :', tenantToken);
  console.log('files :', req.files);
  console.log('path', endpoints.Host.territory + endpoints.Paths.Brands.brandOrgImageUpload);

  var formData = {
    attachment: []
  };

  for (var i = 0; i < req.files.length; i++) {
    fs.renameSync('./src/assets/' + req.files[i].filename, './src/assets/' + req.files[i].originalname, function (err) {
      if (err) {
        console.log("error is", err);
      }
    });

    formData.attachment.push(fs.createReadStream('./src/assets/' + req.files[i].originalname));
  }

  req.body = sanitizeRequest(req.body);
  var options = {
    'url' : endpoints.Host.territory + endpoints.Paths.Brands.brandOrgImageUpload,
    'method' : 'POST',
    'formData': formData,
    'headers' : {
      'tenantToken': tenantToken
    }
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options for brandOrgImageUpload: ', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {
      console.log(body);
      res.send(body);
    } else if (error) {
      res.send(error);
    } else {
      var error = JSON.parse(body);
      res.send({
        'messageCode': error.status,
        "message": error.message
      });
    }

    for (var i = 0; i < req.files.length; i++) {
      if (req.files[i].originalname != undefined || req.files[i].filename != undefined) {
        fs.unlink('./src/assets/' + req.files[i].originalname, function (err) {
          if (err) {
            if (err.code == 'ENOENT') {
              // console.log(configSettings.ErrorMessages.fileNotFound);
            }
          }
        });
        fs.unlink('./src/assets/' + req.files[i].filename, function (err) {
          if (err) {
            if (err.code == 'ENOENT') {
              // console.log(configSettings.ErrorMessages.fileNotFound);
            }
          }
        });
      }
    }
  });
});

module.exports = Brands;
