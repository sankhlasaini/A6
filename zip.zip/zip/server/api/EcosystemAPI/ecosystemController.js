var express = require('express');
var Ecosystem = express.Router();
var profiles = require('./Profile/ecosystemProfile');
var businessDocs = require('./BusinessDocsRoute/businessDocs');
// var businessData = require('./BusinessDataRoute/businessData');
var roles = require('./Roles/ecosystemRoles');
var ecosystemCRUD = require('./Ecosystem/ecosystem');
var instruments = require('./Instruments/ecosystemInstruments')
var items = require('./Items/ecosystemItems');

postHeaders = {
  'Content-Type': 'application/json',
  'tenantToken': 'system'
};
Ecosystem.use('/businessDocs', businessDocs);
// Ecosystem.use('/businessData', businessData);
Ecosystem.use('/profiles', profiles);
Ecosystem.use('/roles', roles);
Ecosystem.use('/instruments', instruments);
Ecosystem.use('/items', items);
Ecosystem.use('/', ecosystemCRUD);

module.exports = Ecosystem;
