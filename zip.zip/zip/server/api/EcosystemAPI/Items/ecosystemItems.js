var express = require('express');
var Item = express.Router();

var essHost = 'http://ess-deltaverge-dev.apps.ocp.deltaverge.com';

Item.post('/createItem', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.createItem,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});


Item.post('/getItems', function (req, res) {

  console.log('getItem body', req.body)
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.getItems,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers),
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('options   getItem', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Item.post('/updateItem', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.updateItem,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

Item.post('/cloneItem', function (req, res) {

  console.log('req.body cloneItem:', req.body);
  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.cloneItem,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('getItemsList options: ', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

module.exports = Item;
