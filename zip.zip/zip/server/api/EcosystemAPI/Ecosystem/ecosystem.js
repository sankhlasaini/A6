var express = require('express');
var EcosystemCRUD = express.Router();

var essHost = 'http://ess-deltaverge-dev.apps.ocp.deltaverge.com';

EcosystemCRUD.post('/createEcosystem', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.createEcosystem,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log(options)
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

EcosystemCRUD.post('/cloneEcosystem', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.cloneEcosystem,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log(options)
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

EcosystemCRUD.post('/getEcosystemListCount', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.getEcosystemListCount,
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.getEcosystemListCount,
    'headers': setHeaders(req.headers),
    'method': 'GET'
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log("options of getEcosystemListCount", options);
  request(options, function (error, response, body) {
    console.log(response.statusCode);
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

EcosystemCRUD.post('/getEcosystemList', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.getEcosystemList,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('getEcosystemList options:', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
})

EcosystemCRUD.post('/getEcosystemById', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.getEcosystemListById,
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.getEcosystemById,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  console.log('getEcosystemById options:', options);
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

EcosystemCRUD.post('/updateEcosystem', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    // 'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.updateEcosystem,
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.updateEcosystem,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});



// EcosystemCRUD.delete('/deleteAllEcosystemTable', function (req, res) {
//   postHeaders.Authorization = req.headers.authorization;
//   req.body = sanitizeRequest(req.body);  var options = {
//     'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.deleteAllEcosystemTable,
//     'method': 'DELETE',
//     'headers': setHeaders(req.headers)ers
//   };
//   if (proxyFlag === 'false') {
//     options.proxy = proxyAddress;
//   }
//   request(options, function (error, response, body) {
//     console.log('RESPONSE BODY : ', body);     console.log('RESPONSE ERROR : ', error);     if (!error && response.statusCode == 200) {

//       res.send(body);
//     } else {
//       res.send({
//         'messageCode': '400',
//         'message': body ? (JSON.parse(body)) : {}
//       });
//     }
//   });
// });

EcosystemCRUD.post('/getGlobalModulesAction', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.getGlobalModulesAction,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

EcosystemCRUD.post('/maintenance', function (req, res) {

  req.body = sanitizeRequest(req.body);
  var options = {
    'url': endpoints.Host.Ecosystems + endpoints.Paths.Ecosystems.maintenance,
    'body': JSON.stringify(req.body),
    'method': 'POST',
    'headers': setHeaders(req.headers)
  };
  if (proxyFlag === 'false') {
    options.proxy = proxyAddress;
  }
  request(options, function (error, response, body) {
    console.log('RESPONSE BODY : ', body);
    console.log('RESPONSE ERROR : ', error);
    if (!error && response.statusCode == 200) {

      res.send(body);
    } else {
      res.send({
        'messageCode': '400',
        'message': body ? (JSON.parse(body)) : {}
      });
    }
  });
});

module.exports = EcosystemCRUD;
