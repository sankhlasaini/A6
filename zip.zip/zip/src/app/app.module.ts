import { ErrorDialogComponent } from './components/post-launch/common/error-dialog/error-dialog.component';
import { HttpClientModule } from '@angular/common/http';
import { ImageResize } from './services/postLaunch/image-resize.service';
import { UserSetupService } from './services/postLaunch/user-setup.service';
import { AssetService } from './services/postLaunch/asset.service';
import { LoginService } from './services/login.service';
import { ImageSizeReducerService } from './services/image-size-reducer.service';
import { BrandService } from './services/brand.service';
import { MasterProductListService } from './services/master-product-list.service';
import { MasterPartyService } from './services/master-party.service';
import { PostLaunchUrlComponent } from './components/post-launch-url/post-launch-url.component';
import { SharedModule } from './shared.module';
import { HelperService } from './services/helper.service';
import { PartnerService } from './services/postLaunch/partner.service';
import { EcoSystemService } from './services/eco-system.service';
import { ProfileSetupService } from './services/postLaunch/profile-setup.service';
import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DateAdapter, NativeDateAdapter } from '@angular/material';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { ProductService } from './services/postLaunch/product.service';
import { TerritoryService } from './services/postLaunch/territory.service';
import { ProfileService } from './services/profile.service';
import { RoleService } from './services/role.service';
import { InstrumentPermissionService } from './services/instrument-permission.service';
import { BusinessDocsService } from './services/business-docs.service';
import { ProductTemplateService } from './services/product-template.service';
import { CrossPlatformService } from './services/postLaunch/cross-platform.service';
import { LocationComponent } from './components/location/location.component';
import 'hammerjs';
import { ItemService } from './services/item.service';
import { ConfirmLabelDialogComponent } from './components/postLogin/common/confirm-label-dialog/confirm-label-dialog.component';
import { ServiceCatalogService } from './services/postLaunch/service-catalog.service';
import { AccountService } from './services/account.service';
import { ConfirmationDialogComponent } from './components/post-launch/common/confirmation-dialog/confirmation-dialog.component';
import { NguiMapModule } from '@ngui/map';
import { GoogleMapDialogComponent } from './components/post-launch/common/google-map-dialog/google-map-dialog.component';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    AppRoutingModule,
    SharedModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
  ],

  declarations: [
    AppComponent,
    LocationComponent,
    PostLaunchUrlComponent,
    ConfirmationDialogComponent,
    ConfirmLabelDialogComponent,
    GoogleMapDialogComponent,
    ErrorDialogComponent,
  ],

  entryComponents: [
    ErrorDialogComponent,
    ConfirmLabelDialogComponent,
    ConfirmationDialogComponent,
    GoogleMapDialogComponent,
  ],

  providers: [
    { provide: DateAdapter, useClass: NativeDateAdapter },
    EcoSystemService,
    ProductService,
    TerritoryService,
    ProfileService,
    RoleService,
    InstrumentPermissionService,
    BusinessDocsService,
    ProductTemplateService,
    ProfileSetupService,
    CrossPlatformService,
    PartnerService,
    HelperService,
    Title,
    MasterPartyService,
    MasterProductListService,
    BrandService,
    ImageSizeReducerService,
    LoginService,
    ItemService,
    ServiceCatalogService,
    UserSetupService,
    AssetService,
    AccountService,
    ImageResize
  ],

  exports: [
  ],

  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }
