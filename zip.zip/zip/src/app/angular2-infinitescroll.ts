import { Directive, ElementRef, Input, Output, EventEmitter } from '@angular/core';
// import { NgModel } from '@angular/common';

@Directive({
    selector: '[InfiniteScroll]',
    // providers: [NgModel],
    // tslint:disable-next-line:use-host-property-decorator
    host: {
        '(scroll)': 'onScroll($event)'
    }
})
// tslint:disable-next-line:directive-class-suffix
export class InfiniteScroll {
    public _element: any;
    public _count: number;
    // tslint:disable-next-line:no-input-rename
    @Input('ScrollDistance') public scrollTrigger: number;
    @Output() public OnScrollMethod = new EventEmitter<any>();

    constructor(public element: ElementRef) {
        this._element = this.element.nativeElement;
        if (!this.scrollTrigger) {
            this.scrollTrigger = 1;
        }
    }

    public onScroll() {
        this._count++;
        if (this._element.scrollTop + this._element.clientHeight >= this._element.scrollHeight) {
            this.OnScrollMethod.emit(null);
        } else {
            if (this._count % this.scrollTrigger === 0) {
                this.OnScrollMethod.emit(null);
            }
        }
    }
}
