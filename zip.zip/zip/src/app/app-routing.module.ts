import { PostLaunchUrlComponent } from './components/post-launch-url/post-launch-url.component';
import { RouterModule, Routes } from '@angular/router';
import { LocationComponent } from './components/location/location.component';
import { NgModule } from '@angular/core';

// routes
const routes: Routes = [
    {
        path: 'ecosystem',
        loadChildren: './modules/ecosystem-module/ecosystem.module#EcosystemModule'
    },
    {
        path: 'postLaunch',
        loadChildren: './modules/postLaunch-module/postLaunch.module#PostLaunchModule'
    },
    { path: 'postLaunchUrl/:orgId', component: PostLaunchUrlComponent },

    { path: 'location', component: LocationComponent },

    { path: '**', redirectTo: '/ecosystem/login', pathMatch: 'full' }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule { }
