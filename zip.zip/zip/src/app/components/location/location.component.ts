import { HelperService } from './../../services/helper.service';
import { Component } from '@angular/core';
import { LocationService } from './../../services/location.service';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css'],
  providers: [LocationService]
})
export class LocationComponent {

  constructor(public helperService: HelperService, private locationService: LocationService) { }

  public search(pincode) {
    this.locationService.search(pincode)
      .subscribe((response) => {
        const data = JSON.stringify(response);
        console.log('response recieved->');
        this.helperService.openSnackBar('Pincode Processed', 'OK');
      });
  }
}
