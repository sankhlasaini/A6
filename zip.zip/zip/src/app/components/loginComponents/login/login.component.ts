import { ForgetPasswordComponent } from './../forget-password/forget-password.component';
import { MatDialog } from '@angular/material';
import { LoginService } from './../../../services/login.service';
import { HelperService } from './../../../services/helper.service';
import { Component, Inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  public loading = false;
  public userForm: FormGroup;
  public self = this;
  public hide = true;
  public count = 0;
  constructor(
    @Inject(FormBuilder) fb: FormBuilder,
    private dialog: MatDialog,
    private router: Router,
    private loginService: LoginService,
    private helperService: HelperService,
    private titleService: Title
  ) {
    this.titleService.setTitle('DV | Login');
    this.userForm = fb.group({
      username: '',
      password: ''
      // email: ['', [Validators.required, Validators.pattern(/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/)]],
      // password: ['', [Validators.required, Validators.pattern(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{6,24}$/)]],
    });
    if (localStorage.getItem('currentUser')) {
      this.helperService.openSnackBar('Already Logged In', 'Redirecting');
      this.loginService.refreshAccessToken().subscribe((res) => {
        this.loginService.redirect();
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public login() {
    this.loading = true;
    this.loginService.getSecret().subscribe((key) => {
      this.loginService.loginISAM(this.userForm.value, key).subscribe((res) => {
        console.log('Login RES : ', res);
        this.loading = false;
        if (res.success) {
          this.helperService.openSnackBar(res.msg, this.loginService.getCurrentUser().user.name);
          this.loginService.redirect();
        } else {
          this.helperService.openSnackBar(res.msg, 'Try Again');
        }
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public forgetPasswordDialog() {
    const dialogRef = this.dialog.open(ForgetPasswordComponent, {
      minWidth: '250px',
      width: '300px',
      data: '',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('-------------', result);
    });
  }

  // public redirect() {
  //   const userType = JSON.parse(localStorage.getItem('currentUser')).userType;
  //   if (userType === 'dv') {
  //     this.router.navigate(['/ecosystem/admin']);
  //   } else if (userType === 'ac') {
  //     this.router.navigate(['/ecosystem/account']);
  //   }
  // }
}
