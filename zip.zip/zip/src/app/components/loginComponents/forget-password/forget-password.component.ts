import { HelperService } from './../../../services/helper.service';
import { LoginService } from './../../../services/login.service';
import { FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Component, OnInit, Inject } from '@angular/core';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit {

  public sendOtpFormControl = new FormControl('', [Validators.required, Validators.pattern(this.helperService.mobileRegex)]);
  public verifyOtpFormControl = new FormControl('', [Validators.required]);
  public passwordFormControl = new FormControl('', [Validators.required]);
  public confirmPasswordFormControl = new FormControl('', [Validators.required]);
  public loading = false;
  public activeTabIndex = 0;
  public hide = true;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ForgetPasswordComponent>,
    private loginService: LoginService,
    private helperService: HelperService
  ) { }

  public ngOnInit() {
    // setTimeout(() => {
    //   document.getElementById('mobileInput').blur();
    // }, 20);
  }

  public verifyUser() {
    if (this.sendOtpFormControl.valid) {
      this.loading = true;
      this.loginService.clientAccessToken().subscribe((result) => {
        console.log('client at', result);
        if (result.success) {
          let token = { token_type: result.result.token_type, accessToken: result.result.access_token, tenantToken: 'system' };
          let body = { globalLoginId: this.sendOtpFormControl.value, preConditionType: 'IS_EXISTING_USER' };
          this.loginService.verifyUser(body, token).subscribe((verifyUserRes) => {
            console.log('result of verifyUser', verifyUserRes);
            if (verifyUserRes.success && verifyUserRes.result) {
              this.generateOTP(token);
            } else {
              this.loading = false;
              this.helperService.openSnackBar('User Not Found', 'Try Another');
            }
          }, (err) => {
            this.loading = false;
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public generateOTP(token) {
    this.loginService.generateOTP({ globalLoginId: this.sendOtpFormControl.value, messageMode: 'SMS' }, token).subscribe((otp) => {
      this.loading = false;
      console.log('result of generateOTP', otp);
      if (otp.success) {
        this.helperService.openSnackBar('OTP Sent', 'Please Enter OTP');
        this.verifyOtpFormControl.reset();
        setTimeout(() => { document.getElementById('otpVerification').focus(); }, 200);
        this.activeTabIndex = 1;
      } else {
        this.helperService.openSnackBar('Send OTP Failed', 'Try Again');
      }
    }, (err) => {
      this.loading = false;
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public verifyOTP() {
    if (this.verifyOtpFormControl.valid) {
      this.loading = true;
      this.loginService.clientAccessToken().subscribe((result) => {
        let token = { token_type: result.result.token_type, accessToken: result.result.access_token, tenantToken: 'system' };
        this.loginService.verifyOTP({ globalLoginId: this.sendOtpFormControl.value, otp: this.verifyOtpFormControl.value }, token).subscribe((verifyOtp) => {
          console.log(verifyOtp);
          this.loading = false;
          if (verifyOtp.success && verifyOtp.result) {
            setTimeout(() => { document.getElementById('passwordConfirmation').focus(); }, 200);
            this.activeTabIndex = 2;
          } else {
            this.activeTabIndex = 0;
            this.helperService.openSnackBar('Wrong OTP', 'Try Again');
          }
        }, (err) => {
          this.activeTabIndex = 0;
          this.loading = false;
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public resetPassword() {
    if (this.passwordFormControl.valid) {
      if (this.passwordFormControl.value === this.confirmPasswordFormControl.value) {
        this.loading = true;
        this.loginService.clientAccessToken().subscribe((result) => {
          let token = { token_type: result.result.token_type, accessToken: result.result.access_token, tenantToken: 'system' };
          this.loginService.resetPassword({ globalLoginId: this.sendOtpFormControl.value, newPassword: this.confirmPasswordFormControl.value }, token).subscribe((result1) => {
            this.loading = false;
            console.log('result of resetPassword', result1);
            if (result1.success) {
              this.helperService.openSnackBar('Password Changed', 'OK');
              this.dialogRef.close();
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      } else {
        this.helperService.openSnackBar('Confirm Password Not Matching', 'OK');
      }
    }
  }

  public close() { this.dialogRef.close(); }

}
