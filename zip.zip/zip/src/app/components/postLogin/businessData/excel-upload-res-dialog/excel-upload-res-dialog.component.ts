import { HelperService } from './../../../../services/helper.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Component, Inject } from '@angular/core';

@Component({
  selector: 'app-excel-upload-res-dialog',
  templateUrl: './excel-upload-res-dialog.component.html',
  styleUrls: ['./excel-upload-res-dialog.component.css']
})
export class ExcelUploadResDialogComponent {

  public partyGridConfig = {
    editable: false,
    search: false,
    cellSearch: true,
    selectable: false,
  };
  public productGridConfig = {
    editable: false,
    search: false,
    cellSearch: true,
    selectable: false,
  };

  public excelList = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ExcelUploadResDialogComponent>,
    private helperService: HelperService
  ) {
    console.log(this.data);
    this.data.type === 'party' ? this.partyUpload() : this.productUpload();
  }

  public partyUpload() {
    if (this.data.data.acceptedRecordList) {
      this.data.data.acceptedRecordList.forEach((rec) => {
        rec.contactPerson == null ? rec.contactPerson = [{ contactPersonName: '' }] : rec.contactPerson = rec.contactPerson;
        rec.addresses == null ? rec.addresses = [{ city: '' }] : rec.addresses = rec.addresses;
        let obj = {
          'Partner Name': rec.partyName,
          'Contact Person': rec.contactPerson[0].contactPersonName,
          'Mobile No.': rec.mobile,
          'City': rec.addresses[0].city,
          'Upload Status': 'Accepted',
          'Rejection Reason': '-',
        };
        this.excelList.push(obj);
      });
    }

    if (this.data.data.rejectedRecordList) {
      this.data.data.rejectedRecordList.forEach((rec) => {
        rec.contactPerson == null ? rec.contactPerson = [{ contactPersonName: '' }] : rec.contactPerson = rec.contactPerson;
        rec.addresses == null ? rec.addresses = [{ city: '' }] : rec.addresses = rec.addresses;
        let obj = {
          'Partner Name': rec.partyName,
          'Contact Person': rec.contactPerson[0].contactPersonName,
          'Mobile No.': rec.mobile,
          'City': rec.addresses[0].city,
          'Upload Status': 'Rejected',
          'Rejection Reason': rec.rejectedReason,
        };
        this.excelList.push(obj);
      });
    }
  }

  public productUpload() {
  }

  public close() {
    this.dialogRef.close();
  }
}
