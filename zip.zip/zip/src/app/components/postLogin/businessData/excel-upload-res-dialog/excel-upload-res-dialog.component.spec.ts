import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExcelUploadResDialogComponent } from './excel-upload-res-dialog.component';

describe('ExcelUploadResDialogComponent', () => {
  let component: ExcelUploadResDialogComponent;
  let fixture: ComponentFixture<ExcelUploadResDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExcelUploadResDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExcelUploadResDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
