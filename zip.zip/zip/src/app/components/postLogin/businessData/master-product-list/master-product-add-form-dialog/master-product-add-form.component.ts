import { LoginService } from './../../../../../services/login.service';
import { ImageSizeReducerService } from './../../../../../services/image-size-reducer.service';
import { BrandService } from './../../../../../services/brand.service';
import { MasterProductListService } from './../../../../../services/master-product-list.service';
import { HelperService } from './../../../../../services/helper.service';
import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';

@Component({
  selector: 'app-master-product-add-form',
  templateUrl: './master-product-add-form.component.html',
  styleUrls: ['./master-product-add-form.component.css'],
})
export class MasterProductAddFormComponent {

  public userForm: FormGroup;
  public brandOrgCtrl: FormControl;
  public brandCtrl: FormControl;
  public categoryCodeCtrl: FormControl;
  public isLoading = false;
  public categoryCodeArray = [];
  public brandOrgs = [];
  public brands = [];
  public brandOrgImageArray = [];
  public brandOrgAttachment = [];
  public productImageAttachment = [];
  public productDocumentAttachment = [];
  public brandOrgImageId = '';
  public brandId;
  public filteredBrandsOrgs;
  public filteredBrands;
  public filteredCategoryCode;
  public nameError: false;
  public brandImageUrl = '';
  public productImageUrl = '';
  public accessToken;
  public productImageIds = [];
  public productImagesArray = [];
  public productDocumentsArray = [];
  public tags = [];
  public productExistFlag = false;
  public productCodeExistFlag = false;
  public productId;
  public touch = true;
  public selectedUOM;
  public currency = ['INR', 'USD'];
  public categoryL1 = [];
  public categoryL2 = [];
  public categoryL3 = [];
  public categoryL1Selected: boolean = true;
  public categoryL2Selected: boolean = true;
  public hsnCodeData = ['India'];
  public validFrom;
  public validTill;
  public tagName = '';
  public uomCat = [
    {
      name: 'Volume',
      uom: ['Litre', 'Gallons', 'Cusecs']
    },
    {
      name: 'Weight',
      uom: ['Kgs', 'Lbs', 'Ounces', 'Gms']
    },
    {
      name: 'Length',
      uom: ['Meters', 'Feet', 'Inches']
    },
    {
      name: 'Area',
      uom: ['Sqmt', 'Sqft', 'Acre']
    },
    {
      name: 'Count',
      uom: ['Nos', 'Pair', 'Dozen']
    },
    {
      name: 'Time',
      uom: ['Seconds', 'Minutes', 'Hours']
    },
    {
      name: 'Storage',
      uom: ['GB', 'MB', 'KB']
    }
  ];

  public placeholders = {
    productLabel: 'Product Name',
    categoryCodeLabel: 'Category Code',
    categoryL1Label: 'Category L1',
    categoryL2Label: 'Category L2',
    categoryL3Label: 'Category L3',
    productType: 'Product Type',
    productcodeLabel: 'Product Code',
    productDescriptionLabel: 'Product Description',
    brandOrgLabel: 'Brand Org Name',
    brandLabel: 'Brand Name',
    brandImagesLabel: 'Brand Images',
    brandDescriptionLabel: 'Brand Description',
    brandcodeLabel: 'Brand Code',
    tagsLabel: 'Add Tags',
    hsnCodeLabel: 'HSN Code',
    productDocumentsLabel: 'Product Documents',
    productImagesLabel: 'Product Images',
    uomCategoryLabel: 'UOM Category',
    uomLabel: 'UOM',
    uomValueLabel: 'UOM Value',
    priceLabel: 'Price',
    currencyLabel: 'Currency',
    validFromLabel: 'Valid From',
    validTillLabel: 'Valid Till',
    taxType1Label: 'Tax Type 1',
    taxType2Label: 'Tax Type 2',
    taxType3Label: 'Tax Type 3'
  };

  constructor(
    @Inject(FormBuilder) fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private helperService: HelperService,
    private dialogRef: MatDialogRef<MasterProductAddFormComponent>,
    public masterProductListService: MasterProductListService,
    public brandService: BrandService,
    public imageSizeReducerService: ImageSizeReducerService,
    private loginService: LoginService,
  ) {

    // Get Segments = Get Category 1
    this.loginService.checkAccessToken().subscribe((token) => {
      this.masterProductListService.getSegments(token).subscribe((result) => {
        if (result.success) {
          this.categoryL1 = result.result.categories;
        }
      });
    });

    console.log('Meta Data for Invitaion', this.data);
    this.userForm = fb.group({
      productName: [''],
      categoryCode: [''],
      categoryL1: new FormControl({ value: '', disabled: false }),
      categoryL2: new FormControl({ value: '', disabled: true }),
      categoryL3: new FormControl({ value: '', disabled: true }),
      productType: [''],
      productCode: [''],
      productDescription: [''],
      brandOrg: [''],
      brand: [''],
      brandDescription: [''],
      brandCode: [''],
      tags: [''],
      hsnCode: ['India'],
      taxType1: [''],
      taxType2: [''],
      taxType3: [''],
      uomCategory: [''],
      uom: [''],
      uomValue: [''],
      price: [''],
      currency: [''],
    });

    this.setHsnDetail();

    if (data.type === 'edit') {
      this.isLoading = true;
      this.loginService.checkAccessToken().subscribe((token) => {
        this.masterProductListService.getProductById(data.row['Product Id'], token).subscribe((result) => {
          console.log('getProductById Result', result);
          if (result.success) {
            this.categoryCodeCtrl.setValue(result.result.product.referenceIds.categoryCode);
            this.categoryDataFromBrickCode();
            this.brandService.getBrandOrgByCode(result.result.product.referenceIds.brandCode, token).subscribe((brandOrgResult) => {
              console.log('getBrandOrgById Result', brandOrgResult);
              if (brandOrgResult.success) {
                this.brandOrgCtrl.setValue(brandOrgResult.result.brandOrg.name);
                this.setBrandDetails(brandOrgResult.result.brandOrg);
                brandOrgResult.result.brandOrg.brands.forEach((brand) => {
                  if (brand.code === result.result.product.referenceIds.brandCode) {
                    this.brandCtrl.setValue(brand.name);
                    const brandCode = this.userForm.get('brandCode');
                    brandCode.setValue(brand.code);
                  }
                });
                this.productId = result.result.product.id;
                this.editProductData(result.result.product);
              }
            });
          }
        });
      });
    }

    this.brandOrgCtrl = new FormControl();
    this.brandCtrl = new FormControl();
    this.categoryCodeCtrl = new FormControl();

    // Filtered CategoryCode
    this.filteredCategoryCode = this.categoryCodeCtrl.valueChanges
      .pipe(startWith(null),
        map((categoryCode) => categoryCode ? this.filterCategoryCode(categoryCode) : this.categoryCodeArray.slice()));

    // Service call to get all BrandOrgs
    this.loginService.checkAccessToken().subscribe((token) => {

      this.brandService.allBrandOrg(token).subscribe((result) => {
        console.log('allBrandOrg Result', result);
        if (result.success) {
          this.brandOrgs = result.result.brandOrgs;
          if (this.brandOrgs.length > 0) {
            this.filteredBrandsOrgs = this.brandOrgCtrl.valueChanges.pipe(startWith(null),
              map((brandOrg) => brandOrg ? this.filterBrandOrgs(brandOrg) : this.brandOrgs.slice()));
          }
        }
      });
    });
  }

  // Method to Filter BrandOrgs
  public filterBrandOrgs(name: string) {
    return this.brandOrgs.filter((brandOrg) =>
      brandOrg.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  // Method to Filter Brands
  public filterBrand(name: string) {
    return this.brands.filter((brand) =>
      brand.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  // Method to Filter CategoryCode
  public filterCategoryCode(code: string) {
    return this.categoryCodeArray.filter((categoryCode) =>
      categoryCode.suppliedCode.indexOf(code) === 0);
  }

  public duplicateProductName() {
    const inputValue = this.userForm.value.productName;
    if (inputValue !== '') {
      this.loginService.checkAccessToken().subscribe((token) => {
        this.masterProductListService.duplicateProductNameCheck(inputValue, token).subscribe((result) => {
          if (result.success) {
            result.result.isExist ? this.productExistFlag = true : this.productExistFlag = false;
          }
        });
      });
    }
  }

  public duplicateProductCode() {
    const inputValue = this.userForm.value.productCode;
    if (inputValue !== '') {
      this.loginService.checkAccessToken().subscribe((token) => {
        this.masterProductListService.duplicateProductCodeCheck(inputValue, token).subscribe((result) => {
          if (result.success) {
            result.result.isExist ? this.productCodeExistFlag = true : this.productCodeExistFlag = false;
          }
        });
      });
    }
  }

  /**
   * categorySelected
   */
  public categorySelected(type, code) {
    console.log('code', code);
    if (type === 'categoryL1') {
      this.loginService.checkAccessToken().subscribe((token) => {

        this.masterProductListService.getFamilies(code, token).subscribe((result) => {
          console.log('getFamilies Result', result);
          if (result.success) {
            this.categoryL2 = result.result.categories;
          }
        });
      });
      const ctrl = this.userForm.get('categoryL2');
      ctrl.enable();
    } else if (type === 'categoryL2') {
      this.loginService.checkAccessToken().subscribe((token) => {

        this.masterProductListService.getClasses(code, token).subscribe((result) => {
          console.log('getClasses Result', result);
          if (result.success) {
            this.categoryL3 = result.result.categories;
          }
        });
      });
      const ctrl = this.userForm.get('categoryL3');
      ctrl.enable();
    } else if (type === 'categoryL3') {
      this.loginService.checkAccessToken().subscribe((token) => {

        this.masterProductListService.getBricks(code, token).subscribe((result) => {
          console.log('getBricks Result', result);
          if (result.success) {
            this.categoryCodeArray = result.result.categories;
            this.categoryCodeCtrl.setValue(code.brickDescription);
          }
        });
      });
    } else if (type === 'categoryCode') {
      const ctrl = this.userForm.get('productType');
      ctrl.setValue(code.displayName);
    }
  }

  public close() {
    this.dialogRef.close();
  }

  public getUOM(val) {
    this.uomCat.forEach((element) => {
      if (element.name === val) {
        this.selectedUOM = element.uom;
      }
    });
  }

  public addTag() {
    let exist = false;
    this.tags.forEach((tag) => {
      if (tag.toLowerCase() === this.tagName.toLowerCase()) {
        this.helperService.openSnackBar('Tag Already Exists', 'Try Another');
        exist = true;
      }
    });
    if (!exist) {
      this.tags.push(this.tagName);
      this.tagName = '';
      this.helperService.openSnackBar('Tag Created', 'OK');
    }
  }

  public uploadProductImage(event) {
    this.imageSizeReducerService.resizeImage(event['target']['files']);
    setTimeout(() => {
      const resizedimageArray = this.imageSizeReducerService.getResizedImage();
      console.log('resizedImage', resizedimageArray);
      this.productImagesArray = resizedimageArray;
      if (resizedimageArray.length > 0) {
        let reader = new FileReader();

        reader.onload = (image: any) => {
          this.productImageUrl = image.target.result;
        };

        reader.readAsDataURL(event['target']['files'][resizedimageArray.length - 1]);
      }
    }, 2000);
  }

  public uploadProductDocuments(event) {
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < event['target']['files'].length; i++) {
      this.productDocumentsArray.push(event['target']['files'][i]);
    }
  }

  // Set Brand Details
  public setBrandDetails(brandOrg) {
    this.brands = brandOrg.brands;
    if (this.brands.length > 0) {
      this.filteredBrands = this.brandCtrl.valueChanges.pipe(
        startWith(null),
        map((brand) => brand ? this.filterBrand(brand) : this.brands.slice()));
    }

    const brandDescription = this.userForm.get('brandDescription');
    brandDescription.setValue(brandOrg.intro);

    if (brandOrg.images !== null && brandOrg.images.length !== 0 && brandOrg.images[0].id !== null) {
      this.brandOrgImageId = brandOrg.images[0].id;
      console.log('this.brandOrgImageId', this.brandOrgImageId);
    } else {
      this.brandOrgImageId = '';
    }
  }

  public setBrandCode(brand) {
    if (brand.code !== null) {
      const brandCode = this.userForm.get('brandCode');
      brandCode.setValue(brand.code);
    }
  }

  public resetBrandCode() {
    const brandCode = this.userForm.get('brandCode');
    brandCode.setValue('');
  }

  public resetBrandOrgDetails() {
    this.brandCtrl.setValue('');
    const brandCode = this.userForm.get('brandCode');
    brandCode.setValue('');
    const brandDescription = this.userForm.get('brandDescription');
    brandDescription.setValue('');
    this.brandImageUrl = '';
    this.brandOrgImageId = '';
  }

  public setHsnDetail() {
    if (this.userForm.value.hsnCode === 'India') {
      this.placeholders.taxType1Label = 'IGST';
      this.placeholders.taxType2Label = 'CGST';
      this.placeholders.taxType3Label = 'SGST';
    }
  }

  public categoryDataFromBrickCode() {
    if (this.categoryCodeCtrl.value.length === 8) {
      this.loginService.checkAccessToken().subscribe((token) => {

        this.masterProductListService.getCategory(this.categoryCodeCtrl.value, token).subscribe((result) => {
          console.log('**', result);
          if (result.success) {
            let categoryL1Object;
            let categoryL2Object;
            let categoryL3Object;
            let categoryL4Object;
            result.result.categories.forEach((category) => {
              if (category.level === 0) {
                categoryL1Object = category;
              } else if (category.level === 1) {
                categoryL2Object = category;
              } else if (category.level === 2) {
                categoryL3Object = category;
              } else if (category.level === 3) {
                categoryL4Object = category;
              }
            });

            const categoryL1 = this.userForm.get('categoryL1');
            categoryL1.setValue(categoryL1Object.displayName);

            this.categorySelected('categoryL1', categoryL1Object.id);
            const categoryL2 = this.userForm.get('categoryL2');
            categoryL2.setValue(categoryL2Object.displayName);
            categoryL2.enable();

            this.categorySelected('categoryL2', categoryL2Object.id);
            const categoryL3 = this.userForm.get('categoryL3');
            categoryL3.setValue(categoryL3Object.displayName);
            categoryL3.enable();

            const productType = this.userForm.get('productType');
            productType.setValue(categoryL4Object.displayName);
          }
        });
      });
    }
  }

  public uploadBrandOrgImage(event: any) {
    console.log(event);
    this.imageSizeReducerService.resizeImage(event['target']['files']);
    setTimeout(() => {
      const resizedimage = this.imageSizeReducerService.getResizedImage();
      console.log('resizedImage', resizedimage[0]);
      this.brandOrgImageArray = resizedimage;
      if (resizedimage[0]) {
        let reader = new FileReader();

        reader.onload = (image: any) => {
          this.brandImageUrl = image.target.result;
        };

        reader.readAsDataURL(event['target']['files'][0]);
      }
    }, 2000);
  }

  // Delete tags in Product
  public delTag(tag) {
    this.tags.splice(this.tags.indexOf(tag), 1);
    this.helperService.openSnackBar('Tag Removed', 'OK');
  }

  public submit(type) {
    this.checkBrandOrg(type);
    this.isLoading = true;
  }

  public checkBrandOrg(type) {
    let duplicateBrandOrgFlag = false;
    let duplicateBrandOrg = {};

    if (this.brandOrgs.length > 0) {
      this.brandOrgs.forEach((brandOrg) => {
        if (this.brandOrgCtrl.value === brandOrg.name) {
          duplicateBrandOrg = brandOrg;
          duplicateBrandOrgFlag = true;
        }
      });
    }

    if (duplicateBrandOrgFlag === false) {
      this.loginService.checkAccessToken().subscribe((token) => {
        this.brandService.brandOrgImageUpload(this.brandOrgImageArray, token).subscribe((brandOrgImageResult) => {
          console.log('productDocumentResult', brandOrgImageResult);
          if (brandOrgImageResult.success) {
            console.log('BrandOrgImage', brandOrgImageResult.result.images);
            this.createBrandOrg(type, brandOrgImageResult.result.images);
          } else {
            this.createBrandOrg(type, []);
          }
        });
      });
    } else {
      this.checkBrand(type, duplicateBrandOrg);
    }
  }

  public createBrandOrg(type, brandOrgImageAttachment) {
    const newBrandOrg = {
      brandOrg: {
        brands: [
          {
            code: this.userForm.value.brandCode,
            createdBy: 'string',
            defaultMargin: 0,
            intro: 'string',
            isObselete: true,
            name: this.brandCtrl.value,
          }
        ],
        createdBy: 'string',
        images: brandOrgImageAttachment,
        intro: this.userForm.value.brandDescription,
        isObselete: true,
        name: this.brandOrgCtrl.value,
      },
      orgId: 'string'
    };

    this.loginService.checkAccessToken().subscribe((token) => {
      this.brandService.createBrandOrg(newBrandOrg, token).subscribe((result) => {
        console.log('BrandOrgCreate', result);
        if (result.success) {
          this.newProduct(type);
        }
      });
    });
  }

  public checkBrand(type, brandOrg) {
    let duplicateBrandFlag = false;
    let duplicateBrand;

    if (brandOrg.brands.length > 0) {
      brandOrg.brands.forEach((brand) => {
        if (this.brandCtrl.value === brand.name) {
          duplicateBrand = brand;
          duplicateBrandFlag = true;
        }
      });
    }

    if (duplicateBrandFlag === false) {
      const newBrand = {
        brands: [
          {
            code: this.userForm.value.brandCode,
            createdBy: 'string',
            defaultMargin: 0,
            intro: 'string',
            isObselete: true,
            name: this.brandCtrl.value
          }
        ],
        id: brandOrg.id
      };
      this.loginService.checkAccessToken().subscribe((token) => {
        this.brandService.updateBrandOrg(newBrand, token).subscribe((brandUpdateResult) => {
          console.log('brandUpdateResult', brandUpdateResult);
          if (brandUpdateResult) {
            this.newProduct(type);
          }
        });
      });
    } else {
      this.newProduct(type);
    }
  }

  public newProduct(type) {
    const newProduct = {
      productName: this.userForm.value.productName,
      categoryCode: this.categoryCodeCtrl.value,
      categoryL1: this.userForm.value.categoryL1,
      categoryL2: this.userForm.value.categoryL2,
      categoryL3: this.userForm.value.categoryL3,
      productType: this.userForm.value.productType,
      productCode: this.userForm.value.productCode,
      productDescription: this.userForm.value.productDescription,
      brandOrg: this.brandOrgCtrl.value,
      brand: this.brandCtrl.value,
      brandDescription: this.userForm.value.brandDescription,
      brandCode: this.userForm.value.brandCode,
      tags: this.tags,
      hsnCode: this.userForm.value.hsnCode,
      taxType1: this.userForm.value.taxType1,
      taxType2: this.userForm.value.taxType2,
      taxType3: this.userForm.value.taxType3,
      uomCategory: this.userForm.value.uomCategory,
      uom: this.userForm.value.uom,
      uomValue: this.userForm.value.uomValue,
      price: this.userForm.value.price,
      currency: this.userForm.value.currency,
      validFrom: this.validFrom,
      validTill: this.validTill,
    };

    if (this.productImagesArray.length > 0 || this.productDocumentsArray.length > 0) {
      this.loginService.checkAccessToken().subscribe((token) => {

        this.masterProductListService.uploadImage(this.productImagesArray, token).subscribe((productImageResult) => {
          console.log('productImageResult', productImageResult);
          if (productImageResult.success) {
            this.productImageAttachment = productImageResult.result.images;
          }
          this.masterProductListService.uploadDocument(this.productDocumentsArray, token).subscribe((productDocumentResult) => {
            console.log('productDocumentResult', productDocumentResult);
            if (productDocumentResult.success) {
              this.productDocumentAttachment = productDocumentResult.result.specification;
              this.uploadProduct(newProduct, type);
            } else {
              this.uploadProduct(newProduct, type);
            }
          });
        });
      });
    } else {
      this.uploadProduct(newProduct, type);
    }
  }

  public uploadProduct(newProduct, type) {
    const productObject = {
      orgId: 'string',
      product: {
        belongsToPkg: 'string',
        code: newProduct.productCode,
        displayName: newProduct.productName,
        images: this.productImageAttachment,
        isObseleted: true,
        isVisible: true,
        longBanner: 'string',
        measuringUnit: {
          isCustom: true,
          measureType: newProduct.uomCategory,
          measureUnit: newProduct.uom,
          measureValue: newProduct.uomValue
        },
        name: newProduct.productName,
        prices: [
          {
            baseCurrency: newProduct.currency,
            basePrice: Number(newProduct.price),
            defaultMargin: 0,
            forcedDeprecated: true,
            pricingType: 'string',
            validFrom: newProduct.validFrom,
            validTo: newProduct.validTill
          }
        ],
        referenceIds: {
          brandCode: newProduct.brandCode,
          categoryCode: newProduct.categoryCode,
          faDetailsId: 'string',
          orgId: 'string'
        },
        shortBanner: newProduct.productDescription,
        specification: this.productDocumentAttachment,
        tags: newProduct.tags.toString(),
        unitType: 'BUNDLED'
      }
    };

    console.log('newProduct', productObject);

    if (type === 'add') {
      this.loginService.checkAccessToken().subscribe((token) => {
        this.masterProductListService.addProduct(productObject, token).subscribe((result) => {
          console.log(result);
          if (result.success) {
            this.isLoading = false;
            this.dialogRef.close('ProductCreated');
            this.helperService.openSnackBar('Product Created', '');
          }
        });
      });
    } else if (type === 'edit') {
      if (this.productImageAttachment.length > 0) {
        productObject.product.images = this.productImageAttachment;
      } else if (this.productImageAttachment.length === 0) {
        productObject.product.images = this.productImageIds;
      }
      productObject.product['id'] = this.productId;
      this.loginService.checkAccessToken().subscribe((token) => {
        this.masterProductListService.updateProduct(productObject, token).subscribe((result) => {
          console.log(result);
          if (result.success) {
            this.isLoading = false;
            this.dialogRef.close('ProductUpdated');
            this.helperService.openSnackBar('Product Updated', '');
          }
        });
      });
    }
  }

  public editProductData(productData) {
    this.getUOM(productData.measuringUnit.measureType);
    productData.name !== null ? this.userForm.get('productName').setValue(productData.name) : this.userForm.get('productName').setValue('');
    productData.code !== null ? this.userForm.get('productCode').setValue(productData.code) : this.userForm.get('productCode').setValue('');
    productData.shortBanner !== null ? this.userForm.get('productDescription').setValue(productData.shortBanner) : this.userForm.get('productDescription').setValue('');
    if (productData.tags !== null) { this.tags = productData.tags.split(','); }
    productData.measuringUnit.measureType !== null ? this.userForm.get('uomCategory').setValue(productData.measuringUnit.measureType) : this.userForm.get('uomCategory').setValue('');
    productData.measuringUnit.measureUnit !== null ? this.userForm.get('uom').setValue(productData.measuringUnit.measureUnit) : this.userForm.get('uom').setValue('');
    productData.measuringUnit.measureValue !== null ? this.userForm.get('uomValue').setValue(productData.measuringUnit.measureValue) : this.userForm.get('uomValue').setValue('');
    productData.prices !== null ? this.userForm.get('price').setValue(productData.prices[0].basePrice) : this.userForm.get('price').setValue('');
    productData.prices !== null ? this.userForm.get('currency').setValue(productData.prices[0].baseCurrency) : this.userForm.get('currency').setValue('');
    productData.HSNCode !== null ? this.userForm.get('hsnCode').setValue('India') : this.userForm.get('hsnCode').setValue('');
    this.setHsnDetail();
    // productData.Tax.IGST !== null ? this.userForm.get('taxType1').setValue('') : this.userForm.get('taxType1').setValue('');
    // productData.Tax.CGST !== null ? this.userForm.get('taxType2').setValue('') : this.userForm.get('taxType2').setValue('');
    // productData.Tax.SGST !== null ? this.userForm.get('taxType3').setValue('') : this.userForm.get('taxType3').setValue('');
    productData.prices !== null ? this.validFrom = new Date(productData.prices[0].validFrom) : this.validFrom = '';
    productData.prices !== null ? this.validTill = new Date(productData.prices[0].validTo) : this.validTill = '';
    if (productData.images !== null && productData.images.length > 0) {
      productData.images.forEach((image) => {
        this.productImageIds.push(image);
      });
    }
    if (productData.specification !== null && productData.specification.length > 0) {
      productData.specification.forEach((document) => {
        this.productDocumentsArray.push(document);
      });
    }
    this.isLoading = false;
  }
}
