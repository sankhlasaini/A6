import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterProductAddFormComponent } from './master-product-add-form.component';

describe('MasterProductAddFormComponent', () => {
  let component: MasterProductAddFormComponent;
  let fixture: ComponentFixture<MasterProductAddFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasterProductAddFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterProductAddFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
