import { LoginService } from './../../../../services/login.service';
import { MasterProductListService } from './../../../../services/master-product-list.service';
import { ExcelUploadResDialogComponent } from './../excel-upload-res-dialog/excel-upload-res-dialog.component';
import { HelperService } from './../../../../services/helper.service';
import { fade, slideDownEnter } from './../../../../animations';
import { MatDialog } from '@angular/material';
import { FormBuilder } from '@angular/forms';
import { MasterProductAddFormComponent } from './master-product-add-form-dialog/master-product-add-form.component';
import { Component, Inject } from '@angular/core';

@Component({
  selector: 'app-master-product-list',
  templateUrl: './master-product-list.component.html',
  styleUrls: ['./master-product-list.component.css'],
  animations: [fade, slideDownEnter]
})
export class MasterProductListComponent {

  public productGridConfig = {
    editable: true,
    search: true,
    cellSearch: true,
    selectable: true,
  }
  public pageSize = 10;
  public totalCount;
  public editRow;
  public excelLoading = false;
  public inputData = [];
  public loading;

  constructor(
    @Inject(FormBuilder) public fb: FormBuilder,
    public dialog: MatDialog,
    private helperService: HelperService,
    public masterProductListService: MasterProductListService,
    private loginService: LoginService,
  ) {
    this.getProductListByPageIndex(0, 10);
  }

  public getProductListByPageIndex(startIndex, endIndex) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.loading = true;
      this.masterProductListService.getProductListByPageIndex(startIndex, endIndex, token).subscribe((result) => {
        console.log(result);
        if (result.success) {
          this.inputData = result.result.product;
          this.loading = false;
        } else {
          this.helperService.openSnackBar('NO PRODUCT FOUND', '');
        }
      });
    });
  }

  public action(type, row) {
    const dialogRef = this.dialog.open(MasterProductAddFormComponent, {
      height: '90%',
      data: { type, row },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
      if (result === 'ProductCreated' || result === 'ProductUpdated') {
        this.inputData = [];
        this.getProductListByPageIndex(2261, 2262);
      }
    });
  }

  public getEditRow(row) {
    console.log('in ts', row);
    this.editRow = JSON.parse(JSON.stringify(row));
    this.action('edit', row);
  }

  public upload(event) {
    this.excelLoading = true;
    console.log('upload', event.srcElement.files[0]);
    if (event.srcElement.files[0]
      && (event.srcElement.files[0].type === 'application/vnd.ms-excel'
        || event.srcElement.files[0].type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    ) {
      console.log('correct');
      this.masterProductListService.uploadExcelProduct(event.srcElement.files[0]).subscribe((excelUploadRes) => {
        console.log('excelUploadRes', excelUploadRes);
        this.excelLoading = false;
        if (excelUploadRes.result.totalCount > 0) {
          const dialogRef = this.dialog.open(ExcelUploadResDialogComponent, {
            height: '80%',
            //  width: '80%',
            // position: { top: '90px', bottom: '', left: '25px', right: '25px' },
            data: { type: 'product', data: excelUploadRes },
          });
          dialogRef.afterClosed().subscribe((result) => {
            // this.findAllParty();
            console.log('data from dialog', result);
            if (result) {
              console.log('Result From ExcelUploadResDialogComponent');
            }
          });
        } else {
          this.helperService.openSnackBar('No Record Found', 'Try Another File');
        }
      });
    } else {
      this.helperService.openSnackBar('Only .xls or .xlsx allowed', 'Try Again');
    }
  }
}
