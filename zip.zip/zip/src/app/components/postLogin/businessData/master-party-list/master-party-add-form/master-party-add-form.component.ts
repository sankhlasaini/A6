import { ActivatedRoute, Router } from '@angular/router';
import { PartnerService } from './../../../../../services/postLaunch/partner.service';
import { LoginService } from './../../../../../services/login.service';
import { slideDownEnter, fade } from './../../../../../animations';
import { HelperService } from './../../../../../services/helper.service';
import { ProfileService } from './../../../../../services/profile.service';
import { TerritoryService } from './../../../../../services/postLaunch/territory.service';
import { MasterPartyService } from './../../../../../services/master-party.service';
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { TerritoryTreeSelectionDialogComponent } from '../../../account-admin/territory-setup/territory-tree-selection-dialog/territory-tree-selection-dialog.component';
import { InviteDialogComponent } from '../invite-dialog/invite-dialog.component';
import { EcoSystemService } from '../../../../../services/eco-system.service';

@Component({
  selector: 'app-master-party-add-form',
  templateUrl: './master-party-add-form.component.html',
  styleUrls: ['./master-party-add-form.component.css'],
  animations: [slideDownEnter, fade]
})
export class MasterPartyAddFormComponent {

  public partyData;
  public ecosystem;
  public urlArray = [];
  public isLinear = false;
  public firstFormGroup: FormGroup;
  public secondFormGroup: FormGroup;
  public thirdFormGroup: FormGroup;
  public parentOrgId = this.loginService.getCurrentUser().user.orgId;
  public partyGridSelectionList = [];
  public productGridSelectionList = [];
  public territoryData = [];
  public territoryList = [];
  public tempArray = [];
  public countryList = [];
  public stateList = [];
  public cityList = [];
  public maxDate;
  public newTerritoryDefination = [];
  public ecoProfileList = [];
  public loading = false;
  public territoryLoading = true;
  public editMode = false;
  public orgId;
  public editPartyOrg;
  public oldTerritoryIds = [];

  public gridConfig = {
    editable: false,
    search: true,
    cellSearch: true,
    selectable: true,
  };

  constructor(
    public dialog: MatDialog,
    private route: ActivatedRoute,
    private _formBuilder: FormBuilder,
    private profileService: ProfileService,
    private territoryService: TerritoryService,
    private masterPartyService: MasterPartyService,
    private partnerService: PartnerService,
    private helperService: HelperService,
    private router: Router,
    private ecoSystemService: EcoSystemService,
    private loginService: LoginService,
  ) {
    route.url.subscribe(() => {
      this.urlArray = decodeURI(this.router.url).split('/');
    });
    this.ecosystem = this.ecoSystemService.getEcoIdByName(this.urlArray[4]);
    this.maxDate = new Date();
    const mobile = this.route.snapshot.paramMap.get('mobile');
    this.setFormGroup();
    mobile === 'add' ? this.enableAddMode() : this.enableEditMode(mobile);
  }

  public enableAddMode() {
    const breadcrumb = [{ label: 'Bussiness Data', link: '' }, { label: 'Master Party List', link: '' }, { label: 'Add Party', link: '' }];
    this.ecoSystemService.updateSharedData('breadcrumb', breadcrumb);

    this.getTerritoryList(this.parentOrgId);
    this.editMode = false;
    setTimeout(() => {
      this.enableFields();
      const profileList = this.profileService.getProfilesLocal(this.ecosystem.id);
      this.ecoProfileList = JSON.parse(JSON.stringify(profileList.filter((profile) => profile.profileSubType !== null &&
        profile.profileSubType !== undefined && profile.profileSubType.toLowerCase() !== 'account')));
    }, 100);
    this.getCountryList('add');
  }

  public enableEditMode(mobile) {
    this.loading = true;
    const partyList = this.masterPartyService.getPartyListLocal();
    console.log('Party List Getting from Local', partyList);
    const org = partyList.find((p) => p.mobile === mobile);
    if (org) {
      const breadcrumb = [{ label: 'Bussiness Data', link: '' }, { label: 'Master Party List', link: '' }, { label: org.name, link: '' }];
      this.ecoSystemService.updateSharedData('breadcrumb', breadcrumb);

      this.loading = false;
      this.partyData = JSON.parse(JSON.stringify(org));
      const profileList = this.profileService.getProfilesLocal(this.partyData.ecosystemId);
      // this.loading = true;
      this.territoryLoading = true;
      this.territoryData = [];
      this.territoryList = [];
      console.log('partyData : ', this.partyData);
      console.log('profiles : ', profileList);
      this.editMode = true;
      this.orgId = this.partyData.partyId;
      this.getTerritoryList(this.parentOrgId);
      this.ecoProfileList = JSON.parse(JSON.stringify(profileList));
      this.getCountryList('edit');
      // this.getTerritoryList(this.partyData.partyId);
      const mob = this.partyData.orgProfile.contactPersons[0].contactAddress.mobile;
      const selectedProfile = this.ecoProfileList.find((profile) => profile.id === this.partyData.orgProfile.profileTemplateId);
      const defaultAddress = this.partyData.orgProfile.contactPersons.find((add) => add.contactAddress.isDefaultAddress);
      this.firstFormGroup.patchValue({
        profile: selectedProfile,
        businessName: this.partyData.name,
        businessDescription: this.partyData.orgDescription,
        businessSummary: this.partyData.orgSummary,
        addressLabel: defaultAddress.contactAddress.addressLabel,
        contactPerson: defaultAddress.contactAddress.firstName,
        mobile: mob.length > 10 ? mob.substr(2, mob.length) : mob,
        email: defaultAddress.contactAddress.email,
        estYear: this.partyData.establishmentDate !== null ? new Date(this.partyData.establishmentDate) : '',
        address: defaultAddress.contactAddress.line1
      });
      setTimeout(() => { this.disableFields(); }, 100);
    } else {
      this.exitAddForm(false, '');
      this.helperService.openSnackBar('Party Not Found', 'OK');
    }
  }

  public disableFields() {
    this.firstFormGroup.get('businessName').disable();
    this.firstFormGroup.get('businessDescription').disable();
    this.firstFormGroup.get('businessSummary').disable();
    this.firstFormGroup.get('addressLabel').disable();
    this.firstFormGroup.get('contactPerson').disable();
    this.firstFormGroup.get('mobile').disable();
    this.firstFormGroup.get('estYear').disable();
    this.firstFormGroup.get('email').disable();
    this.firstFormGroup.get('address').disable();
    this.firstFormGroup.get('country').disable();
    this.firstFormGroup.get('state').disable();
    this.firstFormGroup.get('city').disable();
    this.firstFormGroup.get('profile').disable();
    this.firstFormGroup.get('city').disable();
    this.firstFormGroup.get('state').disable();
    this.firstFormGroup.get('country').disable();
  }

  public enableFields() {
    this.firstFormGroup.get('estYear').enable();
    this.firstFormGroup.get('profile').enable();
    this.firstFormGroup.get('city').enable();
    this.firstFormGroup.get('state').enable();
    this.firstFormGroup.get('country').enable();
  }

  public setFormGroup() {
    this.firstFormGroup = this._formBuilder.group({
      profile: ['', [Validators.required]],
      businessName: ['', [Validators.required]],
      businessDescription: ['', [Validators.maxLength(2500)]],
      businessSummary: ['', [Validators.maxLength(1500)]],
      contactPerson: ['', [Validators.required]],
      addressLabel: ['', [Validators.required]],
      mobile: ['', [Validators.required, Validators.pattern(this.helperService.mobileRegex)]],
      email: ['', [Validators.required, Validators.pattern(this.helperService.emailRegex)]],
      estYear: [''],
      country: [{ value: '', disabled: true }, [Validators.required]],
      state: ['', [Validators.required]],
      city: ['', [Validators.required]],
      address: [''],
      territory: ['', [Validators.required]]
    });

    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: new FormControl('', [Validators.required])
    });
    this.thirdFormGroup = this._formBuilder.group({
      thirdCtrl: new FormControl('', [Validators.required])
    });
  }

  public getTerritoryList(orgId) {
    const territoryListLocal = this.territoryService.getPrimaryOrgTerritoryListLocal();
    console.log(territoryListLocal);
    if (territoryListLocal) {
      console.log('Territory List MASTER::: ' + orgId, territoryListLocal);
      this.initTerritoryList(territoryListLocal);
    } else {
      this.loginService.checkAccessToken().subscribe((token) => {
        this.territoryService.retrieveTerritoriesByOrgId(token, orgId, 0, 200).subscribe((result) => {
          console.log('Territory List MASTER::: ' + orgId, result);
          if (result.success && result.result && result.result.territoryList) {
            this.territoryService.setPrimaryOrgTerritoryListLocal(result.result);
            this.initTerritoryList(result.result);
          } else {
            this.territoryLoading = false;
          }
        }, (err) => {
          this.territoryLoading = false;
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public initTerritoryList(result) {
    console.log('editMode : ', this.editMode);
    if (result.territoryList.length === 0) {
      this.helperService.openSnackBar('No Territory Found', 'Please Create Territory');
    } else {
      this.territoryList = result.territoryList;
      if (this.editMode) {
        this.patchTerritory();
      } else {
        this.territoryLoading = false;
      }
    }
  }

  public patchTerritory() {
    console.log('patch ter');
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.retrieveTerritoriesByOrgId(token, this.orgId, 0, 200).subscribe((result) => {
        console.log('Territory List DB FOR PARTY::: ' + this.orgId, result);
        if (result.success && result.result && result.result.territoryList) {
          const oldTerritoryIds = result.result.territoryList.map((ter) => ter.territoryId);
          if (oldTerritoryIds) { this.oldTerritoryIds = JSON.parse(JSON.stringify(oldTerritoryIds)); }
          const showTerritoryList = [];
          this.territoryData = this.partyData.territories ? this.partyData.territories : [];
          this.territoryData.forEach((ter) => {
            const defination = result.result.territoryList.find((t) => t.territoryId === ter.id);
            if (defination) {
              if (this.partyData.orgType !== 'ROOT_ORG') { ter.id = defination.oldTerritoryId; }
              const masterTer = this.territoryList.find((t) => t.territoryId === ter.id);
              if (masterTer) {
                showTerritoryList.push(masterTer.territoryName + ' (' + ter.territoryTree.length + ') ');
              }
            }
          });
          this.firstFormGroup.patchValue({ territory: showTerritoryList });
        }
        this.territoryLoading = false;
      }, (err) => {
        this.territoryLoading = false;
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public sendInvite() {
    // this.invite.emit(this.partyFormData);
  }

  public getCountryList(mode) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.retrieveAllCountries(token).subscribe((countryListRes) => {
        if (countryListRes.success) {
          this.countryList = countryListRes.result;
          if (mode === 'edit') {
            for (let country of this.countryList) {
              if (country.countryName === this.partyData.orgProfile.contactPersons[0].contactAddress.country) {
                this.firstFormGroup.patchValue({ country });
                this.getStateList('edit', country);
                break;
              }
            }
          }
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getStateList(mode, country) {
    this.firstFormGroup.patchValue({ state: '', city: '' });
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.getStateListByCountryId(country.placeId, token).subscribe((stateListRes) => {
        if (stateListRes.success) {
          this.stateList = stateListRes.result;
          if (mode === 'edit') {
            for (let state of this.stateList) {
              if (state.stateName === this.partyData.orgProfile.contactPersons[0].contactAddress.state) {
                this.firstFormGroup.patchValue({ state });
                this.getCityList('edit', state);
                break;
              }
            }
          }
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getCityList(mode, state) {
    this.firstFormGroup.patchValue({ city: '' });
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.getDistrictListByStateId([state.placeId], token).subscribe((cityListRes) => {
        if (cityListRes.success) {
          this.cityList = cityListRes.result;
          if (mode === 'edit') {
            for (let city of this.cityList) {
              if (city.districtName === this.partyData.orgProfile.contactPersons[0].contactAddress.city) {
                this.firstFormGroup.patchValue({ city });
                break;
              }
            }
          }
        }
        console.log(this.firstFormGroup.value);
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public previewMsg() {
    const dialogRef = this.dialog.open(InviteDialogComponent, {
      // height: '80%',
      //  width: '80%',
      // position: { top: '90px', bottom: '', left: '25px', right: '25px' },
      data: {},
    });
  }

  public selectTerritory() {
    // let selectionType = this.editMode ? undefined : 'checkbox';
    let selectionType = (this.partyData && this.partyData.orgType === 'ROOT_ORG') ? undefined : 'checkbox';
    // let selectionType = 'checkbox';
    if (!this.territoryLoading) {
      if (this.territoryList.length > 0) {
        const dialogRef = this.dialog.open(TerritoryTreeSelectionDialogComponent, {
          height: '90%',
          data: { list: this.territoryList, selected: this.territoryData, selectionType, title: 'Select Territory' },
        });
        dialogRef.afterClosed().subscribe((result) => {
          console.log('data from dialog', result);
          if (result) {
            this.territoryData = result.mapping;
            let showTerritoryList = [];
            result.mapping.forEach((ter) => {
              showTerritoryList.push(this.territoryList.find((t) => t.territoryId === ter.id).territoryName + ' (' + ter.territoryTree.length + ') ');
            });
            this.firstFormGroup.patchValue({ territory: showTerritoryList });
            // this.createTerritoryDefination('res.result.orgId', this.newTerritoryDefination, 'action');
          }
        });
      } else {
        this.helperService.openSnackBar('No Territory Found', 'Please Create Territory');
      }
    } else {
      this.helperService.openSnackBar('Getting Territory Data', 'Please try Again');
    }
  }

  public saveAddForm(action) {
    console.log('ter for defination', this.newTerritoryDefination);
    console.log('ter for mapping in update org', this.territoryData);
    console.log('------------------', this.firstFormGroup.value.profile);
    console.log(this.firstFormGroup.value);
    if (!this.firstFormGroup.valid) {
      this.helperService.openSnackBar('Please Fill Required Fields', 'OK');
    } else {
      this.loading = true;
      let orgObj = {
        ecosystemId: this.ecosystem.id,
        accountId: this.loginService.getCurrentUser().user.accountId,
        accountName: this.loginService.getCurrentUser().user.accountLabel,
        orgName: this.firstFormGroup.controls.businessName.value,
        orgSubType: this.firstFormGroup.controls.profile.value.profileSubType,
        orgType: 'PARTNER_ORG',
        orgProfileTemplateId: this.firstFormGroup.controls.profile.value.id,
        orgProfileTemplateName: this.firstFormGroup.controls.profile.value.name,
        referalOrgId: this.parentOrgId,
        partyAdminContactDetails: {
          firstName: this.firstFormGroup.controls.contactPerson.value,
          middleName: '',
          lastName: '',
          contactAddress: {
            'firstName': this.firstFormGroup.controls.contactPerson.value,
            'middleName': '',
            'lastName': '',
            'email': this.firstFormGroup.controls.email.value.toLowerCase(),
            'mobile': this.firstFormGroup.controls.mobile.value.toString(),
            'addressType': 'HEAD QUARTER',
            'addressLabel': this.firstFormGroup.controls.addressLabel.value,
            'line1': this.firstFormGroup.controls.address.value,
            'line2': '',
            'line3': '',
            'district': this.firstFormGroup.controls.city.value.districtName,
            'city': this.firstFormGroup.controls.city.value.districtName,
            'state': this.firstFormGroup.controls.state.value.stateName,
            'country': this.firstFormGroup.controls.country.value.countryName,
            'countryCode': this.firstFormGroup.controls.country.value.code,
            'isDefaultAddress': true,
            'defaultAddress': true,
          }
        },
        orgDescription: this.firstFormGroup.controls.businessDescription.value,
        orgSummary: this.firstFormGroup.controls.businessSummary.value,
        establishmentDate: this.firstFormGroup.controls.estYear.value,
        territories: []
      };

      console.log('FINAL JSON FOR PANM ::: ', orgObj);

      this.helperService.openSnackBar('Adding Party', 'Please Wait..');
      // this.createTerritoryDefination('res.result.orgId', this.newTerritoryDefination, action);
      this.editMode ? this.updateParty(this.partyData, action) : this.createParty(orgObj, action);
    }
  }

  public createParty(orgObj, action) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.masterPartyService.createParty(orgObj, token).subscribe((res) => {
        console.log(res);
        // this.disableFields(); this.editMode = true;
        if (res.success) {
          if (res.result.orgId) {
            this.newTerritoryDefination = this.territoryService.mappingToDefination(this.territoryList, this.territoryData);
            this.masterPartyService.setPartyListLocal(undefined);
            localStorage.setItem('masterPartyReload', 'true');
            this.helperService.openSnackBar('Party Added', 'OK');
            this.createTerritoryDefination(res.result.orgId, this.newTerritoryDefination, action);
          }
        } else {
          this.helperService.openSnackBar('Party Addition Failed', 'Try Again');
        }
      }, (err) => {
        this.loading = false;
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public updateParty(orgObj, action) {
    this.newTerritoryDefination = this.territoryService.mappingToDefination(this.territoryList, this.territoryData);
    console.log('--- UPDATE -----', orgObj, action);
    this.masterPartyService.setPartyListLocal(undefined);
    localStorage.setItem('masterPartyReload', 'true');
    this.helperService.openSnackBar('Party Updated', 'OK');
    // this.updateOrgWithTerritory(this.orgId, this.territoryData, action);
    this.deleteTerritories(orgObj.partyId, this.newTerritoryDefination, this.oldTerritoryIds, action);
  }

  public deleteTerritories(partyId, newTerritoryDefination, territoryIds, action) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.deleteTerritories({ territoryIds }, token).subscribe((terDeleteRes) => {
        console.log('terDeleteRes', terDeleteRes);
        if (terDeleteRes.success) {
          this.createTerritoryDefination(partyId, newTerritoryDefination, action);
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public createTerritoryDefination(orgId, terList, action) {
    terList.forEach((ter) => {
      ter.oldTerritoryId = JSON.parse(JSON.stringify(ter.territoryId));
      // ter.territoryName = ter.territoryName + '_' + new Date().getTime();
      ter.orgId = orgId;
      delete ter.territoryId;
    });
    terList = this.setNonEditableTerritory(terList);
    console.log('terList request', terList);
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.createTerritories(token, terList).subscribe((terListRes) => {
        console.log('terListRes', terListRes);
        if (terListRes.success) {
          this.helperService.openSnackBar('Territory Created For Party', 'OK');
          this.territoryData.forEach((terMap) => {
            const newTerId = terListRes.result.find((t) => t.oldTerritoryId === terMap.id);
            if (newTerId) { terMap.id = newTerId.newTerritoryId; }
          });
          console.log('ter mapping updated with latest Ids', this.territoryData);
          this.updateOrgWithTerritory(orgId, this.territoryData, action);
        } else {
          this.helperService.openSnackBar('Territory Creation Failed', 'Try Again');
        }
      }, (err) => {
        this.loading = false;
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public updateOrgWithTerritory(orgId, territories, action) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.partnerService.findOrg([{ partyId: orgId }], token).subscribe((orgRes) => {
        console.log('orgRes', orgRes);
        if (orgRes.success && orgRes.result.length > 0) {
          let org = orgRes.result[0];
          org.territories = territories;
          this.partnerService.updateOrg(org, token).subscribe((orgUpdateRes) => {
            console.log('orgUpdateRes', orgUpdateRes);
            this.loading = false;
            if (orgUpdateRes.success) {
              this.helperService.openSnackBar('Territory Mapped to Party', 'OK');
              if (action === 'exit') {
                this.exitAddForm(true, 'ADD');
              }
            } else {
              this.helperService.openSnackBar('Territory Mapping Failed', 'Try Again');
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public exitAddForm(reload, from) {

    console.log('closing add form', reload, from);
    let url = '';
    for (let i = 1; i < this.urlArray.length - 1; i++) {
      url = url + '/' + this.urlArray[i];
    }
    console.log(url);
    this.router.navigate([url]);
    // if (from === 'ADD') {
    //   this.editMode = true;
    // } else { this.editMode = false; }
    // this.outputEvent.emit({ event: 'close', reload });
  }

  public setNonEditableTerritory(terList) {
    let terArray = JSON.parse(JSON.stringify(terList));
    terArray.forEach((ter) => {
      this.modifyTerLvl(ter.territoryLevel);
    });
    return terArray;
  }

  public modifyTerLvl(lvl) {
    lvl.forEach((node) => {
      node.isEditable = false;
      if (node.subTerritoryLevel.length > 0) {
        this.modifyTerLvl(node.subTerritoryLevel);
      }
    });
  }

}
