import { ProfileService } from './../../../../../services/profile.service';
import { HelperService } from './../../../../../services/helper.service';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from './../../../../../services/login.service';
import { slideDownEnter, fade, slideUpEnter } from './../../../../../animations';
import { Component, Output, EventEmitter, Input, OnChanges } from '@angular/core';
import { MatDialog } from '@angular/material';
import { TerritoryService } from '../../../../../services/postLaunch/territory.service';
import { UserSetupService } from '../../../../../services/postLaunch/user-setup.service';
import { MasterPartyService } from '../../../../../services/master-party.service';
import { EcoSystemService } from '../../../../../services/eco-system.service';

@Component({
  selector: 'app-outlet-list',
  templateUrl: './outlet-list.component.html',
  styleUrls: ['./outlet-list.component.css'],
  animations: [slideUpEnter, fade]
})
export class OutletListComponent {

  // @Input() public party;

  // @Input() public profile;

  // @Output() public outputEvent = new EventEmitter();

  public profile;

  @Output() public outputEvent = new EventEmitter();

  public outletDataIndex;

  public reloadPartentList = false;

  public partyData;

  public usersList = [];

  public urlArray = [];

  public activeTabIndex = 0;

  public loading = true;

  public partyGridConfig = {
    editable: true,
    search: false,
    cellSearch: true,
    selectable: false,
  };

  public outletList = [{
    'Outlet Type': '',
    'Outlet Name': '',
    'Territory': '',
    'Address': '',
    'Contact Person': '',
    'Mobile': '',
    'masterId': null
  }];

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private route: ActivatedRoute,
    private loginService: LoginService,
    private ecoSystemService: EcoSystemService,
    private masterPartyService: MasterPartyService,
    private userSetupService: UserSetupService,
    private helperService: HelperService,
    private profileService: ProfileService,
    private territoryService: TerritoryService
  ) {
    route.url.subscribe(() => {
      this.urlArray = decodeURI(this.router.url).split('/');
    });
    const mobile = this.urlArray[6];
    const partyList = this.masterPartyService.getPartyListLocal();
    if (partyList) {
      const party = partyList.find((org) => org.mobile === mobile);
      if (party) {
        this.partyData = JSON.parse(JSON.stringify(party));
        const breadcrumb = [{ label: 'Bussiness Data', link: '' }, { label: 'Master Party List', link: '' }, { label: this.partyData.name, link: '' }, { label: 'Outlets', link: '' }];
        this.ecoSystemService.updateSharedData('breadcrumb', breadcrumb);
        const currentEcosystem = this.ecoSystemService.getEcoIdByName(this.urlArray[4]);
        this.profile = this.profileService.getProfilesLocal(currentEcosystem.id).find((pro) => pro.id === this.partyData.orgProfile.profileTemplateId);
        this.getUserList(this.partyData.partyId);
        console.log('party', this.partyData);
        console.log('profile', this.profile);
        this.initOutletList();
      } else {
        this.helperService.openSnackBar('Party Not Found', 'OK');
        this.back();
      }
    } else {
      this.helperService.openSnackBar('Party Not Found', 'OK');
      this.back();
    }
  }

  public initOutletList() {
    if (this.partyData.orgProfile.contactPersons.length > 1) {
      let outletList = [];
      let terIds = [];
      this.partyData.orgProfile.contactPersons.forEach((address, i) => {
        if (!address.contactAddress.isDefaultAddress) {
          if (address.contactAddress.territories) {
            terIds = terIds.concat(address.contactAddress.territories.map((ter) => ter.id));
          }
          const partyGridData = {
            'Outlet Type': address.contactAddress.addressType,
            'Outlet Name': address.contactAddress.addressLabel,
            'Territory': [],
            'Address': address.contactAddress.line1,
            'Contact Person': address.contactAddress.firstName,
            'Mobile': address.contactAddress.mobile,
            'iconAction1': { label: 'edit', event: 'edit' },
            'masterId': i,
          };
          outletList.push(partyGridData);
        }
      });
      this.outletList = outletList;
      this.getTerritoryName(terIds);
    }
  }

  public getUserList(orgId) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.userSetupService.getUserList(token, orgId, '').subscribe((userRes) => {
        this.loading = false;
        if (userRes.success) {
          this.usersList = userRes.result;
          console.log(this.usersList);
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getTerritoryName(terIds) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.getTerritoriesNameByIds(terIds, token).subscribe((idsRes) => {
        console.log(idsRes, terIds);
        if (idsRes.success) {
          const outletList = JSON.parse(JSON.stringify(this.outletList));
          this.outletList = [];
          outletList.forEach((outlet) => {
            const outletTerritory = [];
            const terData = this.partyData.orgProfile.contactPersons[outlet.masterId].contactAddress.territories;
            if (terData) {
              terData.forEach((t) => {
                const terIdObj = idsRes.result.find((tId) => tId.territoryId === t.id);
                if (terIdObj) {
                  outletTerritory.push(terIdObj.name);
                }
              });
            }
            outlet['Territory'] = outletTerritory.join(', ');
          });
          this.outletList = outletList;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public rowAction(rowId) {
    this.outletDataIndex = rowId.row;
    switch (rowId.action) {
      case 'edit':
        this.openOutletForm('edit');
        break;

      default:
        break;
    }
    console.log(rowId.action, this.partyData);
  }

  public openOutletForm(type) {
    if (type === 'add') {
      this.outletDataIndex = -1;
    }
    this.activeTabIndex = 1;
  }

  public back() {
    console.log('closing outlet list');
    let url = '';
    for (let i = 1; i < this.urlArray.length - 2; i++) {
      url = url + '/' + this.urlArray[i];
    }
    console.log(url);
    this.router.navigate([url]);
  }

  public formOutputEvent(event) {
    if (event.exit) {
      this.activeTabIndex = 0;
      if (event.reload) {
        const activePartyId = this.partyData.partyId;
        this.updatePartyList(activePartyId);
      }
    }
  }

  public updatePartyList(activePartyId) {
    this.loading = true;
    this.masterPartyService.setPartyListLocal(undefined);
    localStorage.setItem('masterPartyReload', 'true');
    this.loginService.checkAccessToken().subscribe((token) => {
      this.masterPartyService.findAllParty([{ accountId: this.loginService.getCurrentUser().user.accountId }], token).subscribe((partyListRes) => {
        console.log('Party List Res from DB', partyListRes);
        if (partyListRes.success) {
          this.masterPartyService.setPartyListLocal(partyListRes.result);
          this.partyData = partyListRes.result.find((party) => party.partyId === activePartyId);
          this.initOutletList();
          this.reloadPartentList = true;
        }
        this.loading = false;
      }, (err) => {
        this.loading = false;
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

}
