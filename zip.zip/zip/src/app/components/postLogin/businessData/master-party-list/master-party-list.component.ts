import { AccountService } from './../../../../services/account.service';
import { EcoSystemService } from './../../../../services/eco-system.service';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from './../../../../services/login.service';
import { InviteDialogComponent } from './invite-dialog/invite-dialog.component';
import { MasterPartyService } from './../../../../services/master-party.service';
import { ExcelUploadResDialogComponent } from './../excel-upload-res-dialog/excel-upload-res-dialog.component';
import { HelperService } from './../../../../services/helper.service';
import { fade, slideDownEnter, slideLeft, slideUpEnter } from './../../../../animations';
import { FormBuilder } from '@angular/forms';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ProfileService } from '../../../../services/profile.service';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-master-party-list',
  templateUrl: './master-party-list.component.html',
  styleUrls: ['./master-party-list.component.css'],
  animations: [fade, slideDownEnter, slideLeft, slideUpEnter]
})
export class MasterPartyListComponent implements OnInit {

  public accountId = this.loginService.getCurrentUser().user.accountId;
  public partyData;
  public loading = true;
  public selectedList = [];
  public fullPartyList = [];
  public activeTabIndex = 0;
  public partyGridConfig = {
    editable: true,
    search: true,
    cellSearch: true,
    selectable: false,
  };
  public readOnly = false;
  public inputData = [{
    'Business Name': '',
    'Profile': '',
    'Contact Person': '',
    'Mobile': '',
    // 'Email': '',
    'City': '',
    'Status': '',
    'masterId': null
  }];

  public excelLoading = false;
  public urlArray = [];
  public profileList = [];
  public currentEcosystem;

  constructor(
    @Inject(FormBuilder) public fb: FormBuilder,
    public dialog: MatDialog,
    private helperService: HelperService,
    private loginService: LoginService,
    private route: ActivatedRoute,
    private router: Router,
    private accountService: AccountService,
    private titleService: Title,
    private profileService: ProfileService,
    private ecoSystemService: EcoSystemService,
    private masterPartyService: MasterPartyService
  ) {
    this.titleService.setTitle('DV | Party List');
    route.url.subscribe(() => {
      const breadcrumb = [{ label: 'Bussiness Data', link: '' }, { label: 'Master Party List', link: '' }];
      this.ecoSystemService.updateSharedData('breadcrumb', breadcrumb);

      console.log('Router Changed to List', localStorage.getItem('masterPartyReload'));
      if (localStorage.getItem('masterPartyReload') === 'true') {
        localStorage.removeItem('masterPartyReload');
        this.ngOnInit();
      }

      this.urlArray = decodeURI(this.router.url).split('/');
      if (this.urlArray[6]) {
        this.activeTabIndex = 1;
      } else {
        this.activeTabIndex = 0;
      }
    });

    const mobile = this.route.snapshot.paramMap.get('mobile');
    console.log(this.route.snapshot.paramMap);
    console.log(this.route.snapshot.params);
  }

  public ngOnInit() {
    console.log('ngOnInit');
    this.currentEcosystem = this.ecoSystemService.getEcoIdByName(this.urlArray[4]);
    console.log(this.currentEcosystem);
    if (this.currentEcosystem) {
      this.profileList = this.profileService.getProfilesLocal(this.currentEcosystem.id);
      if (this.profileList) {
        this.findAllParty();
      } else {
        this.loginService.checkAccessToken().subscribe((token) => {
          this.profileService.getProfilesByEcoId(this.currentEcosystem.id, token).subscribe((res) => {
            this.profileService.setProfilesLocal({ ecosystemId: this.currentEcosystem.id, profileList: res.result });
            this.profileList = res.result;
            this.findAllParty();
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        });
      }
    }
  }

  public addParty() {
    const baseUrl = decodeURI(this.router.url);
    console.log(baseUrl);
    this.router.navigate([baseUrl, 'add']);
    this.activeTabIndex = 1;
  }

  public rowAction(rowId) {
    console.log(rowId);
    this.partyData = JSON.parse(JSON.stringify(this.fullPartyList.find((p) => p.partyId === rowId.row)));
    const baseUrl = decodeURI(this.router.url);
    console.log(baseUrl);
    switch (rowId.action) {
      case 'outlet':
        this.router.navigate([baseUrl + '/' + this.partyData.mobile + '/outlet']);
        this.activeTabIndex = 1;
        break;

      case 'edit':
        this.activeTabIndex = 1;
        this.router.navigate([baseUrl, this.partyData.mobile]);
        break;

      default:
        break;
    }
  }

  public upload(event) {
    this.excelLoading = true;
    console.log('upload', event.srcElement.files[0]);
    if (event.srcElement.files[0]
      && (event.srcElement.files[0].type === 'application/vnd.ms-excel'
        || event.srcElement.files[0].type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    ) {
      console.log('correct');
      this.loginService.checkAccessToken().subscribe((token) => {
        this.masterPartyService.uploadExcelParty(event.srcElement.files[0], token).subscribe((excelUploadRes) => {
          console.log('excelUploadRes', excelUploadRes);
          this.excelLoading = false;
          if (excelUploadRes.success) {
            if (excelUploadRes.result.totalCount > 0) {
              const dialogRef = this.dialog.open(ExcelUploadResDialogComponent, {
                height: '80%',
                //  width: '80%',
                // position: { top: '90px', bottom: '', left: '25px', right: '25px' },
                data: { type: 'party', data: excelUploadRes.result },
              });
              dialogRef.afterClosed().subscribe((result) => {
                this.findAllParty();
                console.log('data from dialog', result);
                if (result) {
                  console.log('Result From ExcelUploadResDialogComponent');
                }
              });
            } else {
              this.helperService.openSnackBar('No Record Found', 'Try Another File');
            }
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    } else {
      this.helperService.openSnackBar('Only .xls or .xlsx allowed', 'Try Again');
    }
  }

  public findAllParty() {
    this.loading = true;
    const partyList = this.masterPartyService.getPartyListLocal();
    if (partyList) {
      console.log('Party List Getting from Local', partyList);
      this.setupPartyTable(partyList);
    } else {
      console.log('Party List Getting from DB');
      this.loginService.checkAccessToken().subscribe((token) => {
        this.masterPartyService.findAllParty([{ accountId: this.accountId }], token).subscribe((partyListRes) => {
          console.log('Party List Res from DB', partyListRes);
          if (partyListRes.success) {
            this.masterPartyService.setPartyListLocal(partyListRes.result);
            this.setupPartyTable(partyListRes.result);
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public setupPartyTable(partyList) {

    if (partyList.length > 0) {
      this.inputData = [];
      this.fullPartyList = [];
      this.fullPartyList = partyList;
      partyList.forEach((element) => {
        const partyGridData = {
          'Business Name': element.name,
          'Profile': this.getProfileName(element.orgProfile.profileTemplateId),
          'Contact Person': element.orgProfile.contactPersons[0].firstName,
          'Mobile': element.mobile,
          // 'Email': element.email,
          'City': element.orgProfile.contactPersons[0].contactAddress.city,
          'Status': element.status,
          'masterId': element.partyId,
          'action1': { label: 'Outlet (' + (element.orgProfile.contactPersons.length - 1) + ')', event: 'outlet' },
          'iconAction1': { label: 'edit', event: 'edit' }
        };
        this.inputData.push(partyGridData);
      });
    } else {
      this.inputData = [{
        'Business Name': '',
        'Profile': '',
        'Contact Person': '',
        'Mobile': '',
        // 'Email': '',
        'City': '',
        'Status': '',
        'masterId': null
      }];
    }
    setTimeout(() => { this.loading = false; }, 200);
  }

  public getProfileName(id) {
    const profile = this.profileList.find((pro) => pro.id === id);
    if (profile) {
      return profile.name;
    } else {
      return '-';
    }
  }

  public listSelectEvent(list) {
    this.selectedList = [];
    list.forEach((item) => {
      this.selectedList.push(item.masterId);
    });
    console.log(this.selectedList);
  }

  public inviteParty(party) {
    this.sendInvitation([this.invitePartyJson(party)]);
  }

  public bulkInvite() {
    const dialogRef = this.dialog.open(InviteDialogComponent, {
      // height: '80%',
      //  width: '80%',
      // position: { top: '90px', bottom: '', left: '25px', right: '25px' },
      data: {},
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        let invitationList = [];
        this.fullPartyList.forEach((item) => {
          if (this.selectedList.indexOf(item.uuid) !== -1) {
            invitationList.push(this.invitePartyJson(item));
            console.log(item);
          }
        });
        console.log('Result From InviteDialogComponent', invitationList);
        this.sendInvitation(invitationList);
      }
    });
  }

  public sendInvitation(partyList) {
    this.helperService.openSnackBar('Sending Invitation', 'Please Wait...');
    this.loginService.checkAccessToken().subscribe((token) => {
      this.masterPartyService.bulkInvite(partyList, token).subscribe((res) => {
        if (res.success) {
          this.helperService.openSnackBar('Invitation Sent', 'OK');
          this.selectedList = [];
          this.findAllParty();
          console.log(res);
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public invitePartyJson(party) {
    let obj = {
      businessIdLabel: party.businessIdLabel,
      businessIdValue: party.businessIdValue,
      count: 1,
      ecosystemId: party.ecosystemProfile.ecosystemId,
      ecosystemProfileId: party.ecosystemProfile.ecosystemProfileId,
      email: party.emailAddress,
      iosURL: '',
      mobile: party.mobile,
      partyAddress: party.addresses[0],
      partySubType: 'string',
      partyType: '',
      playStoreURL: '',
      profileLabelName: party.ecosystemProfile.profileLabelName,
      invitatedPartyName: party.partyName,
      referalOrgId: party.parentOrgId,
      referalPartyName: 'LOGGED_IN_PARTY_NAME',
      referalUserName: 'DvAdmin',
      reminder: false,
      sendtoEmail: true,
      sendtoMobile: true,
      sentByExistingOnboardedParty: false,
      status: 'INVITED',
      suggestedPartner: [],
      suggestedProduct: [],
      webURL: 'string'
    };
    party.suggestedPartner.forEach((par) => {
      let sugPar = { suggestedPartnerIds: par };
      obj.suggestedPartner.push(sugPar);
    });
    party.suggestedProduct.forEach((pro) => {
      let sugPro = { suggestedProductIds: pro };
      obj.suggestedProduct.push(sugPro);
    });
    return obj;
  }

}
