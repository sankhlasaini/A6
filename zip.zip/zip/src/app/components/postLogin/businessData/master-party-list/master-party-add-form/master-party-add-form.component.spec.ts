import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterPartyAddFormComponent } from './master-party-add-form.component';

describe('MasterPartyAddFormComponent', () => {
  let component: MasterPartyAddFormComponent;
  let fixture: ComponentFixture<MasterPartyAddFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasterPartyAddFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterPartyAddFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
