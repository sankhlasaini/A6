import { HelperService } from './../../../../../services/helper.service';
import { MasterPartyService } from './../../../../../services/master-party.service';
import { MasterProductListService } from './../../../../../services/master-product-list.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Component, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { LoginService } from '../../../../../services/login.service';

@Component({
  selector: 'app-grid-dialog',
  templateUrl: './grid-dialog.component.html',
  styleUrls: ['./grid-dialog.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class GridDialogComponent {

  public selectedRowData = [];
  public inputData = [];
  public loading = true;
  public selectedList = [];
  public partyGridConfig = {
    editable: false,
    search: true,
    cellSearch: true,
    selectable: true,
  };
  public productGridConfig = {
    editable: false,
    search: true,
    cellSearch: true,
    selectable: true,
  };

  constructor(
    public dialogRef: MatDialogRef<GridDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private masterProductListService: MasterProductListService,
    private masterPartyService: MasterPartyService,
    private helperService: HelperService,
    private loginService: LoginService
  ) {
    console.log('this.data', this.data);
    if (this.data.type === 'product') {
      this.getProductData();
    } else {
      this.getPartyData();
    }
  }

  public getProductData() {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.masterProductListService.getProductListByPageIndex(0, 100, token).subscribe((productListRes) => {
        console.log('productListRes', productListRes);
        if (!productListRes.success) {
          this.inputData = [{
            'Product ID': '',
            'masterId': null,
            'Product Type': '',
            'Product Name': '',
            'Brand Name': '',
            'Product Description': ''
          }];
          this.helperService.openSnackBar('Something went wrong', 'Please Try Again');
          console.log('ERROR : ', productListRes);
        } else {
          productListRes.result.productCatalog.forEach((element) => {
            if (this.data.selected.indexOf(element.productId) === -1) {
              let obj = {
                'Product ID': element.productId,
                'masterId': element.productId,
                'Product Type': element.productType,
                'Product Name': element.name,
                'Brand Name': element.brandName,
                'Product Description': element.description
              };
              this.inputData.push(obj);
            }
          });
        }
        console.log(this.inputData);
        this.loading = false;
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getPartyData() {
    this.loginService.checkAccessToken().subscribe((token) => {
      // this.masterPartyService.findAllOrganizations(0, 100, token).subscribe((partyListRes) => {
      //   console.log('partyListRes', partyListRes);
      //   if (partyListRes.success) {
      //     partyListRes.result.forEach((element) => {
      //       if (this.data.selected.indexOf(element.uuid) === -1) {
      //         let city = '';
      //         element.addresses == null ? city = '' : city = element.addresses[0]['city'];
      //         let contactPersonName = '';
      //         element.contactPerson == null ? contactPersonName = '' : contactPersonName = element.contactPerson[0].contactPersonName;

      //         let obj = {
      //           'Party Name': element.partyName,
      //           'Contact Person': contactPersonName,
      //           'Mobile No.': element.mobile,
      //           'City': city,
      //           'masterId': element.uuid
      //         };
      //         this.inputData.push(obj);
      //       }
      //     });
      //   } else {
      //     this.inputData = [{
      //       'Party Name': '',
      //       'Contact Person': '',
      //       'Mobile No.': '',
      //       'City': '',
      //       'masterId': null
      //     }];
      //   }
      //   console.log(this.inputData);
      //   this.loading = false;
      // });
    });

  }

  public close() {
    this.dialogRef.close();
  }

  public listSelectEvent(list) {
    this.selectedList = list;
  }

  public submit() {
    let idList = [];
    this.selectedList.forEach((pro) => {
      idList.push(pro['masterId']);
    });
    console.log('selectedData', idList);
    this.dialogRef.close(idList);
  }

}
