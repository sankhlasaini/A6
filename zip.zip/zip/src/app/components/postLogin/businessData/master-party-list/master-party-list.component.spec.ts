import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterPartyListComponent } from './master-party-list.component';

describe('MasterPartyListComponent', () => {
  let component: MasterPartyListComponent;
  let fixture: ComponentFixture<MasterPartyListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasterPartyListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterPartyListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
