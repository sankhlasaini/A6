import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../../../../../services/login.service';

@Component({
  selector: 'party-invitation-message',
  templateUrl: './invitation-message.component.html',
  styleUrls: ['./invitation-message.component.css']
})
export class InvitationMessageComponent {

  public contactPerson = '';
  public businessName = '';
  public playStoreLink = 'Play Store Link';
  public appStoreLink = 'App Store Link';

  constructor(
    private loginService: LoginService
  ) {
    const currentUser = this.loginService.getCurrentUser();
    this.contactPerson = currentUser.user.name;
    this.businessName = currentUser.user.orgLabel;
  }


}
