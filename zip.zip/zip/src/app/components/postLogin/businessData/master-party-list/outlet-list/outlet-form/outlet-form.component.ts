import { Component, OnInit, ViewEncapsulation, Output, EventEmitter, Input, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { slideDownEnter, fade } from '../../../../../../animations';
import { TerritoryService } from '../../../../../../services/postLaunch/territory.service';
import { TerritoryTreeSelectionDialogComponent } from '../../../../account-admin/territory-setup/territory-tree-selection-dialog/territory-tree-selection-dialog.component';
import { PartnerService } from '../../../../../../services/postLaunch/partner.service';
import { HelperService } from '../../../../../../services/helper.service';
import { LoginService } from '../../../../../../services/login.service';
import { ConfirmationDialogComponent } from '../../../../../post-launch/common/confirmation-dialog/confirmation-dialog.component';
import { GoogleMapDialogComponent } from '../../../../../post-launch/common/google-map-dialog/google-map-dialog.component';
import { ProfileSetupService } from '../../../../../../services/postLaunch/profile-setup.service';

@Component({
  selector: 'app-outlet-form',
  templateUrl: './outlet-form.component.html',
  styleUrls: ['./outlet-form.component.css'],
  animations: [slideDownEnter, fade]
})
export class OutletFormComponent implements OnChanges {

  @Output() public outputEvent = new EventEmitter();
  @Input() public outletDataIndex;
  @Input() public profile;
  @Input() public partyData;
  @Input() public usersList;

  public outletData;
  public currentPartyData;
  public firstFormGroup: FormGroup;
  public territoryData = [];
  public territoryList = [];
  public tempArray = [];
  public newTerritoryDefination = [];
  public loading = false;
  public territoryLoading = true;
  public editMode = false;
  public editPartyOrg;
  public oldTerritoryIds = [];
  public outletTypeList = [];
  // public countryList = [];
  // public stateList = [];
  // public cityList = [];
  public clearLocationFlag = false;

  constructor(
    public dialog: MatDialog,
    private _formBuilder: FormBuilder,
    private territoryService: TerritoryService,
    private partnerService: PartnerService,
    private helperService: HelperService,
    private loginService: LoginService,
    private profileSetupService: ProfileSetupService
  ) {
  }

  public ngOnChanges() {
    this.currentPartyData = JSON.parse(JSON.stringify(this.partyData));

    console.log(this.usersList);

    // this.loading = true;
    this.outletTypeList = this.profile.attribGrps.filter((atGrp) => atGrp.sysGenName === 'def_attrib_grp_outlet_type');
    console.log(this.outletTypeList);
    this.territoryLoading = true;
    this.territoryData = [];
    this.territoryList = [];
    console.log('outletDataIndex : ', this.outletDataIndex);
    this.setFormGroup();
    if (this.outletDataIndex > -1) {
      // EDIT MODE
      this.outletData = this.currentPartyData.orgProfile.contactPersons[this.outletDataIndex];
      // this.outletData.contactAddress.googleAddressAutoFill = { pincode: false, state: false, country: false, district: false }
      this.editMode = true;
      console.log('EDIT MODE :: ', this.outletData);
      this.enableEditMode();
    } else {
      // ADD MODE
      this.editMode = false;
      this.outletData = {
        firstName: '',
        middleName: '',
        lastName: '',
        contactAddress: {
          'email': '',
          'mobile': '',
          'addressType': '',
          'addressLabel': '',
          'firstName': '',
          'middleName': '',
          'lastName': '',
          'line1': '',
          'line2': '',
          'line3': '',
          'area': null,
          'district': '',
          'city': '',
          'state': '',
          'country': '',
          'countryCode': '',
          'landmark': null,
          'pincode': null,
          'landline': null,
          'isDefaultAddress': false,
          'images': null,
          'gpsLocation': { latitude: '', longitude: '' },
          'territories': null,
          // 'googleAddressAutoFill': {
          //   pincode: false, state: false, country: false, district: false
          // }
        }
      };
      console.log('Add MODE :: ', this.outletData);
      // this.getCountryList('add');
    }
    this.getTerritoryList(this.currentPartyData.partyId);
  }

  public enableEditMode() {
    // this.getCountryList('edit');
    // this.getTerritoryList(this.partyData.partyId);
    this.firstFormGroup.patchValue({
      outletType: this.outletTypeList.find((outletType) => outletType.label === this.outletData.contactAddress.addressType),
      outletName: this.outletData.contactAddress.addressLabel,
      manager: this.usersList.find((user) => user.mobile === this.outletData.contactAddress.mobile),
      address : this.outletData.contactAddress.line1
    });
  }

  public setFormGroup() {
    this.firstFormGroup = this._formBuilder.group({
      outletType: ['', [Validators.required]],
      outletName: ['', [Validators.required, Validators.maxLength(40)]],
      manager: ['', [Validators.required]],
      territory: ['', [Validators.required]],
      address: ['', [Validators.required]]
    });
  }

  public getTerritoryList(orgId) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.retrieveTerritoriesByOrgId(token, orgId, 0, 200).subscribe((result) => {
        console.log('Territory List MASTER::: ' + orgId, result);
        if (result.success && result.result && result.result.territoryList) {
          this.initTerritoryList(result.result);
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public initTerritoryList(result) {
    console.log('editMode : ', this.editMode);
    if (result.territoryList.length === 0) {
      this.helperService.openSnackBar('No Territory Found', 'Please Create Territory');
    } else {
      this.territoryList = result.territoryList;
      if (this.editMode) { this.patchTerritory(); }
      this.territoryLoading = false;
    }
  }

  public patchTerritory() {
    console.log('patch ter');
    const showTerritoryList = [];
    this.territoryData = this.outletData.contactAddress.territories ? this.outletData.contactAddress.territories : [];
    this.territoryData.forEach((ter) => {
      const masterTer = this.territoryList.find((t) => t.territoryId === ter.id);
      if (masterTer) {
        showTerritoryList.push(masterTer.territoryName + ' (' + ter.territoryTree.length + ') ');
      }
    });
    this.firstFormGroup.patchValue({ territory: showTerritoryList });
  }

  public selectTerritory() {
    // let selectionType = this.editMode ? undefined : 'checkbox';
    let selectionType = 'checkbox';
    // let selectionType = 'checkbox';
    if (!this.territoryLoading) {
      if (this.territoryList.length > 0) {
        const dialogRef = this.dialog.open(TerritoryTreeSelectionDialogComponent, {
          height: '90%',
          data: { list: this.territoryList, selected: this.territoryData, selectionType, singleLeafSelection: true, title: 'Select Territory' },
        });
        dialogRef.afterClosed().subscribe((result) => {
          console.log('data from dialog', result);
          if (result) {
            this.territoryData = result.mapping;
            let showTerritoryList = [];
            result.mapping.forEach((ter) => {
              showTerritoryList.push(this.territoryList.find((t) => t.territoryId === ter.id).territoryName + ' (' + ter.territoryTree.length + ') ');
            });
            this.firstFormGroup.patchValue({ territory: showTerritoryList });
            // this.createTerritoryDefination('res.result.orgId', this.newTerritoryDefination, 'action');
          }
        });
      } else {
        this.helperService.openSnackBar('No Territory Found', 'Please Create Territory');
      }
    } else {
      this.helperService.openSnackBar('Getting Territory Data', 'Please try Again');
    }
  }

  public saveAddForm(action) {
    console.log('ter for defination', this.newTerritoryDefination);
    console.log('ter for mapping in update org', this.territoryData);
    console.log('------------------', this.firstFormGroup.value.profile);
    console.log(this.firstFormGroup.value);
    if (!this.firstFormGroup.valid) {
      this.helperService.openSnackBar('Please Fill Required Fields', 'OK');
    } else {
      if (this.outletData.contactAddress.country === '') {
        this.helperService.openSnackBar('Please Select Location From MAP', 'OK');
      } else {
        this.outletData.firstName = this.firstFormGroup.value.manager.name;
        this.outletData.contactAddress.email = this.firstFormGroup.value.manager.email;
        this.outletData.contactAddress.mobile = this.firstFormGroup.value.manager.mobile;
        this.outletData.contactAddress.addressType = this.firstFormGroup.value.outletType.label;
        this.outletData.contactAddress.addressLabel = this.firstFormGroup.value.outletName;
        this.outletData.contactAddress.line1 = this.firstFormGroup.value.address;
        this.outletData.contactAddress.firstName = this.firstFormGroup.value.manager.name;
        this.outletData.contactAddress.images = [];
        this.outletData.contactAddress.territories = this.territoryData;

        console.log(this.outletData);
        if (this.editMode) {
          this.currentPartyData.orgProfile.contactPersons[this.outletDataIndex] = this.outletData;
          this.updateParty(this.currentPartyData, 'edit');
        } else {
          this.currentPartyData.orgProfile.contactPersons.push(this.outletData);
          this.updateParty(this.currentPartyData, 'add');
        }
        console.log('FINAL UPDATE :::: ', this.currentPartyData);
      }
    }
  }

  public deleteOutlet(index) {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      autoFocus: false,
      data: {
        discardAction: 'CANCEL',
        autoFocus: false,
        submitAction: 'DELETE',
        title: 'Are You Sure ?',
        subTitle: this.firstFormGroup.value.outletName + ' Outlet will be Deleted'
      }
    });
    dialogRef.afterClosed().subscribe((selectedPoc) => {
      console.log('ConfirmationDialogComponent Result : ', selectedPoc);
      if (selectedPoc) {
        this.currentPartyData.orgProfile.contactPersons.splice(index, 1);
        this.updateParty(this.currentPartyData, 'edit');
      }
    });
  }

  public updateParty(orgObj, type) {
    this.loading = true;
    this.helperService.openSnackBar(type === 'edit' ? 'Updating' : 'Adding' + ' Outlet', 'Please Wait...');
    this.loginService.checkAccessToken().subscribe((token) => {
      this.partnerService.updateOrg(orgObj, token).subscribe((orgUpdateRes) => {
        console.log('orgUpdateRes', orgUpdateRes);
        this.loading = false;
        this.helperService.openSnackBar('Outlet ' + type === 'edit' ? 'Updated' : 'Added', 'OK');
        this.helperService.openSnackBar('Outlets Updated', 'OK');
        this.outputEvent.emit({ exit: true, reload: true });
      }, (err) => {
        this.loading = false;
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public exit() {
    this.outputEvent.emit({ exit: true, reload: false });
  }

  public setNonEditableTerritory(terList) {
    let terArray = JSON.parse(JSON.stringify(terList));
    terArray.forEach((ter) => {
      this.modifyTerLvl(ter.territoryLevel);
    });
    return terArray;
  }

  public modifyTerLvl(lvl) {
    lvl.forEach((node) => {
      node.isEditable = false;
      if (node.subTerritoryLevel.length > 0) {
        this.modifyTerLvl(node.subTerritoryLevel);
      }
    });
  }

  public openMap(latLong) {
    const dialogRef = this.dialog.open(GoogleMapDialogComponent, {
      // width: '50%',
      height: '70%',
      maxWidth: '100%',
      disableClose: true,
      data: { center: latLong.latitude + ',' + latLong.longitude, }
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('Result from MAP', result);
      if (result) {
        if (result.marker && result.marker.lat != null && result.marker.lng != null && result.marker.lat !== '' && result.marker.lng !== '') {
          const latlng = result.marker.lat + ',' + result.marker.lng;
          this.outletData.contactAddress.gpsLocation.latitude = result.marker.lat;
          this.outletData.contactAddress.gpsLocation.longitude = result.marker.lng;
          this.autoFillAddress(latlng);
        }
        if (result.clearLocation) {
          this.clearLocationFlag = result.clearLocation;
        }
      }
    });
  }

  public autoFillAddress(center) {
    this.profileSetupService.getAddressfromDialog(center).subscribe((res) => {
      console.log('Address from Gmaps Result : ', res);
      // if (this.clearLocationFlag) { this.clearAddress(); }
      if (res) {
        this.outletData.contactAddress.country = res.country;
        this.outletData.contactAddress.countryCode = res.countryCode;
        this.outletData.contactAddress.state = res.state;
        this.outletData.contactAddress.district = res.district;
        this.outletData.contactAddress.pincode = res.pincode;
        this.outletData.contactAddress.city = res.city;
        this.outletData.contactAddress.line2 = res.line2;
        this.outletData.contactAddress.area = res.area;
        this.outletData.contactAddress.line1 = res.address;
        this.firstFormGroup.patchValue({ address: this.outletData.contactAddress.line1 });
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });

    console.log(this.outletData);
  }

  // public clearAddress() {
  //   this.outletData.contactAddress.googleAddressAutoFill.pincode = false;
  //   this.outletData.contactAddress.googleAddressAutoFill.state = false;
  //   this.outletData.contactAddress.googleAddressAutoFill.country = false;
  //   this.outletData.contactAddress.googleAddressAutoFill.district = false;
  //   this.outletData.contactAddress.country = '';
  //   this.outletData.contactAddress.state = '';
  //   this.outletData.contactAddress.district = '';
  //   this.outletData.contactAddress.pincode = '';
  //   this.outletData.contactAddress.city = '';
  //   this.outletData.contactAddress.line2 = '';
  //   this.outletData.contactAddress.line1 = '';
  // }


}
