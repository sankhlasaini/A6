import { slideDownEnter } from './../../../../animations';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, Inject, Pipe, ViewChild, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';

@Component({
  selector: 'app-party-grid',
  templateUrl: './party-grid.component.html',
  styleUrls: ['./party-grid.component.css'],
  animations: [slideDownEnter]
})
export class PartyGridComponent implements OnChanges {

  public displayedColumns = [];
  public dataSource;
  public selection = new SelectionModel(true, []);
  public keyArray = [];
  public previousKey;
  public searchCount = 0;
  public users = [];
  public searchArray = [];
  public tableForm: FormGroup;
  public index = 0;
  public keyNames = [];
  public dataObj = {};
  public addForm = false;
  public listData = [];

  @Input() public gridConfig;

  @Input() public inputData;
  @ViewChild(MatPaginator) public paginator: MatPaginator;
  @ViewChild(MatSort) public sort: MatSort;
  @Output() public rowAction = new EventEmitter();
  @Output() public selectedList = new EventEmitter();

  public searchHeader = [];

  constructor(@Inject(FormBuilder) public fb: FormBuilder, public dialog: MatDialog) { }

  public hideCol(headerKey) {
    if (headerKey.includes('action') || headerKey.includes('iconAction') || headerKey === 'select' || headerKey === 'masterId' || headerKey === 'id' || headerKey === 'Party Setup') {
      return false;
    } else {
      return true;
    }
  }

  public checkForAction(headerKey) {
    if (headerKey.includes('iconAction')) {
      return 'icon';
    } else if (headerKey.includes('action')) {
      return 'button';
    } else {
      return null;
    }
  }

  public ngOnChanges() {
    this.displayedColumns = [];
    this.listData = JSON.parse(JSON.stringify(this.inputData));
    console.log('listData', this.listData);
    const keyObj = JSON.parse(JSON.stringify(this.listData[0]));
    this.searchHeader = Object.keys(this.listData[0]);

    if (this.gridConfig.selectable) {
      this.displayedColumns.push('select');
    }

    this.displayedColumns.push('id');

    this.searchHeader.forEach((key) => {
      this.displayedColumns.push(key);
    });

    // if (this.gridConfig.editable) {
    //   this.displayedColumns.push('action');
    // }

    console.log('displayColumn', this.displayedColumns);
    let id = 1;
    this.listData.forEach((element) => {
      element['id'] = id.toString();
      // element['editFlag'] = false;
      element['selected'] = false;
      id++;
    });

    this.users = this.listData;

    this.searchHeader.forEach((searchKey) => {
      this.keyArray.push({ key: searchKey, value: '' });
    });
    // for (let i = 1; i <= 5; i++) { users.push(createNewUser(i)); }

    // Assign the data to the data source for the table to render
    console.log(this.users);
    if (this.users.length === 1 && this.users[0].masterId == null) {
      console.log(this.users[0].masterId);
      console.log(this.users.length);
      this.dataSource = new MatTableDataSource();
    } else {
      this.dataSource = new MatTableDataSource(this.users);
    }
    this.searchHeader.forEach((key) => {
      keyObj[key] = [''];
    });
    this.tableForm = this.fb.group(keyObj);
  }

  /**
   * Set the paginator and sort after the view init since this component will
   * be able to query its view for the initialized paginator and sort.
   */
  // tslint:disable-next-line:use-life-cycle-interface
  public ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  public action(row, action) {
    this.rowAction.emit({ row, action });
  }

  public sorting() {
    // const sortedArray = this.users.filter((row) => {
    //   return row['editFlag'].toString().includes('true');
    // });
    // if (sortedArray.length > 0) {
    //   sortedArray[0].editFlag = false;
    // }
    this.dataSource.sort = this.sort;
  }
  public paginate() {
    // this.flagOff();
    this.dataSource.paginator = this.paginator;
  }
  public applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  public isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numlistData = this.dataSource.data.length;
    // console.log(numSelected, ' - ', numlistData);
    return numSelected === numlistData;
  }

  public masterToggle() {
    if (this.isAllSelected()) {
      // NO ROW SELECTED
      this.selection.clear();
      this.dataSource.data.forEach((row) => {
        row.selected = false;
      });
    } else {
      this.dataSource.data.forEach((row) => {
        row.selected = true;
        this.selection.select(row);
      });
    }
    this.selectedList.emit(this.selection.selected);
  }

  public toggleGridRow(selected, row) {
    this.selection.toggle(row);
    row.selected = selected;
    this.selectedList.emit(this.selection.selected);
  }

  // Search Method
  public searchByColumn(key, inputValue, event) {
    this.keyArray.forEach((element) => {
      if (element.key === key) {
        element.value = inputValue;
      }
    });
    this.search(key, this.keyArray, inputValue, this.listData, this.users);
  }

  public search(key, keyArray, inputValue, originalDataArray, showDataArray) {
    let searchCount = 0;
    let tempArray = [];
    const lastKey = key;
    let lastKeyValue;
    keyArray.forEach((element) => {
      tempArray = showDataArray;
      if (element.key === lastKey) {
        lastKeyValue = element.value;
      } else {

        if (searchCount === 0) {
          if (element.value !== '') {
            showDataArray = this.searchFilter(element.key, element.value, originalDataArray);
            this.dataSource = new MatTableDataSource(showDataArray);
          }
          searchCount = 1;
        } else {
          if (element.value !== '') {
            showDataArray = this.searchFilter(element.key, element.value, tempArray);
            this.dataSource = new MatTableDataSource(showDataArray);
          }
        }
      }
    });

    if (searchCount !== 0) {
      showDataArray = this.searchFilter(lastKey, lastKeyValue, tempArray);
      this.dataSource = new MatTableDataSource(showDataArray);
    }
  }

  public searchFilter(key, inputValue, dataArray) {
    return dataArray.filter((row) => {
      return row[key].toLowerCase().includes(inputValue.toLowerCase());
    });
  }

}
