import { Component, Output, Input, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-business-data',
  templateUrl: './business-data.component.html',
  styleUrls: ['./business-data.component.css'],
})
export class BusinessDataComponent {
  public businessData = true;

  @Input() public businessDataShow;

  @Output() public businessDataType = new EventEmitter();

  constructor() {

  }

  public action(type) {
    this.businessDataType.emit(type);
  }

}
