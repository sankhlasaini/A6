import { slideDownEnter } from './../../../../animations';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, Inject, Pipe, ViewChild, Input, EventEmitter, Output, OnChanges } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';

@Component({
  selector: 'app-product-grid',
  templateUrl: './product-grid.component.html',
  styleUrls: ['./product-grid.component.css'],
  animations: [slideDownEnter]
})
export class ProductGridComponent implements OnChanges {

  @Input() public gridConfig;
  @Input() public inputData;
  @Output() public editRow = new EventEmitter();

  public displayedColumns = ['select', 'id'];
  public dataSource;
  public selection = new SelectionModel(true, []);
  public keyArray = [];
  public previousKey;
  public searchCount = 0;
  public users = [];
  public listData = [];
  public searchArray = [];
  public tableForm: FormGroup;
  public index = 0;
  public keyNames = [];
  public dataObj = {};

  @ViewChild(MatPaginator) public paginator: MatPaginator;
  @ViewChild(MatSort) public sort: MatSort;

  public searchHeader = [];

  constructor( @Inject(FormBuilder) public fb: FormBuilder, public dialog: MatDialog,
  ) { }

  public ngOnChanges() {
    console.log('inputData in Product Grid', this.inputData);
    if (this.inputData.length === 0) {
      this.listData = [
        {
          // 'Image': '',
          'Product Name': '',
          'Brand Org Name': '',
          'Brand Name': '',
          'Product Type': '',
          'Product Id': '',
        },
      ];
    } else {
      this.listData = this.inputData;
    }
    const keyObj = JSON.parse(JSON.stringify(this.listData[0]));
    this.searchHeader = Object.keys(this.listData[0]);
    this.searchHeader.forEach((key) => {
      this.displayedColumns.push(key);
    });
    this.displayedColumns.push('action');

    console.log('displayColumn', this.displayedColumns);
    let id = 1;
    this.listData.forEach((element) => {
      element['id'] = id.toString();
      element['editFlag'] = false;
      element['selected'] = false;
      id++;
    });

    this.users = this.listData;

    this.searchHeader.forEach((searchKey) => {
      this.keyArray.push({ key: searchKey, value: '' });
    });
    // for (let i = 1; i <= 5; i++) { users.push(createNewUser(i)); }

    // Assign the data to the data source for the table to render

    if (this.inputData.length === 0) {
      this.dataSource = new MatTableDataSource();
    } else {
      this.dataSource = new MatTableDataSource(this.users);
    }
    this.searchHeader.forEach((key) => {
      keyObj[key] = [''];
    });
    this.tableForm = this.fb.group(keyObj);
  }

  /**
   * Set the paginator and sort after the view init since this component will
   * be able to query its view for the initialized paginator and sort.
   */
  // tslint:disable-next-line:use-life-cycle-interface
  public ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  public Edit(row) {
    this.editRow.emit(row);
  }

  public sorting() {
    this.dataSource.sort = this.sort;
  }

  public paginate() {
    this.dataSource.paginator = this.paginator;
  }

  public applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  public isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numlistData = this.dataSource.data.length;
    return numSelected === numlistData;
  }

  public masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
      this.dataSource.data.forEach((row) => {
        row.selected = false;
        console.log('row is ', row);
      });
    } else {
      this.dataSource.data.forEach((row) => {
        row.selected = true;
        this.selection.select(row);
        console.log('row is ', row);
      });
    }
  }

  public selectRow(selected, row) {
    // alert(selected);
    row.selected = selected;
    if (selected) {
      console.log(selected, row);
    }
  }

  // Search Method
  public searchByColumn(key, inputValue, event) {
    this.keyArray.forEach((element) => {
      if (element.key === key) {
        element.value = inputValue;
      }
    });
    this.search(key, this.keyArray, inputValue, this.listData, this.users);
  }

  public search(key, keyArray, inputValue, originalDataArray, showDataArray) {
    let searchCount = 0;
    let tempArray = [];
    const lastKey = key;
    let lastKeyValue;
    keyArray.forEach((element) => {
      tempArray = showDataArray;
      if (element.key === lastKey) {
        lastKeyValue = element.value;
      } else {

        if (searchCount === 0) {
          if (element.value !== '') {
            showDataArray = this.searchFilter(element.key, element.value, originalDataArray);
            this.dataSource = new MatTableDataSource(showDataArray);
          }
          searchCount = 1;
        } else {
          if (element.value !== '') {
            showDataArray = this.searchFilter(element.key, element.value, tempArray);
            this.dataSource = new MatTableDataSource(showDataArray);
          }
        }
      }
    });

    if (searchCount !== 0) {
      showDataArray = this.searchFilter(lastKey, lastKeyValue, tempArray);
      this.dataSource = new MatTableDataSource(showDataArray);
    }
  }

  public searchFilter(key, inputValue, dataArray) {
    return dataArray.filter((row) => {
      return row[key].toLowerCase().includes(inputValue.toLowerCase());
    });
  }

}
