import { Component } from '@angular/core';
import { LoginService } from '../../../services/login.service';
import { EcoSystemService } from '../../../services/eco-system.service';
import { HelperService } from '../../../services/helper.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { fade, slideUpEnter, slideUp, flip, tags } from './../../../animations';

@Component({
  selector: 'app-dv-admin',
  templateUrl: './dv-admin.component.html',
  styleUrls: ['./dv-admin.component.css'],
  animations: [fade, slideUpEnter, flip, tags, slideUp]
})
export class DvAdminComponent {

  public selectedEcoName = '';
  public loading = true;
  public ecoSystemList = [];
  public ecoSystemCount = 0;
  public ecoSystemPageSize = 100;
  public userLoading = true;
  public sideBarOpen = false;
  public sideBarMode = 'over';
  public urlArray = [];

  constructor(
    private ecoSystemService: EcoSystemService,
    private loginService: LoginService,
    private helperService: HelperService,
    private router: Router,
    private route: ActivatedRoute,
    private titleService: Title
  ) {
    if (window.screen.availWidth > 900) {
      this.sideBarOpen = true;
      this.sideBarMode = 'side';
    } else {
      this.sideBarOpen = false;
      this.sideBarMode = 'over';
    }

    route.url.subscribe(() => {
      this.urlArray = decodeURI(this.router.url).split('/');
      if (this.urlArray[3] === 'eco') {
        this.selectedEcoName = this.urlArray[4];
      }
    });

    this.ecoSystemService.getSharedData().subscribe((data) => {
      this.ecoSystemCount = 0;
      this.ecoSystemList = [];
      this.ecoSystemList = data.get('ecosystemList');
      this.ecoSystemCount = data.get('ecosystemCount');
      console.log(this.ecoSystemList);
    });

  }

  public appLoading(event) {
    if (event) {
      this.userLoading = false;
      this.getEcoSystemList();
    }
  }

  public getEcoSystemList() {
    this.loading = true;
    this.loginService.checkAccessToken().subscribe((token) => {
      token.tenantToken = 'system';
      this.ecoSystemService.getEcoSystemListCount(token).subscribe((countRes) => {
        console.log('getting eco system count RES : ', countRes);
        if (countRes.success && countRes.result.length > 0) {
          this.setEcoList(0, countRes.result[0].count);
        } else {
          this.loading = false;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  // shorting ecosystem list
  public setEcoList(i, totalCount) {
    this.loginService.checkAccessToken().subscribe((token) => {
      token.tenantToken = 'system';
      this.ecoSystemService.getEcoSystemList(i, totalCount, token).subscribe((ecoList) => {
        if (ecoList.success) {
          let fullList = JSON.parse(JSON.stringify(ecoList.result.reverse()));
          console.log('Got Record ', i, '--', totalCount, ecoList.result);
          this.ecoSystemService.setAllEcoList(totalCount, fullList);
          // this.checkEcoFromURL(this.urlArray[3], this.urlArray[4]);
          if (this.ecoSystemCount > this.ecoSystemList.length) {
            this.setEcoList(this.ecoSystemList.length, this.ecoSystemCount);
          }
          this.loading = false;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }
}
