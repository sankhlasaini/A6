import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DvAdminComponent } from './dv-admin.component';

describe('DvAdminComponent', () => {
  let component: DvAdminComponent;
  let fixture: ComponentFixture<DvAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DvAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DvAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
