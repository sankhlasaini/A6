import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Component, OnInit, Inject } from '@angular/core';

@Component({
  selector: 'app-confirm-label-dialog',
  templateUrl: './confirm-label-dialog.component.html',
  styleUrls: ['./confirm-label-dialog.component.css']
})
export class ConfirmLabelDialogComponent {

  public labelError = { error: true, type: '' };
  public labelList = [];
  public title = '';
  public newLabel = '';
  public limit = 40;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any, private dialogRef: MatDialogRef<ConfirmLabelDialogComponent>) {
    console.log(data);
    this.title = data.title;
    this.labelList = data.labelList;
    if (this.data.input) {
      this.newLabel = this.data.input;
      this.validateLabel(this.newLabel);
    }
  }

  public cancel() {
    this.dialogRef.close();
  }

  public submit() {
    if (!this.labelError.error) {
      this.dialogRef.close(this.newLabel.trim());
    }
  }

  public validateLabel(newLabel) {
    this.labelError = { error: false, type: '' };
    const label = newLabel.toLowerCase().trim();
    if (label === '') {
      this.labelError = { error: true, type: 'required' };
    } else {
      if (this.labelList.indexOf(label) === -1) {
        this.labelError = { error: false, type: '' };
      } else {
        this.labelError = { error: true, type: 'duplicate' };
      }
    }
  }

}
