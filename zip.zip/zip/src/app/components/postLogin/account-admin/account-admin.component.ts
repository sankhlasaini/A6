import { Component, OnInit, AfterViewInit, AfterViewChecked } from '@angular/core';
import { fade, slideUpEnter, slideUp, flip, tags } from './../../../animations';
import { EcoSystemService } from '../../../services/eco-system.service';
import { LoginService } from '../../../services/login.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from '../../../services/account.service';
import { MasterPartyService } from '../../../services/master-party.service';
import { TerritoryService } from '../../../services/postLaunch/territory.service';
import { ProfileService } from '../../../services/profile.service';
@Component({
  selector: 'app-account-admin',
  templateUrl: './account-admin.component.html',
  styleUrls: ['./account-admin.component.css'],
  animations: [fade, slideUpEnter, flip, tags, slideUp]
})
export class AccountAdminComponent implements OnInit {

  public userLoading = true;
  public sideBarOpen = false;
  public sideBarMode = 'over';
  public urlArray = [];
  public loading = true;
  public accountId = '';
  public accountDetails;
  public activeEcosystem;
  public ecoName = '';
  public ecoVersion = '';
  public selectionPanel = [];
  public listSetupDone = false;
  public breadcrumbs = [];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private loginService: LoginService,
    private accountService: AccountService,
    private ecoSystemService: EcoSystemService,
    private territoryService: TerritoryService,
    private profileService: ProfileService,
    private masterPartyService: MasterPartyService
  ) {
    if (window.screen.availWidth > 900) {
      this.sideBarOpen = true;
      this.sideBarMode = 'side';
    } else {
      this.sideBarOpen = false;
      this.sideBarMode = 'over';
    }
    this.route.url.subscribe(() => {
      this.urlArray = decodeURI(this.router.url).split('/');
      if (this.listSetupDone) {
        this.resetLink(this.selectionPanel);
        this.autoSelectOptions();
      }
    });
  }

  public ngOnInit() {
    this.ecoSystemService.getSharedData().subscribe((data) => {
      const bread = data.get('breadcrumb');
      if (bread) { setTimeout(() => { this.breadcrumbs = JSON.parse(JSON.stringify(bread)); }); }
    });
  }

  public appLoading(event) {
    if (event) {
      this.userLoading = false;
      this.accountId = this.loginService.getCurrentUser().user.accountId;
      console.log('Account ID : ', this.accountId);
      // this.findAllParty();
      this.territoryService.setPrimaryOrgTerritoryListLocal(undefined);
      this.masterPartyService.setPartyListLocal(undefined);
      // this.getAllTerritory(this.loginService.getCurrentUser().user.orgId);
      this.loginService.checkAccessToken().subscribe((token) => {
        token.tenantToken = 'system';
        this.accountService.findAccount({ accountId: this.accountId }, token).subscribe((res) => {
          console.log('account Result form DB', res);
          if (res.success && res.result[0]) {
            this.accountDetails = res.result[0];
            this.accountService.setAccountLocalByAcId(res.result);
            this.getEcosystemById(this.accountDetails.ecosystemIdTenant);
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public getEcosystemById(ecosystemId) {
    this.loading = true;
    this.loginService.checkAccessToken().subscribe((token) => {
      console.log('TOKEN :: ', token, ecosystemId);
      this.ecoSystemService.getEcoSystemById(ecosystemId, token).subscribe((ecoList) => {
        console.log('TESTING============================', ecoList);
        console.log('Got Record ', '--', ecoList.result);
        this.ecoSystemService.setAllEcoList(ecoList.result.length, ecoList.result);
        this.activeEcosystem = ecoList.result[0];
        this.profileService.getProfilesByEcoId(ecosystemId, token).subscribe((res) => {
          this.profileService.setProfilesLocal({ ecosystemId, profileList: res.result });
          this.loading = false;
          this.setupList();
        }, (err) => {
          this.loading = false;
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
        // this.ecoSystemService.setAllEcoList(ecoList.result.length, ecoList.result);
      }, (err) => {
        this.loading = false;
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public setupList() {
    this.ecoName = this.activeEcosystem.name;
    this.ecoVersion = this.activeEcosystem.version;
    this.selectionPanel = [{
      label: 'Manage Account',
      type: 'list',
      link: '/ecosystem/account',
      isSelected: false,
      options: [],
      icon: 'account_box'
    }, {
      label: 'Bussiness Data',
      type: 'accordion',
      link: '/ecosystem/account/eco/' + this.ecoName + '_V' + this.ecoVersion,
      icon: 'business',
      options: [{
        label: 'Territory Set-up',
        type: 'list',
        link: '/territory',
        icon: 'place',
        isSelected: false
      }, {
        label: 'Master Party List',
        type: 'list',
        link: '/masterPartyList',
        icon: 'format_list_bulleted',
        isSelected: false,
        isDisabled: false
      }, {
        label: 'Category',
        type: 'list',
        link: '',
        icon: 'format_list_bulleted',
        isSelected: false,
        isDisabled: true
      }, {
        label: 'Master Product List',
        type: 'list',
        link: '',
        icon: 'format_list_bulleted',
        isSelected: false,
        isDisabled: true
      }, {
        label: 'Master Service List',
        type: 'list',
        link: '',
        icon: 'format_list_bulleted',
        isSelected: false,
        isDisabled: true
      }],
      isSelected: false,
    },
    {
      label: this.ecoName,
      type: 'accordion',
      link: '/ecosystem/account/eco/' + this.ecoName + '_V' + this.ecoVersion,
      icon: 'public',
      options: [{
        label: 'Profile Set-up',
        type: 'list',
        icon: 'format_list_bulleted',
        link: '/profile',
        isSelected: false
      }, {
        label: 'Role Set-up',
        type: 'list',
        icon: 'format_list_bulleted',
        link: '/role',
        isSelected: false
      }],
      isSelected: false,
    }
    ];
    console.log(this.selectionPanel);
    this.autoSelectOptions();
    this.listSetupDone = true;
  }

  public autoSelectOptions() {
    if (this.urlArray[3] === 'eco') {
      if (this.urlArray[5]) {
        // tslint:disable-next-line:prefer-for-of
        for (let i = 0; i < this.selectionPanel.length; i++) {
          let option = this.selectionPanel[i].options.find((opt) => opt.link === '/' + this.urlArray[5]);
          if (option) {
            this.selectionPanel[i].isSelected = true;
            option.isSelected = true;
            break;
          }
        }
      } else {
        this.router.navigate(['/ecosystem/account']);
      }
    } else {
      this.selectionPanel[0].isSelected = true;
    }
  }

  public selectLink(i, j) {
    if (!this.selectionPanel[i].isDisabled) {
      if (j === -1 || (j > -1 && !this.selectionPanel[i].options[j].isDisabled)) {
        let redirect = '';
        redirect = this.selectionPanel[i].link;
        if (j > -1) {
          redirect = redirect + this.selectionPanel[i].options[j].link;
        }
        this.router.navigate([redirect]);
      }
    }

  }

  public resetLink(list) {
    list.forEach((item) => {
      item.isSelected = false;
      if (item.options) { this.resetLink(item.options); }
    });
  }

  // public findAllParty() {
  //   this.loading = true;
  //   this.loginService.checkAccessToken().subscribe((token) => {
  //     this.masterPartyService.findAllParty([{ accountId: this.accountId }], token).subscribe((partyListRes) => {
  //       console.log('result for Party setup', partyListRes);
  //       if (partyListRes.success && partyListRes.result.length > 0) {
  //         this.masterPartyService.setPartyListLocal(partyListRes.result);
  //       }
  //     }, (err) => {
  //       console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
  //     });
  //   }, (err) => {
  //     console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
  //   });
  // }

  // public getAllTerritory(orgId) {
  //   this.territoryService.setPrimaryOrgTerritoryListLocal(undefined);
  //   this.loginService.checkAccessToken().subscribe((token) => {
  //     this.territoryService.retrieveTerritoriesByOrgId(token, orgId, 0, 200).subscribe((result) => {
  //       console.log('Territory List RES ::: ', result);
  //       if (result.success && result.result.territoryList) {
  //         this.territoryService.setPrimaryOrgTerritoryListLocal(result.result);
  //       }
  //     });
  //   });
  // }

}
