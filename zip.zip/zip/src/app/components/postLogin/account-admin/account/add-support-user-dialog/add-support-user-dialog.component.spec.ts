import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSupportUserDialogComponent } from './add-support-user-dialog.component';

describe('AddSupportUserDialogComponent', () => {
  let component: AddSupportUserDialogComponent;
  let fixture: ComponentFixture<AddSupportUserDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddSupportUserDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddSupportUserDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
