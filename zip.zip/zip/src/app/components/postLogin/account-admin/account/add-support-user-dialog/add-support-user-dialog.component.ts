import { UserSetupService } from './../../../../../services/postLaunch/user-setup.service';
import { EcoSystemService } from './../../../../../services/eco-system.service';
import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { HelperService } from '../../../../../services/helper.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { LoginService } from '../../../../../services/login.service';

@Component({
  selector: 'app-add-support-user-dialog',
  templateUrl: './add-support-user-dialog.component.html',
  styleUrls: ['./add-support-user-dialog.component.css']
})
export class AddSupportUserDialogComponent implements OnInit {

  public userForm: FormGroup;
  public enabledActions = [];
  public allGlobalActions = [];

  constructor(
    @Inject(FormBuilder) public fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private helperService: HelperService,
    private dialogRef: MatDialogRef<AddSupportUserDialogComponent>,
    private ecoSystemService: EcoSystemService,
    private loginService: LoginService,
    private userSetupService: UserSetupService
  ) {
    console.log('----- Support Admin ----', this.data);
  }

  public ngOnInit() {
    this.actionMapping();
    this.userForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.pattern(this.helperService.emailRegex)]],
      mobile: ['', [Validators.required, Validators.pattern(this.helperService.mobileRegex)]],
    });
  }

  public actionMapping() {
    const modulesList = this.ecoSystemService.getLocalModulesAction();
    console.log('-----MODULE LIST ----', modulesList);
    modulesList.forEach((module, index) => {
      module.functionList.forEach((func) => {
        func.actionList.forEach((action) => {
          this.allGlobalActions.push(action);
        });
      });
    });

    this.roleMapping();
  }

  public roleMapping() {
    this.data.role.actionsList.forEach((action) => {
      const mapEndPoints = this.getMapEndPoints(action.actionId);
      let actObj = {
        actionId: action.actionId,
        actionLabel: mapEndPoints.action.actionLabel,
        actionVersion: mapEndPoints.action.actionVersion.toString(),
        mappedEndpointCanUris: mapEndPoints.endpoints
      };
      this.enabledActions.push(actObj);
    });
  };

  public getMapEndPoints(actionId) {
    const act = this.allGlobalActions.find((ac) => ac.actionId === actionId);
    return { action: act, endpoints: act.linkedApiIds.map((api) => api.endpointCannonicalUniqueUri) };
  }

  public supportUserObject() {
    this.helperService.openSnackBar('Sending User Invite', 'Please Wait...');
    let supportUser = {
      accountId: this.data.accountId,
      accountName: this.data.accountName,
      orgId: this.data.partyId,
      orgName: this.data.accountName,
      contactDetails: {
        firstName: this.userForm.value.name,
        middleName: '',
        lastName: '',
        contactAddress: {
          firstName: this.userForm.value.name,
          middleName: '',
          lastName: '',
          email: this.userForm.value.email.toLowerCase(),
          mobile: this.userForm.value.mobile,
          addressType: 'supportUser',
          addressLabel: '',
          line1: '',
          line2: '',
          line3: '',
          district: '',
          city: '',
          state: '',
          country: '',
          landmark: '',
          pincode: '',
          isDefaultAddress: true,
          images: [
            {
              gridFsid: '',
              gridFsFileName: ''
            }
          ],
          gpsLocation: {
            latitude: '',
            longitude: ''
          }
        }
      },
      roles: [
        {
          roleId: this.data.role.id,
          roleLabel: this.data.role.name,
          version: this.data.role.version.toString(),
          enabledActions: this.enabledActions
        }
      ],
      globalDapFilterRules: [],
      messageMode: 'BOTH',
      supervisorId: ''
    };
    this.loginService.checkAccessToken().subscribe((token) => {
      this.userSetupService.getUserById({ organizationId: this.loginService.getCurrentUser().user.orgId, isDefaultUser: true }, token).subscribe((response) => {
        console.log('getUserById ---- RESPONSE ----', response);
        if (response.success && response.result.length > 0) {
          supportUser.supervisorId = response.result[0].partyId;
        }
        this.createSupportUser(supportUser);
        console.log('---- Support User ----', supportUser);
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public createSupportUser(supportUser) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.userSetupService.userInvite(token, supportUser).subscribe((res) => {
        console.log('--- RESPONSE FROM USERINVITE ----', res);
        if (res.success) {
          this.userSetupService.setUsersListLocal(undefined);
          this.helperService.openSnackBar('User Invite sent', 'OK');
          this.dialogRef.close('OK');
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

}
