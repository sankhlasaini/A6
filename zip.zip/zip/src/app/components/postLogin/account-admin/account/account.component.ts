import { HelperService } from './../../../../services/helper.service';
import { UserSetupService } from './../../../../services/postLaunch/user-setup.service';
import { MatDialog } from '@angular/material';
import { Component, OnInit } from '@angular/core';
import { AddSupportUserDialogComponent } from './add-support-user-dialog/add-support-user-dialog.component';
import { slideUpEnter } from '../../../../animations';
import { Title } from '@angular/platform-browser';
import { EcoSystemService } from '../../../../services/eco-system.service';
import { LoginService } from '../../../../services/login.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css'],
  animations: [slideUpEnter]
})
export class AccountComponent {

  public profilesData = [];
  public accountRoleDataObj;
  public partyId;
  public roleId;
  public supportUserLoading = true;

  public partyGridConfig = {
    editable: false,
    search: false,
    cellSearch: true,
    selectable: false,
  };

  public supportUser = [{
    Name: '',
    Mobile: '',
    Status: '',
    masterId: null,
  }];

  constructor(
    public dialog: MatDialog,
    private titleService: Title,
    private userSetupService: UserSetupService,
    private loginService: LoginService,
    private ecoSystemService: EcoSystemService,
    private helperService: HelperService
  ) {
    this.titleService.setTitle('DV | Account');
    const breadcrumb = [{ label: 'Manage Account', link: '' }];
    this.ecoSystemService.updateSharedData('breadcrumb', breadcrumb);
  }

  public addSupprtUser() {
    if (this.accountRoleDataObj) {
      const dialogRef = this.dialog.open(AddSupportUserDialogComponent, {
        // height: '82%',
        // width: '60%',
        // position: { top: '90px', bottom: '', left: '25px', right: '25px' },
        data: this.accountRoleDataObj,
      });
      dialogRef.afterClosed().subscribe((result) => {
        console.log('data from dialog', result);
        if (result === 'OK') {
          this.getsupportUsers(this.partyId, this.roleId);
        }
      });
    } else {
      this.helperService.openSnackBar('Account Support Admin Role Not Found', 'OK');
    }
  }

  public accountEvent(event) {
    console.log(event);
    if (event.event === 'supportAdminRole' && event.data.role) {
      this.accountRoleDataObj = event.data;
      this.partyId = event.data.partyId;
      this.roleId = event.data.role.id;
      this.getsupportUsers(event.data.partyId, event.data.role.id);
    } else {
      this.supportUserLoading = false;
    }
  }

  public getsupportUsers(partyId, supportUserRoleId) {
    this.supportUserLoading = true;
    const objectForService = {
      organizationId: partyId,
      roles: [{ roleId: supportUserRoleId }]
    };
    console.log('---- New Object ---', objectForService);
    this.loginService.checkAccessToken().subscribe((token) => {
      this.userSetupService.getUserById(objectForService, token).subscribe((response) => {
        this.supportUserLoading = false;
        console.log('getUserById ---- RESPONSE ----', response);
        if (response.success) {
          this.supportUser = [];
          if (response.result.length > 0) {
            response.result.forEach((user) => {
              this.supportUser.push({
                Name: user.name,
                Mobile: user.mobile,
                Status: user.state,
                masterId: '',
              });
            });
          } else {
            this.supportUser.push({ Name: '', Mobile: '', Status: '', masterId: null, });
          }
        }
        console.log('---- SUPPROT USER ----', this.supportUser);
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public listSelectEvent(event) {
    console.log(event);
  }

  public partyRowAction(event) {
    console.log(event);
  }

}
