import { LoginService } from './../../../../../services/login.service';
import { HelperService } from './../../../../../services/helper.service';
import { TerritoryService } from './../../../../../services/postLaunch/territory.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { slideUpEnter } from '../../../../../animations';

@Component({
  selector: 'app-create-territory',
  templateUrl: './create-territory.component.html',
  styleUrls: ['./create-territory.component.css'],
  animations: [slideUpEnter]
})
export class CreateTerritoryComponent implements OnChanges {

  @Input() public inputData;
  @Input() public levelList;
  @Output() public outputEvent = new EventEmitter();

  public levelGrp = [];
  public levelAllowedGrp = [];
  public levelCount = [];

  constructor(
    private route: ActivatedRoute,
    private territoryService: TerritoryService,
    private helperService: HelperService,
    private loginService: LoginService,
  ) { }

  public ngOnChanges() {
    console.log('INPUT CHANGED \n', this.inputData);
    this.levelGrp = [];
    this.addLevelGrp(this.inputData);
  }

  public selectNode(levelIndex, nodeIndex, node) {
    this.levelGrp[levelIndex].nodes.map((n) => n.isSelected = false);
    node.isSelected = true;
    this.removeLevelGrp(levelIndex);
    this.addLevelGrp(node.subTerritoryLevel);
  }

  public removeLevelGrp(levelIndex) {
    while (this.levelGrp.length - 1 !== levelIndex) {
      this.levelGrp.pop();
    }
  }

  public addLevelGrp(nodes) {
    if (nodes.length > 0) {
      this.levelGrp.push({
        nodes,
        levelTitle: nodes[0].levelType,
        customLevel: this.isCustomLevel(nodes[0].levelType)
      });
      let selectedNodeIndex = this.levelGrp[this.levelGrp.length - 1].nodes.findIndex((n) => n.isSelected === true);
      this.levelGrp[this.levelGrp.length - 1].nodes.map((n) => n.isSelected = false);
      console.log('ADDING LEVEL SELECTED NODE', selectedNodeIndex, this.levelGrp[this.levelGrp.length - 1].nodes);
      if (this.levelGrp[this.levelGrp.length - 1].nodes.length > 0) {
        if (selectedNodeIndex === -1) { selectedNodeIndex = 0; }
        this.levelGrp[this.levelGrp.length - 1].nodes[selectedNodeIndex].isSelected = true;
        this.selectNode(this.levelGrp.length - 1, selectedNodeIndex, this.levelGrp[this.levelGrp.length - 1].nodes[selectedNodeIndex]);
      }
    }
    console.log('Territory Levels ', this.inputData);
    console.log('UI Levels Grp', this.levelGrp);
    this.addStandardLevel();
  }

  public addStandardLevel() {
    for (let i = this.levelGrp.length - 1; i >= 0; i--) {
      console.log(this.levelGrp[i].levelTitle);
      if (!this.isCustomLevel(this.levelGrp[i].levelTitle)) {
        if (this.levelGrp[i].nodes.length > 0) {
          let nextLevel = '';
          switch (this.levelGrp[i].levelTitle) {
            case 'country': nextLevel = 'state';
              break;
            case 'state': nextLevel = 'district';
              break;
            case 'district': nextLevel = 'town';
              break;
            case 'town': nextLevel = 'pincode';
              break;
            default:
              break;
          }
          if (nextLevel !== '') {
            this.levelGrp.push({ nodes: [], levelTitle: nextLevel, customLevel: false });
          }
        }
        break;
      }
    }
  }

  public isCustomLevel(level) {
    if (level.toLowerCase() === 'country'
      || level.toLowerCase() === 'state'
      || level.toLowerCase() === 'district'
      || level.toLowerCase() === 'town'
      || level.toLowerCase() === 'pincode') {
      return false;
    } else { return true; }
  }

  public modifyLevel(levelIndex, isCustom, actionType) {
    this.levelAllowedGrp = [];
    this.levelCount = [];
    this.checkLevelTree(this.inputData, -1);
    console.log(this.levelAllowedGrp);
    if (isCustom) {
      console.log('Custom Level : ', levelIndex);
      if (actionType === 'edit') {
        if (this.levelCount.filter((lvl) => lvl === levelIndex).length > 1) {
          this.addCustomLevel(levelIndex - 1, actionType, this.levelAllowedGrp[levelIndex]);
        } else {
          this.addCustomLevel(levelIndex - 1, actionType, '');
        }
      } else {
        let selectedParent = this.levelGrp[levelIndex].nodes.find((node) => node.isSelected);
        let noOfBranchAtLvl = this.levelCount.filter((lvl) => lvl === levelIndex + 1).length;
        console.log('NO OF BRANCH : ', noOfBranchAtLvl);
        console.log('Parent : ', selectedParent);
        switch (noOfBranchAtLvl) {
          case 0:
            this.addCustomLevel(levelIndex, actionType, '');
            break;
          case 1:
            if (selectedParent.subTerritoryLevel.length > 0) {
              console.log('ALone with data');
              this.addCustomLevel(levelIndex, actionType, '');
            } else {
              if (this.isCustomLevel(this.levelAllowedGrp[levelIndex + 1])) {
                this.addCustomLevel(levelIndex, actionType, this.levelAllowedGrp[levelIndex + 1]);
              } else {
                this.helperService.openSnackBar('Please Add ' + this.levelAllowedGrp[levelIndex + 1] + ' to Proceed', 'OK');
              }
            }
            break;
          default:
            if (selectedParent.subTerritoryLevel.length > 0) {
              this.helperService.openSnackBar(this.levelAllowedGrp[levelIndex + 1] + ' Already Defined', 'OK');
            } else {
              if (this.isCustomLevel(this.levelAllowedGrp[levelIndex + 1])) {
                this.addCustomLevel(levelIndex, actionType, this.levelAllowedGrp[levelIndex + 1]);
              } else {
                this.helperService.openSnackBar('Please Add ' + this.levelAllowedGrp[levelIndex + 1] + ' to Proceed', 'OK');
              }
            }
            break;
        }
      }
    } else {
      if (this.levelAllowedGrp[levelIndex]) {
        if (this.levelAllowedGrp[levelIndex] === this.levelGrp[levelIndex].levelTitle) {
          this.selectStandardNodes(levelIndex);
          // this.helperService.openSnackBar('VALID', this.levelAllowedGrp[levelIndex]);
        } else {
          this.helperService.openSnackBar('Please Add ' + this.levelAllowedGrp[levelIndex] + ' to Proceed', 'OK');
        }
      } else {
        this.selectStandardNodes(levelIndex);
        // this.helperService.openSnackBar('ADD ANYTHING', 'OK');
      }
    }
  }

  public selectStandardNodes(levelIndex) {
    console.log(levelIndex);
    for (let i = levelIndex - 1; i >= 0; i--) {
      if (!this.isCustomLevel(this.levelGrp[i].levelTitle)) {
        console.log(this.levelGrp[i].levelTitle);
        let selectedStandardParent = this.levelGrp[i].nodes.find((lvl) => lvl.isSelected);
        let levelParent = this.levelGrp[levelIndex - 1].nodes.find((lvl) => lvl.isSelected);
        if (selectedStandardParent && levelParent) {
          console.log(levelIndex);
          this.outputEvent.emit({
            levelType: this.levelGrp[levelIndex].levelTitle,
            isCustomLevel: false,
            standardParentId: selectedStandardParent.id,
            parent: levelParent,
            levelIndex
          });
        } else {
          this.helperService.openSnackBar('Please Select a ' + this.levelGrp[levelIndex - 1].levelTitle + ' to Proceed', 'OK');
        }
        break;
      }
    }
  }

  public addCustomLevel(levelIndex, type, levelTypeAllowed) {
    console.log(levelIndex);
    for (let i = levelIndex; i >= 0; i--) {
      if (!this.isCustomLevel(this.levelGrp[i].levelTitle)) {
        console.log(this.levelGrp[i].levelTitle);
        let selectedStandardParent = this.levelGrp[i].nodes.find((lvl) => lvl.isSelected);
        let levelParent = this.levelGrp[levelIndex].nodes.find((n) => n.isSelected);
        console.log('===============>>>>>>>>>>>>>>>>>>>> ', levelTypeAllowed);
        if (selectedStandardParent && levelParent) {
          console.log(levelIndex);
          this.outputEvent.emit({
            isCustomLevel: true,
            parent: levelParent,
            levelIndex,
            levelTypeAllowed,
            existingLevels: this.levelAllowedGrp,
            standardParent: selectedStandardParent,
            type
          });
        } else {
          this.helperService.openSnackBar('Please Select a ' + this.levelGrp[levelIndex - 1].levelTitle + ' to Proceed', 'OK');
        }
        break;
      }
    }
    console.log(this.levelGrp[levelIndex]);
  }

  public removeField(levelIndex) {
    console.log('Parent : ', this.levelGrp[levelIndex - 1].nodes.findIndex((n) => n.isSelected));
    console.log('To be Remove : ', this.levelGrp[levelIndex]);
    let childWithData = this.levelGrp[levelIndex].nodes.find((n) => n.subTerritoryLevel.length > 0);
    if (childWithData) {
      this.helperService.openSnackBar('Please Remove Level From ' + childWithData.levelName, 'OK');
    } else {
      let parentIndex = this.levelGrp[levelIndex - 1].nodes.findIndex((n) => n.isSelected);
      this.levelGrp[levelIndex - 1].nodes[parentIndex].subTerritoryLevel = [];
      this.selectNode(levelIndex - 1, parentIndex, this.levelGrp[levelIndex - 1].nodes[parentIndex]);
    }
  }

  public checkLevelTree(lvl, count) {
    count++;
    console.log('count : ', count);
    this.levelCount.push(count);
    this.levelAllowedGrp[count] = lvl[0].levelType;
    lvl.forEach((ele, i) => {
      if (ele.subTerritoryLevel.length > 0) {
        this.checkLevelTree(ele.subTerritoryLevel, count);
      }
    });
  }

}
