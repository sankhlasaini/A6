import { Component, OnInit } from '@angular/core';
import { HelperService } from '../../../../../services/helper.service';
import { LoginService } from '../../../../../services/login.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { TerritoryService } from '../../../../../services/postLaunch/territory.service';
import { TerrtioryLabelDialogComponent } from '../territory-label-dialog/territory-label-dialog.component';
import { MasterPartyService } from '../../../../../services/master-party.service';
import { PartnerService } from '../../../../../services/postLaunch/partner.service';

@Component({
  selector: 'app-define-territory',
  templateUrl: './define-territory.component.html',
  styleUrls: ['./define-territory.component.css']
})
export class DefineTerritoryComponent implements OnInit {

  public loading = true;
  public territoryData = {
    orgId: '',
    territoryName: '',
    territoryId: null,
    territoryLabelName: null,
    territoryLevel: [],
    supportedCurrency: 'INR',
    supportedTimeZone: 'IST'
  };
  public terrtioryDefaultName = '';
  public showLevelList = false;
  public listInputData;
  public urlArray = [];
  public editMode = false;
  public partyList = [];
  public orgId = this.loginService.getCurrentUser().user.orgId;

  constructor(
    private helperService: HelperService,
    private loginService: LoginService,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private partnerService: PartnerService,
    private router: Router,
    private masterPartyService: MasterPartyService,
    private territoryService: TerritoryService,
  ) {
    this.urlArray = decodeURI(this.router.url).split('/');
    this.territoryData.territoryName = this.route.snapshot.paramMap.get('id');
  }

  public ngOnInit() {
    if (this.route.snapshot.url[0].path === 'edit') {
      const dataForEdit = this.territoryService.getTerritoryData();
      this.territoryService.saveTerritoryData(undefined);
      console.log('Territory Data For Edit : ', this.territoryData);
      if (dataForEdit && dataForEdit.territoryId) {
        this.enableEditMode(dataForEdit);
      } else {
        console.log('calling list from edit');
        this.loginService.checkAccessToken().subscribe((token) => {
          this.territoryService.retrieveTerritoriesByOrgId(token, this.orgId, 0, 200).subscribe((result) => {
            console.log('Territory List ::: ', result);
            if (result.success && result.result && result.result.territoryList) {
              this.territoryService.setPrimaryOrgTerritoryListLocal(result.result);
              const territoryDB = result.result.territoryList.find((ter) =>
                (ter.territoryName.toLowerCase() === this.territoryData.territoryName.toLowerCase() && this.orgId === ter.orgId));
              if (territoryDB) {
                this.enableEditMode(territoryDB);
              } else {
                this.helperService.openSnackBar('Territory Not Found', 'OK');
                this.redirectToList();
              }
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    } else {
      if (this.territoryService.getTerritoryData() && this.territoryService.getTerritoryData().add) {
        this.findAllParty();
        this.territoryData.orgId = this.orgId;
        this.loginService.checkAccessToken().subscribe((token) => {
          this.territoryService.retrieveAllCountries(token).subscribe((countryResult) => {
            console.log('---countryResult---', countryResult);
            if (countryResult.success) {
              countryResult.result.forEach((country) => {
                this.territoryData.territoryLevel.push({
                  levelName: country.countryName,
                  id: country.placeId,
                  levelType: 'country',
                  code: country.code,
                  levelCategory: 'STANDARD',
                  isExpandable: true,
                  isEditable: true,
                  isSelected: true,
                  accessFlag: true,
                  subTerritoryLevel: []
                });
              });
            }
            this.loading = false;
            console.log('add country', this.territoryData);
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      } else {
        this.redirectToList();
      }
    }
  }

  public enableEditMode(dataForEdit) {
    this.editMode = true;
    this.terrtioryDefaultName = JSON.parse(JSON.stringify(dataForEdit.territoryName));
    this.territoryData = dataForEdit;
    this.findAllParty();
    this.loading = false;
  }

  public findAllParty() {
    const partyList = this.masterPartyService.getPartyListLocal();
    console.log('party list local ', partyList);
    if (partyList) {
      this.partyList = partyList;
    } else {
      const accountId = this.loginService.getCurrentUser().user.accountId;
      this.loginService.checkAccessToken().subscribe((token) => {
        this.masterPartyService.findAllParty([{ accountId }], token).subscribe((partyListRes) => {
          console.log('result for Party setup', partyListRes);
          if (partyListRes.success && partyListRes.result.length > 0) {
            this.partyList = partyListRes.result;
            this.masterPartyService.setPartyListLocal(partyListRes.result);
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public editTerritoryName() {
    const dialogRef = this.dialog.open(TerrtioryLabelDialogComponent, {
      data: {
        label: JSON.parse(JSON.stringify(this.territoryData.territoryName)),
        defaultLabel: this.terrtioryDefaultName.trim().toLowerCase(),
        title: 'Edit Territory Name'
      }
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
      if (result) { this.territoryData.territoryName = result; }
    });
  }

  public createTerritoryResponse(response) {
    console.log('response ::: ', response);
    this.showLevelList = true;
    this.listInputData = response;
  }

  public levelListResponse(response, listType) {
    this.showLevelList = false;
  }

  public redirectToList() {
    let url = '';
    for (let i = 1; i < this.urlArray.length - 2; i++) {
      url = url + '/' + this.urlArray[i];
    }
    console.log(url);
    this.router.navigate([url]);
  }

  public onSave() {
    console.log('Territory Data For Service FINAL', this.territoryData);
    if (this.editMode === false) {
      // delete this.territoryData.territoryId;
      this.loginService.checkAccessToken().subscribe((token) => {
        this.territoryService.createTerritory(token, this.territoryData).subscribe((result) => {
          console.log('Territory Create Res : ', result);
          if (result.success && result.result.territoryId) {
            this.territoryService.setPrimaryOrgTerritoryListLocal(undefined);
            this.helperService.openSnackBar(this.territoryData.territoryName + ' Territory Created', 'OK');
            this.updateOrgTerritoryMapping(result.result.territoryId, this.territoryData.territoryLevel);
          } else {
            this.helperService.openSnackBar(this.territoryData.territoryName + ' Territory Creation Failed', 'Try Again');
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    } else {
      this.loginService.checkAccessToken().subscribe((token) => {
        this.territoryService.updateTerritory(token, this.territoryData).subscribe((result) => {
          console.log('result', result);
          if (result.success && result.result === true) {
            this.territoryService.setPrimaryOrgTerritoryListLocal(undefined);
            this.helperService.openSnackBar(this.territoryData.territoryName + ' Territory Updated', 'OK');
            this.updateOrgTerritoryMapping(this.territoryData.territoryId, this.territoryData.territoryLevel);
          } else {
            this.helperService.openSnackBar(this.territoryData.territoryName + ' Territory Update Failed', 'Try Again');
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public updateOrgTerritoryMapping(territoryId, territoryData) {
    console.log('Territory Mapping Data :', territoryId, territoryData);
    let terObj = { id: territoryId, territoryTree: [] };
    console.log(territoryData);
    territoryData.forEach((root) => {
      this.createLeafNode(root, terObj, root.id, root.levelType);
    });
    console.log(terObj);
    if (this.partyList && this.partyList.length > 0) {
      const rootParty = this.partyList.find((p) => p.orgType === 'ROOT_ORG');
      console.log('ROOT PARTY : ', rootParty);
      if (rootParty) {
        if (!rootParty.territories) { rootParty.territories = []; }
        const index = rootParty.territories.findIndex((ter) => ter.id === territoryId);
        if (index > -1) {
          rootParty.territories[index] = terObj;
        } else {
          rootParty.territories.push(terObj);
        }
      }
      console.log(rootParty);
      this.loginService.checkAccessToken().subscribe((token) => {
        this.partnerService.updateOrg(rootParty, token).subscribe((partyUpdateRes) => {
          console.log(partyUpdateRes);
          if (partyUpdateRes.success) {
            this.masterPartyService.setPartyListLocal(undefined);
            this.helperService.openSnackBar('Territory Mapped to Party', 'OK');
          } else {
            this.helperService.openSnackBar('Territory Mapping Failed', 'OK');
          }
          this.redirectToList();
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public createLeafNode(node, terObj, selectedNodeId, selectedNodeLevelType) {
    if (node.subTerritoryLevel.length > 0) {
      node.subTerritoryLevel.forEach((n) => {
        this.createLeafNode(n, terObj, selectedNodeId, selectedNodeLevelType);
      });
    } else {
      let obj = {
        nodeId: node.id,
        nodeLevelType: node.levelType,
        selectedNodeId,
        selectedNodeLevelType
      };
      const index = terObj.territoryTree.findIndex((ter) => ter.nodeId === obj.nodeId);
      if (index !== -1) {
        terObj.territoryTree[index] = obj;
      } else {
        terObj.territoryTree.push(obj);
      }
    }
  }

}
