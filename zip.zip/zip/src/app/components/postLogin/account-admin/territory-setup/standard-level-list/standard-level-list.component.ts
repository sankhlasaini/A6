import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { TerritoryService } from '../../../../../services/postLaunch/territory.service';
import { LoginService } from '../../../../../services/login.service';
import { slideUpEnter } from '../../../../../animations';

@Component({
  selector: 'app-standard-level-list',
  templateUrl: './standard-level-list.component.html',
  styleUrls: ['./standard-level-list.component.css'],
  animations: [slideUpEnter]
})
export class StandardLevelListComponent implements OnChanges {
  @Input() public inputData;
  @Output() public outputEvent = new EventEmitter();

  public standardNodesList = [];
  public loading = true;
  public selectAll = false;
  public intermediate = false;
  public selectedNodesCount = 0;

  constructor(
    private territoryService: TerritoryService,
    private loginService: LoginService
  ) { }

  public ngOnChanges() {
    console.log('---inputData---', this.inputData);
    this.loading = true;
    switch (this.inputData.levelType) {
      case 'state':
        this.getStateList(this.inputData.parent.subTerritoryLevel, this.inputData.standardParentId);
        break;
      case 'district':
        this.getDistrictList(this.inputData.parent.subTerritoryLevel, this.inputData.standardParentId);
        break;
      case 'town':
        this.getTownList(this.inputData.parent.subTerritoryLevel, this.inputData.standardParentId);
        break;
      case 'pincode':
        this.getPincodeList(this.inputData.parent.subTerritoryLevel, this.inputData.standardParentId);
        break;
      default:
        break;
    }
  }

  public getStateList(selectedNodes, countryId) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.getStateListByCountryId(countryId, token).subscribe((stateResult) => {
        console.log('stateResult :', stateResult);
        if (stateResult.success) {
          stateResult.result.forEach((state) => {
            const selNode = selectedNodes.find((n) => (n.id === state.placeId && n.levelName === state.stateName && n.levelType === this.inputData.levelType));
            this.standardNodesList.push({
              code: state.code,
              id: state.placeId,
              levelName: state.stateName,
              levelType: this.inputData.levelType,
              isEditable: true,
              isExpandable: true,
              levelCategory: 'STANDARD',
              subTerritoryLevel: selNode ? selNode.subTerritoryLevel : [],
              isSelected: selNode ? true : false
            });
          });
          console.log(this.standardNodesList);
          this.toggleOnInit();
          this.loading = false;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getDistrictList(selectedNodes, stateId) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.getDistrictListByStateId([stateId], token).subscribe((districtResult) => {
        console.log('districtResult :', districtResult);
        if (districtResult.success) {
          districtResult.result.forEach((district) => {
            const selNode = selectedNodes.find((n) => (n.id === district.placeId && n.levelName === district.districtName && n.levelType === this.inputData.levelType));
            this.standardNodesList.push({
              id: district.placeId,
              levelName: district.districtName,
              levelType: this.inputData.levelType,
              code: district.code,
              isEditable: true,
              levelCategory: 'STANDARD',
              subTerritoryLevel: selNode ? selNode.subTerritoryLevel : [],
              isExpandable: true,
              isSelected: selNode ? true : false
            });
          });
          console.log(this.standardNodesList);
          this.toggleOnInit();
          this.loading = false;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getTownList(selectedNodes, districtId) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.getTownListByDistrictId([districtId], token).subscribe((townResult) => {
        console.log('townResult :', townResult);
        if (townResult.success) {
          townResult.result.forEach((town) => {
            const selNode = selectedNodes.find((n) => (n.id === town.placeId && n.levelName === town.townName && n.levelType === this.inputData.levelType));
            this.standardNodesList.push({
              id: town.placeId,
              levelName: town.townName,
              levelType: this.inputData.levelType,
              code: town.code,
              isEditable: true,
              isExpandable: true,
              isSelected: selNode ? true : false,
              levelCategory: 'STANDARD',
              subTerritoryLevel: selNode ? selNode.subTerritoryLevel : [],
            });
          });
          console.log(this.standardNodesList);
          this.toggleOnInit();
          this.loading = false;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getPincodeList(selectedNodes, townId) {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.territoryService.retrieveByTownIdListOrPincodeList([townId], token).subscribe((pincodeResult) => {
        console.log('pincodeResult :', pincodeResult);
        if (pincodeResult.success) {
          pincodeResult.result.forEach((pincode) => {
            const selNode = selectedNodes.find((n) => (n.id === pincode.pincodeId && n.levelName === pincode.pincode.toString() && n.levelType === this.inputData.levelType));
            this.standardNodesList.push({
              id: pincode.pincodeId,
              levelName: pincode.pincode.toString(),
              levelType: this.inputData.levelType,
              code: pincode.code,
              isEditable: true,
              isExpandable: true,
              isSelected: selNode ? true : false,
              levelCategory: 'STANDARD',
              subTerritoryLevel: selNode ? selNode.subTerritoryLevel : []
            });
          });
          console.log(this.standardNodesList);
          this.toggleOnInit();
          this.loading = false;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public toggleOnInit() {
    this.selectAll = false;
    this.intermediate = false;
    this.selectedNodesCount = this.standardNodesList.filter((n) => n.isSelected).length;
    if (this.selectedNodesCount === this.standardNodesList.length) {
      this.selectAll = true;
    } else if (0 < this.selectedNodesCount && this.selectedNodesCount < this.standardNodesList.length) {
      this.intermediate = true;
    }
  }

  public toggleNode(node) {
    node.isSelected = !node.isSelected;
    this.toggleOnInit();
  }

  public toggleAllNode() {
    this.selectAll = !this.selectAll;
    this.intermediate = false;
    this.standardNodesList.forEach((node) => {
      node.isSelected = this.selectAll;
    });
    this.selectedNodesCount = this.selectAll ? this.standardNodesList.length : 0;
  }

  public onCancel() {
    this.outputEvent.emit(undefined);
  }

  public onSave() {
    const selectedLevelNodes = this.standardNodesList.filter((n) => n.isSelected);
    this.inputData.parent.subTerritoryLevel = selectedLevelNodes;
    this.outputEvent.emit(undefined);
  }

}
