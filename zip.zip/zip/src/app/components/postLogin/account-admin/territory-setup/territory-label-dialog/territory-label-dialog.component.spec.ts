import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmLabelDialogComponent } from './confirm-label-dialog.component';

describe('ConfirmLabelDialogComponent', () => {
  let component: ConfirmLabelDialogComponent;
  let fixture: ComponentFixture<ConfirmLabelDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmLabelDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmLabelDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
