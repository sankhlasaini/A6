// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { AdditionalAttrDialogComponent } from './additional-attr-dialog.component';

// describe('AdditionalAttrDialogComponent', () => {
//   let component: AdditionalAttrDialogComponent;
//   let fixture: ComponentFixture<AdditionalAttrDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AdditionalAttrDialogComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AdditionalAttrDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
