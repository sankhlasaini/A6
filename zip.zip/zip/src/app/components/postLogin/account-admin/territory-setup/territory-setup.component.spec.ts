import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TerritorySetupComponent } from './territory-setup.component';

describe('TerritorySetupComponent', () => {
  let component: TerritorySetupComponent;
  let fixture: ComponentFixture<TerritorySetupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TerritorySetupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TerritorySetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
