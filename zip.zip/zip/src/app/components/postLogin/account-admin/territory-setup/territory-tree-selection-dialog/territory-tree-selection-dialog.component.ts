import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { HelperService } from '../../../../../services/helper.service';
import { LoginService } from '../../../../../services/login.service';
import { TerritoryService } from '../../../../../services/postLaunch/territory.service';

@Component({
  selector: 'app-territory-tree-selection-dialog',
  templateUrl: './territory-tree-selection-dialog.component.html',
  styleUrls: ['./territory-tree-selection-dialog.component.css']
})
export class TerritoryTreeSelectionDialogComponent implements OnInit {
  public orgId = '';
  public territoryList = [];
  public territoryListTree = [];
  public tempArray = [];
  public loading = false;
  public selectedFiles = [];
  public finalTree = [];
  public rootParentId = '';
  public parentIds = [];
  public tempSelectedLevelArray = [];
  public newTerritoryArray = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<TerritoryTreeSelectionDialogComponent>,
    private helperService: HelperService,
    private loginService: LoginService
  ) {
    console.log(data);
  }

  public ngOnInit() {
    this.orgId = this.loginService.getCurrentUser().user.orgId;
    this.territoryList = this.data.list;
    this.territoryList.forEach((ter) => {
      ter.territoryLevel[0]['deleteFlag'] = true;
    });
    this.territoryListTree = JSON.parse(JSON.stringify(this.territoryList));
    this.modifyData(this.territoryListTree);
    let selectedIds = [];
    this.territoryListTree.forEach((ter) => {
      ter.selectedData = [];
      let tree = this.selectedDataCheck(ter.territoryId);
      let obj = {
        id: ter.territoryId,
        name: ter.territoryName,
        territoryTree: JSON.parse(JSON.stringify(tree))
      };
      this.finalTree.push(obj);
      let arr = JSON.parse(JSON.stringify(tree)).map((node) => node.nodeId);
      selectedIds.push(arr);
    });

    console.log(this.territoryListTree);
    console.log(selectedIds);

    this.territoryListTree.forEach((ter, index) => {
      if (selectedIds[index]) {
        this.checkSelectedNode(ter.children, selectedIds[index], index);
      }
    });
  }

  public selectedDataCheck(id) {
    let tree = this.data.selected.find((d) => d.id === id);
    if (tree) { return tree.territoryTree; } else { return []; }

  }

  public modifyData(nodes) {
    nodes.forEach((node) => {
      node.levelName ? node.label = node.levelName : node.label = node.territoryName;
      node.subTerritoryLevel ? node.children = node.subTerritoryLevel : node.children = node.territoryLevel;
      if (node.children.length > 0) {
        node.leaf = false;
        if (this.data.singleLeafSelection === true) {
          node.selectable = false;
        }
        this.modifyData(node.children);
      } else {
        node.leaf = true;
      }
    });
  }

  public nodeSelect(event, index) {
    if (this.data.singleLeafSelection === true) {
      this.territoryListTree.forEach((ter, i) => {
        this.finalTree[i].territoryTree = [];
        ter.selectedData = [];
        this.removePartialSelected(ter.children);
        if (i === index) { this.checkSelectedNode(ter.children, [event.node.id], i); }
      });
    }
    let node = event.node;
    let terObj = this.finalTree[index];
    console.log(node);
    this.createLeafNode(node, terObj, event.node.id, event.node.levelType, event.node.levelName);
    console.log(this.finalTree);
  }

  public nodeUnselect(event, index) {
    let node = event.node;
    let terObj = this.finalTree[index];
    console.log(node);
    this.removeLeafNode(node, terObj);
    if (this.territoryListTree[index].selectedData.length === 0) {
      this.finalTree[index].territoryTree = [];
    }
  }

  public removeLeafNode(node, terObj) {
    if (node.children.length > 0) {
      node.children.forEach((n) => {
        this.removeLeafNode(n, terObj);
      });
    } else {
      const index = terObj.territoryTree.findIndex((n) => n.nodeId === node.id);
      terObj.territoryTree.splice(index, 1);
      // console.log('removing : ', node, index);
    }
  }

  public createLeafNode(node, terObj, selectedNodeId, selectedNodeLevelType, selectedNodeName) {
    if (node.children.length > 0) {
      node.children.forEach((n) => {
        this.createLeafNode(n, terObj, selectedNodeId, selectedNodeLevelType, selectedNodeName);
      });
    } else {
      let obj = {
        nodeId: node.id,
        nodeLevelType: node.levelType,
        nodeName: node.levelName,
        selectedNodeId,
        selectedNodeName,
        selectedNodeLevelType
      };
      const index = terObj.territoryTree.findIndex((ter) => ter.nodeId === obj.nodeId);
      if (index !== -1) {
        terObj.territoryTree[index] = obj;
      } else {
        terObj.territoryTree.push(obj);
      }
    }
  }

  public removePartialSelected(list) {
    list.forEach((ele) => {
      ele.partialSelected = false;
      if (ele.children.length > 0) {
        this.removePartialSelected(ele.children);
      }
    });
  }

  public checkSelectedNode(nodes, str, index) {
    // this.addLeafFlag(nodes);
    // console.log(nodes, str, index);
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < nodes.length; i++) {
      if (str.indexOf(nodes[i].id) > -1) {
        if (this.territoryListTree[index].selectedData.indexOf(nodes[i]) === -1) {
          this.territoryListTree[index].selectedData.push(nodes[i]);
        }
      }
      if (!nodes[i].leaf) {
        // tslint:disable-next-line:prefer-for-of
        for (let j = 0; j < nodes[i].children.length; j++) {
          // console.log(nodes[i].children[j].id);
          if (str.find((st) => st === nodes[i].children[j].id)) {
            if (!this.territoryListTree[index].selectedData.find((f) => f.id === nodes[i].children[j].id)) {
              this.territoryListTree[index].selectedData.push(nodes[i].children[j]);
            }
          }
        }
        this.checkSelectedNode(nodes[i].children, str, index);
      }
      let count = nodes[i].children.length;
      let c = 0;
      // tslint:disable-next-line:prefer-for-of
      for (let j = 0; j < nodes[i].children.length; j++) {
        if (this.territoryListTree[index].selectedData.includes(nodes[i].children[j])) {
          c++;
        }
        if (nodes[i].children[j].partialSelected) {
          nodes[i].partialSelected = true;
        }
      }
      if (c === 0) {
        console.log();
      } else if (c === count) {
        nodes[i].partialSelected = false;
        if (!this.territoryListTree[index].selectedData.includes(nodes[i])) {
          this.territoryListTree[index].selectedData.push(nodes[i]);
        }
      } else {
        nodes[i].partialSelected = true;
      }
    }
  }

  public onSubmit() {
    console.log(this.finalTree);
    this.dialogRef.close({ mapping: this.finalTree.filter((tree) => tree.territoryTree.length > 0), defination: this.newTerritoryArray });
  }

  public close() {
    this.dialogRef.close();
  }

}
