import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Component, Input, Output, EventEmitter, OnChanges, OnInit, Inject } from '@angular/core';
import { HelperService } from '../../../../../../services/helper.service';

@Component({
  selector: 'app-custom-level-selection-dialog',
  templateUrl: './custom-level-selection-dialog.component.html',
  styleUrls: ['./custom-level-selection-dialog.component.css']
})

export class CustomLevelSelectionDialogComponent implements OnInit {

  public mappingData = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<CustomLevelSelectionDialogComponent>,
    private helperService: HelperService
  ) { }

  public ngOnInit() {
    console.log(this.data);
    if (this.data.type === 'edit') {
      this.mappingData = this.data.mappingData;
      // this.data.parent.subTerritoryLevel.forEach((node) => {
      //   if (node.subTerritoryLevel.length > 0) {
      //     this.mappingData.push({ oldParent: node, newParent: this.data.selectedNodes.find((n) => n.id === node.id) });
      //   }
      // });
    } else {
      this.mappingData = [{ oldParent: this.data.parent, newParent: {} }];
    }
    console.log(this.mappingData);
  }

  public close() {
    this.dialogRef.close();
  }

  public onSubmit() {
    this.mappingData.forEach((map) => {
      if (map.newParent) {
        map.newParent.subTerritoryLevel = map.oldParent.subTerritoryLevel;
      }
    });
    this.data.parent.subTerritoryLevel = this.data.selectedNodes;
    this.dialogRef.close({ updated: true });
  }

  public clearSelection() {
    this.mappingData.map((m) => m.newParent = {});
  }

  public onSelection(index) {
    console.log(index);
    for (let i = 0; i < this.mappingData.length; i++) {
      if (i !== index) {
        console.log(i);
        if (this.mappingData[i].newParent) {
          if (this.mappingData[index].newParent.id === this.mappingData[i].newParent.id) {
            console.log('found in ', i);
            this.helperService.openSnackBar(this.mappingData[index].newParent.levelName + ' is Already Selected', 'OK');
            this.mappingData[index].newParent = {};
            break;
          }
        }
      }
    }
  }

}
