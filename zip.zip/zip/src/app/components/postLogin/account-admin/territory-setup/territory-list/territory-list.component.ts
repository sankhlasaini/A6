import { TerrtioryLabelDialogComponent } from './../territory-label-dialog/territory-label-dialog.component';
import { Component, OnInit } from '@angular/core';
import { slideUp, expend } from '../../../../../animations';
import { HelperService } from '../../../../../services/helper.service';
import { LoginService } from '../../../../../services/login.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { TerritoryService } from '../../../../../services/postLaunch/territory.service';
import { TerritoryTreeSelectionDialogComponent } from '../territory-tree-selection-dialog/territory-tree-selection-dialog.component';

@Component({
  selector: 'app-territory-list',
  templateUrl: './territory-list.component.html',
  styleUrls: ['./territory-list.component.css'],
  animations: [slideUp, expend]
})
export class TerritoryListComponent implements OnInit {

  public territoryList = [];
  public showOptions = -1;
  public orgId;
  public loading = true;

  constructor(
    private helperService: HelperService,
    private loginService: LoginService,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private router: Router,
    private territoryService: TerritoryService
  ) { }

  public ngOnInit() {
    this.loading = true;
    this.orgId = this.loginService.getCurrentUser().user.orgId;
    const territoryListLocal = this.territoryService.getPrimaryOrgTerritoryListLocal();
    if (territoryListLocal) {
      console.log('Territory List ::: ', territoryListLocal);
      this.initTerritoryList(territoryListLocal);
    } else {
      this.loginService.checkAccessToken().subscribe((token) => {
        this.territoryService.retrieveTerritoriesByOrgId(token, this.orgId, 0, 200).subscribe((result) => {
          console.log('Territory List ::: ', result);
          if (result.success && result.result && result.result.territoryList) {
            this.territoryService.setPrimaryOrgTerritoryListLocal(result.result);
            this.initTerritoryList(result.result);
          } else {
            this.loading = false;
          }
        }, (err) => {
          this.loading = false;
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public initTerritoryList(list) {
    list.territoryList.forEach((ter) => {
      let levelAllowedGrp = [];
      this.checkLevelTree(ter.territoryLevel, -1, levelAllowedGrp);
      ter.levelCount = levelAllowedGrp.length;
      this.territoryList.push(ter);
    });
    this.loading = false;
  }

  public createTerritory() {
    const dialogRef = this.dialog.open(TerrtioryLabelDialogComponent, {
      data: {
        label: '',
        title: 'Create Territory Hierarchy'
      }
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
      if (result) {
        console.log(this.router.url);
        this.territoryService.saveTerritoryData({ add: true });
        this.router.navigate([decodeURI(this.router.url) + '/add', result]);
        console.log(result);
      }
    });
  }

  public checkLevelTree(lvl, count, levelAllowedGrp) {
    count++;
    levelAllowedGrp[count] = lvl[0].levelType;
    lvl.forEach((ele, i) => {
      if (ele.subTerritoryLevel.length > 0) {
        this.checkLevelTree(ele.subTerritoryLevel, count, levelAllowedGrp);
      }
    });
  }

  public viewTerritory(ter) {
    console.log('view');
    const dialogRef = this.dialog.open(TerritoryTreeSelectionDialogComponent, {
      height: '90%',
      data: { list: [ter], selected: [], selectionType: undefined, title: 'Territory : ' + ter.territoryName },
    });
  }

  public editTerritory(ter) {
    console.log('Edit Territory ::: ', ter);
    this.territoryService.saveTerritoryData(ter);
    this.router.navigate([decodeURI(this.router.url) + '/edit', ter.territoryName]);
  }

}
