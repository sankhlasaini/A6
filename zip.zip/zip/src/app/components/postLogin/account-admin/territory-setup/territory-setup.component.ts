import { Component } from '@angular/core';
import { EcoSystemService } from '../../../../services/eco-system.service';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../../../../services/login.service';
import { slideUpEnter, expend } from '../../../../animations';
import { MatDialog } from '@angular/material';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-territory-setup',
  templateUrl: './territory-setup.component.html',
  styleUrls: ['./territory-setup.component.css'],
  animations: [slideUpEnter, expend]
})
export class TerritorySetupComponent {

  public urlArray = [];
  public currentEcosystem;

  constructor(
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private router: Router,
    private titleService: Title,
    private ecoSystemService: EcoSystemService,
  ) {
    const breadcrumb = [{ label: 'Bussiness Data', link: '' }, { label: 'Territory Set-up', link: '' }];
    this.ecoSystemService.updateSharedData('breadcrumb', breadcrumb);
    this.titleService.setTitle('DV | Territory');
    this.route.url.subscribe(() => {
      this.urlArray = decodeURI(this.router.url).split('/');
      this.currentEcosystem = this.ecoSystemService.getEcoIdByName(this.urlArray[4]);
      console.log(this.currentEcosystem);
    });
  }
}
