import { TerritoryService } from './../../../../../services/postLaunch/territory.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { LoginService } from '../../../../../services/login.service';

@Component({
  selector: 'app-territory-label-dialog',
  templateUrl: './territory-label-dialog.component.html',
  styleUrls: ['./territory-label-dialog.component.css']
})
export class TerrtioryLabelDialogComponent {

  public title = '';
  public limit = 40;
  public newLabel = new FormControl('', [Validators.required]);

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<TerrtioryLabelDialogComponent>,
    private territoryService: TerritoryService,
    private loginService: LoginService
  ) {
    console.log(data);
    this.newLabel.patchValue(data.label);
    this.title = data.title;
  }

  public cancel() {
    this.dialogRef.close();
  }

  public submit() {
    const newLabel = this.newLabel.value;
    console.log(newLabel);
    if (newLabel.trim() !== '') {
      this.newLabel.setErrors(null);
      if (newLabel.trim().toLowerCase() === this.data.defaultLabel) {
        this.dialogRef.close(this.newLabel.value);
      } else {
        this.loginService.checkAccessToken().subscribe((token) => {
          this.territoryService.duplicateTerritoryNameCheck(this.loginService.getCurrentUser().user.orgId, newLabel, token).subscribe((res) => {
            console.log(res);
            if (res.success && res.result) {
              this.newLabel.setErrors({ duplicate: true });
            } else {
              this.dialogRef.close(this.newLabel.value);
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    }
  }

}
