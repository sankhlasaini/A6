import { slideUp } from './../../../../../animations';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { HelperService } from './../../../../../services/helper.service';
import { BusinessDocsService } from './../../../../../services/business-docs.service';
import { Component, OnInit } from '@angular/core';
import { EcoSystemService } from './../../../../../services/eco-system.service';
import { FormGroup, FormBuilder } from '@angular/forms';
// tslint:disable-next-line:max-line-length
import { MatDialog } from '@angular/material';
import { AttributesDialogComponent } from './attributes-dialog/attributes-dialog.component';
import { LoginService } from '../../../../../services/login.service';

@Component({
  selector: 'app-business-doc',
  templateUrl: './business-doc.component.html',
  styleUrls: ['./business-doc.component.css'],
  animations: [slideUp]
})

export class BusinessDocComponent implements OnInit {

  public ecoSystemId;
  public businessDocs;
  public businessDocsBACKUP;
  public labelError = { error: false, id: '', type: '' };
  constructor(
    private ecoSystemService: EcoSystemService,
    private _fb: FormBuilder,
    public dialog: MatDialog,
    private businessDocsService: BusinessDocsService,
    private helperService: HelperService,
    private titleService: Title,
    private router: Router,
    private loginService: LoginService
  ) {
    this.titleService.setTitle('DV | Business Docs');
  }

  public ngOnInit() {
    const ecoName = decodeURI(this.router.url.split('/')[4]);
    const ecosystem = this.ecoSystemService.getEcoIdByName(ecoName);
    this.ecoSystemId = ecosystem.ecosystemId;
    this.initBDocs();
  }

  public initBDocs() {
    if (this.ecoSystemId) {
      if (!this.businessDocsService.getBDoc().updated || this.businessDocsService.getBDoc().data[0].ecosystemId !== this.ecoSystemId) {
        console.log('BDOC Changed. Getting from DB');
        this.getDataFromDB();
      } else {
        console.log('Getting BDOC from Local');
        const bDocData = JSON.parse(JSON.stringify(this.businessDocsService.getBDoc().data));
        this.processBDocData(bDocData);
      }
    }
  }

  public getDataFromDB() {
    this.loginService.checkAccessToken().subscribe((token) => {
      this.businessDocsService.getBusinessDocs(this.ecoSystemId, token).subscribe((bDocRes) => {
        console.log('BUSINESS DOCS DATA', bDocRes);
        if (bDocRes.success) {
          this.processBDocData(bDocRes.result);
          this.businessDocsService.setBDoc(bDocRes.result, true);
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public processBDocData(bDocRes) {
    if (bDocRes.length === 0) {
      console.log('ERROR IN BUSINESS DOCS NO DATA FOUND');
    }
    this.businessDocs = bDocRes[0];
    this.businessDocsBACKUP = JSON.parse(JSON.stringify(bDocRes[0]));
  }

  public openBDocAttribute(i, j, k) {
    const dialogRef = this.dialog.open(AttributesDialogComponent, {
      height: '90%',
      data: JSON.parse(JSON.stringify(this.businessDocs.businessDocumentModule[i].
        businessDocumentFunctionalServices[j].businessDocuments[k])),
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result.update) {
          this.businessDocs.businessDocumentModule[i].businessDocumentFunctionalServices[j].businessDocuments[k] = result.data;
          this.saveBDoc(result.data.businessDocumentName + ' Attributes');
        }
      }
    });
  }

  public saveBDoc(msg) {
    this.businessDocsService.updateBusinessDocs(this.businessDocs).subscribe((bDocRes) => {
      console.log(bDocRes);
      if (bDocRes) {
        this.helperService.openSnackBar(msg, 'UPDATED');
        this.getDataFromDB();
        this.businessDocsService.setBDoc({}, false);
      } else {
        this.resetBDoc();
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public resetBDoc() {
    this.businessDocs = JSON.parse(JSON.stringify(this.businessDocsBACKUP));
  }

  public validateLabel(label, id) {
    this.labelError = { error: false, id: '', type: '' };
    if (label.trim() !== '') {
      this.businessDocs.businessDocumentModule.forEach((bm) => {
        bm.businessDocumentFunctionalServices.forEach((fm) => {
          fm.businessDocuments.forEach((businessDocuments) => {
            if (businessDocuments.businessDocumentId !== id &&
              businessDocuments.businessDocumentLabel.toLowerCase().trim() === label.toLowerCase().trim()) {
              this.labelError = { error: true, id, type: 'duplicate' };
            }
          });
        });
      });
    } else {
      this.labelError = { error: true, id, type: 'required' };
    }
  }
}
