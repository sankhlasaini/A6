import { slideUpEnter } from './../../../../../animations';
import { ItemService } from './../../../../../services/item.service';
import { Component, OnInit } from '@angular/core';
import { EcoSystemService } from '../../../../../services/eco-system.service';
import { MatDialog } from '@angular/material';
import { Title } from '@angular/platform-browser';
import { HelperService } from '../../../../../services/helper.service';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../../../../../services/login.service';
import { AdditionalAttrDialogComponent } from '../profile/additional-attr-dialog/additional-attr-dialog.component';
import { ConfirmLabelDialogComponent } from '../../../common/confirm-label-dialog/confirm-label-dialog.component';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css'],
  animations: [slideUpEnter]
})
export class ItemComponent implements OnInit {

  public itemFromDB = [];
  public itemFromDBBACKUP;
  public ecoSystemId = '';
  public loading = false;

  constructor(
    private titleService: Title,
    public dialog: MatDialog,
    private ecoSystemService: EcoSystemService,
    private helperService: HelperService,
    private itemService: ItemService,
    private router: Router,
    private route: ActivatedRoute,
    private loginService: LoginService
  ) {
    this.titleService.setTitle('DV | Item');
  }

  public ngOnInit() {
    this.route.url.subscribe(() => {
      const ecoName = decodeURI(this.router.url.split('/')[4]);
      console.log(ecoName);
      const ecosystem = this.ecoSystemService.getEcoIdByName(ecoName);
      const breadcrumb = [{ label: ecosystem.name, link: '' }, { label: 'Items', link: '' }];
      this.ecoSystemService.updateSharedData('breadcrumb', breadcrumb);
      console.log('eco in Item : ', ecosystem);
      this.ecoSystemId = ecosystem.id;
      this.initItem();
    });
  }

  public initItem() {
    this.itemFromDB = [];
    if (this.ecoSystemId) {
      if (!this.itemService.getItemLocal(this.ecoSystemId)) {
        console.log('Item Changed. Getting from DB');
        this.getItemFromDB();
      } else {
        this.loading = true;
        console.log('Getting Item from Local');
        const itemData = this.itemService.getItemLocal(this.ecoSystemId);
        this.initItemList(itemData);
        this.loading = false;
      }
    }
  }

  public getItemFromDB() {
    this.loading = true;
    this.loginService.checkAccessToken().subscribe((token) => {
      // token.tenantToken = 'system';
      this.itemService.getItemsByEcoId(this.ecoSystemId, token).subscribe((res) => {
        console.log('Items Result form DB at ngOnChanges', res);
        if (res.success) {
          this.initItemList(res.result);
          this.itemService.setItemLocal({ ecosystemId: this.ecoSystemId, itemList: res.result });
        } else {
          this.itemService.setItemLocal(undefined);
        }
        this.loading = false;
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public initItemList(itemList) {
    this.itemFromDB = [];
    itemList.forEach((item) => {
      const index = this.itemFromDB.findIndex((itemGrp) => itemGrp.itemType === item.itemType);
      if (index > -1) {
        this.itemFromDB[index].items.push(item);
      } else {
        this.itemFromDB.push({ itemType: item.itemType, items: [item], error: { error: false, id: -1, type: '' } });
      }
    });
    this.itemFromDBBACKUP = JSON.parse(JSON.stringify(this.itemFromDB));
    console.log(this.itemFromDB);
  }

  public additionalAttr(item, itemIndex, itemGrpIndex) {
    console.log(item);
    const dialogRef = this.dialog.open(AdditionalAttrDialogComponent, {
      height: '90%',
      //  width: '80%',
      // position: { top: '90px', bottom: '', left: '25px', right: '25px' },
      data: item.attribGrps,
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('data from dialog', result);
      if (result) {
        this.itemFromDB[itemGrpIndex].items[itemIndex].attribGrps = result;
        this.updateItems([this.itemFromDB[itemGrpIndex].items[itemIndex]]);
      }
    });
  }

  public validateLabel(itemType) {
    itemType.saveDisabled = false;
    itemType.items.forEach((it) => {
      it.error = { error: false, type: '' };
      if (it.name.trim() === '') {
        it.error = { error: true, type: 'required' };
        itemType.saveDisabled = true;
      } else {
        itemType.items.forEach((it2) => {
          if (it.id !== it2.id && it.name.toLowerCase().trim() === it2.name.toLowerCase().trim()) {
            it.error = { error: true, type: 'duplicate' };
            itemType.saveDisabled = true;
          }
        });
      }
    });
  }

  public updateItems(itemArray) {
    console.log(itemArray);
    this.loginService.checkAccessToken().subscribe((token) => {
      // token.tenantToken = 'system';
      this.itemService.updateItem(itemArray, token).subscribe((res) => {
        if (res.success && res.result) {
          this.itemFromDBBACKUP = JSON.parse(JSON.stringify(this.itemFromDB));
          this.helperService.openSnackBar('Items Saved Successfully', 'OK');
          this.itemService.setItemLocal(undefined);
        } else {
          this.itemFromDB = JSON.parse(JSON.stringify(this.itemFromDBBACKUP));
          this.helperService.openSnackBar('Items Update Failed', 'Reverting Changes');
        }
        console.log(res);
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public cancelUpdate(itemGrp) {
    this.itemFromDB[itemGrp].items = JSON.parse(JSON.stringify(this.itemFromDBBACKUP[itemGrp].items));
  }

  public cloneItem(item, list) {
    let itemNameArr = [];
    // this.itemFromDB.forEach((itemGrp) => { itemGrp.items.forEach((it) => itemNameArr.push(it.name.trim().toLowerCase())); });
    list.forEach((it) => itemNameArr.push(it.name.trim().toLowerCase()));
    const dialogRef = this.dialog.open(ConfirmLabelDialogComponent, {
      data: {
        labelList: itemNameArr,
        title: 'Enter Item Label'
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('data from dialog', result);
      if (result) {
        const cloneBody = {
          itemId: item.id,
          itemName: result
        };
        this.loading = true;
        this.loginService.checkAccessToken().subscribe((token) => {
          // token.tenantToken = 'system';
          this.itemService.cloneItem(cloneBody.itemId, cloneBody.itemName, token).subscribe((cloneItemRes) => {
            console.log('CLONE ITEM RES :: ', cloneItemRes);
            if (cloneItemRes.success) {
              this.getItemFromDB();
              this.helperService.openSnackBar('ITEM Cloned', 'OK');
            } else {
              this.helperService.openSnackBar('ITEM Clone Failed', 'Try Again');
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    });
  }
}
