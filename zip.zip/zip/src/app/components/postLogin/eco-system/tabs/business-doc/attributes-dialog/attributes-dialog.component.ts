import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-attributes-dialog',
  templateUrl: './attributes-dialog.component.html',
  styleUrls: ['./attributes-dialog.component.css']
})
export class AttributesDialogComponent {
  public validForm = true;
  public businessDocumentsBACKUP;
  public labelError = { error: false, index: '', type: '' };
  public labelSubError = { error: false, index1: '', index2: '', type: '' };

  constructor(
    @Inject(MAT_DIALOG_DATA) public businessDocuments: any,
    private dialogRef: MatDialogRef<AttributesDialogComponent>
  ) {
    console.log(this.businessDocuments);
    this.businessDocumentsBACKUP = JSON.parse(JSON.stringify(this.businessDocuments));
  }

  public cancel() {
    this.dialogRef.close({ update: false, data: this.businessDocumentsBACKUP });
  }

  public submit() {
    this.dialogRef.close({ update: true, data: this.businessDocuments });
  }

  public validateLabel(label, index) {
    this.labelError = { error: false, index: '', type: '' };
    if (label.trim() !== '') {
      for (let i = 0; i < this.businessDocuments.attributes.length; i++) {
        if (i !== index && this.businessDocuments.attributes[i].fieldLabel.toLowerCase().trim() === label.toLowerCase().trim()) {
          this.labelError = { error: true, index, type: 'duplicate' };
        }
      }
    } else {
      this.labelError = { error: true, index, type: 'required' };
    }
  }

  public validateSubLabel(label, index1, index2) {
    this.labelSubError = { error: false, index1: '', index2: '', type: '' };
    if (label.trim() !== '') {
      for (let j = 0; j < this.businessDocuments.attributes[index1].subattributes.length; j++) {
        if (j !== index2 &&
          this.businessDocuments.attributes[index1].subattributes[j].fieldLabel.toLowerCase().trim() === label.toLowerCase().trim()) {
          this.labelSubError = { error: true, index1, index2, type: 'duplicate' };
        }
      }
    } else {
      this.labelSubError = { error: true, index1, index2, type: 'required' };
    }
  }

}
