import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { fade, slideUp, tags, slideUpEnter } from './../../../animations';
import { HelperService } from './../../../services/helper.service';
import { Component, OnInit } from '@angular/core';
import { EcoSystemService } from './../../../services/eco-system.service';
import { LoginService } from '../../../services/login.service';
import { MatDialog } from '@angular/material';
import { ConfirmLabelDialogComponent } from '../common/confirm-label-dialog/confirm-label-dialog.component';
import { DvAdminComponent } from '../dv-admin/dv-admin.component';

@Component({
  selector: 'app-eco-system',
  templateUrl: './eco-system.component.html',
  styleUrls: ['./eco-system.component.css'],
  animations: [fade, slideUp, tags, slideUpEnter]
})

export class EcoSystemComponent implements OnInit {

  public ecoSystem;
  public tagName = '';
  public activeTabIndex = 0;
  public routeLinks: any[];
  public activeLinkIndex = 0;
  public urlArray = [];
  public loading = true;
  public currentEcosystemName = '';
  public breadcrumbs = [];

  constructor(
    private ecoSystemService: EcoSystemService,
    private helperService: HelperService,
    private route: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    private loginService: LoginService,
    public dvAdminComponent: DvAdminComponent
  ) {
    route.url.subscribe(() => {
      this.urlArray = decodeURI(this.router.url).split('/');
      if (this.urlArray[3] === 'eco') {
        this.currentEcosystemName = this.urlArray[4];
      }
      let tempEco = this.ecoSystemService.getEcoIdByName(this.currentEcosystemName);
      if (tempEco === undefined) {
        this.helperService.openSnackBar('No Ecosystem Found', 'Try Another');
        router.navigate(['/ecosystem/admin']);
      } else {
        this.ecoSystem = JSON.parse(JSON.stringify(tempEco));
        const baseUrl = this.urlArray[0] + '/' + this.urlArray[1] + '/' + this.urlArray[2] + '/' + this.urlArray[3] + '/';
        this.routeLinks = [
          { label: 'Manage Account', link: baseUrl + this.currentEcosystemName + '/accounts', routeName: 'accounts' },
          { label: 'Profile', link: baseUrl + this.currentEcosystemName + '/profile', routeName: 'profile' },
          { label: 'Role', link: baseUrl + this.currentEcosystemName + '/role', routeName: 'role' },
          // { label: 'Business Document', link: baseUrl + this.currentEcosystemName + '/businessDocument', routeName: 'businessDocument' },
          { label: 'Item', link: baseUrl + this.currentEcosystemName + '/item', routeName: 'item' }
        ];
        this.activeLinkIndex = this.getLinkIndex(this.urlArray[5]);
        this.loading = false;
      }
    });
  }

  public ngOnInit() {
    this.ecoSystemService.getSharedData().subscribe((data) => {
      const bread = data.get('breadcrumb');
      if (bread) { setTimeout(() => { this.breadcrumbs = JSON.parse(JSON.stringify(bread)); }); }
    });
  }

  public getLinkIndex(tabName) {
    let selectedIndex = 0;
    this.routeLinks.forEach((ele, i) => {
      if (tabName === ele.routeName) {
        selectedIndex = i;
      }
    });
    // console.log('Final LINKS ', this.routeLinks);
    return selectedIndex;
  }

  public addTag() {
    let exist = false;
    if (this.ecoSystem.tags == null) {
      this.ecoSystem.tags = [];
    }
    this.ecoSystem.tags.forEach((tag) => {
      if (tag.toLowerCase() === this.tagName.toLowerCase()) {
        this.helperService.openSnackBar('Tag Already Exists', 'Try Another');
        exist = true;
      }
    });
    if (!exist && this.tagName) {
      this.ecoSystem.tags.push(this.tagName);
      this.tagName = '';
      this.updateEcoSystem(this.ecoSystem, 'Tag Created');
    }
  }

  public delTag(tag) {
    this.ecoSystem.tags.splice(this.ecoSystem.tags.indexOf(tag), 1);
    this.updateEcoSystem(this.ecoSystem, 'Tag Removed');
  }

  // update data in DB
  public updateEcoSystem(eco, msg) {
    this.loginService.checkAccessToken().subscribe((token) => {
      // token.tenantToken = 'system';
      this.ecoSystemService.updateEcosystem(eco, token).subscribe((response) => {
        console.log('updateEcoSystem Response : ', response);
        if (response.success && response.result) {
          // this.selectedEcoBackup = JSON.parse(JSON.stringify(eco));
          this.ecoSystemService.setEcoIdByName(eco.name + '_V' + eco.version, eco);
          this.helperService.openSnackBar(msg, 'OK');
        } else {
          this.ecoSystem = JSON.parse(JSON.stringify(this.ecoSystemService.getEcoIdByName(eco.name + '_V' + eco.version)));
          this.helperService.openSnackBar('EcoSystem Update Failed', 'Reverting Changes');
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  // clone a Ecosystem
  public cloneEcosystem(eco) {
    const dialogRef = this.dialog.open(ConfirmLabelDialogComponent, {
      data: {
        labelList: this.ecoSystemService.getAllEcoList().map((ecosystem) => ecosystem.name.trim().toLowerCase()),
        title: 'Enter Eco System Label'
      }
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.helperService.openSnackBar('Cloning Ecosystem', 'Please Wait');
        this.loginService.checkAccessToken().subscribe((token) => {
          // token.tenantToken = 'system';
          this.ecoSystemService.cloneEcoSystem(eco.id, result, token).subscribe((res) => {
            console.log('cloneEcosystem Result : ', res);
            if (res.success) {
              // this.getEcoSystemList();
              this.helperService.openSnackBar('Ecosystem Cloned', 'OK');
              this.dvAdminComponent.getEcoSystemList();
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    });
  }

}
