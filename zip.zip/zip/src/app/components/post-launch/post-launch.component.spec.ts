// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { PostLaunchComponent } from './post-launch.component';

// describe('PostLaunchComponent', () => {
//   let component: PostLaunchComponent;
//   let fixture: ComponentFixture<PostLaunchComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PostLaunchComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PostLaunchComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
