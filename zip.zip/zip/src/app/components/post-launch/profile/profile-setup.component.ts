import { MatDialog } from '@angular/material';
import { fade, slideUp } from './../../../animations';
import { HelperService } from './../../../services/helper.service';
import { PartnerService } from './../../../services/postLaunch/partner.service';
import { ProfileSetupService } from './../../../services/postLaunch/profile-setup.service';
import { CrossPlatformService } from './../../../services/postLaunch/cross-platform.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserSetupService } from '../../../services/postLaunch/user-setup.service';
import { GoogleMapDialogComponent } from '../common/google-map-dialog/google-map-dialog.component';
import { FormArray } from '@angular/forms';

@Component({
  selector: 'app-profile-setup',
  templateUrl: './profile-setup.component.html',
  styleUrls: ['./profile-setup.component.css'],
  animations: [fade, slideUp]
})
export class ProfileSetupComponent implements OnInit {

  public step = 1;
  public profileSetupForm;
  public orgIdObj;
  public loading = false;
  public usersList = [];
  public primaryPartner;
  public activeTabIndex = 0;
  public clearLocationFlag = false;
  public tab3Valid = { validOutlet: true, validBId: true };
  public currency = [];
  public timezone = [];
  public outletFormData: FormArray;

  constructor(
    private router: Router,
    private crossPlatformService: CrossPlatformService,
    private profileSetupService: ProfileSetupService,
    private partnerService: PartnerService,
    private helperService: HelperService,
    private dialog: MatDialog,
    private userSetupService: UserSetupService,
  ) {
    this.orgIdObj = this.crossPlatformService.getOrgId();
  }

  public ngOnInit() {
    // if (!this.profileSetupService.getProfileSetup().updated) {
    //   console.log('Profile Setup Data Changed. Getting from DB');
    //   this.getProfileFromDB();
    // } else {
    console.log('Getting Profile Setup Data from Local');
    const profileRes = JSON.parse(JSON.stringify(this.profileSetupService.getProfileSetup().data));
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.initProfileSetupData(profileRes, token);
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
    // }
  }

  // Get Profile Data from DB
  public getProfileFromDB() {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.partnerService.findOrg([{ partyId: this.orgIdObj.orgId }], token).subscribe((profileRes) => {
        console.log('Result for find Org', profileRes);
        if (profileRes.success && profileRes.result.length > 0) {
          this.profileSetupService.setProfileSetup(profileRes.result, true);
          this.initProfileSetupData(profileRes.result, token);
        } else {
          this.helperService.openSnackBar('FAILED to Load Profile', 'Try Again');
          this.router.navigate(['/postLaunch']);
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  // INIT Profile Data to Rendering
  public initProfileSetupData(profileRes, accessToken) {
    this.profileSetupForm = profileRes[0];
    console.log('Profile Object', this.profileSetupForm);
    this.getUsersforParty(this.orgIdObj.orgId);
    this.profileSetupForm.establishmentDate = this.profileSetupForm.establishmentDate !== null ? new Date(this.profileSetupForm.establishmentDate) : null;
    this.profileSetupForm.orgProfile.contactPersons.forEach((conPer) => {
      conPer.contactAddress.googleAddressAutoFill = { pincode: false, state: false, country: false, district: false };
    });
    this.getCurrencyAndTimezone(this.profileSetupForm.orgProfile.contactPersons[0].contactAddress.countryCode);
  }

  // Get List of users of this Org
  public getUsersforParty(orgId) {

    const usersListLocal = this.userSetupService.getUsersListLocal();
    if (usersListLocal) {
      console.log('userslist getting from local');
      this.usersList = usersListLocal;
      this.initAttributesGroup(this.profileSetupForm.orgProfile);
    } else {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.userSetupService.getUserList(token, orgId, '').subscribe((userRes) => {
          if (userRes.success) {
            this.userSetupService.setUsersListLocal(userRes.result);
            this.usersList = userRes.result;
            this.initAttributesGroup(this.profileSetupForm.orgProfile);
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public initAttributesGroup(profile) {
    const ecoProfile = this.crossPlatformService.getEcoSystemProfile();
    if (ecoProfile) {
      const addInfoGrp = ecoProfile.attribGrps.find((atGrp) => atGrp.sysGenName === 'def_attrib_grp_additional_info');
      let busReg = [];
      if (addInfoGrp) {
        addInfoGrp.attributes.forEach((at) => {
          if (at.sysGenName.includes('def_attrib_bus_reg_id') && !at.sysGenName.includes('img')) {
            busReg.push(at);
          }
        });
        console.log('OUTLET : ', busReg);
      }
      // const poc1 = profile.contactPersons.find((con) => con.contactAddress.defaultAddress);

      const poc1 = this.usersList.find((user) => user.isDefaultUser);

      if (!profile.attributeGroup) { profile.attributeGroup = []; }
      if (!profile.attributeGroup.find((at) => (at.attributeGrpKey === 'point_of_contact_1')) && poc1) {
        profile.attributeGroup.push({
          attributeGrpKey: 'point_of_contact_1',
          attributeGrpLabel: 'Point Of Contact 1',
          attributes: [
            { key: 'name', keyLabel: 'Name', value: poc1.name },
            { key: 'mobile', keyLabel: 'Mobile', value: poc1.mobile },
            { key: 'email', keyLabel: 'Email', value: poc1.email }
          ]
        });
      }
      if (!profile.attributeGroup.find((at) => (at.attributeGrpKey === 'default'))) {
        profile.attributeGroup.push({
          attributeGrpKey: 'default',
          attributeGrpLabel: 'Default',
          attributes: [
            { key: 'currency', keyLabel: 'Currency', value: '' },
            { key: 'timezone', keyLabel: 'Timezone', value: '' },
            { key: 'key_categories', keyLabel: 'Key categories', value: '' }
          ]
        });
      }
      if (!profile.attributeGroup.find((at) => at.attributeGrpKey === 'business_details')) {
        profile.attributeGroup.push({
          attributeGrpKey: 'business_details',
          attributeGrpLabel: 'Business Details',
          attributes: []
        });
        let busDetail = profile.attributeGroup.find((at) => at.attributeGrpKey === 'business_details');
        busReg.forEach((reg, index) => {
          busDetail.attributes.push({ key: 'business_id_' + (index + 1), keyLabel: reg.label, value: '', isAttachment: '', attachments: [] });
        });
      }
    } else {
      this.helperService.openSnackBar('No System Found', 'Try Again');
      this.router.navigate(['/postLaunch']);
    }
    this.loading = false;
  }

  // Changes Steps of Stepper
  public changeStep(type) {
    if (type === 'prev') {
      if (this.step === 1) {
        this.router.navigate(['/postLaunch']);
      } else {
        this.step--;
        this.activeTabIndex = this.step - 1;
      }
    } else {
      if (this.step === 3) {
        if (this.tab3Valid.validOutlet && this.tab3Valid.validBId) {
          this.submit();
        } else {
          const msg = this.tab3Valid.validBId ? 'Outlet Data is Invalid' : 'Bussiness Id is Invalid';
          this.helperService.openSnackBar(msg, 'OK');
        }
      } else {
        this.step++;
        this.activeTabIndex = this.step - 1;
      }
    }
  }

  public tab3Validion(event) {
    switch (event.type) {
      case 'outlet':
        this.tab3Valid.validOutlet = event.valid;
        this.outletFormData = event.data;
        break;
      case 'bId':
        this.tab3Valid.validBId = event.valid;
        break;
      default:
        break;
    }
  }

  public openMap(latLong, index) {
    const dialogRef = this.dialog.open(GoogleMapDialogComponent, {
      width: '100%',
      height: '100%',
      maxWidth: '100%',
      disableClose: true,
      data: { center: latLong.latitude + ',' + latLong.longitude, }
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('Result from MAP', result);
      if (result) {
        if (result.marker && result.marker.lat != null && result.marker.lng != null && result.marker.lat !== '' && result.marker.lng !== '') {
          const latlng = result.marker.lat + ',' + result.marker.lng;
          this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.gpsLocation.latitude = result.marker.lat;
          this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.gpsLocation.longitude = result.marker.lng;
          this.autoFillAddress(latlng, index);
        }
        if (result.clearLocation) {
          this.clearLocationFlag = result.clearLocation;
        }
      }
    });
  }

  public autoFillAddress(center, index) {
    this.profileSetupService.getAddressfromDialog(center).subscribe((res) => {
      console.log('Address from Gmaps Result : ', res);
      if (this.clearLocationFlag) { this.clearAddress(index); }
      if (res) {
        this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.country = res.country;
        this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.countryCode = res.countryCode;
        this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.state = res.state;
        this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.district = res.district;
        this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.pincode = res.pincode;
        this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.city = res.city;
        this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.line2 = res.line2;
        this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.area = res.area;
        this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.line1 = res.address;
        if (this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.isDefaultAddress) {
          this.getCurrencyAndTimezone(res.countryCode);
        }
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
    // console.log(this.googleAddressAutoFill);
  }

  public clearAddress(index) {
    this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.googleAddressAutoFill.pincode = false;
    this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.googleAddressAutoFill.state = false;
    this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.googleAddressAutoFill.country = false;
    this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.googleAddressAutoFill.district = false;
    this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.country = '';
    this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.state = '';
    this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.district = '';
    this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.pincode = '';
    this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.city = '';
    this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.line2 = '';
    this.profileSetupForm.orgProfile.contactPersons[index].contactAddress.line1 = '';
  }

  public getCurrencyAndTimezone(code) {
    console.log(code);
    code = code ? code : 'IN';
    // Due to Service Error Always "IN" in set as CODE with Tenant Token "system"
    this.currency = [];
    this.timezone = [];
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      token.tenantToken = 'system';
      this.profileSetupService.retrieveCurrencyAndTimezoneByCountryCode({ code }, token).subscribe((res) => {
        console.log('Timezone Result for ' + code + ' : ', res);
        if (res.success) {
          this.currency = res.result.currencies;
          this.timezone = res.result.timeZones;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  // Final Save Function to Update Profile
  public submit() {
    this.setupOutletData(this.outletFormData);
    console.log(this.outletFormData);
    // this.loading = true;
    console.log('Final Submitting of Profile :: ', this.profileSetupForm);
    this.helperService.openSnackBar('Updating Profile', 'Please Wait');
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.partnerService.updateOrg(this.profileSetupForm, token).subscribe((updateRes) => {
        console.log('Profile Update RES :: ', updateRes);
        this.profileSetupService.setProfileSetup({}, false);
        this.partnerService.findOrg([{ partyId: this.orgIdObj.orgId }], token).subscribe((profileRes) => {
          this.loading = false;
          if (profileRes.success && profileRes.result.length > 0) {
            this.profileSetupService.setProfileSetup(profileRes.result, true);
            this.helperService.openSnackBar('Profile Updated', 'OK');
            this.router.navigate(['/postLaunch']);
          }
        }, (err) => {
          this.loading = false;
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        this.loading = false;
        if (!JSON.parse(err.message).accessdenied) {
          this.helperService.openSnackBar('Profile Update Failed', 'Try Again');
        }
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public setupOutletData(outletFormData) {
    this.profileSetupForm.orgProfile.contactPersons = this.profileSetupForm.orgProfile.contactPersons.filter((out) => out.contactAddress.isDefaultAddress);
    let outletArrayFinal = [];
    outletFormData.forEach((form: FormArray) => {
      let obj = {
        firstName: form.get('manager').value.name, middleName: '', lastName: '',
        contactAddress: {
          'email': form.get('manager').value.email,
          'mobile': form.get('manager').value.mobile,
          'addressType': form.get('outletType').value,
          'addressLabel': form.get('outletName').value,
          'firstName': form.get('manager').value.name,
          'line1': form.get('line1').value,
          'line2': form.get('area').value,
          'area': form.get('area').value,
          'district': form.get('address').value.district,
          'city': form.get('address').value.city,
          'state': form.get('address').value.state,
          'country': form.get('address').value.country,
          'countryCode': form.get('address').value.countryCode,
          'pincode': form.get('address').value.pincode,
          'images': form.get('images').value,
          'gpsLocation': { latitude: form.get('latitude').value, longitude: form.get('longitude').value },
          'defaultAddress': false,
          'isDefaultAddress': false,
          'territories': form.get('territory').value.data
        }
      };
      this.profileSetupForm.orgProfile.contactPersons.push(obj);
    });
  }
}
