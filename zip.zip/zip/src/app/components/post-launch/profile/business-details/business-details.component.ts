import { ProfileSetupComponent } from './../profile-setup.component';
import { HelperService } from './../../../../services/helper.service';
import { EventEmitter, Output, Inject, OnInit, ViewChild } from '@angular/core';
import { Component, Input, OnChanges } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ProfileSetupService } from './../../../../services/postLaunch/profile-setup.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { ViewListDialogComponent } from '../../common/view-list-dialog/view-list-dialog.component';
import { ConfirmationDialogComponent } from '../../common/confirmation-dialog/confirmation-dialog.component';
import { TerritoryService } from '../../../../services/postLaunch/territory.service';
import { TerritorySelectionDialogComponent } from '../../territory-selection-dialog/territory-selection-dialog.component';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { GoogleMapDialogComponent } from '../../common/google-map-dialog/google-map-dialog.component';

@Component({
  selector: 'app-business-details',
  templateUrl: './business-details.component.html',
  styleUrls: ['./business-details.component.css']
})
export class BusinessDetailsComponent implements OnChanges {

  @Input() public profileSetupForm;
  @Input() public usersList;
  @Output() public valid = new EventEmitter();

  public pincodeLabel;
  public outletSelect = [];
  public fileCount = {};
  public docAssociatedWithBid = [];
  public count = 0;
  public flag = 0;
  public bIdName;
  public index = 0;
  public fileUrl: any;
  public imageCount = 0;
  public imageArray = [];
  public renderedImage;
  public imageFlag = 0;
  public emailPattern = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
  public mobPattern = /^[789]\d{9}$/;
  public labelError = { error: false, index: '', type: '' };
  public bIdError = { error: false, index: '', type: '' };
  public globalTerritoryList = [];
  public territorylistLoading = true;

  public outletForm: FormGroup;
  public outletFormArray: FormArray;

  @ViewChild('myForm') public myform;

  constructor(
    private fb: FormBuilder,
    public dialog: MatDialog,
    private profileSetupService: ProfileSetupService,
    private crossPlatformService: CrossPlatformService,
    private helperService: HelperService,
    private territoryService: TerritoryService,
    public profileSetupComponent: ProfileSetupComponent
  ) {
  }

  public addItem(outlet) {
    this.outletFormArray = this.outletForm.get('outletFormArray') as FormArray;
    this.outletFormArray.push(this.createOutletForm(outlet));
    console.log(this.outletForm.get('outletFormArray'));
  }

  public createOutletForm(outlet): FormGroup {
    const manager = outlet.contactAddress.mobile ? this.usersList.find((user) => user.mobile === outlet.contactAddress.mobile) : '';
    const address = {
      address: outlet.contactAddress.line1,
      line2: outlet.contactAddress.line2,
      area: outlet.contactAddress.area,
      city: outlet.contactAddress.city,
      country: outlet.contactAddress.country,
      countryCode: outlet.contactAddress.countryCode,
      district: outlet.contactAddress.district,
      pincode: outlet.contactAddress.pincode,
      state: outlet.contactAddress.state
    };
    return this.fb.group({
      outletType: [outlet.contactAddress.addressType, [Validators.required]],
      outletName: [outlet.contactAddress.addressLabel, [Validators.required, Validators.maxLength(40)]],
      manager: [manager, [Validators.required]],
      territory: ['', [Validators.required]],
      address: [address, [Validators.required]],
      area: [address.area],
      line1: [address.address, [Validators.required]],
      latitude: [outlet.contactAddress.gpsLocation.latitude, [Validators.required]],
      longitude: [outlet.contactAddress.gpsLocation.longitude, [Validators.required]],
      images: [outlet.contactAddress.images]
    });
  }

  public ngOnChanges() {
    console.log('ADD ITEM :: ');
    this.outletForm = this.fb.group({
      outletFormArray: this.fb.array([])
    });

    const outletsList = this.profileSetupForm.orgProfile.contactPersons.filter((out) => !out.contactAddress.isDefaultAddress);
    this.outletForm.statusChanges.subscribe(() => {
      console.log('statusChanges : ', this.outletForm.status);
      this.profileSetupForm.orgProfile.contactPersons = this.profileSetupForm.orgProfile.contactPersons.filter((out) => out.contactAddress.isDefaultAddress);
      this.valid.emit({
        valid: this.outletForm.valid, type: 'outlet', msg: 'Outlet Form is Invalid',
        data: this.outletForm.get('outletFormArray')['controls']
      });
      this.outletForm.markAsDirty();
    });

    console.log(outletsList);

    outletsList.forEach((outlet) => {
      this.addItem(outlet);
    });

    this.outletSelect = [];
    const ecoProfile = this.crossPlatformService.getEcoSystemProfile();
    if (ecoProfile) {
      ecoProfile.attribGrps.forEach((element) => {
        switch (element.sysGenName) {
          case 'def_attrib_grp_outlet_type':
            this.outletSelect.push(element);
            break;
          default:
            break;
        }
      });
      this.setupBusinessDetails(this.profileSetupForm.orgProfile.attributeGroup);
      this.getTerritoryList(outletsList);
    }
  }

  public getTerritoryList(outletsList) {
    this.territorylistLoading = true;
    const pageStartIndex = 0;
    const territoryPageSize = 100;
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.territoryService.retrieveTerritoriesByOrgId(token, this.crossPlatformService.getOrgId().orgId, pageStartIndex, territoryPageSize).subscribe((result) => {
        console.log('Territory result', result);
        if (result.success && result.result && result.result.territoryList) {
          this.globalTerritoryList = result.result.territoryList;
          outletsList.forEach((outlet, i) => {
            this.createTerritoryData(outlet.contactAddress.territories, this.outletForm.get('outletFormArray')['controls'][i]);
          });
          this.territorylistLoading = false;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public setupBusinessDetails(atGrp) {
    this.docAssociatedWithBid = [];
    const bDetails = atGrp.find((at) => (at.attributeGrpKey === 'business_details'));
    this.docAssociatedWithBid = bDetails.attributes;
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.docAssociatedWithBid.forEach((bId) => {
        if (bId.attachments && bId.attachments.length > 0) {
          bId.url = this.profileSetupService.getDownloadFileUrl([bId.attachments[0].gridFSid], token);
        }
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public uploadDocument(event, bId) {
    let file = event.srcElement.files[0];
    file.rename = this.profileSetupForm.name + '_' + bId.value + '.' + file.name.split('.')[1];
    console.log(file);
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.profileSetupService.uploadFile([file], token).subscribe((response) => {
        console.log('Doc Upload res : ', response);
        if (response) {
          bId.attachment = true;
          bId.attachments = [{ gridFSid: response.result[0].gridFSid, gridFsFileName: response.result[0].fileName }];
          bId.url = this.profileSetupService.getDownloadFileUrl([bId.attachments[0].gridFSid], token);
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public selectPOC(item: FormGroup) {
    const dialogRef = this.dialog.open(ViewListDialogComponent, {
      height: '90%',
      width: '90%',
      data: {
        data: this.usersList, type: 'poc',
        title: 'Select Person Of Contact', selectable: true
      }
    });
    dialogRef.afterClosed().subscribe((selectedPoc) => {
      if (selectedPoc) {
        item.patchValue({ manager: selectedPoc });
      }
    });
  }

  public validateBId(label, index, list) {
    console.log(label, index, list);
    let id = label.toLowerCase().trim();
    if (id !== '') {
      const bIdObj = list.find((bId, i) => (i !== index && bId.value.toLowerCase().trim() === id));
      if (bIdObj) {
        this.bIdError = { error: true, index, type: 'duplicate' };
      } else {
        this.bIdError = { error: false, index: '', type: '' };
      }
    } else {
      this.bIdError = { error: false, index: '', type: '' };
    }
    this.valid.emit({ valid: !this.bIdError.error, type: 'bId', msg: 'Bussiness Id is Invalid' });
  }

  public addOutlet() {
    // this.outletSelect = this.outletSelect.sort((a, b) => (a.label.toLowerCase() > b.label.toLowerCase()) ? 1 : ((b.label.toLowerCase() > a.label.toLowerCase()) ? -1 : 0));
    const dialogRef = this.dialog.open(ViewListDialogComponent, {
      height: '90%',
      width: '90%',
      data: { data: this.outletSelect, type: 'outlet', title: 'Select Outlet', selectable: true }
    });
    dialogRef.afterClosed().subscribe((selectedOutlet) => {
      console.log('Outlet Select Result', selectedOutlet);
      if (selectedOutlet) {
        const outlet = {
          firstName: '', middleName: '', lastName: '',
          contactAddress:
          {
            'email': '',
            'mobile': '',
            'addressType': selectedOutlet.label,
            'addressLabel': 'Outlet ' + this.profileSetupForm.orgProfile.contactPersons.length,
            'firstName': '',
            'middleName': '',
            'lastName': '',
            'line1': '',
            'line2': '',
            'line3': '',
            'area': '',
            'district': '',
            'city': '',
            'state': '',
            'country': '',
            'landmark': '',
            'pincode': '',
            'landline': '',
            'images': null,
            'gpsLocation': { latitude: '', longitude: '' },
            'defaultAddress': false,
            'isDefaultAddress': false,
            'googleAddressAutoFill': {
              pincode: false, state: false, country: false, district: false
            }
          }
        };
        // this.profileSetupForm.orgProfile.contactPersons.push(outlet);
        this.addItem(outlet);
      }
    });
  }

  public setLocationForNewOutlet(outlet) {
    const lat = '12.9715987';
    const lng = '77.59456269999998';
    if (outlet.latLong.latitude === '') {
      outlet.latLong.latitude = lat;
      outlet.latLong.longitude = lng;
      // console.log(navigator.geolocation);
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
          console.log('Your geolocation is already enabled ');
          outlet.latLong.latitude = position.coords['latitude'].toString();
          outlet.latLong.longitude = position.coords['longitude'].toString();
        }, () => {
          console.log('Please enable your geolocation');
        });
      }
    }
    return outlet;
  }

  public removeOutlet(formGroupArray: FormArray, removeIndex) {
    console.log(formGroupArray.controls['outletFormArray'].controls[removeIndex])
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      // height: '90%',
      // width: '90%',
      data: {
        discardAction: 'CANCEL',
        submitAction: 'REMOVE',
        title: 'Are You Sure ?',
        subTitle: formGroupArray.controls['outletFormArray'].controls[removeIndex].controls['outletName'].value + ' will be Removed.'
      }
    });
    dialogRef.afterClosed().subscribe((selectedPoc) => {
      console.log('ConfirmationDialogComponent Result : ', selectedPoc, formGroupArray);
      if (selectedPoc) {
        const control = <FormArray>formGroupArray.controls['outletFormArray'];
        control.removeAt(removeIndex);
      }
    });
  }

  public setDocuments() {
    this.profileSetupForm.businessDocs = this.docAssociatedWithBid;
  }

  public selectTerritory(existingTerritoryList, outlet: FormGroup) {
    if (!this.territorylistLoading) {
      const dialogRef = this.dialog.open(TerritorySelectionDialogComponent, {
        maxWidth: '100%',
        width: '100%',
        height: '100%',
        data: { invokeFrom: 'service', globalTerritoryList: this.globalTerritoryList, singleLeafSelection: true, existingTerritoryList },
      });

      dialogRef.afterClosed().subscribe((territoryResult) => {
        console.log(territoryResult);
        if (territoryResult) {
          this.createTerritoryData(territoryResult.mapping, outlet);
          console.log(outlet);
        }
      });
    } else {
      this.helperService.openSnackBar('Loading Territory Data', 'Try Again');
    }
  }

  public createTerritoryData(territoryResult, outlet: FormGroup) {
    console.log(territoryResult)
    if (!territoryResult) { territoryResult = []; }
    console.log('territoryResult', territoryResult);
    console.log(this.globalTerritoryList);
    const showTerritoryList = [];
    if (territoryResult !== '') {
      territoryResult.forEach((territory, i) => {
        const terTemp = this.globalTerritoryList.find((ter) => ter.territoryId === territory.id);
        if (terTemp) {
          showTerritoryList.push(terTemp.territoryName + ' (' + territory.territoryTree.length + ')');
        }
      });
      outlet.patchValue({
        territory: territoryResult.length > 0 ? { data: territoryResult, display: showTerritoryList } : ''
      });
    }
  }

  public openMap(latitude, longitude, form: FormGroup) {
    const dialogRef = this.dialog.open(GoogleMapDialogComponent, {
      width: '100%',
      height: '100%',
      maxWidth: '100%',
      disableClose: true,
      data: { center: latitude + ',' + longitude }
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('Result from MAP', result);
      if (result) {
        if (result.marker && result.marker.lat != null && result.marker.lng != null && result.marker.lat !== '' && result.marker.lng !== '') {
          const latlng = result.marker.lat + ',' + result.marker.lng;
          this.profileSetupService.getAddressfromDialog(latlng).subscribe((res) => {
            console.log('Address from Gmaps Result : ', res);
            if (res) {
              form.patchValue({
                area: res.area,
                line1: res.address,
                address: res,
                latitude: result.marker.lat,
                longitude: result.marker.lng
              });
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });

        }
      }
    });
  }

}
