// import { ProfileSetupComponent } from './profile-setup.component';
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// describe('ProfileSetupComponent', () => {
//   let component: ProfileSetupComponent;
//   let fixture: ComponentFixture<ProfileSetupComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ProfileSetupComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ProfileSetupComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
