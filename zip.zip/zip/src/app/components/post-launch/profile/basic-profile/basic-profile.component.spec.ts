import { BasicProfileComponent } from './basic-profile.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HelperService } from './../../../../services/helper.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MaterialModule } from './../../../../material.module';
import { Component, OnInit, Input, OnChanges, OnDestroy, Output, EventEmitter, NO_ERRORS_SCHEMA } from '@angular/core';
import { ProfileSetupService } from './../../../../services/postLaunch/profile-setup.service';
import { MatDialog } from '@angular/material';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Http, HttpModule, XHRBackend, Response, ResponseOptions } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { fakeAsync } from '@angular/core/testing';
import { tick } from '@angular/core/testing';

describe('BasicProfileComponent', () => {
    let component: BasicProfileComponent;
    let fixture: ComponentFixture<BasicProfileComponent>;
    // tslint:disable-next-line:prefer-const
    let expectedWebLinksForm: FormGroup;
    // tslint:disable-next-line:new-parens
    const fb = new FormBuilder;
    // let addBtn: DebugElement;
    let inputtag;

    const expectedProfileSetupForm = {
        partyName: 'PUNIA LTD.',
        categoriesList: []
    };

    // let page;
    // class Page {
    //     public gotoSpy: jasmine.Spy;

    //     public addBtn: DebugElement;
    //     public inputtag: HTMLInputElement;

    //     constructor() {
    //         // const router = TestBed.get(Router);
    //         this.gotoSpy = spyOn(component, 'addTag').and.callThrough();
    //     }

    //     public addPageElements() {
    //         if (component.profileSetupForm) {
    //             const buttons = fixture.debugElement.queryAll(By.css('button'));
    //             this.addBtn = buttons[3];
    //             const inputs = fixture.debugElement.queryAll(By.css('input'));
    //             this.inputtag = inputs[4].nativeElement;
    //         }
    //     }
    // }

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [BrowserAnimationsModule, MaterialModule, HttpModule, FormsModule, ReactiveFormsModule],
            declarations: [BasicProfileComponent],
            providers: [MatDialog, CrossPlatformService, ProfileSetupService, HelperService],
            schemas: [NO_ERRORS_SCHEMA]
        })
            .compileComponents();
    }));

    // beforeEach(() => {
    //     fixture = TestBed.createComponent(BasicProfileComponent);
    //     component = fixture.componentInstance;
    //     component.profileSetupForm = expectedProfileSetupForm;
    //     component.profileSetupForm.partyName = expectedProfileSetupForm.partyName;
    //     component.webLinksForm = fb.group({
    //         websiteLinks: [],
    //         facebookUrl: [],
    //     });
    //     // const buttons = fixture.debugElement.queryAll(By.css('button'));
    //     // addBtn = buttons[3];
    //     // const inputs = fixture.debugElement.queryAll(By.css('input'));
    //     // inputtag = inputs[4].nativeElement;
    //     fixture.whenStable().then(() => {
    //         fixture.detectChanges();
    //     });
    //     fixture.detectChanges();
    // });

    // function createComponent() {
    //     fixture = TestBed.createComponent(BasicProfileComponent);
    //     component = fixture.componentInstance;
    //     page = new Page();

    //     fixture.detectChanges();
    //     return fixture.whenStable().then(() => {
    //         fixture.detectChanges();
    //         page.addPageElements();
    //     });
    // }

    // it('should be created', () => {
    //     expect(component).toBeTruthy();
    // });

    it('add Tag Input', fakeAsync(() => {
        fixture = TestBed.createComponent(BasicProfileComponent);
        component = fixture.componentInstance;
        component.profileSetupForm = expectedProfileSetupForm;
        component.profileSetupForm.partyName = expectedProfileSetupForm.partyName;
        component.webLinksForm = fb.group({
            websiteLinks: [],
            facebookUrl: [],
        });
        fixture.detectChanges();

        const inputs = fixture.debugElement.query(By.css('.tagClass'));
        inputtag = inputs.nativeElement;
        inputtag.value = 'stylish';

        inputs.triggerEventHandler('input', { target: inputs.nativeElement });
        fixture.detectChanges();
        expect(inputtag.value).toBe(component['tagName']);
    }));

    it('add Tags in categoryList', fakeAsync(() => {
        fixture = TestBed.createComponent(BasicProfileComponent);
        component = fixture.componentInstance;
        component.profileSetupForm = expectedProfileSetupForm;
        component.profileSetupForm.partyName = expectedProfileSetupForm.partyName;
        component.webLinksForm = fb.group({
            websiteLinks: [],
            facebookUrl: [],
        });
        fixture.detectChanges();

        const inputs = fixture.debugElement.query(By.css('.tagClass'));
        const leftclickevent = { button: 0 };

        inputs.nativeElement.value = 'math';
        inputs.triggerEventHandler('input', { target: inputs.nativeElement });
        fixture.detectChanges();

        const button = fixture.debugElement.query(By.css('.addTagBtn'));
        button.triggerEventHandler('click', leftclickevent);
        fixture.detectChanges();

        inputs.nativeElement.value = 'class';
        inputs.triggerEventHandler('input', { target: inputs.nativeElement });
        fixture.detectChanges();

        button.triggerEventHandler('click', leftclickevent);
        fixture.detectChanges();

        inputs.nativeElement.value = 'student';
        inputs.triggerEventHandler('input', { target: inputs.nativeElement });
        fixture.detectChanges();

        button.triggerEventHandler('click', leftclickevent);
        fixture.detectChanges();
        tick(1000);
        expect(expectedProfileSetupForm.categoriesList).toBe(component.profileSetupForm.categoriesList);
        expect(['math', 'class', '']).toEqual(component.profileSetupForm.categoriesList);
    }));
});
