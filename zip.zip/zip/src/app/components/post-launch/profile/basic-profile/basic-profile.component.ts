import { ImageResize } from './../../../../services/postLaunch/image-resize.service';
import { CropImageDialogComponent } from './../../common/crop-image-dialog/crop-image-dialog.component';
import { ViewAllImagesDialogComponent } from './../../common/view-all-images-dialog/view-all-images-dialog.component';
import { OptionDialogComponent } from './../../common/option-dialog/option-dialog.component';
import { HelperService } from './../../../../services/helper.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, Input, OnChanges, OnDestroy, Output, EventEmitter } from '@angular/core';
import { ProfileSetupService } from './../../../../services/postLaunch/profile-setup.service';
import { MatDialog } from '@angular/material';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';

@Component({
  selector: 'app-basic-profile',
  templateUrl: './basic-profile.component.html',
  styleUrls: ['./basic-profile.component.css']
})
export class BasicProfileComponent implements OnChanges {

  @Input() public profileSetupForm;
  @Output() public valid = new EventEmitter();

  public dialogResult = '';
  public logoImageId;
  public webLinksForm: FormGroup;
  public fileUrl;
  public urlPattern = '/^(ftp|http|https):\/\/[^ "]+$/';
  public currentEcoProfile;
  public keyCatagory = [];
  public logoThumb;
  public primaryImages = [];
  public accessToken;

  constructor(
    private fb: FormBuilder,
    public dialog: MatDialog,
    private helperService: HelperService,
    public profileSetupService: ProfileSetupService,
    public crossPlatformService: CrossPlatformService,
    private imageResize: ImageResize
  ) { }

  public ngOnChanges() {
    this.currentEcoProfile = this.crossPlatformService.getEcoSystemProfile();

    this.webLinksForm = this.fb.group({
      websiteLinks: ['', Validators.pattern(/((?:https?\:\/\/|www\.)(?:[-a-z0-9]+\.)*[-a-z0-9]+.*)/i)],
      facebookUrl: ['', Validators.pattern(/^(https?:\/\/)?(www\.)?facebook.com\/[a-zA-Z0-9(\.\?)?]/)],
    });

    this.setLogo(this.profileSetupForm.orgProfile.avatar);

    const primaryAddress = this.profileSetupForm.orgProfile.contactPersons.find((con) => con.contactAddress.isDefaultAddress === true);
    if (primaryAddress) { this.primaryImages = primaryAddress.contactAddress.images; }

    console.log('Profile in Basic Profile Section :', this.profileSetupForm);
    const defaultGrp = this.profileSetupForm.orgProfile.attributeGroup.find((at) => (at.attributeGrpKey === 'default'));
    const cat = defaultGrp.attributes.find((at) => at.key === 'key_categories').value;
    cat === '' ? this.keyCatagory = [] : this.keyCatagory = cat.split(',');
  }

  public setLogo(logo) {
    if (logo && logo.gridFSid) {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.logoThumb = this.profileSetupService.getDownloadFileUrl([logo.gridFSid], token);
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public setPrimaryImages(event) {
    const primaryAddress = this.profileSetupForm.orgProfile.contactPersons.find((con) => con.contactAddress.isDefaultAddress === true);
    if (primaryAddress) { primaryAddress.contactAddress.images = event; }
  };

  public setKeyCatagory(val) {
    const defaultGrp = this.profileSetupForm.orgProfile.attributeGroup.find((at) => (at.attributeGrpKey === 'default'));
    defaultGrp.attributes.find((at) => at.key === 'key_categories').value = val.toString();
  }

  public openImageCropDialog(event) {
    let dialogRef;
    console.log(event);
    if (event) {
      if (event.type === 'image/jpeg' || event.type === 'image/jpg' || event.type === 'image/png') {
        dialogRef = this.dialog.open(CropImageDialogComponent, {
          maxWidth: '100%',
          width: '100%',
          height: '100%',
          data: event,
          disableClose: true
        });
        dialogRef.afterClosed().subscribe((result) => {
          if (result) {
            this.logoThumb = result.image;
            this.uploadLogo(result.cropedImageFileObj);
          }
        });
      } else {
        this.helperService.openSnackBar('Only .jpg, .jpeg, .png Allowed', 'Try Again');
      }
    }
  }

  public logoChange() {
    const dialogRef = this.dialog.open(OptionDialogComponent, {
      data: [{ option: 'Take New Logo', icon: 'camera_enhance' },
      { option: 'Remove Logo', icon: 'delete' }],
      disableClose: false
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result === 'delete') {
          this.profileSetupForm.orgProfile.avatar = { gridFSid: '', gridFsFileName: '' };
          this.logoThumb = undefined;
        } else {
          this.openImageCropDialog(result);
        }
      }
    });
  }

  public uploadLogo(logoFile) {
    this.imageResize.imageReducerNew(logoFile).then((imgRes) => {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.profileSetupService.uploadFile([imgRes], token).subscribe((response) => {
          console.log('LOGO Upload res : ', response);
          if (response) {
            this.profileSetupForm.orgProfile.avatar = { gridFSid: response.result[0].gridFSid, gridFsFileName: response.result[0].fileName };
            this.setLogo(this.profileSetupForm.orgProfile.avatar);
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    });
  }

}
