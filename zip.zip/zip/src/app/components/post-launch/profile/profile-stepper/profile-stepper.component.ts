import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-profile-stepper',
  templateUrl: './profile-stepper.component.html',
  styleUrls: ['./profile-stepper.component.css'],
})
export class ProfileStepperComponent {

  @Input() public step;

}
