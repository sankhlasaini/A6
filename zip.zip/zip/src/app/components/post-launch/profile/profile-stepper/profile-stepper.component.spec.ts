// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { ProfileStepperComponent } from './profile-stepper.component';

// describe('ProfileStepperComponent', () => {
//   let component: ProfileStepperComponent;
//   let fixture: ComponentFixture<ProfileStepperComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ProfileStepperComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ProfileStepperComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
