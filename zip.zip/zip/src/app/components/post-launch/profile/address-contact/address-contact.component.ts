import { ProfileSetupComponent } from './../profile-setup.component';
import { UserSetupService } from './../../../../services/postLaunch/user-setup.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { HelperService } from './../../../../services/helper.service';
import { MatDialog } from '@angular/material';
import { ProfileSetupService } from './../../../../services/postLaunch/profile-setup.service';
import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { ViewListDialogComponent } from '../../common/view-list-dialog/view-list-dialog.component';

@Component({
  selector: 'app-address-contact',
  templateUrl: './address-contact.component.html',
  styleUrls: ['./address-contact.component.css']
})
export class AddressContactComponent implements OnChanges {
  @Input() public profileSetupForm;
  @Input() public usersList;
  @Input() public currency;
  @Input() public timezone;
  @Output() public valid = new EventEmitter();

  public timezoneValue = '';
  public currencyValue = '';
  public pocSelect = [1, 2, 3, 4, 5, 6];
  public autocomplete: any;
  public address: any = {};
  public marker = { display: false, lat: '', lng: '' };
  public clearLocationFlag = false;
  public googleAddressAutoFill = {
    line1: false, line2: false, city: false, pincode: false,
    state: false, country: false, district: false
  };
  public pointOfContact = [];

  constructor(
    private profileSetupService: ProfileSetupService,
    private helperService: HelperService,
    public dialog: MatDialog,
    public profileSetupComponent: ProfileSetupComponent,
    private userSetupService: UserSetupService,
    private crossPlatformService: CrossPlatformService
  ) { }

  public ngOnChanges() {
    console.log('Users List', this.usersList);
    if (this.profileSetupForm.orgProfile.contactPersons[0].contactAddress.gpsLocation == null) {
      this.profileSetupForm.orgProfile.contactPersons[0].contactAddress.gpsLocation = { latitude: '', longitude: '' };
    }
    this.setupPoc(this.profileSetupForm.orgProfile.attributeGroup);
    this.getTzCur();
  }

  public setupPoc(atGrp) {
    this.pointOfContact = [];
    const poc1 = atGrp.find((at) => (at.attributeGrpKey === 'point_of_contact_1'));
    if (poc1) {
      this.pointOfContact.push({
        key: poc1.attributeGrpKey,
        label: poc1.attributeGrpLabel,
        name: poc1.attributes.find((e) => e.key === 'name').value,
        mobile: poc1.attributes.find((e) => e.key === 'mobile').value,
        email: poc1.attributes.find((e) => e.key === 'email').value,
      });
    }
    const poc2 = atGrp.find((at) => (at.attributeGrpKey === 'point_of_contact_2'));
    if (poc2) {
      this.pointOfContact.push({
        key: poc2.attributeGrpKey,
        label: poc2.attributeGrpLabel,
        name: poc2.attributes.find((e) => e.key === 'name').value,
        mobile: poc2.attributes.find((e) => e.key === 'mobile').value,
        email: poc2.attributes.find((e) => e.key === 'email').value,
      });
    }
    const poc3 = atGrp.find((at) => (at.attributeGrpKey === 'point_of_contact_3'));
    if (poc3) {
      this.pointOfContact.push({
        key: poc3.attributeGrpKey,
        label: poc3.attributeGrpLabel,
        name: poc3.attributes.find((e) => e.key === 'name').value,
        mobile: poc3.attributes.find((e) => e.key === 'mobile').value,
        email: poc3.attributes.find((e) => e.key === 'email').value,
      });
    }
  }

  public addPOC() {
    const dialogRef = this.dialog.open(ViewListDialogComponent, {
      height: '90%',
      width: '90%',
      data: {
        data: this.usersList.filter((user) => !this.pointOfContact.find((p) => (p.mobile === user.mobile && p.email === user.email))),
        type: 'poc', selectable: true,
        title: 'Select Person Of Contact'
      }
    });
    dialogRef.afterClosed().subscribe((selectedPoc) => {
      console.log('Result from POC : ', selectedPoc);
      if (selectedPoc) {
        if (this.pointOfContact.find((p) => (p.mobile === selectedPoc.mobile && p.email === selectedPoc.email))) {
          this.helperService.openSnackBar('POC Already Exist', 'OK');
        } else {
          const attribute = {
            attributeGrpKey: 'point_of_contact_' + (this.pointOfContact.length + 1),
            attributeGrpLabel: 'Point Of Contact ' + (this.pointOfContact.length + 1),
            attributes: [
              { key: 'name', keyLabel: 'Name', value: selectedPoc.name },
              { key: 'mobile', keyLabel: 'Mobile', value: selectedPoc.mobile },
              { key: 'email', keyLabel: 'Email', value: selectedPoc.email }
            ]
          };
          this.profileSetupForm.orgProfile.attributeGroup.push(attribute);
          this.setupPoc(this.profileSetupForm.orgProfile.attributeGroup);
        }
      }
    });
  }

  public removePOC() {
    const pocKey = this.profileSetupForm.orgProfile.attributeGroup.findIndex((p) => p.attributeGrpKey === this.pointOfContact[this.pointOfContact.length - 1].key);
    this.profileSetupForm.orgProfile.attributeGroup.splice(pocKey, 1);
    this.pointOfContact.pop();
  }

  public getTzCur() {
    const defaultGrp = this.profileSetupForm.orgProfile.attributeGroup.find((at) => (at.attributeGrpKey === 'default'));
    this.currencyValue = defaultGrp.attributes.find((at) => at.key === 'currency').value;
    this.timezoneValue = defaultGrp.attributes.find((at) => at.key === 'timezone').value;
  }

  public setTzCur() {
    const defaultGrp = this.profileSetupForm.orgProfile.attributeGroup.find((at) => (at.attributeGrpKey === 'default'));
    defaultGrp.attributes.find((at) => at.key === 'currency').value = this.currencyValue;
    defaultGrp.attributes.find((at) => at.key === 'timezone').value = this.timezoneValue;
  }

  public initialized(autocomplete: any) {
    this.autocomplete = autocomplete;
  }

}
