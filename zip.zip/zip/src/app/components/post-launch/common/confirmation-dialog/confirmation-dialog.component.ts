import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.css']
})
export class ConfirmationDialogComponent {

  public title = '';
  public subTitle = '';
  public discardAction = '';
  public submitAction = '';

  constructor(
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ConfirmationDialogComponent>) {
    console.log(this.data);
    this.title = this.data.title;
    this.subTitle = this.data.subTitle;
    this.discardAction = this.data.discardAction;
    this.submitAction = this.data.submitAction;
  }

  public submit() {
    this.dialogRef.close(true);
  }

}
