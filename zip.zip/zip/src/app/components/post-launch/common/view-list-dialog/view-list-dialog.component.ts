import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-list-dialog',
  templateUrl: './view-list-dialog.component.html',
  styleUrls: ['./view-list-dialog.component.css']
})
export class ViewListDialogComponent {

  constructor(
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public dataList: any,
    private dialogRef: MatDialogRef<ViewListDialogComponent>) {
    console.log(this.dataList);
  }

  public selectItem(outlet) {
    if (this.dataList.selectable) {
      this.dialogRef.close(outlet);
    }
  }

  public close() {
    this.dialogRef.close();
  }

}
