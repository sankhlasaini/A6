// import { ErrorDialogComponent } from './error-dialog.component';
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// describe('GoogleMapComponent', () => {
//   let component: ErrorDialogComponent;
//   let fixture: ComponentFixture<ErrorDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ErrorDialogComponent]
//     })
//       .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ErrorDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
