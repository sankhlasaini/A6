import { ProductService } from './../../../../services/postLaunch/product.service';
import { ProductTemplateService } from './../../../../services/product-template.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { Router } from '@angular/router';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Component, Inject } from '@angular/core';

@Component({
  selector: 'post-launch-bottom-sheet',
  templateUrl: './bottom-sheet-dialog.component.html',
  styleUrls: ['./bottom-sheet-dialog.component.css'],
})
export class BottomSheetDialogComponent {
  public showDownTemp = false;
  public choices = [];
  public selectedValue;
  public selectPlaceholder = '';

  constructor(
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private productTemplateService: ProductTemplateService,
    private crossPlatformService: CrossPlatformService,
    private productService: ProductService,
    private dialogRef: MatDialogRef<BottomSheetDialogComponent>
  ) {
    console.log(this.data.type);
    switch (this.data.type) {
      case 'product':
        this.getProductTemplates();
        break;
      case 'territory':
        break;
      case 'partner':
        break;
      case 'products and Brands':
        this.getProductTemplates();
        break;
      case 'Brands':
        break;
      default:
        break;

    }
  }

  public close() {
    this.dialogRef.close();
  }

  public action1Btn() {
    if (this.data.action1.action) {
      this.router.navigate([this.data.action1.action]);
      this.dialogRef.close();
    } else {
      switch (this.data.type) {
        case 'product':
          if (this.selectedValue) {
            this.router.navigate(['/postLaunch/productBrandDashboard/addProduct/' + this.selectedValue]);
            this.dialogRef.close();
          }
          break;
        case 'products and Brands':
          this.router.navigate(['/postLaunch/productBrandDashboard/addProduct/' + this.selectedValue]);
          this.dialogRef.close();
          break;
        case 'Brands':
          this.router.navigate(['/postLaunch/productBrandDashboard/addBrandOrg']);
          this.dialogRef.close();
          break;
        default:
          break;
      }
    }
  }

  public action2Btn() {
    if (this.data.action2.action) {
      this.router.navigate([this.data.action2.action]);
      this.dialogRef.close();
    }
  }

  // getting all the Product template for particular Ecosystem
  public getProductTemplates() {
    this.selectPlaceholder = 'Select Product Template';
    this.productTemplateService.getProductTemplateListFromDB(this.crossPlatformService.getOrgId().ecoSystemId, '').subscribe((res) => {
      console.log('getProductTemplateListFromDB RES :: ', res);
      if (res.success) {
        const productTemp = res.result.productTemplates;
        if (productTemp !== null) {
          this.choices = [];
          productTemp.forEach((element) => {
            const obj = {
              id: element.templateId,
              label: element.templateLabel
            };
            this.choices.push(obj);
          });
        }
        this.selectedValue = this.choices[0].id;
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }
  public dvMasterProduct() {
    if (this.data.action3.action) {
      this.router.navigate([this.data.action3.action]);
      this.dialogRef.close();
    } else {
      switch (this.data.type) {
        case 'products and Brands':
          this.router.navigate(['/postLaunch/productBrandDashboard/dvMasterSetup']);
          this.dialogRef.close();
          break;
        default:
          break;
      }
    }
  }

  public excelUpload(file) {
    console.log(file);
    if (file) {
      switch (this.data.type) {
        case 'product':
          this.productService.excelUpload(file, this.crossPlatformService.getOrgId().orgId).subscribe((res) => {
            console.log('excelUpload RES :: ', res);
            this.dialogRef.close(true);
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
          break;
        default:
          break;
      }
    }

  }
}
