// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ViewAllImagesDialogComponent } from './view-all-images-dialog.component';

// describe('ViewAllImagesDialogComponent', () => {
//   let component: ViewAllImagesDialogComponent;
//   let fixture: ComponentFixture<ViewAllImagesDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ViewAllImagesDialogComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ViewAllImagesDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
