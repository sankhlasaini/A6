import { ServiceCatalogService } from './../../../../services/postLaunch/service-catalog.service';
import { HelperService } from './../../../../services/helper.service';
import { ProfileSetupService } from './../../../../services/postLaunch/profile-setup.service';
import { Component, OnInit, Inject, ViewChild, OnChanges } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { ImageResize } from '../../../../services/postLaunch/image-resize.service';

@Component({
  selector: 'app-view-all-images-dialog',
  templateUrl: './view-all-images-dialog.component.html',
  styleUrls: ['./view-all-images-dialog.component.css']
})
export class ViewAllImagesDialogComponent implements OnInit {

  public imageArray = [];
  public activeTabIndex = 0;
  public activeImage;
  public loading = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public inputData: any,
    public dialog: MatDialog,
    public profileSetupService: ProfileSetupService,
    public crossPlatformService: CrossPlatformService,
    private helperService: HelperService,
    private imageResize: ImageResize,
    private serviceCatalogService: ServiceCatalogService,
    private dialogRef: MatDialogRef<ViewAllImagesDialogComponent>) { }

  public ngOnInit() {
    this.imageArray = this.inputData.data;
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.imageArray.forEach((img) => {
        if (this.inputData.from.toLowerCase() === 'service') {
          const image = this.serviceCatalogService.findImage(img.id);
          if (image) {
            img.url = image.base64;
          } else {
            this.serviceCatalogService.downloadFile(img.id, token).subscribe((imgRes) => {
              this.serviceCatalogService.storeImage(img.id, imgRes.result);
              img.url = this.serviceCatalogService.findImage(img.id).base64;
            });
          }
        } else {
          img.url = this.profileSetupService.getDownloadFileUrl([img.gridFSid], token)[0];
        }
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public close() {
    console.log(this.imageArray);
    this.imageArray.forEach((file) => { delete file.url; });
    this.dialogRef.close(this.imageArray);
  }

  public back() {
    if (this.activeTabIndex === 0) {
      this.close();
    } else {
      this.activeTabIndex = 0;
      this.activeImage = undefined;
    }
  }

  public deleteImage(index) {
    this.imageArray.splice(index, 1);
  }

  public addImages(event) {
    let tempImageArray = [];
    let reducedImages = [];
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < event.srcElement.files.length; i++) {
      const fileType = event.srcElement.files[i].type;
      if (fileType === 'image/jpeg' || fileType === 'image/jpg' || fileType === 'image/png') {
        tempImageArray.push(event.srcElement.files[i]);
      } else {
        this.helperService.openSnackBar('Only .jpg, .jpeg, .png Allowed', 'Try Again');
      }
    }
    console.log('-----TEMP FILTER ARRAY----', tempImageArray);
    if (tempImageArray.length > 0) {
      const totalImages = this.imageArray.length + tempImageArray.length;
      console.log('Totel Images : ', totalImages);
      if (totalImages > this.inputData.limit) {
        this.helperService.openSnackBar('Max ' + this.inputData.limit + ' Files are Allowed', 'Select Again');
      } else {
        this.loading = true;
        setTimeout(() => { this.helperService.openSnackBar('Adding Images', 'Please Wait'); }, 1000);
        tempImageArray.forEach((img, i) => {
          this.imageResize.imageReducerNew(img).then((imgRes) => {
            reducedImages.push(imgRes);
            if (reducedImages.length === tempImageArray.length) {
              this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
                if (this.inputData.from.toLowerCase() === 'service') {
                  this.cmfImagesUpload(reducedImages, token);
                } else {
                  this.panmImagesUpload(reducedImages, token);
                }
              }, (err) => {
                console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
              });
            }
          });
        });
      }
    }
  }

  public panmImagesUpload(reducedImages, token) {
    this.profileSetupService.uploadFile(reducedImages, token).subscribe((response) => {
      console.log('Images panm Upload res : ', response);
      this.loading = false;
      if (response) {
        response.result.forEach((res) => {
          this.helperService.openSnackBar('Images Added', 'OK');
          this.imageArray.push({
            gridFSid: res.gridFSid,
            gridFsFileName: res.fileName,
            url: this.profileSetupService.getDownloadFileUrl([res.gridFSid], token)[0]
          });
        });
      }
    }, (err) => {
      this.loading = false;
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public cmfImagesUpload(reducedImages, token) {
    this.serviceCatalogService.uploadImages(reducedImages, token).subscribe((response) => {
      this.loading = false;
      console.log('Images cmf Upload res : ', response);
      if (response) {
        response.result.images.forEach((res) => {
          this.helperService.openSnackBar('Images Added', 'OK');
          this.imageArray.push({
            gridFSid: res.id,
            gridFsFileName: res.name,
            id: res.id,
            name: res.name,
            url: ''
          });
          const image = this.serviceCatalogService.findImage(this.imageArray[this.imageArray.length - 1].gridFSid);
          if (image) {
            this.imageArray[this.imageArray.length - 1].url = image.base64;
          } else {
            this.serviceCatalogService.downloadFile(this.imageArray[this.imageArray.length - 1].gridFSid, token).subscribe((imgRes) => {
              this.serviceCatalogService.storeImage(this.imageArray[this.imageArray.length - 1].gridFSid, imgRes.result);
              this.imageArray[this.imageArray.length - 1].url = this.serviceCatalogService.findImage(this.imageArray[this.imageArray.length - 1].gridFSid).base64;
            });
          }
        });
      }
    }, (err) => {
      this.loading = false;
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public viewImage(index) {
    this.activeImage = index;
    this.activeTabIndex = 1;
  }

  public fabAction(index) {
    if (this.activeTabIndex > 0) {
      this.deleteImage(index);
      this.activeTabIndex = 0;
      this.activeImage = undefined;
    }
  }

  // public openDialog(index) {
  //   let dialogRef;

  //   if (this.data[index]) {
  //     // tslint:disable-next-line:max-line-length
  //     const path = '/profile/downloadFile/?fileId=' + this.data[index].fileReferenceId;
  //     dialogRef = this.dialog.open(ImageFullViewDialogComponent, {
  //       width: '100%',
  //       height: '100%',
  //       data: path,
  //       disableClose: false
  //     });
  //   }
  // }
}
