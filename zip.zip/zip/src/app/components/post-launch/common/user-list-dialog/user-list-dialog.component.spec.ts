// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { RequestDocumentsDialogComponent } from './request-documents-dialog.component';

// describe('RequestDocumentsDialogComponent', () => {
//   let component: RequestDocumentsDialogComponent;
//   let fixture: ComponentFixture<RequestDocumentsDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ RequestDocumentsDialogComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RequestDocumentsDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
