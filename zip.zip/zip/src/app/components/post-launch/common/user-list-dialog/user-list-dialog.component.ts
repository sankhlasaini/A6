import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MatDialog, MAT_DIALOG_DATA } from '@angular/material';
import { HelperService } from './../../../../services/helper.service';
import { slideUp } from '../../../../animations';
import { ViewListDialogComponent } from '../../common/view-list-dialog/view-list-dialog.component';

@Component({
  selector: 'app-user-list-dialog',
  templateUrl: './user-list-dialog.component.html',
  styleUrls: ['./user-list-dialog.component.css'],
  animations: [slideUp]
})
export class UserListDialogComponent implements OnInit {

  public listData = [];
  public usersList = [];
  public usersPageSize = 10;
  public listCardConfig = {
    image: true,
    menu: false,
    footer: true,
    multiSelect: this.data.selectable
  };

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<UserListDialogComponent>,
    private helperService: HelperService,
    private dialog: MatDialog,
  ) {
  }

  public ngOnInit() {
    this.dialogRef.afterOpen().subscribe(() => {
      console.log(this.data);
      this.data.users.forEach((user) => {
        this.listData.push({
          imageId: user.userProfile.avatar ? user.userProfile.avatar.gridFSid : '',
          default: false,
          title: user.name,
          isSelected: user.isSelected,
          userList: user,
          initialData: user,
          subTitle: user.roles ? user.roles.map((role) => role.roleLabel) : [],
          subTitle1: this.getActionList(user),
          footer: [{ placeholder: 'Supervisor', value: user.supervisorName ? user.supervisorName : 'NA', clickable: false },
          { placeholder: 'Reportees', value: user.reportee ? user.reportee.length : 0, clickable: true }]
        });
      });
      this.getNextList(0);
      console.log(this.data);
    });
  }

  public getNextList(start) {
    console.log(start, ' - ', start + this.usersPageSize);
    if (this.usersList.length < this.listData.length) {
      const nextList = this.listData.slice(start, start + this.usersPageSize);
      this.usersList = this.usersList.concat(nextList);
    }
  }

  public getActionList(user) {
    user.actionList = [];
    let roleList = [];
    if (this.data.role) {
      roleList = user.roles ? user.roles.filter((rl) => rl.roleId === this.data.role.id) : [];
    } else {
      roleList = user.roles ? user.roles : [];
    }
    roleList.forEach((currentRole) => {
      if (currentRole && currentRole.enabledActions !== null && currentRole.enabledActions.length > 0) {
        currentRole.enabledActions.forEach((action) => {
          if (user.actionList.indexOf(action.actionLabel) === -1) {
            user.actionList.push(action.actionLabel);
          }
        });
      }
    });
    return user.actionList;
  }

  public responseFromList(event) {
    console.log(event);
    switch (event.eventFrom) {
      case 'footer':
        if (event.eventData === 'Reportees') {
          let param = { data: [], title: 'Reportees', type: 'partnerInfo' };
          if (event.initialData.reportee) {
            event.initialData.reportee.forEach((rep) => {
              param.data.push({
                line1: rep.name,
                line2: rep.roles.map((r) => r.roleLabel)
              });
            });
            this.openListDialog(param);
          }
        }
        break;
      case 'multiSelect':
        console.log(this.data);
        if (this.data.multi === false) {
          console.log('single selection');
          this.listData.forEach((d) => {
            if (event.initialData.partyId !== d.initialData.partyId) {
              d.isSelected = false;
            }
          });
        }

        break;
      default:
        break;
    }
  }

  public openListDialog(param) {
    if (param.data.length > 0) {
      const dialogRef = this.dialog.open(ViewListDialogComponent, {
        height: '60%',
        width: '80%',
        data: { data: param.data, type: param.type, title: param.title, selectable: false }
      });
    }
  }

  public submit() {
    console.log('submit');
    const index = this.listData.findIndex((d) => d.isSelected === true);
    console.log(index);
    if (index > -1) {
      this.dialogRef.close(this.listData);
    } else {
      this.helperService.openSnackBar('NO User Selected', 'OK');
    }
  }

}
