import { ServiceCatalogService } from './../../../../services/postLaunch/service-catalog.service';
import { HelperService } from './../../../../services/helper.service';
import { Component, OnInit, Input, EventEmitter, OnChanges, Output } from '@angular/core';
import { ImageResize } from '../../../../services/postLaunch/image-resize.service';
import { CrossPlatformService } from '../../../../services/postLaunch/cross-platform.service';
import { ViewAllImagesDialogComponent } from '../view-all-images-dialog/view-all-images-dialog.component';
import { ProfileSetupService } from '../../../../services/postLaunch/profile-setup.service';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-image-section',
  templateUrl: './image-section.component.html',
  styleUrls: ['./image-section.component.css']
})
export class ImageSectionComponent implements OnChanges {

  @Input() public inputData;
  @Input() public limit;
  @Input() public from;
  @Output() public outputData = new EventEmitter();

  public renderImageUrl;
  public imageArray = [];
  public align = 'row';
  public loading = false;

  constructor(
    private imageResize: ImageResize,
    private helperService: HelperService,
    private crossPlatformService: CrossPlatformService,
    private profileSetupService: ProfileSetupService,
    public dialog: MatDialog,
    private serviceCatalogService: ServiceCatalogService
  ) { }

  public ngOnChanges() {
    console.log('in image section : ', this.inputData);
    if (!this.inputData) {
      this.inputData = [];
    } else {
      if (this.from.toLowerCase() === 'service') {
        this.align = 'column';
        this.inputData.forEach((d) => { d.gridFSid = d.id; d.gridFsFileName = d.name; });
      }
      this.setImageThumb(this.inputData);
    }
  }

  public imageUplaod(event) {
    let tempImageArray = [];
    let reducedImages = [];
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < event.srcElement.files.length; i++) {
      const fileType = event.srcElement.files[i].type;
      if (fileType === 'image/jpeg' || fileType === 'image/jpg' || fileType === 'image/png') {
        tempImageArray.push(event.srcElement.files[i]);
      } else {
        this.helperService.openSnackBar('Only .jpg, .jpeg, .png Allowed', 'Try Again');
      }
    }
    console.log('-----TEMP FILTER ARRAY----', tempImageArray);
    if (tempImageArray.length > 0) {
      const totalImages = this.inputData.length + tempImageArray.length;
      console.log('Totel Images : ', totalImages);
      if (totalImages > this.limit) {
        this.helperService.openSnackBar('Max ' + this.limit + ' Files are Allowed', 'Select Again');
      } else {
        this.loading = true;
        setTimeout(() => { this.helperService.openSnackBar('Adding Images', 'Please Wait'); }, 1000);
        tempImageArray.forEach((img, i) => {
          this.imageResize.imageReducerNew(img).then((imgRes) => {
            reducedImages.push(imgRes);
            if (reducedImages.length === tempImageArray.length) {
              this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
                if (this.from.toLowerCase() === 'service') {
                  this.cmfImagesUpload(reducedImages, token);
                } else {
                  this.panmImagesUpload(reducedImages, token);
                }
              }, (err) => {
                console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
              });
            }
          });
        });
      }
    }
  }

  public panmImagesUpload(reducedImages, token) {
    this.profileSetupService.uploadFile(reducedImages, token).subscribe((response) => {
      console.log('Images panm Upload res : ', response);
      this.loading = false;
      if (response) {
        response.result.forEach((res) => {
          this.inputData.push({ gridFSid: res.gridFSid, gridFsFileName: res.fileName });
          this.outputData.emit(this.inputData);
          this.helperService.openSnackBar('Images Added', 'OK');
        });
        this.renderImageUrl = this.profileSetupService.getDownloadFileUrl([this.inputData[this.inputData.length - 1].gridFSid], token)[0];
      }
    }, (err) => {
      this.loading = false;
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public cmfImagesUpload(reducedImages, token) {
    this.serviceCatalogService.uploadImages(reducedImages, token).subscribe((response) => {
      this.loading = false;
      console.log('Images cmf Upload res : ', response);
      if (response) {
        response.result.images.forEach((res) => {
          this.inputData.push({ gridFSid: res.id, gridFsFileName: res.name, id: res.id, name: res.name });
          this.outputData.emit(this.inputData);
          this.helperService.openSnackBar('Images Added', 'OK');
        });

        const image = this.serviceCatalogService.findImage(this.inputData[this.inputData.length - 1].gridFSid);
        if (image) {
          this.renderImageUrl = image.base64;
        } else {
          this.serviceCatalogService.downloadFile(this.inputData[this.inputData.length - 1].gridFSid, token).subscribe((imgRes) => {
            this.serviceCatalogService.storeImage(this.inputData[this.inputData.length - 1].gridFSid, imgRes.result);
            this.renderImageUrl = this.serviceCatalogService.findImage(this.inputData[this.inputData.length - 1].gridFSid).base64;
          });
        }
      }
    }, (err) => {
      this.loading = false;
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public setImageThumb(images) {
    if (images.length > 0) {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        if (this.from.toLowerCase() === 'service') {
          const image = this.serviceCatalogService.findImage(this.inputData[this.inputData.length - 1].gridFSid);
          if (image) {
            this.renderImageUrl = image.base64;
          } else {
            this.serviceCatalogService.downloadFile(this.inputData[this.inputData.length - 1].gridFSid, token).subscribe((imgRes) => {
              this.serviceCatalogService.storeImage(this.inputData[this.inputData.length - 1].gridFSid, imgRes.result);
              this.renderImageUrl = this.serviceCatalogService.findImage(this.inputData[this.inputData.length - 1].gridFSid).base64;
            });
          }
        } else {
          this.renderImageUrl = this.profileSetupService.getDownloadFileUrl([this.inputData[this.inputData.length - 1].gridFSid], token)[0];
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public viewAllImagesDialog() {
    const dialogRef = this.dialog.open(ViewAllImagesDialogComponent, {
      maxWidth: '100%',
      width: '100%',
      height: '100%',
      autoFocus: false,
      data: { data: this.inputData, limit: this.limit, from: this.from },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.inputData = result;
        this.setImageThumb(this.inputData);
        this.outputData.emit(this.inputData);
        // if (this.imageArray.length > 0) {
        //   this.imageResize.getBase64(this.imageArray[this.imageArray.length - 1]).then((base64) => {
        //     this.imagesThumb = base64;
        //     console.log(this.imagesThumb);
        //   });
        // }
      }
    });
  }

}
