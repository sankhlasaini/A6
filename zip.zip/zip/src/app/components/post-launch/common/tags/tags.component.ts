import { HelperService } from './../../../../services/helper.service';
import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'dv-tags',
  templateUrl: './tags.component.html',
  styleUrls: ['./tags.component.css']
})
export class TagsComponent implements OnChanges {
  // Input & Output for Tags
  // inputData = ['tag1', 'tag2'];
  // if limit = -1 then there is no limit

  @Input() public inputData;
  @Input() public label;
  @Input() public limit;
  @Output() public outputData = new EventEmitter();

  public tags = [];
  public tagName = '';

  constructor(private helperService: HelperService) { }

  public ngOnChanges() {
    this.tags = JSON.parse(JSON.stringify(this.inputData));
  }

  public addTag(newTag) {
    if (this.limit < 0 || this.tags.length < this.limit) {
      if (newTag) {
        let exist = false;
        this.tags.forEach((tag) => {
          if (tag.toLowerCase() === newTag.toLowerCase()) {
            this.helperService.openSnackBar(this.label + ' Already Exists', 'Try Another');
            exist = true;
          }
        });
        if (!exist) {
          this.tags.push(this.tagName);
          this.tagName = '';
        }
      }
      this.outputData.emit(this.tags);
    } else {
      this.helperService.openSnackBar(this.label + ' Limit is ' + this.limit, 'OK');
    }
  }

  public delTag(tag) {
    this.tags.splice(this.tags.indexOf(tag), 1);
    // this.helperService.openSnackBar('Tag Removed', 'OK');
    this.outputData.emit(this.tags);
  }
}
