import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Component, ChangeDetectorRef, Inject } from '@angular/core';

@Component({
  selector: 'app-google-dialog-map',
  templateUrl: './google-map-dialog.component.html',
  styleUrls: ['./google-map-dialog.component.css']
})
export class GoogleMapDialogComponent {

  public autocomplete: any;
  public address: any = {};
  public center: any;
  public marker = { display: false, lat: '', lng: '' };

  constructor(
    private ref: ChangeDetectorRef,
    private dialogRef: MatDialogRef<GoogleMapDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    this.center = this.data.center;
    console.log(this.data);
    this.marker.lat = this.center.split(',')[0];
    this.marker.lng = this.center.split(',')[1];
    console.log('Center', this.center);
    console.log('Marker', this.marker);
  }

  public closeMap() {
    this.dialogRef.close();
  }

  public initialized(autocomplete: any) {
    this.autocomplete = autocomplete;
  }

  public placeChanged(place) {
    console.log('place', place);
    if (!place.geometry) {
      window.alert("No details available for input: '" + place.name + "'");
      return;
    } else if (place.geometry.location) {
      this.center = place.geometry.location;
      console.log('typeeeeeee', this.center.lat(), this.center.lng());
      this.marker.lat = this.center.lat();
      this.marker.lng = this.center.lng();
      console.log('placefromautocomplete', place);
      // tslint:disable-next-line:prefer-for-of
      for (let i = 0; i < place.address_components.length; i++) {
        const addressType = place.address_components[i].types[0];
        this.address[addressType] = place.address_components[i].long_name;
      }
    }
    this.ref.detectChanges();
  }

  public dragstart(event) {
    console.log('DARG Start :: ', event.latLng.lat(), event.latLng.lng());
  }

  public dragend(event) {
    const latLng = { lat: JSON.parse(JSON.stringify(event.latLng.lat())), lng: JSON.parse(JSON.stringify(event.latLng.lng())) };
    console.log('DARG END :: ', event.latLng.lat(), event.latLng.lng());

    this.marker.lat = latLng.lat;
    this.marker.lng = latLng.lng;
    this.center = latLng.lat + ',' + latLng.lng;
  }

  public dlog({ target: marker }) {
    this.marker.display = !this.marker.display;
    if (this.marker.display) {
      this.marker.lat = marker.getPosition().lat();
      this.marker.lng = marker.getPosition().lng();
      marker.nguiMapComponent.openInfoWindow('iw', marker);
    } else {
      marker.nguiMapComponent.closeInfoWindow('iw', marker);
    }
  }

  public markLocation() {
    console.log(this.marker.lat, this.marker.lng);
    this.dialogRef.close({ marker: this.marker, clearLocation: true });
  }

  public myCurrentLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        console.log('Your geolocation is already enabled ');
        const latlng = position.coords['latitude'] + ',' + position.coords['longitude'];
        this.center = latlng;
        this.marker.lat = position.coords['latitude'].toString();
        this.marker.lng = position.coords['longitude'].toString();
        console.log(this.center);
      }, () => {
        alert('Please enable your geolocation');
      });
    }
  }
}
