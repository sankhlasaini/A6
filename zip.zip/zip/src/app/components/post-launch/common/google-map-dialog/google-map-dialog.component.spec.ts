// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { GoogleMapDialogComponent } from './google-map-dialog.component';

// describe('GoogleMapComponent', () => {
//   let component: GoogleMapDialogComponent;
//   let fixture: ComponentFixture<GoogleMapDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ GoogleMapDialogComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(GoogleMapDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
