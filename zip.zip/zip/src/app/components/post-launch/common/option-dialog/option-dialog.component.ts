import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Component, Inject } from '@angular/core';

@Component({
  selector: 'option-dialog',
  templateUrl: './option-dialog.component.html',
  styleUrls: ['./option-dialog.component.css'],
})
export class OptionDialogComponent {

  public optionsData: any;

  constructor( @Inject(MAT_DIALOG_DATA) public data: any, private dialogRef: MatDialogRef<OptionDialogComponent>) {
    this.optionsData = data;
  }

  public close() {
    this.dialogRef.close('close');
  }

  public action(index) {
    if (index === 1) {
      this.dialogRef.close('delete');
    }
  }

  public uploadLogo(fileEvent) {
    this.dialogRef.close(fileEvent);
  }

}
