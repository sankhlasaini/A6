// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ImageFullViewDialogComponent } from './image-full-view-dialog.component';

// describe('ImageFullViewDialogComponent', () => {
//   let component: ImageFullViewDialogComponent;
//   let fixture: ComponentFixture<ImageFullViewDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ImageFullViewDialogComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ImageFullViewDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
