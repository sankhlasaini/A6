import { ImageCropperComponent } from 'ng2-img-cropper';
import { Component, OnInit, Inject, ViewChild, OnChanges } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-image-full-view-dialog',
  templateUrl: './image-full-view-dialog.component.html',
  styleUrls: ['./image-full-view-dialog.component.css']
})
export class ImageFullViewDialogComponent implements OnInit {

  private imageSize;
  private width;
  private height;
  // tslint:disable-next-line:max-line-length
  constructor( @Inject(MAT_DIALOG_DATA) public data: any, private dialogRef: MatDialogRef<ImageFullViewDialogComponent>) { }

  public ngOnInit() {
    this.width = document.getElementById('fullView').clientWidth;
    this.height = document.getElementById('fullView').clientHeight;
    this.setImage();
    this.getimage();
  }

  public close() {
    this.dialogRef.close(this.data);
  }

  public getimage() {
    const image = new Image();
    console.log('width', this.width, 'height', this.height);
    const path = this.data;
    image.src = path;

    const promise = new Promise((resolve, reject) => {
      image.onload = () => {
        const imgHeight = image.height;
        const imgWidth = image.width;
        const imageSize = { imgHeight, imgWidth };
        if (imageSize != null) { resolve(imageSize); } else { reject('ERROR'); }
      };
    })
      .then(
      (data) => {
        console.log(data);
        this.imageSize = data;
        if (this.imageSize.imgHeight / this.imageSize.imgWidth >= 2) {
          const renderImage = document.getElementById('renderImage');
          renderImage.style.width = (this.width - 50) + 'px';
          renderImage.style.height = (this.height - 100) + 'px';
        }
        return data;
      },
      (err) => { console.log(err); }
      );
  }

  public setImage() {
    const image = document.getElementById('renderImage');
    image.style.width = this.width + 'px';
    // image.style.height = ((62 * screen.height) / 800) + 'px';
  }
}
