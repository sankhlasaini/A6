import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailListCardComponent } from './detail-list-card.component';

describe('DetailListCardComponent', () => {
  let component: DetailListCardComponent;
  let fixture: ComponentFixture<DetailListCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailListCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailListCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
