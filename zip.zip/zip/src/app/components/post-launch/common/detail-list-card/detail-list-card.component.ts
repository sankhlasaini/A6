import { ListDialogComponent } from './../list-dialog/list-dialog.component';
import { MatDialog } from '@angular/material';
import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { CrossPlatformService } from '../../../../services/postLaunch/cross-platform.service';
import { ProfileSetupService } from '../../../../services/postLaunch/profile-setup.service';

@Component({
  selector: 'app-detail-list-card',
  templateUrl: './detail-list-card.component.html',
  styleUrls: ['./detail-list-card.component.css']
})
export class DetailListCardComponent implements OnChanges {
  @Input() public configuration;
  @Input() public inputData;
  @Output() public outputEvent = new EventEmitter();

  public inputData2;
  public footer1;
  public footer2;
  public multiSelectArray = [];
  // public check = false;
  public forTerritory = false;

  constructor(
    private crossPlatformService: CrossPlatformService,
    private profileSetupService: ProfileSetupService
  ) {
  }

  public ngOnChanges() {
    this.inputData2 = this.inputData;

    // if(this.inputData2.subTitle){
    //   this.inputData2.for
    // }

    this.multiSelectArray = [];
    if (this.configuration.from === 'territory') {
      this.forTerritory = true;
    }
    if (this.configuration.footer) {
      this.footer1 = this.inputData2.footer[0];
      this.footer2 = this.inputData2.footer[1];
    }

    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      if (this.configuration.image) {
        if (this.inputData2.imageId) {
          this.inputData2.avatar = this.profileSetupService.getDownloadFileUrl([this.inputData2.imageId], token)[0];
        } else {
          this.inputData2.avatar = '../../../../../assets/images/user-default.png';
        }
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public outputResponse() {
    this.outputEvent.emit('IN LIST CARD');
  }

  public footerClickEvent(placeholder, value, clickable) {
    if (clickable) {
      this.inputData2.footer.forEach((footer) => {
        if (placeholder === footer.placeholder) {
          this.outputEvent.emit({
            eventFrom: 'footer',
            eventData: placeholder,
            reference: this.inputData2.title,
            id: this.inputData2.id,
            initialData: this.inputData2.initialData,
            userList: this.inputData2.userList,
            dataLength: value,
          });
          console.log(placeholder, value);
        }
      });
    }
  }

  public menuClickEvent(option, index) {
    console.log('menu option is detailList', option);
    if (option === 'Select') {
      this.configuration.multiSelect = true;
      this.configuration.menu = false;
      this.multiSelectEvent(option);
    } else {
      this.outputEvent.emit({
        eventFrom: 'menu', eventData: option, reference: this.inputData2.title, id: this.inputData2.id,
        initialData: this.inputData2.initialData, userList: this.inputData2.userList
      });
    }
  }

  public cardClickEvent(cardData) {
    console.log('cardData is', cardData);

    this.outputEvent.emit({ eventFrom: 'card', eventData: cardData });
  }

  public multiSelectEvent(option) {
    this.inputData2.isSelected = !this.inputData2.isSelected;
    this.outputEvent.emit({
      eventFrom: 'multiSelect',
      eventData: option,
      reference: this.inputData2.title,
      id: this.inputData2.id,
      initialData: this.inputData2.initialData,
      isSelected: this.inputData2.isSelected
    });
  }

}
