import { HelperService } from './../../../../services/helper.service';
import { ProfileSetupService } from './../../../../services/postLaunch/profile-setup.service';
import { Component, OnInit, Inject, OnChanges } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { ServiceCatalogService } from '../../../../services/postLaunch/service-catalog.service';

@Component({
  selector: 'app-view-all-documents-dialog',
  templateUrl: './view-all-documents-dialog.component.html',
  styleUrls: ['./view-all-documents-dialog.component.css']
})
export class ViewAllDocumentsDialogComponent {

  public filesArray = [];

  public loading = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public inputData: any,
    private profileSetupService: ProfileSetupService,
    public crossPlatformService: CrossPlatformService,
    private helperService: HelperService,
    private serviceCatalogService: ServiceCatalogService,
    private dialogRef: MatDialogRef<ViewAllDocumentsDialogComponent>
  ) {
    console.log(this.inputData);
    this.filesArray = this.inputData.data;
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.filesArray.forEach((file) => {
        if (this.inputData.from.toLowerCase() === 'service') {
          file.url = file.gridFSid;
        } else {
          file.url = this.profileSetupService.getDownloadFileUrl([file.gridFSid], token)[0];
        }
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public close() {
    console.log(this.filesArray);
    this.filesArray.forEach((file) => { delete file.url; });
    this.dialogRef.close(this.filesArray);
  }

  public deleteFile(index) {
    this.filesArray.splice(index, 1);
  }

  public addFiles(event) {
    this.loading = true;
    let tempFilesArray = [];
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < event.srcElement.files.length; i++) {
      const fileType = event.srcElement.files[i].type;
      if (fileType === 'application/msword' || fileType === 'application/pdf' || fileType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        if (event.srcElement.files[i].size <= (2 * 1024 * 1024)) {
          tempFilesArray.push(event.srcElement.files[i]);
        } else {
          this.helperService.openSnackBar('Maximum 2 MB File Allowed', 'Try Again');
        }
      } else {
        this.helperService.openSnackBar('Only .doc, .docx, .pdf Allowed', 'Try Again');
      }
    }
    console.log('-----TEMP FILTER ARRAY----', tempFilesArray);
    if (tempFilesArray.length > 0) {
      const totalFiles = this.filesArray.length + tempFilesArray.length;
      console.log('Totel Files : ', totalFiles);
      if (totalFiles > this.inputData.limit) {
        this.helperService.openSnackBar('Max ' + this.inputData.limit + ' Files are Allowed', 'Select Again');
        this.loading = false;
      } else {
        setTimeout(() => { this.helperService.openSnackBar('Adding Files', 'Please Wait'); }, 1000);
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          if (this.inputData.from.toLowerCase() === 'service') {
            this.cmfFilesUpload(tempFilesArray, token);
          } else {
            this.panmFilesUpload(tempFilesArray, token);
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    } else {
      this.loading = false;
    }
  }

  public panmFilesUpload(files, token) {
    this.profileSetupService.uploadFile(files, token).subscribe((response) => {
      console.log('Images panm Upload res : ', response);
      this.loading = false;

      if (response.success) {
        response.result.forEach((res) => {
          this.filesArray.push({
            gridFSid: res.gridFSid,
            gridFsFileName: res.fileName,
            url: this.profileSetupService.getDownloadFileUrl([res.gridFSid], token)[0]
          });
          this.helperService.openSnackBar('Images Added', 'OK');
        });
      }
    }, (err) => {
      this.loading = false;

      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public cmfFilesUpload(files, token) {
    this.serviceCatalogService.uploadDocuments(files, token).subscribe((response) => {
      console.log('Documents cmf Upload res : ', response);
      this.loading = false;

      if (response.success) {

        response.result.specification.forEach((res) => {
          this.filesArray.push({
            gridFSid: res.id,
            gridFsFileName: res.fileName,
            id: res.id,
            fileName: res.fileName,
            url: res.id
          });
          this.helperService.openSnackBar('Files Added', 'OK');
        });
      }
    }, (err) => {
      this.loading = false;
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public downloadFile(id) {
    if (this.inputData.from.toLowerCase() === 'service') {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.serviceCatalogService.downloadFile(id, token).subscribe((fileRes) => {
          console.log(fileRes);
          if (fileRes.success) {
            let link = document.createElement('a');
            link.href = 'data:' + fileRes.result.fileType + ';base64,' + fileRes.result.fileContent;
            link.download = fileRes.result.fileName;
            link.click();
          }
        });
      });
    } else {
      let link = document.createElement('a');
      link.href = id;
      link.click();
    }
  }
}
