// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ViewAllDocumentsDialogComponent } from './view-all-documents-dialog.component';

// describe('ViewAllDocumentsDialogComponent', () => {
//   let component: ViewAllDocumentsDialogComponent;
//   let fixture: ComponentFixture<ViewAllDocumentsDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ViewAllDocumentsDialogComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ViewAllDocumentsDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
