import { AssetService } from './../../../../services/postLaunch/asset.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { TerritoryService } from './../../../../services/postLaunch/territory.service';
import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-dialog',
  templateUrl: './list-dialog.component.html',
  styleUrls: ['./list-dialog.component.css']
})
export class ListDialogComponent {
  public territoryNameArray = [];
  public templateType = 'serviceCatagory';
  public serviceLineList = [];
  public reporteeData = [];
  constructor(
    private router: Router,
    private territoryService: TerritoryService,
    private crossPlatformService: CrossPlatformService,
    private assetService: AssetService,
    @Inject(MAT_DIALOG_DATA) public dataList: any,
    private dialogRef: MatDialogRef<ListDialogComponent>) {
    console.log(this.dataList);
    const listDialog = JSON.parse(JSON.stringify(this.dataList));
    switch (listDialog.type) {
      case 'serviceLine':
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          this.assetService.getGetCategoryByLevel(this.templateType, token).subscribe((res) => {
            if (res.success) {
              res.result.categories == null ? res.result.categories = [] : res.result.categories = res.result.categories;
              // this.serviceLineList = res.result.categories;
              console.log('getGetCategoryByLevel : ', res.result.categories);
              listDialog.data.forEach((serviceLineId) => {
                res.result.categories.forEach((serviceLine) => {
                  if (serviceLine.id === serviceLineId) {
                    this.serviceLineList.push({ line1: serviceLine.name });
                  }
                });
              });
              this.dataList.data = this.serviceLineList;
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
        break;
      case 'territories':
        this.crossPlatformService.checkPartyAccessToken().subscribe((at) => {
          this.territoryService.getTerritoryById(at, listDialog.data).subscribe((res) => {
            console.log('res for terr', res);
            if (res.success) {
              if (res.result) {
                res.result.forEach((element) => {
                  this.territoryNameArray.push({ line1: element.territoryName });
                  if (this.territoryNameArray.length === listDialog.data.length) {
                    this.dataList.data = this.territoryNameArray;
                    console.log('res for getTerritoryById', listDialog.data);
                  }
                });
              }
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });

        break;
      case 'reportees':
        console.log('reportees', listDialog);
        this.reporteeData = [];
        listDialog.data.forEach((reportee) => {
          const role = reportee.roles.map((reporteeRole) => reporteeRole.roleLabel);
          this.reporteeData.push({ line1: reportee.name, line2: role });
        });
        this.dataList.data = this.reporteeData;
        break;
      default:
        break;
    }
  }

  public selectItem(item) {
    if (this.dataList.selectable) {
      this.dialogRef.close(item);
    }
  }

  public close() {
    this.dialogRef.close();
  }

}
