import { Component, OnInit, Inject, ViewChild, OnChanges } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { ImageCropperComponent, ImageCropperModule, CropperSettings, Bounds } from 'ng2-img-cropper';

@Component({
  selector: 'app-crop-image-dialog',
  templateUrl: './crop-image-dialog.component.html',
  styleUrls: ['./crop-image-dialog.component.css']
})
export class CropImageDialogComponent implements OnInit {

  @ViewChild('cropper', undefined)
  public cropper: ImageCropperComponent;
  public imagedata: any;
  public name: string;
  public cropperSettings: CropperSettings;
  public croppedWidth: number;
  public croppedHeight: number;
  public file: File;
  public croppedImage = false;

  // tslint:disable-next-line:max-line-length
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<CropImageDialogComponent>
  ) { }

  public ngOnInit() {
    const width = document.getElementById('cropContainer').clientWidth;
    const height = document.getElementById('cropContainer').clientHeight;

    this.cropperSettings = new CropperSettings();
    this.cropperSettings.noFileInput = true;
    this.cropperSettings = new CropperSettings();
    this.cropperSettings.width = width;
    this.cropperSettings.height = width;
    this.cropperSettings.croppedWidth = 400;
    this.cropperSettings.croppedHeight = 400;
    this.cropperSettings.canvasWidth = width;
    this.cropperSettings.canvasHeight = height - 100;
    this.cropperSettings.minWidth = 5;
    this.cropperSettings.minHeight = 5;
    this.cropperSettings.rounded = false;
    this.cropperSettings.cropperDrawSettings.strokeColor = 'rgba(255,255,255,1)';
    this.cropperSettings.cropperDrawSettings.strokeWidth = 2;
    this.cropperSettings.keepAspect = true;
    this.cropperSettings.preserveSize = true;
    this.cropperSettings.cropOnResize = true;
    this.fileChangeListener(this.data);
    this.imagedata = {};
  }

  public imageConvertor() {
    const file = this.data;
    const imgB64 = this.imagedata.image;
    const image = imgB64.split(',')[1];
    const byteCharacters = atob(image);

    const byteNumbers = new Array(byteCharacters.length);
    // console.log(file);
    // console.log(imgB64);
    // console.log(image);
    // console.log(byteCharacters);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blob = new Blob([byteArray], { type: file.type });
    // tslint:disable-next-line:max-line-length
    const cropedImageFileObj = new File([blob], file.name, { type: file.type, lastModified: Date.now() });
    this.fileChangeListener(cropedImageFileObj);
    return cropedImageFileObj;
  }

  public fileChangeListener($event) {
    const image: any = new Image();
    if ($event.srcElement) {
      this.file = $event.target.files[0];
    } else {
      this.file = $event;
    }
    const myReader: FileReader = new FileReader();
    const that = this;
    myReader.onloadend = (loadEvent: any) => {
      // console.log(loadEvent);
      image.src = loadEvent.target.result;
      that.cropper.setImage(image);
    };
    myReader.readAsDataURL(this.file);
  }

  public crop() {
    const imageObj = { image: this.imagedata.image, cropedImageFileObj: this.imageConvertor() };
    this.dialogRef.close(imageObj);
    // this.dialogRef.close();
  }

  public close() {
    this.dialogRef.close();
  }

}
