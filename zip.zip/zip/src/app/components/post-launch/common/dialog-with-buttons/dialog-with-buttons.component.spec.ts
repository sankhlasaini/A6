import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogWithButtonsComponent } from './dialog-with-buttons.component';

describe('DialogWithButtonsComponent', () => {
  let component: DialogWithButtonsComponent;
  let fixture: ComponentFixture<DialogWithButtonsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogWithButtonsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogWithButtonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
