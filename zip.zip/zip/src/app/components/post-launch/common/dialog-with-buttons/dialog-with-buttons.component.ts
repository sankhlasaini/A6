import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';
import { CrossPlatformService } from '../../../../services/postLaunch/cross-platform.service';
import { TerritoryService } from '../../../../services/postLaunch/territory.service';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-dialog-with-buttons',
  templateUrl: './dialog-with-buttons.component.html',
  styleUrls: ['./dialog-with-buttons.component.css']
})
export class DialogWithButtonsComponent implements OnInit {

  // input for this Dialog
  // data: {
  //   config: { button: true, input: true, cancelButton: true, multiselect: true, singleSelect: true },
  //   for: '',
  //   title: '',
  //   input: { placeholder: '' },
  //   button: { text: '' }
  // }

  public inputName;
  public error = { showError: '', errorFlag: false };
  public nameFormControl = new FormControl('', [Validators.required, Validators.maxLength(30), Validators.pattern(/^[A-Za-z\d\s]+$/)]);

  constructor(
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<DialogWithButtonsComponent>,
    private crossPlatformService: CrossPlatformService,
    private territoryService: TerritoryService
  ) { }

  public ngOnInit() {
    if (this.data.input) {
      this.nameFormControl.patchValue(this.data.input.label);
    }
    console.log(this.data);
  }

  public close() {
    this.dialogRef.close();
  }

  public action(actionFor) {
    console.log(this.nameFormControl, 'valid : ', this.nameFormControl.valid, actionFor);
    switch (actionFor) {
      case 'confirm':
        this.dialogRef.close('OK');
        break;
      case 'newTerritory':
        const newLabel = this.nameFormControl.value;
        if (newLabel.trim() !== '') {
          this.nameFormControl.setErrors(null);
          if (newLabel.trim().toLowerCase() === this.data.input.defaultLabel) {
            this.dialogRef.close(this.nameFormControl.value);
          } else {
            this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
              this.territoryService.duplicateTerritoryNameCheck(this.crossPlatformService.getOrgId().user.orgId, newLabel, token).subscribe((res) => {
                console.log(res);
                if (res.success && res.result) {
                  this.nameFormControl.setErrors({ duplicateName: true });
                } else {
                  this.dialogRef.close(this.nameFormControl.value);
                }
              }, (err) => {
                console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
              });
            }, (err) => {
              console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
            });
          }
        }
        break;
      case 'asignUsersTo':
        const tempArray = this.data.multiSelectArray.filter((item) => item.isSelected === true);
        console.log('tempArray', tempArray);
        if (tempArray.length > 0) {
          this.dialogRef.close(tempArray);
        }
        break;
      default:
        if (this.nameFormControl.valid) { this.dialogRef.close(this.nameFormControl.value); }
        break;
    }
  }

  public selectedData(index) {
    if (this.data.config.singleSelect) {
      this.data.multiSelectArray.forEach((item, i) => {
        index === i ? item.isSelected = true : item.isSelected = false;
      });
    } else if (this.data.config.multiSelect) { this.data.multiSelectArray[index].isSelected = !this.data.multiSelectArray[index].isSelected; }
  }

  public validateLabel(newLabel) {
    if (this.data.input && this.data.input.labelList) {
      newLabel = newLabel.toLowerCase().trim();
      if (newLabel !== '' && !this.nameFormControl.getError('pattern') && newLabel.length <= 30) {
        if (this.data.input.labelList.indexOf(newLabel) === -1) {
          this.nameFormControl.setErrors(null);
        } else {
          console.log('error');
          this.nameFormControl.setErrors({ duplicateLabel: true });
        }
      }
    }
  }

}
