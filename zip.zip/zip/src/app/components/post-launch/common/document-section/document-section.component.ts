import { ServiceCatalogService } from './../../../../services/postLaunch/service-catalog.service';
import { HelperService } from './../../../../services/helper.service';
import { Component, OnInit, Input, EventEmitter, OnChanges, Output } from '@angular/core';
import { CrossPlatformService } from '../../../../services/postLaunch/cross-platform.service';
import { ProfileSetupService } from '../../../../services/postLaunch/profile-setup.service';
import { MatDialog } from '@angular/material';
import { ViewAllDocumentsDialogComponent } from '../view-all-documents-dialog/view-all-documents-dialog.component';

@Component({
  selector: 'app-document-section',
  templateUrl: './document-section.component.html',
  styleUrls: ['./document-section.component.css']
})
export class DocumentSectionComponent implements OnChanges {

  @Input() public inputData;
  @Input() public limit;
  @Input() public from;
  @Output() public outputData = new EventEmitter();

  public docArray = [];
  public fileSelection = 'multiple';
  public align = 'row';
  public loading = false;

  constructor(
    private helperService: HelperService,
    private crossPlatformService: CrossPlatformService,
    private profileSetupService: ProfileSetupService,
    public dialog: MatDialog,
    private serviceCatalogService: ServiceCatalogService
  ) { }

  public ngOnChanges() {
    this.fileSelection = this.limit === 1 ? 'single' : 'multiple';
    console.log('in docs section : ', this.inputData);
    if (!this.inputData) {
      this.inputData = [];
    } else {
      if (this.from.toLowerCase() === 'service') {
        this.align = 'column';
        this.inputData.forEach((d) => { d.gridFSid = d.id; d.gridFsFileName = d.fileName; });
      }
    }
  }

  public fileUplaod(event) {
    let tempFilesArray = [];
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < event.srcElement.files.length; i++) {
      const fileType = event.srcElement.files[i].type;
      if (fileType === 'application/msword' || fileType === 'application/pdf' || fileType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        if (event.srcElement.files[i].size <= (2 * 1024 * 1024)) {
          tempFilesArray.push(event.srcElement.files[i]);
        } else {
          this.helperService.openSnackBar('Maximum 2 MB File Allowed', 'Try Again');
        }
      } else {
        this.helperService.openSnackBar('Only .doc, .docx, .pdf Allowed', 'Try Again');
      }
    }
    console.log('-----TEMP FILTER ARRAY----', tempFilesArray);
    if (tempFilesArray.length > 0) {
      const totalFiles = this.inputData.length + tempFilesArray.length;
      console.log('Totel Files : ', totalFiles);
      if (totalFiles > this.limit) {
        this.helperService.openSnackBar('Max ' + this.limit + ' Files are Allowed', 'Select Again');
      } else {
        this.loading = true;
        setTimeout(() => { this.helperService.openSnackBar('Adding Files', 'Please Wait'); }, 1000);
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          if (this.from.toLowerCase() === 'service') {
            this.cmfFilesUpload(tempFilesArray, token);
          } else {
            this.panmFilesUpload(tempFilesArray, token);
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    }
  }

  public panmFilesUpload(files, token) {
    this.profileSetupService.uploadFile(files, token).subscribe((response) => {
      console.log('Documents panm Upload res : ', response);
      this.loading = false;
      if (response.success) {
        response.result.forEach((res) => {
          this.inputData.push({ gridFSid: res.gridFSid, gridFsFileName: res.fileName });
          this.outputData.emit(this.inputData);
          this.helperService.openSnackBar('Files Added', 'OK');
        });
      }
    }, (err) => {
      this.loading = false;
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public cmfFilesUpload(files, token) {
    this.serviceCatalogService.uploadDocuments(files, token).subscribe((response) => {
      console.log('Documents cmf Upload res : ', response);
      this.loading = false;
      if (response.success) {
        response.result.specification.forEach((res) => {
          this.inputData.push({ gridFSid: res.id, gridFsFileName: res.fileName, id: res.id, fileName: res.fileName });
          this.outputData.emit(this.inputData);
          this.helperService.openSnackBar('Files Added', 'OK');
        });
      }
    }, (err) => {
      this.loading = false;
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public viewAllDocsDialog() {
    const dialogRef = this.dialog.open(ViewAllDocumentsDialogComponent, {
      maxWidth: '100%',
      width: '100%',
      height: '100%',
      autoFocus: false,
      data: { data: this.inputData, limit: this.limit, from: this.from, fileSelection: this.fileSelection },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.inputData = result;
        this.outputData.emit(this.inputData);
      }
    });

  }

}
