import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'app-selection-list-dialog',
  templateUrl: './selection-list-dialog.component.html',
  styleUrls: ['./selection-list-dialog.component.css']
})
export class SelectionListDialogComponent implements OnInit {

  constructor(
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<SelectionListDialogComponent>
  ) { }

  public ngOnInit() {
    console.log(this.data);
  }

}
