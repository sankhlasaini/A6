import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectionListDialogComponent } from './selection-list-dialog.component';

describe('SelectionListDialogComponent', () => {
  let component: SelectionListDialogComponent;
  let fixture: ComponentFixture<SelectionListDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectionListDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectionListDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
