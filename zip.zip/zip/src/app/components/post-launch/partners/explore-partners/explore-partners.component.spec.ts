// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ExplorePartnersComponent } from './explore-partners.component';

// describe('ExplorePartnersComponent', () => {
//   let component: ExplorePartnersComponent;
//   let fixture: ComponentFixture<ExplorePartnersComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ExplorePartnersComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ExplorePartnersComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
