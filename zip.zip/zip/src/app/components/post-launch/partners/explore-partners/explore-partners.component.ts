import { TerritoryService } from './../../../../services/postLaunch/territory.service';
import { slideDown, slideUp } from './../../../../animations';
import { HelperService } from './../../../../services/helper.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { Component, OnInit, ViewChildren, QueryList, AfterViewInit } from '@angular/core';
import { PartnerService } from './../../../../services/postLaunch/partner.service';
import { InfiniteScroll } from './../../../../angular2-infinitescroll';
import { RetailerProfileDialogComponent } from './../retailer-profile-dialog/retailer-profile-dialog.component';
import { MatDialog } from '@angular/material';
import { Output, EventEmitter } from '@angular/core';
import { ProfileSetupService } from '../../../../services/postLaunch/profile-setup.service';
import { SwiperComponent } from 'angular2-useful-swiper';

@Component({
  selector: 'app-explore-partners',
  templateUrl: './explore-partners.component.html',
  styleUrls: ['./explore-partners.component.css'],
  animations: [slideDown, slideUp]
})
export class ExplorePartnersComponent {

  @ViewChildren('swiperCard') public swiperCard: QueryList<SwiperComponent>;

  public partnerList = [];
  public partnerFullList = [];
  public accessToken = '';
  public territoryIds = [];

  public config: SwiperOptions = {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    spaceBetween: 0,
    slidesPerView: 'auto',
    grabCursor: true,
  };

  public orgId;
  public loadMore = true;
  public loading = false;
  public partnersPageSize = 20;
  public fileUrl;

  constructor(
    private partnerService: PartnerService,
    private crossPlatformService: CrossPlatformService,
    public dialog: MatDialog,
    private territoryService: TerritoryService,
    private helperService: HelperService,
    private profileSetupService: ProfileSetupService,
  ) {
    this.orgId = this.crossPlatformService.getOrgId().orgId;
    this.findNotConnectedOrg();
  }

  public findNotConnectedOrg() {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.accessToken = token.accessToken;
      this.partnerService.findNotConnectedOrg(this.orgId, token).subscribe((res) => {
        console.log(res);
        if (res.success) {
          res.result.forEach((p) => {
            p.territories = p.territories ? p.territories : [];
            this.partnerFullList.push({
              name: p.name,
              area: p.orgProfile.contactPersons[0].contactAddress.line1 + (p.orgProfile.contactPersons[0].contactAddress.line1 === '' ? '' : ',')
                + p.orgProfile.contactPersons[0].contactAddress.city,
              partyId: p.partyId,
              accountId: p.accountId,
              email: p.email,
              territoryNameList: [],
              territoryIdsList: p.territories.map((t) => t.id),
              mobile: p.mobile,
              avatar: '../../../../../assets/images/user-default.png',
              party: p,
            });
            p.territories.map((t) => t.id).forEach((id) => { if (this.territoryIds.indexOf(id) === -1) { this.territoryIds.push(id); } });
          });
          if (this.territoryIds.length > 0) {
            this.territoryService.getTerritoriesNameByIds(this.territoryIds, token).subscribe((idsRes) => {
              console.log(idsRes);
              if (idsRes.success) {
                this.partnerFullList.forEach((rl) => {
                  if (rl.party && rl.party.orgProfile.avatar && rl.party.orgProfile.avatar.gridFSid) {
                    rl.avatar = this.profileSetupService.getDownloadFileUrl([rl.party.orgProfile.avatar.gridFSid], token)[0];
                  }
                  rl.territoryIdsList.forEach((id) => {
                    const ter = idsRes.result.find((t) => t.territoryId === id);
                    if (ter) { rl.territoryNameList.push(ter.name); }
                  });
                });
              }
            }, (err) => {
              console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
            });
          }
          this.getNextList(0);
        } else {
          this.loadMore = false;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getNextList(start) {
    console.log(start, ' - ', start + this.partnersPageSize);
    if (this.partnerList.length <= this.partnerFullList.length) {
      const nextList = this.partnerFullList.slice(start, start + this.partnersPageSize);
      this.partnerList = this.partnerList.concat(nextList);
      console.log(this.partnerFullList);
      console.log(this.partnerList);
      if (this.partnerList.length >= this.partnerFullList.length) {
        this.loadMore = false;
      }
    }
  }

  public showProfile(partner, index) {
    const dialogRef = this.dialog.open(RetailerProfileDialogComponent, {
      width: '100%',
      height: '100%',
      maxWidth: '100%',
      data: { partner, type: 'explore', existing: true, showAction: true },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
      if (result.success && result.success === true) {
        partner.hide = true;
      }
    });
  }

  public sendConnect(partner, index) {
    this.swiperCard.forEach((element, i) => {
      if (i !== index) { element.swiper.slidePrev(); }
    });
    this.loading = true;
    console.log(partner);

    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.partnerService.addNetwork(this.orgId, partner.partyId, token).subscribe((res) => {
        console.log(res);
        this.loading = false;
        if (res.success && res.result) {
          partner.hide = true;
          this.getNextList(this.partnerList.length);
          // setTimeout(() => {
          //   this.partnerList.splice(index, 1);
          // }, 400);
          this.helperService.openSnackBar('Connect Request Sent to ' + partner.name, 'OK');
        } else {
          this.helperService.openSnackBar('Connect Request Failed', 'Try Again');
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

}
