import { HelperService } from './../../../../services/helper.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { Component, OnInit } from '@angular/core';
import { EditInviteDialogComponent } from './../edit-invite-dialog/edit-invite-dialog.component';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { PartnerService } from './../../../../services/postLaunch/partner.service';

@Component({
  selector: 'app-send-invite',
  templateUrl: './send-invite.component.html',
  styleUrls: ['./send-invite.component.css']
})
export class SendInviteComponent implements OnInit {
  public isLoading = false;
  public links = {
    playStore: '',
    iStore: ''
  };
  public currentUserName = '';
  public smsHide: boolean = true;
  public emailHide: boolean = true;
  public pushLeftSms = '';
  public pushLeftEmail = '';
  public details = {
    sms: {
      // tslint:disable-next-line:max-line-length
      content: 'Hi, You have invited by <<User Name who is sending Invite>> from <<Party Name who is sending Invitation>> to join DV as thier Partner and get the opportunity to expand your business online. Click here <<DV App playstore link>> - Google PlayStore <<DV App istore link>> - Apple AppStore to join'
    },
    email: {
      subject: 'Invitation from your business partner <<Party Name who is sending Invitation>> to join DV',
      // tslint:disable-next-line:max-line-length
      content: 'Dear <<Contact Person Name>>, You have invited by <<User Name who is sending Invite>> from <<Party Name who is sending Invitation>> to join DV as thier Partner. With DeltaVerge , you can explore, collaborate with other partners and offer exciting products to customer. With the platform, you can monitor product performance, auto-settle and course-correct your offerings on-the-go.<<DV App playstore link>> - Google PlayStore <<DV App istore link>> - Apple AppStore. Cheers, Team Deltaverge'
    }
  };

  public obj = {
    invitatedPartyName: 'PUNIA',
    partySubType: 'PRIVILEDGE',
    referalPartyName: 'YADWINDER',
    email: 'yadpunia10@gmail.com',
    mobile: '8950056890',
    sendtoMobile: true,
    sendtoEmail: false,
    webURL: 'www.google.com',
    iosURL: 'www.iphone.com',
    playStoreURL: 'www.playstore.com',
    ecosystemProfileId: 'gffgdfggf',
    ecosystemId: 'bmbmbmbmnjjnj',
    profileLabelName: 'FARMER',
    isSentByExistingOnboardedParty: false,
    status: 'PENDING',
    referalOrgId: '70a16e92-7bd4-4d59-a8e4-8b1c5e497794',
    reminder: false,
    count: 1,
    requestDocuments: [],
    businessIdValue: ''
  };

  public sendInviteObj;
  constructor(
    public dialog: MatDialog, private router: Router,
    private partnerService: PartnerService,
    private crossPlatformService: CrossPlatformService,
    private helperService: HelperService) {
  }

  public ngOnInit() {
    this.currentUserName = this.crossPlatformService.getOrgId().partyName;
    this.setPreviewMessage();
  }

  public setPreviewMessage() {
    this.sendInviteObj = this.partnerService.getDetails();
    console.log(this.sendInviteObj);
    if (this.sendInviteObj) {
      this.details.sms.content = this.details.sms.content.replace('<<User Name who is sending Invite>>', this.currentUserName);
      this.details.sms.content = this.details.sms.content.replace('<<Party Name who is sending Invitation>>', this.sendInviteObj.partyName);
      this.details.sms.content = this.details.sms.content.replace('<<DV App playstore link>>', this.links.playStore);
      this.details.sms.content = this.details.sms.content.replace('<<DV App istore link>>', this.links.iStore);

      this.details.email.content = this.details.email.content.replace('<<User Name who is sending Invite>>', this.currentUserName);
      this.details.email.content = this.details.email.content.replace('<<Party Name who is sending Invitation>>', this.sendInviteObj.partyName);
      this.details.email.content = this.details.email.content.replace('<<Contact Person Name>>', this.sendInviteObj.referalUserName);
      this.details.email.content = this.details.email.content.replace('<<DV App playstore link>>', this.links.playStore);
      this.details.email.content = this.details.email.content.replace('<<DV App istore link>>', this.links.iStore);

      this.details.email.subject = this.details.email.subject.replace('<<Party Name who is sending Invitation>>', this.sendInviteObj.partyName);
    }
  }

  public editInvite(option) {

    const dialogRef = this.dialog.open(EditInviteDialogComponent, {
      width: '100%',
      height: '100%',
      maxWidth: '100%',
      data: {
        option,
        details: this.details
      }
    });
  }

  public onSendInvite() {
    if (this.sendInviteObj) {
      delete this.sendInviteObj.partyName;
      delete this.sendInviteObj.userName;

      this.isLoading = true;

      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        // this.partnerService.sendInvite(this.sendInviteObj, token).subscribe((res) => {
        //   console.log(res);
        //   this.isLoading = false;
        //   if (res.success && res.result.invitationId !== undefined && res.result.invitationId !== null) {
        //     this.helperService.openSnackBar('Invite sent successfully', 'OK');
        //     this.router.navigate(['/postLaunch/partner']);
        //   } else {
        //     this.helperService.openSnackBar('Sorry! Try again', 'OK');
        //   }
        // });
      });
    }
  }
}
