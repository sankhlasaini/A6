import { ProfileSetupService } from './../../../../services/postLaunch/profile-setup.service';
import { SwiperComponent } from 'angular2-useful-swiper/lib/swiper.module';
import { slideDown, slideUp } from './../../../../animations';
import { HelperService } from './../../../../services/helper.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { RetailerProfileDialogComponent } from './../retailer-profile-dialog/retailer-profile-dialog.component';
import { PartnerService } from './../../../../services/postLaunch/partner.service';
import { MatDialog } from '@angular/material';
import { Component } from '@angular/core';
import { Output, EventEmitter } from '@angular/core';
import { TerritoryService } from '../../../../services/postLaunch/territory.service';

@Component({
  selector: 'app-connections',
  templateUrl: './connections.component.html',
  styleUrls: ['./connections.component.css'],
  animations: [slideDown, slideUp]
})
export class ConnectionsComponent {

  // loading = true;
  public orgId;
  public partnerList = [];
  public connectedNetworkList = [];
  public loadMore = true;
  public partnersPageSize = 20;
  public endOfRecoards = false;
  public fileUrl;
  public accessToken = '';
  public networkHitCount = 0;
  public territoryIds = [];

  constructor(
    public dialog: MatDialog,
    private partnerService: PartnerService,
    private crossPlatformService: CrossPlatformService,
    private helperService: HelperService,
    private profileSetupService: ProfileSetupService,
    private territoryService: TerritoryService,
  ) {
    this.orgId = this.crossPlatformService.getOrgId().orgId;
    this.networkHitCount = 0;
    this.findNetwork({ sourceId: this.crossPlatformService.getOrgId().orgId, state: 'TRADABLE' });
    this.findNetwork({ targetId: this.crossPlatformService.getOrgId().orgId, state: 'TRADABLE' });
  }

  public findNetwork(param) {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      console.log(param);
      this.partnerService.findNetwork(param, token).subscribe((res) => {
        console.log('find AWAITED network : ', res);
        this.networkHitCount++;
        if (res.success) {
          this.connectedNetworkList = this.connectedNetworkList.concat(res.result);
          if (this.networkHitCount > 1) {
            this.connectedNetworkList = this.helperService.sortByTime(this.connectedNetworkList, 'updatedOn');
            console.log('calling ord');
            this.getPartnerDetails(0);
          }
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getPartnerDetails(startIndex) {
    console.log(startIndex, ' - ', startIndex + this.partnersPageSize);
    if (this.loadMore) {
      let partyList = [];
      for (let i = startIndex; i < startIndex + this.partnersPageSize; i++) {
        if (this.connectedNetworkList[i]) {
          if (this.connectedNetworkList[i].sourceId === this.orgId) {
            partyList.push({ partyId: this.connectedNetworkList[i].targetId });
          } else {
            partyList.push({ partyId: this.connectedNetworkList[i].sourceId });
          }
        }
      }
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.partnerService.findOrg(partyList, token).subscribe((res) => {
          if (res.success) {
            for (let i = startIndex; i < startIndex + this.partnersPageSize; i++) {
              if (this.connectedNetworkList[i]) {
                let party;
                if (this.connectedNetworkList[i].sourceId === this.orgId) {
                  party = res.result.find((p) => this.connectedNetworkList[i].targetId === p.partyId);
                } else {
                  party = res.result.find((p) => this.connectedNetworkList[i].sourceId === p.partyId);
                }
                this.partnerList.push(this.createRecord(this.connectedNetworkList[i], party));
              }
            }
            console.log('connected', this.partnerList);
            if (this.territoryIds.length > 0) {
              this.territoryService.getTerritoriesNameByIds(this.territoryIds, token).subscribe((idsRes) => {
                console.log(idsRes);
                if (idsRes.success) {
                  this.partnerList.forEach((rl) => {
                    if (rl.party && rl.party.orgProfile.avatar && rl.party.orgProfile.avatar.gridFSid) {
                      rl.avatar = this.profileSetupService.getDownloadFileUrl([rl.party.orgProfile.avatar.gridFSid], token)[0];
                    }
                    if (rl.territoryIdsList) {
                      rl.territoryIdsList.forEach((id) => {
                        const ter = idsRes.result.find((t) => t.territoryId === id);
                        if (ter) { rl.territoryNameList.push(ter.name); }
                      });
                    }
                  });
                }
              }, (err) => {
                console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
              });
            }
            if (this.partnerList.length >= this.connectedNetworkList.length) {
              this.loadMore = false;
            }
          } else {
            this.loadMore = false;
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public createRecord(ele, p) {
    if (p) {
      p.territories = p.territories ? p.territories : [];
      ele.name = p.name;
      ele.area = p.orgProfile.contactPersons[0].contactAddress.line1 + (p.orgProfile.contactPersons[0].contactAddress.line1 === '' ? '' : ',')
        + p.orgProfile.contactPersons[0].contactAddress.city;
      ele.partyId = p.partyId;
      ele.accountId = p.accountId;
      ele.territoryNameList = [];
      ele.territoryIdsList = p.territories.map((t) => t.id);
      ele.email = p.email;
      ele.mobile = p.mobile;
      ele.time = new Date(ele.updatedOn).toLocaleDateString('en-GB');
      ele.party = p;
      ele.avatar = '../../../../../assets/images/user-default.png';
      ele.territoryIdsList.forEach((id) => { if (this.territoryIds.indexOf(id) === -1) { this.territoryIds.push(id); } });
    }
    return ele;
  }

  public showProfile(partner) {
    const dialogRef = this.dialog.open(RetailerProfileDialogComponent, {
      width: '100%',
      height: '100%',
      maxWidth: '100%',
      data: { partner, type: 'connected', existing: true },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
    });
  }
}
