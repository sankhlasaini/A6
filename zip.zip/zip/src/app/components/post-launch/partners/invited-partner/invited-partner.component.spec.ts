// import { InvitedPartnerComponent } from './invited-partner.component';
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// describe('RecentActivitiesComponent', () => {
//   let component: InvitedPartnerComponent;
//   let fixture: ComponentFixture<InvitedPartnerComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [InvitedPartnerComponent]
//     })
//       .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(InvitedPartnerComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
