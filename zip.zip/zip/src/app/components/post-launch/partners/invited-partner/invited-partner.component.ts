import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { slideDown, slideUp } from './../../../../animations';
import { RetailerProfileDialogComponent } from './../retailer-profile-dialog/retailer-profile-dialog.component';
import { MatDialog } from '@angular/material';
import { HelperService } from './../../../../services/helper.service';
import { PartnerService } from './../../../../services/postLaunch/partner.service';
import { Component, Input } from '@angular/core';
import { Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-invited-partner',
  templateUrl: './invited-partner.component.html',
  styleUrls: ['./invited-partner.component.css'],
  animations: [slideDown, slideUp]
})
export class InvitedPartnerComponent {

  public config: SwiperOptions = {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    spaceBetween: 0,
    slidesPerView: 'auto',
    grabCursor: true,
  };

  public partnerList = [];
  public partnerListDisplay = [];
  public loading = false;
  public loadMore = true;
  public partnersPageSize = 10;

  constructor(
    private partnerService: PartnerService,
    private helperService: HelperService,
    public dialog: MatDialog,
    private crossPlatformService: CrossPlatformService
  ) {

    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      // this.partnerService.findAllInvitationOfParty(token).subscribe((res) => {
      //   if (res.success && res.result.length > 0) {
      //     this.partnerList = this.filterPartnerList(res.result);
      //     console.log(this.partnerList);
      //     this.getNextPartners(0);
      //   } else {
      //     this.loadMore = false;
      //   }
      // });
    });
  }

  public getNextPartners(start) {
    this.partnerListDisplay = this.partnerListDisplay.concat(this.partnerList.slice(start, start + this.partnersPageSize));
    if (this.partnerListDisplay.length >= this.partnerList.length) {
      this.loadMore = false;
    }
  }

  public filterPartnerList(list) {
    list.forEach((element) => {
      if (element.status === 'PENDING') {
        if (element.reminderSentAt == null) {
          element.type = 'invite';
          element.timeStamp = element.inviteSentAt;
          element.time = new Date(element.timeStamp).toLocaleDateString('en-GB');
        } else {
          element.type = 'reminder';
          element.timeStamp = element.reminderSentAt[element.reminderSentAt.length - 1];
          element.time = new Date(element.timeStamp).toLocaleDateString('en-GB');
        }
        this.partnerList.push(element);
      }
    });
    return this.helperService.sortByTime(this.partnerList, 'timeStamp');
  }

  public sendReminder(partner) {

    if (partner.count >= 4) {
      this.helperService.openSnackBar('Maximum Reminders has been Sent', 'OK');
    } else {
      const obj = {
        invitationId: partner.invitationId,
        invitatedPartyName: partner.invitatedPartyName,
        partySubType: partner.partySubType,
        referalPartyName: partner.referalPartyName,
        email: partner.email,
        mobile: partner.mobile,
        sendtoMobile: partner.sendtoMobile,
        sendtoEmail: partner.sendtoEmail,
        webURL: partner.webURL,
        iosURL: partner.iosURL,
        playStoreURL: partner.playStoreURL,
        ecosystemProfileId: partner.ecosystemProfileId,
        ecosystemId: partner.ecosystemId,
        profileLabelName: partner.profileLabelName,
        isSentByExistingOnboardedParty: partner.isSentByExistingOnboardedParty,
        status: partner.status,
        referalOrgId: partner.referalOrgId,
        reminder: true
      };
      this.loading = true;

      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        // this.partnerService.sendReminder(obj, token).subscribe((res) => {
        //   this.loading = false;
        //   if (res.success && res.result === true) {
        //     this.helperService.openSnackBar('Reminder Successfully Sent', 'OK');
        //     partner.count++;
        //     console.log(partner);
        //   } else {
        //     this.helperService.openSnackBar('Sorry! Try again!', 'OK');
        //   }
        // });
      });
    }
    console.log(partner);
  }

  public selectPartner(partner) {
    const dialogRef = this.dialog.open(RetailerProfileDialogComponent, {
      width: '100%',
      height: '100%',
      maxWidth: '100%',
      data: { partner, type: 'reminder', existing: false },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
    });
  }

}
