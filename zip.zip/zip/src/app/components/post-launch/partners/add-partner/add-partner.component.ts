import { ProfileSetupService } from './../../../../services/postLaunch/profile-setup.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ProfileService } from './../../../../services/profile.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { PartnerService } from './../../../../services/postLaunch/partner.service';
import { MatDialog } from '@angular/material';
import { ShowMessageDialogComponent } from './../show-message-dialog/show-message-dialog.component';
import { AddBrandsDialogComponent } from './../add-brands-dialog/add-brands-dialog.component';
import { RequestDocumentsDialogComponent } from './../request-documents-dialog/request-documents-dialog.component';
import { HelperService } from './../../../../services/helper.service';

@Component({
  selector: 'app-add-partner',
  templateUrl: './add-partner.component.html',
  styleUrls: ['./add-partner.component.css']
})
export class AddPartnerComponent implements OnInit {
  public setFlagPincodeError: boolean = false;
  public ecoSystemId = this.crossPlatformService.getOrgId().ecoSystemId;
  public requestDocuments = [];
  public loading;
  public orgId;
  public body;
  public partnerList;
  public setFlag: boolean = false;
  public gstinError = false;
  public mobileError = false;
  public emailError = false;
  public Error = false;
  public isLoading: boolean = true;
  public partnerTypes = [{
    name: 'Trade Partner'
  }];
  public partnerDetail = {
    partyName: '',
    userName: '',
    invitatedPartyName: 'PUNIA',
    partySubType: 'PRIVILEDGE',
    referalPartyName: 'YADWINDER',
    email: 'yadpunia10@gmail.com',
    mobile: '8950056890',
    referalUserName: '',
    sendtoMobile: true,
    sendtoEmail: false,
    webURL: 'www.google.com',
    iosURL: 'www.iphone.com',
    playStoreURL: 'www.playstore.com',
    ecosystemProfileId: 'gffgdfggf',
    ecosystemId: 'bmbmbmbmnjjnj',
    profileLabelName: 'FARMER',
    isSentByExistingOnboardedParty: false,
    status: 'PENDING',
    referalOrgId: '70a16e92-7bd4-4d59-a8e4-8b1c5e497794',
    reminder: false,
    partyAddress: { area: '' },
    count: 1,
    requestDocuments: [],
    businessIdValue: ''
  };
  public orgIdObj;
  public addPartnerFormGroup: FormGroup;
  constructor(
    private router: Router,
    private fb: FormBuilder, private profileService: ProfileService,
    private crossPlatformService: CrossPlatformService,
    private partnerService: PartnerService,
    private helperService: HelperService,
    private profileSetupService: ProfileSetupService, public dialog: MatDialog) {

    this.orgIdObj = this.crossPlatformService.getOrgId();
    console.log(this.orgIdObj);

    // this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
    //   this.profileSetupService.partyProfileInformation(this.orgIdObj.orgId, token).subscribe((res) => {
    //     if (res.success) {
    //       this.partnerDetail.partyName = res.result.partyName;
    //       this.partnerDetail.userName = res.result.userName;
    //       this.partnerService.setDetails(this.partnerDetail);
    //       this.getProfiles(res.result);
    //     }
    //   });
    // });

    this.addPartnerFormGroup = this.fb.group({
      partnerType: new FormControl('', [Validators.required]),
      partnerName: new FormControl('', [Validators.required]),
      gstin: new FormControl('', [Validators.required, Validators.pattern('[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}')]),
      contactPerson: new FormControl('', [Validators.required]),
      mobile: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required, GlobalValidator.mailFormat]),
      areaOrLocality: new FormControl('', ),
      pincode: new FormControl('', [Validators.pattern('[0-9]{6}')]),
      additionalCheckBox: new FormControl('', []),
      addtionalTextBox: new FormControl('', []),

    });
  }
  public ngOnInit() {
    console.log();
  }

  public getProfiles(result) {
    if (result) {
      if (result.ecosystemProfile.ecosystemId != null) {
        this.ecoSystemId = result.ecosystemProfile.ecosystemId;
      }
    }
    this.profileService.getProfilesByEcoId(this.ecoSystemId, '').subscribe((metaDataRes) => {
      if (metaDataRes != null) {
        this.partnerTypes = [];
        console.log(metaDataRes);
        const res = metaDataRes[0];
        if (res != null) {
          res.profileList.forEach((element) => {
            const obj = {
              name: element.profileName,
              id: element.profileId,
              label: element.profileLabel
            };
            this.partnerTypes.push(obj);
          });
        }
      }
      this.isLoading = false;
    });
  }

  public onPreview() {

    Object.keys(this.addPartnerFormGroup.controls).forEach((field) => {
      const control = this.addPartnerFormGroup.get(field);
      control.markAsTouched({
        onlySelf: true
      });
    });

    if (this.addPartnerFormGroup.valid) {
      this.isLoading = true;

      const obj = this.addPartnerFormGroup.value;
      console.log('on Preview obj', obj);

      // if (obj.partnerName) {
      //   const res = this.checkPartnerDublicateName(obj.partnerName);
      //   console.log(res);
      // }

      this.checkPincodeSubmit();

      this.partnerDetail.invitatedPartyName = obj.partnerName;
      this.partnerDetail.partySubType = '';
      this.partnerDetail.referalPartyName = this.partnerDetail.partyName;
      this.partnerDetail.email = obj.email;
      this.partnerDetail.mobile = obj.mobile;
      this.partnerDetail.referalUserName = obj.contactPerson;
      this.partnerDetail.sendtoMobile = true;
      this.partnerDetail.sendtoEmail = false;
      this.partnerDetail.webURL = '';
      this.partnerDetail.iosURL = '';
      this.partnerDetail.playStoreURL = '';
      this.partnerDetail.ecosystemProfileId = obj.partnerType.id;
      this.partnerDetail.ecosystemId = this.ecoSystemId;
      this.partnerDetail.profileLabelName = obj.partnerType.label;
      this.partnerDetail.isSentByExistingOnboardedParty = false;
      this.partnerDetail.status = 'PENDING';
      this.partnerDetail.referalOrgId = this.orgIdObj.orgId;
      this.partnerDetail.reminder = false;
      this.partnerDetail.count = 1;
      this.partnerDetail.requestDocuments = this.requestDocuments;
      this.partnerDetail.businessIdValue = obj.gstin;
      this.partnerDetail.partyAddress.area = obj.areaOrLocality;
      this.partnerService.setDetails(this.partnerDetail);

    }

  }
  public sendInvite() {
    if (this.setFlag) {
      this.router.navigate(['/postLaunch/partner/sendInvite']);
    }
  }

  public showMessageDialog(obj) {
    const dialogRef = this.dialog.open(ShowMessageDialogComponent, {
      // height:'50%',
      data: obj
    });
  }

  public checkPartnerDublicateGSTIN(gstin) {
    const obj = {
      businessIdValue: gstin
    };
    const errorMessage = {
      partnerName: 'Partner',
      message: 'You have already invited the Partner on <<Invited Date and Time. Do you want to send a reminder?',
      action: 'reminder',
      requestName: 'Send a Reminder'
    };
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      // this.partnerService.checkDublicatePartnerByGSTIN(obj, token).subscribe((res) => {
      //   console.log(res);
      //   if (res.success) {
      //     if (res.result.uuid) {
      //       this.setFlag = false;
      //       this.showMessageDialog(errorMessage);
      //     } else {
      //       this.setFlag = true;
      //       this.checkPincode();
      //     }
      //   }
      //   this.isLoading = false;
      // });
    });
  }

  public checkPincodeSubmit() {
    if (this.setFlagPincodeError) {
      this.setFlag = false;
    } else {
      this.setFlag = true;
    }
    this.isLoading = false;
    this.sendInvite();
  }

  public checkPincode() {
    const val = this.addPartnerFormGroup.value.pincode;
    this.setFlag = true;
    if (val.length === 6) {
      this.isLoading = true;
      this.setFlagPincodeError = false;
      this.setFlag = false;
      const obj = {
        pincode: val
      };
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        // this.partnerService.checkPincodeExist(obj, token).subscribe((res) => {
        //   console.log(res);
        //   if (res.success) {
        //     if (res.result.pincode === null) {
        //       this.setFlagPincodeError = true;
        //       this.setFlag = false;
        //     } else {
        //       this.setFlag = true;
        //     }
        //   }
        //   this.isLoading = false;
        // });
      });
    }

  }

  public requestDocumentsDialog() {
    console.log('request documents');
    const dialogRef = this.dialog.open(RequestDocumentsDialogComponent, { height: '50%', data: this.requestDocuments });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('data from dialog', result);
      if (result) {
        console.log(result);
        this.requestDocuments = result;
      }
    });
  }

  public addProductsCatalog() {
    // console.log("product catelog");
    const dialogRef = this.dialog.open(AddBrandsDialogComponent, {
      height: '100%',
      width: '100%',
      maxWidth: '100%',
      data: 'obj'
    });
  }

  // send remainder method
  public sendReminder(partner) {
    const obj = {
      invitationId: partner.invitationId,
      invitatedPartyName: partner.invitatedPartyName,
      partySubType: partner.partySubType,
      referalPartyName: partner.referalPartyName,
      email: partner.email,
      mobile: partner.mobile,
      sendtoMobile: partner.sendtoMobile,
      sendtoEmail: partner.sendtoEmail,
      webURL: partner.webURL,
      iosURL: partner.iosURL,
      playStoreURL: partner.playStoreURL,
      ecosystemProfileId: partner.ecosystemProfileId,
      ecosystemId: partner.ecosystemId,
      profileLabelName: partner.profileLabelName,
      isSentByExistingOnboardedParty: partner.isSentByExistingOnboardedParty,
      status: partner.status,
      referalOrgId: partner.referalOrgId,
      reminder: true
    };
    this.loading = true;
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      // this.partnerService.sendReminder(obj, token).subscribe((res) => {
      //   this.loading = false;
      //   if (res.success && res.result) {
      //     this.helperService.openSnackBar('Reminder sent successfully!', 'Ok');
      //   } else {
      //     this.helperService.openSnackBar('Sorry! Try again!', 'Ok');
      //   }
      // });
    });
    console.log(partner);
  }

  // send connect request method
  public sendConnect(partner, index) {
    this.loading = true;
    console.log(partner);

    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      // this.partnerService.createNetwork(this.orgId, partner.uuid, token).subscribe((res) => {
      //   console.log(res);
      //   this.loading = false;
      //   if (res.success && res.result) {
      //     this.partnerList.splice(index, 1);
      //     this.helperService.openSnackBar('Connect Request Sent to ' + partner.name, 'OK');
      //   } else {
      //     this.helperService.openSnackBar('Connect Request Failed', 'Try Again');
      //   }
      // });
    });
  }

  public validatePartner(formValue, value) {
    console.log('formControlName, value', formValue, value);
    this.body = null;
    // this.Error = false;
    if (value.trim().length > 0) {
      if (formValue === 'gstin') {
        console.log('inside gstin');
        this.gstinError = false;
        this.Error = this.gstinError;
        this.body = { businessIdValue: value.trim(), searchSuggestion: true };
      }
      if (formValue === 'email') {
        console.log('inside email');
        this.emailError = false;
        this.Error = this.emailError;
        this.body = { emailAddress: value.trim(), searchSuggestion: true };
      }
      if (formValue === 'mobile') {
        console.log('inside mobile');
        this.mobileError = false;
        this.Error = this.mobileError;
        this.body = { mobile: value.trim(), searchSuggestion: true };
      }
      console.log('body', this.body);

      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {

        // this.partnerService.addPartnerValidation(this.body, token).subscribe((result) => {
        //   console.log('result', result);
        //   if (result.success && (result.result.message === 'Party already available' && result.result.isExist === true)) {
        //     // this.userForm.get('product').setErrors;
        //     console.log('already exist');
        //     if (this.body.businessIdValue) {
        //       this.gstinError = true;
        //     }
        //     if (this.body.emailAddress) {
        //       this.emailError = true;
        //     }
        //     if (this.body.mobile) {
        //       this.mobileError = true;
        //     }
        //     // this.helperService.openSnackBar('Product Code already exist!', 'Try Another');
        //   }
        // });
      });
    }
  }
}
// public checkMobileNumber() {
//   console.log();
// }
// public checkEmail() {
//   console.log();
// }

// tslint:disable-next-line:max-classes-per-file
export class GlobalValidator {
  public static mailFormat(control: FormControl): ValidationResult {
    const EMAIL_REGEXP = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (control.value !== '' && (control.value.length <= 5 || !EMAIL_REGEXP.test(control.value))) {
      return {
        incorrectMailFormat: true
      };
    }
    return null;
  }
}

interface ValidationResult {
  [key: string]: boolean;
}
