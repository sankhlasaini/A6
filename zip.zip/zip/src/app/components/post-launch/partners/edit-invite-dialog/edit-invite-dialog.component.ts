import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { MAT_DIALOG_DATA } from '@angular/material';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-edit-invite-dialog',
  templateUrl: './edit-invite-dialog.component.html',
  styleUrls: ['./edit-invite-dialog.component.css']
})
export class EditInviteDialogComponent implements OnInit {
  public editInviteForm: FormGroup;
  public isEmail = false;
  constructor(
    private router: Router, @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<EditInviteDialogComponent>,
    private fb: FormBuilder) {

    this.editInviteForm = this.fb.group({
      type: '',
      subject: new FormControl('', [Validators.required]),
      content: new FormControl('', [Validators.required])
    });
    if (data != null) {
      if (data.option != null) {
        this.editInviteForm.patchValue({
          type: data.option
        });
        if (data.option === 'Email') {
          this.isEmail = true;
          if (data.details != null) {
            this.editInviteForm.patchValue({
              subject: data.details.email.subject,
              content: data.details.email.content
            });
          }
        } else {
          this.isEmail = false;
          this.editInviteForm.patchValue({
            content: data.details.sms.content
          });
        }
      }
    }
  }

  public ngOnInit() {
    console.log();
  }
  public cancelInvite() {
    this.dialogRef.close();
  }
  public saveInvite() {
    this.dialogRef.close('data');
  }
}
