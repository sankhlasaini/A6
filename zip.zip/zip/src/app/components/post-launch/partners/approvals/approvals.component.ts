import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { PartnerService } from './../../../../services/postLaunch/partner.service';
import { Component } from '@angular/core';

@Component({
  selector: 'app-approvals',
  templateUrl: './approvals.component.html',
  styleUrls: ['./approvals.component.css']
})
export class ApprovalsComponent {

  public orgId;

  constructor(
    private partnerService: PartnerService,
    private crossPlatformService: CrossPlatformService
  ) { }

}
