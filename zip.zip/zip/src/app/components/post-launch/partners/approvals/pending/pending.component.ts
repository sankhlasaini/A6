import { slideDown, slideUp } from './../../../../../animations';
import { HelperService } from './../../../../../services/helper.service';
import { CrossPlatformService } from './../../../../../services/postLaunch/cross-platform.service';
import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { PartnerService } from './../../../../../services/postLaunch/partner.service';
import { InfiniteScroll } from './../../../../../angular2-infinitescroll';
import { RetailerProfileDialogComponent } from './../../retailer-profile-dialog/retailer-profile-dialog.component';
import { MatDialog } from '@angular/material';
import { Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'partner-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.css'],
  animations: [slideDown, slideUp]
})
export class PendingComponent {

  public pendingNetworkList = [];
  public partnerList = [];
  public accessToken = '';
  public config: SwiperOptions = {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    spaceBetween: 0,
    slidesPerView: 'auto',
    grabCursor: true,
  };

  public orgId;
  public loading = false;
  public loadMore = true;
  public partnersPageSize = 5;
  public fileUrl;
  public inviterName = '';

  constructor(
    private partnerService: PartnerService,
    private crossPlatformService: CrossPlatformService,
    public dialog: MatDialog, private helperService: HelperService) {
    this.orgId = this.crossPlatformService.getOrgId().orgId;
    // this.getPartnerDetails(0);
    this.partnerList = [];
    // this.pendingList = this.helperService.sortByTime(this.pendingList, 'contractInviteSentAt');
    // console.log('Pending List After Sorting : ', this.pendingList);
    this.findNetwork({ targetId: this.crossPlatformService.getOrgId().orgId, state: 'AWAITED' });
  }

  public findNetwork(param) {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      console.log(param);
      this.partnerService.findNetwork(param, token).subscribe((res) => {
        console.log('find AWAITED network by targetId: ', res);
        if (res.success) {
          // res.result.forEach((ele) => {
          //   this.pendingNetworkList.find((p) => p).sourceId
          // });
          this.pendingNetworkList = this.helperService.sortByTime(res.result, 'updatedOn');
          this.getPartnerDetails(0);
        }
      });
    });
  }

  public getPartnerDetails(startIndex) {
    if (this.loadMore) {
      let partyList = [];
      for (let i = startIndex; i < startIndex + this.partnersPageSize; i++) {
        if (this.pendingNetworkList[i]) {
          partyList.push({ partyId: this.pendingNetworkList[i].sourceId });
        }
      }
      console.log(partyList);
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.partnerService.findOrg(partyList, token).subscribe((res) => {
          if (res.success) {
            for (let i = startIndex; i < startIndex + this.partnersPageSize; i++) {
              if (this.pendingNetworkList[i]) {
                const party = res.result.find((p) => this.pendingNetworkList[i].sourceId === p.partyId);
                if (party) {
                  this.partnerList.push(this.createRecord(this.pendingNetworkList[i], party));
                }
              }
            }
            console.log('pending list :: ', this.partnerList);
            if (this.partnerList.length >= this.pendingNetworkList.length) {
              this.loadMore = false;
            }
          } else {
            this.loadMore = false;
          }
        });
      });
    }
  }

  public createRecord(ele, p) {
    ele.name = p.name;
    ele.area = p.orgProfile.contactPersons[0].contactAddress.line1 + (p.orgProfile.contactPersons[0].contactAddress.line1 === '' ? '' : ',')
      + p.orgProfile.contactPersons[0].contactAddress.city;
    ele.partyId = p.partyId;
    ele.accountId = p.accountId;
    ele.email = p.email;
    ele.mobile = p.mobile;
    ele.time = new Date(ele.updatedOn).toLocaleDateString('en-GB');
    ele.party = p;
    return ele;
  }

  public showProfile(partner, index) {
    const dialogRef = this.dialog.open(RetailerProfileDialogComponent, {
      width: '100%',
      height: '100%',
      maxWidth: '100%',
      data: { partner, type: 'pendingByMe', existing: true, inviterName: 'Inviter Name', showAction: true },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
      if (result.success && result.success === true) {
        partner.hide = true;
      }
    });
  }

  public action(partner, index, status) {
    this.loading = true;
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      console.log(partner.partyId, this.orgId, status);
      this.partnerService.updateNetwork(partner.partyId, this.orgId, status, token).subscribe((res) => {
        console.log(res);
        this.loading = false;
        if (res.success && res.result) {
          partner.hide = true;
          // this.partnerList.splice(index, 1);
          if (status === 'TRADABLE') {
            this.helperService.openSnackBar('You are now CONNECTED with', partner.name);
          } else {
            this.helperService.openSnackBar('Request REJECTED for', partner.name);
          }
        } else {
          this.helperService.openSnackBar('Request Failed', 'Try Again');
        }
      });
    });
  }

}
