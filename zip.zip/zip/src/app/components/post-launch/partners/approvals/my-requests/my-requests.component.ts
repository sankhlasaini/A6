import { slideDown, slideUp } from './../../../../../animations';
import { HelperService } from './../../../../../services/helper.service';
import { CrossPlatformService } from './../../../../../services/postLaunch/cross-platform.service';
import { Component, Input, OnChanges } from '@angular/core';
import { PartnerService } from './../../../../../services/postLaunch/partner.service';
import { InfiniteScroll } from './../../../../../angular2-infinitescroll';
import { RetailerProfileDialogComponent } from './../../retailer-profile-dialog/retailer-profile-dialog.component';
import { MatDialog } from '@angular/material';
import { Output, EventEmitter } from '@angular/core';
import { ProfileSetupService } from '../../../../../services/postLaunch/profile-setup.service';

@Component({
  selector: 'partner-my-requests',
  templateUrl: './my-requests.component.html',
  styleUrls: ['./my-requests.component.css'],
  animations: [slideDown, slideUp]
})
export class MyRequestsComponent {

  public pendingNetworkList = [];
  public partnerList = [];
  public fileUrl;
  public accessToken = '';
  // config: SwiperOptions = {
  //   pagination: '.swiper-pagination',
  //   paginationClickable: true,
  //   nextButton: '.swiper-button-next',
  //   prevButton: '.swiper-button-prev',
  //   spaceBetween: 0,
  //   slidesPerView: 'auto',
  //   grabCursor: true,
  // };

  public orgId;
  // loading = true;
  public inviterName = '';
  public loadMore = true;
  public partnersPageSize = 5;

  constructor(
    public dialog: MatDialog,
    private helperService: HelperService,
    private profileSetupService: ProfileSetupService,
    private partnerService: PartnerService,
    private crossPlatformService: CrossPlatformService
  ) {
    this.orgId = this.crossPlatformService.getOrgId().orgId;
    this.findNetwork({ sourceId: this.crossPlatformService.getOrgId().orgId, state: 'AWAITED' });
  }

  public findNetwork(param) {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      console.log(param);
      this.partnerService.findNetwork(param, token).subscribe((res) => {
        console.log('find AWAITED network : ', res);
        if (res.success) {
          this.pendingNetworkList = this.helperService.sortByTime(res.result, 'updatedOn');
          this.getPartnerDetails(0);
        }
      });
    });
  }

  public getPartnerDetails(startIndex) {
    if (this.loadMore) {
      let partyList = [];
      for (let i = startIndex; i < startIndex + this.partnersPageSize; i++) {
        if (this.pendingNetworkList[i]) {
          partyList.push({ partyId: this.pendingNetworkList[i].targetId });
        }
      }
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.partnerService.findOrg(partyList, token).subscribe((res) => {
          if (res.success) {
            for (let i = startIndex; i < startIndex + this.partnersPageSize; i++) {
              if (this.pendingNetworkList[i]) {
                const party = res.result.find((p) => this.pendingNetworkList[i].targetId === p.partyId);
                if (party) {
                  this.partnerList.push(this.createRecord(this.pendingNetworkList[i], party));
                }
              }
            }
            console.log('my Request List : ', this.partnerList);
            if (this.partnerList.length >= this.pendingNetworkList.length) {
              this.loadMore = false;
            }
          } else {
            this.loadMore = false;
          }
        });
      });
    }
  }

  public createRecord(ele, p) {
    ele.name = p.name;
    ele.area = p.orgProfile.contactPersons[0].contactAddress.line1 + (p.orgProfile.contactPersons[0].contactAddress.line1 === '' ? '' : ',')
      + p.orgProfile.contactPersons[0].contactAddress.city;
    ele.partyId = p.partyId;
    ele.accountId = p.accountId;
    ele.email = p.email;
    ele.mobile = p.mobile;
    ele.time = new Date(ele.updatedOn).toLocaleDateString('en-GB');
    ele.party = p;
    return ele;
  }

  public showProfile(partner) {
    const dialogRef = this.dialog.open(RetailerProfileDialogComponent, {
      width: '100%',
      height: '100%',
      maxWidth: '100%',
      data: { partner, type: 'pendingRequest', existing: true, inviterName: 'this.currentUser', showAction: true },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
    });
  }
}
