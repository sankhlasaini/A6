import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MatDialog, MAT_DIALOG_DATA } from '@angular/material';
import { HelperService } from './../../../../services/helper.service';

@Component({
  selector: 'app-request-documents-dialog',
  templateUrl: './request-documents-dialog.component.html',
  styleUrls: ['./request-documents-dialog.component.css']
})
export class RequestDocumentsDialogComponent implements OnInit {
  public flag: any;
  public requestDocumentsArray = [{
    name: '',
    title: 'Document'
  }];
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<RequestDocumentsDialogComponent>,
    private helperService: HelperService, ) {
    if (this.data.length > 0) {
      this.requestDocumentsArray = [];
      this.data.forEach((element) => {
        const obj = {
          name: element.name,
          title: element.title
        };
        this.requestDocumentsArray.push(obj);
      });
    }
    this.updateData();
  }

  public ngOnInit() {
    console.log();
  }

  public addMore() {
    if (this.requestDocumentsArray.length < 3) {
      this.requestDocumentsArray.push({ name: '', title: 'Document' });
    }
    this.updateData();
  }
  public removeDocument(i) {
    this.requestDocumentsArray.splice(i, 1);
    this.updateData();
  }
  public onSubmit() {
    this.flag = false;
    this.requestDocumentsArray.forEach((element) => {
      if (element.name.trim().length < 1) {
        this.flag = true;
      }
    });
    if (!this.flag) {
      this.dialogRef.close(this.requestDocumentsArray);
    } else {
      this.helperService.openSnackBar('Please fill fields !', 'Ok');
    }
  }
  public closeDialog() {
    // console.log('close');
    this.dialogRef.close();
  }
  public updateData() {
    this.requestDocumentsArray.forEach((element) => {
      element.title = 'Document ' + (this.requestDocumentsArray.indexOf(element) + 1);
    });
  }
}
