import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { SwiperComponent } from 'angular2-useful-swiper/lib/swiper.module';
import { HelperService } from './../../../../services/helper.service';

@Component({
  selector: 'app-add-brands-dialog',
  templateUrl: './add-brands-dialog.component.html',
  styleUrls: ['./add-brands-dialog.component.css']
})
export class AddBrandsDialogComponent implements OnInit {

  public selectedOption = 'brand';
  public color = 'primary';
  public checked = false;
  public disabled = false;
  public brandsTotal;
  public selectedBrandsCount;
  public selectedBrands;
  public allBrands = [{
    brandName: 'Dettol ',
    category: 'Personal Hygiene',
    marginDiscount: 7,
    addtionalCashDiscount: 6,
    isBrandSelected: false,
    isTaxIncluded: true
  },
  {
    brandName: 'Colgate',
    category: 'Personal Care',
    marginDiscount: 7,
    addtionalCashDiscount: 6,
    isBrandSelected: false,
    isTaxIncluded: true
  },
  {
    brandName: 'Colgate',
    category: 'Personal Care',
    marginDiscount: 7,
    addtionalCashDiscount: 6,
    isBrandSelected: false,
    isTaxIncluded: true
  },
  {
    brandName: 'Colgate',
    category: 'Personal Care',
    marginDiscount: 7,
    addtionalCashDiscount: 6,
    isBrandSelected: false,
    isTaxIncluded: true
  },
  {
    brandName: 'Colgate',
    category: 'Personal Care',
    marginDiscount: 7,
    addtionalCashDiscount: 6,
    isBrandSelected: false,
    isTaxIncluded: true
  },
  {
    brandName: 'Colgate',
    category: 'Personal Care',
    marginDiscount: 7,
    addtionalCashDiscount: 6,
    isBrandSelected: false,
    isTaxIncluded: true
  },
  {
    brandName: 'Colgate',
    category: 'Personal Care',
    marginDiscount: 7,
    addtionalCashDiscount: 6,
    isBrandSelected: false,
    isTaxIncluded: true
  },
  {
    brandName: 'Himalaya',
    category: 'Baby Care',
    marginDiscount: 7,
    addtionalCashDiscount: 6,
    isBrandSelected: false,
    isTaxIncluded: false
  }];

  public productList = [{
    name: 'Tooth Paste',
    id: 'product_1',
    productDisplayColor: ''
  }, {
    name: 'Tooth Paste',
    id: 'product_1',
    productDisplayColor: ''
  }, {
    name: 'Tooth Paste',
    id: 'product_1',
    productDisplayColor: ''
  }, {
    name: 'Tooth Paste',
    id: 'product_1',
    productDisplayColor: ''
  }, {
    name: 'Tooth Paste',
    id: 'product_1',
    productDisplayColor: ''
  }];
  public secondary = 'color-secondary';
  public primary = 'color-primary';
  public config: SwiperOptions = {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    // paginationHide: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    spaceBetween: 0,
    slidesPerView: '1',
    grabCursor: true,
  };
  @ViewChild('usefulSwiper') public usefulSwiper: SwiperComponent;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<AddBrandsDialogComponent>,
    private helperService: HelperService
  ) {
    this.brandsTotal = this.allBrands.length;
  }
  public ngOnInit() {
    // console.log('add brands');
  }

  public close() {
    this.dialogRef.close();
  }
  public selectBrand(i) {
    if (this.allBrands[i].isBrandSelected) {
      this.allBrands[i].isBrandSelected = false;
    } else {
      this.allBrands[i].isBrandSelected = true;
    }

    this.selectedBrands = this.allBrands.filter((brand) => brand.isBrandSelected === true);

    this.selectedBrandsCount = this.selectedBrands.length;

  }
  public calculate(operation, index, field) {
    const by = 1;
    switch (operation) {
      case 'add':
        this.allBrands[index][field] = this.allBrands[index][field] + by;
        break;
      case 'sub':
        this.allBrands[index][field] = this.allBrands[index][field] - by;
        break;
      default:
        break;
    }
    // console.log("calculate", operation, index, field);
    console.log(this.allBrands);

  }

  public brandsSubmit() {
    this.selectedBrands = this.allBrands.filter((brand) => brand.isBrandSelected === true);
    if (this.selectedBrands.length > 0) {
      this.selectedOption = 'product';
      this.selectedBrands.forEach((element) => {
        element.brandColor = this.secondary;
      });
      this.getProductListFromBrand();
    } else {
      this.helperService.openSnackBar('Please select brand(s)', 'OK');
    }
  }

  public backToBrands() {
    this.selectedOption = 'brand';

  }

  public productsSubmit() {
    console.log('in product submit');
  }

  public getProductListFromBrand() {
    this.productList.forEach((element) => {
      element.productDisplayColor = 'secondary';
    });
  }

  public selectProductFromProductList(product, index) {
    this.productList.forEach((element) => {
      if (element === product) {
        element.productDisplayColor = this.primary;
      } else {
        element.productDisplayColor = this.secondary;
      }
    });
  }

  public nextSlide() {
    this.usefulSwiper.swiper.slideNext();
  }

  public prevSlide() {
    this.usefulSwiper.swiper.slidePrev();
  }

  public selectBrandForProductList(brand, j) {

    this.selectedBrands.forEach((element) => {
      if (element === brand) {
        element.brandColor = this.primary;
      } else {
        element.brandColor = this.secondary;
      }
    });

  }
}
