// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AddBrandsDialogComponent } from './add-brands-dialog.component';

// describe('AddBrandsDialogComponent', () => {
//   let component: AddBrandsDialogComponent;
//   let fixture: ComponentFixture<AddBrandsDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AddBrandsDialogComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AddBrandsDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
