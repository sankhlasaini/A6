import { BottomSheetDialogComponent } from './../common/bottom-sheet-dialog/bottom-sheet-dialog.component';
import { slideUp, flyIn } from './../../../animations';
import { CrossPlatformService } from './../../../services/postLaunch/cross-platform.service';
import { PartnerService } from './../../../services/postLaunch/partner.service';
import { Component } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-partners',
  templateUrl: './partners.component.html',
  styleUrls: ['./partners.component.css'],
  animations: [slideUp, flyIn]
})
export class PartnersComponent {

  public webMode;
  public connectedList = [];
  public recentList = [];
  public pendingList = [];
  public recentListLoading = true;
  public serviceHitCount = 0;

  constructor(
    public dialog: MatDialog,
    private partnerService: PartnerService,
    private crossPlatformService: CrossPlatformService
  ) {
    this.webMode = this.crossPlatformService.getWebMode();
    if (this.crossPlatformService.getWebMode() === undefined) {
      setTimeout(() => {
        this.webMode = this.crossPlatformService.getWebMode();
      }, 1500);
    }

    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {

      // Use for PENDING PARTY DATA

      // this.findNetwork({ sourceId: this.crossPlatformService.getOrgId().orgId, state: 'AWAITED' }, 'pending', token);
      // this.findNetwork({ targetId: this.crossPlatformService.getOrgId().orgId, state: 'AWAITED' }, 'pending', token);

      this.findNetwork({ sourceId: this.crossPlatformService.getOrgId().orgId, state: 'TRADABLE' }, 'connected', token);
      this.findNetwork({ targetId: this.crossPlatformService.getOrgId().orgId, state: 'TRADABLE' }, 'connected', token);
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public findNetwork(param, type, token) {
    console.log(param);
    this.partnerService.findNetwork(param, token).subscribe((res) => {
      console.log('findAllPartners : ', res);
      this.serviceHitCount++;
      if (res.success) {
        switch (type) {
          case 'pending':
            this.pendingList = this.pendingList.concat(res.result);
            break;
          case 'connected':
            this.connectedList = this.connectedList.concat(res.result);
            break;
          default:
            break;
        }
      }
      // if (this.serviceHitCount >= 1) {      // IF PENDING Party are Active
      if (this.serviceHitCount >= 2) {
        let fullList = [];
        fullList = fullList.concat(this.connectedList);
        fullList = fullList.concat(this.pendingList);
        this.recentList = fullList;
        this.recentListLoading = false;
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  // dialog
  public openDialog() {
    const dialogRef = this.dialog.open(BottomSheetDialogComponent, {
      width: '100%',
      maxWidth: '100%',
      data: {
        title: 'Add Partner Using :',
        action1: { label: 'Form', icon: 'fa fa-file-text', color: '#0b89d1', action: '/postLaunch/partner/addPartner' },
        action2: { label: 'Excel Upload', icon: 'fa fa-file-excel-o', color: '#4ba205', action: '' },
        type: 'partner',
        downloadTemplate: true,
        selection: false
      },
      position: { bottom: '0' },
    });
  }

}
