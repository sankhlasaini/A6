// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { RetailerProfileDialogComponent } from './retailer-profile-dialog.component';

// describe('RetailerProfileDialogComponent', () => {
//   let component: RetailerProfileDialogComponent;
//   let fixture: ComponentFixture<RetailerProfileDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ RetailerProfileDialogComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RetailerProfileDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
