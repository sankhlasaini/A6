import { AssetService } from './../../../../services/postLaunch/asset.service';
import { UserSetupService } from './../../../../services/postLaunch/user-setup.service';
import { expend, slideUp } from './../../../../animations';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { HelperService } from './../../../../services/helper.service';
import { PartnerService } from './../../../../services/postLaunch/partner.service';
import { ProfileSetupService } from './../../../../services/postLaunch/profile-setup.service';
import { ProductService } from './../../../../services/postLaunch/product.service';
import { Component, Inject, ViewChild, OnChanges } from '@angular/core';
import { MatDialogRef, MatDialog, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';
import { ViewListDialogComponent } from '../../common/view-list-dialog/view-list-dialog.component';

@Component({
  selector: 'app-retailer-profile-dialog',
  templateUrl: './retailer-profile-dialog.component.html',
  styleUrls: ['./retailer-profile-dialog.component.css'],
  animations: [expend, slideUp]
})
export class RetailerProfileDialogComponent {
  public orgId;
  public brands = [];
  public connectedNetworkList = [];
  public connections = [];
  public connectionLoading = true;
  public serviceLineLoading = true;
  public serviceLineList = [];
  public outlets = [];
  public loadingProfile = true;
  public loadingContract = true;
  public loading = false;
  public btnLoading = false;
  public fileUrl;
  public accessToken = '';
  public retailerData = {
    logo: '../../../../../assets/images/user-default.png',
    partyName: '',
    partySubType: '',
    territoryNameList: [],
    address: { line1: '', line2: '', line3: '', city: '', state: '', country: '', pincode: '', },
    poc: { contactPersonName: '-', contactPersonEmail: '-', mobile: '-' }

  };
  public inviter = {
    inviterName: '',
    time: '',
    type: ''
  };

  public displayCard = {
    contact: false,
    sender: false,
    contracts: false,
    thisMonth: false,
    actionBtn: {
      label: '',
      icon: '',
      style: ''
    }
  };
  public connectionHitCount = 0;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<RetailerProfileDialogComponent>,
    private dialog: MatDialog,
    private productService: ProductService,
    private profileSetupService: ProfileSetupService,
    private partnerService: PartnerService,
    private helperService: HelperService,
    private crossPlatformService: CrossPlatformService,
    private userSetupService: UserSetupService,
    private assetService: AssetService,
    private router: Router,
  ) {

    this.orgId = this.crossPlatformService.getOrgId().orgId;
    this.displayData(this.data);
    console.log('Data from Parent to Display : ', data);
    this.loadingContract = false;
    // partner who are NOT on platform
    if (this.data.existing === false) {
      this.inviter.inviterName = this.data.partner.referalPartyName;
      this.retailerData.partyName = this.data.partner.invitatedPartyName;
      this.retailerData.poc.contactPersonName = this.data.partner.invitatedPartyName;
      this.retailerData.poc.contactPersonEmail = this.data.partner.email;
      this.retailerData.poc.mobile = this.data.partner.mobile;
      this.retailerData.partySubType = this.data.partner.profileLabelName;
      if (this.data.partner.reminderSentAt !== null) {
        this.inviter.type = 'Reminder Sent';
        this.inviter.time = new Date(this.data.partner.reminderSentAt
        [this.data.partner.reminderSentAt.length - 1]).toLocaleDateString('en-GB');
      } else {
        this.inviter.type = 'Invite Sent';
        this.inviter.time = new Date(this.data.partner.inviteSentAt).toLocaleDateString('en-GB');
      }
      this.loadingProfile = false;
    } else {
      this.retailerData.logo = this.data.partner.avatar;
      // partner who are on platform
      this.dialogRef.afterOpen().subscribe(() => {
        this.setPartnerProfile(this.data.partner);
      });
      this.getPrimaryUser(this.data.partner.partyId);
      this.getConnections({ sourceId: this.data.partner.partyId, state: 'TRADABLE' });
      this.getConnections({ targetId: this.data.partner.partyId, state: 'TRADABLE' });
      this.getOutlets(this.data.partner.party.orgProfile.contactPersons);
    }

  }

  public setPartnerProfile(p) {
    // if (profileRes.result.logo != null) {
    //   this.retailerData.logo = '/partnerSetup/downloadFile/?fileId=' + profileRes.result.logo.fileReferenceId + '&&accessToken=' + this.accessToken;
    // }
    const address = p.party.orgProfile.contactPersons[0].contactAddress;
    this.retailerData.partyName = p.name;
    // this.retailerData.partySubType = profileRes.result.partySubType;
    this.retailerData.territoryNameList = p.territoryNameList;
    this.retailerData.address.line1 = address.line1;
    this.retailerData.address.line2 = address.line2;
    this.retailerData.address.line3 = address.line3;
    this.retailerData.address.state = address.state;
    this.retailerData.address.pincode = address.pincode;
    this.retailerData.address.city = address.city;
    this.retailerData.address.country = address.country;
    this.retailerData.poc.contactPersonName = address.firstName + ' ' + address.middleName + ' ' + address.lastName;
    this.retailerData.poc.contactPersonEmail = this.data.type === 'explore' ? this.hideString(address.email, 'email') : address.email;
    this.retailerData.poc.mobile = this.data.type === 'explore' ? this.hideString(address.mobile, 'text') : address.mobile;
    this.loadingProfile = false;
  }

  public hideString(str, type) {
    if (type === 'email') {
      let emailArr = str.split('@');
      let emailArrStr1 = emailArr[0];
      emailArr = emailArr[1].split('.');
      let emailArrStr2 = emailArr[0];
      let emailArrStr3 = emailArr[1];
      let str1Temp = '';
      let str2Temp = '';

      for (let i = 0; i < emailArrStr1.length; i++) {
        if (i === 0 || i === (emailArrStr1.length - 1)) {
          str1Temp = str1Temp + emailArrStr1.charAt(i);
        } else {
          str1Temp = str1Temp + '*';
        }
      }
      for (let i = 0; i < emailArrStr2.length; i++) {
        if (i === 0) {
          str2Temp = str2Temp + emailArrStr2.charAt(i);
        } else {
          str2Temp = str2Temp + '*';
        }
      }
      return str1Temp + '@' + str2Temp + '.' + emailArrStr3;
    } else {
      let str2 = '';
      for (let i = 0; i < str.length; i++) {
        if (i < (str.length / 2)) {
          str2 = str2 + '*';
        } else {
          str2 = str2 + str.charAt(i);
        }
      }
      return str2;
    }
  }

  public displayData(data) {
    if (this.data.existing) {
      switch (this.data.type) {
        case 'explore':
          this.displayCard.contact = true;
          this.displayCard.actionBtn.label = 'Connect';
          this.displayCard.actionBtn.icon = 'plug';
          this.displayCard.actionBtn.style = 'greenBack';
          break;
        case 'pendingRequest':
          this.displayCard.sender = true;
          this.displayCard.contact = true;
          this.displayCard.actionBtn.label = 'Request Sent';
          this.displayCard.actionBtn.icon = 'plug';
          this.displayCard.actionBtn.style = 'greenBack';
          this.inviter.inviterName = this.data.inviterName;
          this.inviter.time = this.data.partner.time;
          this.inviter.type = 'Request Sent';
          break;
        case 'pendingByMe':
          this.displayCard.sender = true;
          this.displayCard.contact = true;
          this.displayCard.actionBtn.label = 'Approve';
          this.displayCard.actionBtn.icon = 'check';
          this.displayCard.actionBtn.style = 'greenBack';
          this.inviter.inviterName = this.data.inviterName;
          this.inviter.time = this.data.partner.time;
          this.inviter.type = 'Request Received';
          break;
        case 'connected':
          // this.displayCard.contracts = true;
          // this.displayCard.thisMonth = true;
          this.displayCard.contact = true;
          this.displayCard.actionBtn.label = 'Start Trading';
          this.displayCard.actionBtn.icon = 'suitcase';
          this.displayCard.actionBtn.style = '';
          break;
        default:
          break;
      }
    } else {
      this.displayCard.sender = true;
      this.displayCard.contact = true;
      this.displayCard.actionBtn.label = 'Send Reminder';
      this.displayCard.actionBtn.icon = 'bell';
      this.displayCard.actionBtn.style = 'yellowBack';
    }

  }

  public close() {
    this.dialogRef.close(this.data);
  }

  public getPrimaryUser(orgId) {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.userSetupService.getUserList(token, orgId, '').subscribe((userListRes) => {
        console.log('userListRes : ', userListRes);
        this.serviceLineLoading = false;
        if (userListRes.success) {
          const primaryUser = userListRes.result.find((user) => user.isDefaultUser);
          if (primaryUser && primaryUser.globalDapFilterRules) {
            const serviceLines = primaryUser.globalDapFilterRules.find((dap) => dap.filterKey === 'serviceLine');
            if (serviceLines) {
              const userSerLines = JSON.parse(serviceLines.filterValue);
              if (userSerLines && userSerLines.length > 0) {
                const serviceLinesAll = this.assetService.getServiceLinesLocal();
                console.log('service line List Full :', serviceLinesAll);
                if (serviceLinesAll) {
                  userSerLines.forEach((serLine) => {
                    const ser = serviceLinesAll.categories.find((s) => s.id === serLine);
                    if (ser) { this.serviceLineList.push({ line1: ser.name }); }
                  });
                }
              }
            }
          }
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public showDetails(type) {
    let param = { data: [], title: '', type };
    switch (type) {
      case 'serviceLine':
        param = { data: this.serviceLineList, title: 'Service Lines', type: 'partnerInfo' };
        this.openDialog(param);
        break;
      case 'connection':
        param = { data: this.connections, title: 'Connections', type: 'partnerInfo' };
        this.openDialog(param);
        break;
      case 'outletView':
        param = { data: this.outlets, title: 'Outlets', type: 'partnerInfo' };
        this.openDialog(param);
        break;
      default:
        break;
    }
  }

  public getConnections(param) {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      console.log(param);
      this.partnerService.findNetwork(param, token).subscribe((res) => {
        this.connectionHitCount++;
        console.log('find AWAITED network : ', res);
        if (res.success) {
          this.connectedNetworkList = this.connectedNetworkList.concat(res.result);
          if (this.connectionHitCount > 1) {
            console.log('calling org', this.connectedNetworkList);
            this.getPartnerDetails(this.connectedNetworkList);
          }
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getOutlets(addresses) {
    console.log(addresses);
    addresses.forEach((add) => {
      if (!add.contactAddress.isDefaultAddress) {
        this.outlets.push({ line1: add.contactAddress.addressLabel });
      }
    });
  }

  public getPartnerDetails(list) {
    if (list.length > 0) {
      let partyList = [];
      list.forEach((ele) => {
        if (ele.sourceId === this.data.partner.partyId) {
          partyList.push({ partyId: ele.targetId });
        } else {
          partyList.push({ partyId: ele.sourceId });
        }
      });
      console.log(partyList);
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.partnerService.findOrg(partyList, token).subscribe((res) => {
          this.connectionLoading = false;
          if (res.success) {
            console.log('0000', res.result);
            this.connections = res.result.map((party) => { return { line1: party.name }; });
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    } else {
      this.connectionLoading = false;
    }
  }

  public submitAction(type) {
    console.log('Action : ', type);
    switch (type) {
      case 'reminder':
        this.sendReminder(this.data.partner);
        break;
      case 'explore':
        this.addNetwork(this.data.partner);
        break;
      case 'pendingByMe':
        this.updateNetwork('TRADABLE');
        break;
      case 'rejectRequest':
        this.updateNetwork('TERMINATED');
        break;
      case 'pendingRequest':
        // this.updateNetwork('ALREADY');
        break;
      default:
        break;
    }
  }

  public addNetwork(partner) {
    this.btnLoading = true;
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.partnerService.addNetwork(this.orgId, partner.partyId, token).subscribe((res) => {
        console.log('Result from add Network : ', res);
        this.btnLoading = false;
        if (res.success && res.result) {
          this.dialogRef.close({ success: true });
          this.helperService.openSnackBar('Connect Request Sent to ' + partner.name, 'OK');
        } else {
          this.helperService.openSnackBar('Connect Request Failed', 'Try Again');
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public updateNetwork(status) {
    console.log(status);
    console.log(this.data.partner);
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.partnerService.updateNetwork(this.data.partner.sourceId, this.data.partner.targetId, status, token).subscribe((res) => {
        console.log('updateNetwork Result : ', res);
        this.loading = false;
        if (res.success) {
          this.dialogRef.close({ success: true });
          if (status === 'TRADABLE') {
            this.helperService.openSnackBar('You are now CONNECTED with', this.data.partner.name);
          } else {
            this.helperService.openSnackBar('Request REJECTED for', this.data.partner.name);
          }
        } else {
          this.helperService.openSnackBar('Request Failed', 'Try Again');
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public sendReminder(partner) {
    if (partner.count >= 4) {
      this.helperService.openSnackBar('Maximum Reminders has been Sent', 'OK');
    } else {
      const obj = {
        invitationId: partner.invitationId,
        invitatedPartyName: partner.invitatedPartyName,
        partySubType: partner.partySubType,
        referalPartyName: partner.referalPartyName,
        email: partner.email,
        mobile: partner.mobile,
        sendtoMobile: partner.sendtoMobile,
        sendtoEmail: partner.sendtoEmail,
        webURL: partner.webURL,
        iosURL: partner.iosURL,
        playStoreURL: partner.playStoreURL,
        ecosystemProfileId: partner.ecosystemProfileId,
        ecosystemId: partner.ecosystemId,
        profileLabelName: partner.profileLabelName,
        isSentByExistingOnboardedParty: partner.isSentByExistingOnboardedParty,
        status: partner.status,
        referalOrgId: partner.referalOrgId,
        reminder: true
      };
      this.loading = true;

      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        // this.partnerService.sendReminder(obj, token).subscribe((res) => {
        //   this.loading = false;
        //   if (res.success && res.result) {
        //     this.helperService.openSnackBar('Reminder Successfully Sent', 'OK');
        //     partner.count++;
        //   } else {
        //     this.helperService.openSnackBar('Sorry! Try again!', 'OK');
        //   }
        // });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }

    // console.log(partner);
  }

  public openDialog(param) {
    if (param.data.length > 0) {
      const dialogRef = this.dialog.open(ViewListDialogComponent, {
        height: '60%',
        width: '80%',
        data: { data: param.data, type: param.type, title: param.title, selectable: false }
      });
      // dialogRef.afterClosed().subscribe((selectedOutlet) => {
      //   console.log('data from dialog', selectedOutlet);
      // });
    } else {
      this.helperService.openSnackBar('No ' + param.title + ' Found', 'OK');
    }
  }

}
