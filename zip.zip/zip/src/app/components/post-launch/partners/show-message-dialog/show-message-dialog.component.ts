import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
@Component({
  selector: 'app-show-message-dialog',
  templateUrl: './show-message-dialog.component.html',
  styleUrls: ['./show-message-dialog.component.css']
})
export class ShowMessageDialogComponent implements OnInit {
  public partnerName;
  public alertMessage;
  public requestName;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any, private dialogRef: MatDialogRef<ShowMessageDialogComponent>) {
    this.partnerName = this.data.partnerName;
    this.alertMessage = this.data.message;
    this.requestName = this.data.requestName;
  }

  public ngOnInit() {
    console.log();
  }

}
