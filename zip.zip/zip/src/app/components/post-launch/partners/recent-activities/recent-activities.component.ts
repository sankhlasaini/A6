import { slideUp, fade } from './../../../../animations';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { PartnerService } from './../../../../services/postLaunch/partner.service';
import { MatDialog } from '@angular/material';
import { RetailerProfileDialogComponent } from './../retailer-profile-dialog/retailer-profile-dialog.component';
import { HelperService } from './../../../../services/helper.service';
import { element } from 'protractor';
import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { Output, EventEmitter } from '@angular/core';
import { TerritoryService } from '../../../../services/postLaunch/territory.service';
import { ProfileSetupService } from '../../../../services/postLaunch/profile-setup.service';

@Component({
  selector: 'app-recent-activities',
  templateUrl: './recent-activities.component.html',
  styleUrls: ['./recent-activities.component.css'],
  animations: [fade, slideUp]
})
export class RecentActivitiesComponent implements OnChanges {

  @Input() public recentList;

  public loading = true;
  public recentListUpdated = [];
  public finalList = [];
  public maxRecoardToDisplay = 10;
  public currentUser = '';
  public orgId = '';
  public territoryIds = [];

  constructor(
    private helperService: HelperService,
    public dialog: MatDialog,
    private territoryService: TerritoryService,
    private partnerService: PartnerService,
    private crossPlatformService: CrossPlatformService,
    private profileSetupService: ProfileSetupService
  ) { }

  public ngOnChanges() {
    this.orgId = this.crossPlatformService.getOrgId().orgId;

    if (this.recentList.length > 0) {
      // console.log(this.recentList);
      // console.log(this.helperService.sortByTime(this.recentList, 'updatedOn'));
      this.recentListUpdated = this.helperService.sortByTime(this.recentList, 'updatedOn').slice(0, this.maxRecoardToDisplay);
      // this.connectedList = this.helperService.sortByTime(this.recentList, 'contractConnectedAt').slice(0, this.maxRecoardToDisplay);
      console.log(this.recentListUpdated);
      this.getPartnerDetails();
    } else {
      this.loading = false;
    }
  }

  public getPartnerDetails() {
    let partyList = [];
    this.recentListUpdated.forEach((ele) => {
      if (ele.sourceId === this.orgId) {
        partyList.push({ partyId: ele.targetId });
      } else {
        partyList.push({ partyId: ele.sourceId });
      }
    });

    console.log(partyList);
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.partnerService.findOrg(partyList, token).subscribe((res) => {
        if (res.success) {
          console.log('0000', res.result);
          this.recentListUpdated.forEach((ele) => {
            if (ele.sourceId === this.orgId) {
              this.createRecentRecord(ele, res.result.find((party) => ele.targetId === party.partyId));
            } else {
              this.createRecentRecord(ele, res.result.find((party) => ele.sourceId === party.partyId));
            }
          });
          this.loading = false;
          console.log(this.recentListUpdated);
          this.territoryService.getTerritoriesNameByIds(this.territoryIds, token).subscribe((idsRes) => {
            console.log(idsRes);
            if (idsRes.success) {
              this.recentListUpdated.forEach((rl) => {
                if (rl.party && rl.party.orgProfile.avatar && rl.party.orgProfile.avatar.gridFSid) {
                  rl.avatar = this.profileSetupService.getDownloadFileUrl([rl.party.orgProfile.avatar.gridFSid], token)[0];
                }
                if (rl.territoryIdsList) {
                  rl.territoryIdsList.forEach((id) => {
                    const ter = idsRes.result.find((t) => t.territoryId === id);
                    if (ter) { rl.territoryNameList.push(ter.name); }
                  });
                }
              });
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }
  public createRecentRecord(ele, p) {
    if (p) {
      p.territories = p.territories ? p.territories : [];
      ele.name = p.name;
      ele.area = p.orgProfile.contactPersons[0].contactAddress.line1 + (p.orgProfile.contactPersons[0].contactAddress.line1 === '' ? '' : ',')
        + p.orgProfile.contactPersons[0].contactAddress.city;
      ele.partyId = p.partyId;
      ele.accountId = p.accountId;
      ele.email = p.email;
      ele.mobile = p.mobile;
      ele.time = new Date(ele.updatedOn).toLocaleDateString('en-GB');
      ele.territoryNameList = [];
      ele.territoryIdsList = p.territories.map((t) => t.id);
      ele.timeDifference = this.helperService.timeDifference(Date.now(), ele.updatedOn);
      ele.party = p;
      ele.avatar = '../../../../../assets/images/user-default.png';
      ele.territoryIdsList.forEach((id) => { if (this.territoryIds.indexOf(id) === -1) { this.territoryIds.push(id); } });
    }
  }

  public showProfile(partner, type) {
    console.log(partner, type);
    switch (type) {
      // case 'invite':
      //   this.openDialog(party, 'reminder', false, '');
      //   break;
      // case 'reminder':
      //   this.openDialog(party, 'reminder', false, '');
      //   break;
      case 'TRADABLE':
        this.openDialog({ partner, type: 'connected', existing: true, inviterName: 'Inviter Name', showAction: false });
        break;
      case 'AWAITED':
        let pendingType = '';
        if (partner.sourceId === this.orgId) {
          pendingType = 'pendingRequest';
        } else {
          pendingType = 'pendingByMe';
        }
        this.openDialog({ partner, type: pendingType, existing: true, inviterName: 'Inviter Name', showAction: true });
        break;
      default:
        break;
    }
  }

  public openDialog(param) {
    const dialogRef = this.dialog.open(RetailerProfileDialogComponent, {
      width: '100%',
      height: '100%',
      maxWidth: '100%',
      data: param,
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
    });
  }

}
