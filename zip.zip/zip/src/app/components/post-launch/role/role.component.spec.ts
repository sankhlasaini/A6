import { async, ComponentFixture, TestBed } from '@angular/core/testing';


describe('ExistingRoleListComponent', () => {
  let component: ExistingRoleComponent;
  let fixture: ComponentFixture<ExistingRoleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ExistingRoleComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
