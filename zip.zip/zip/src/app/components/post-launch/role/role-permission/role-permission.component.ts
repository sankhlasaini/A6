import { slideUpEnter, fade } from './../../../../animations';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { RoleService } from './../../../../services/role.service';
import { EcoSystemService } from './../../../../services/eco-system.service';
import { HelperService } from './../../../../services/helper.service';
import { DialogWithButtonsComponent } from './../../common/dialog-with-buttons/dialog-with-buttons.component';
import { MatDialog, MatTabChangeEvent } from '@angular/material';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-role-permission',
  templateUrl: './role-permission.component.html',
  styleUrls: ['./role-permission.component.css'],
  animations: [slideUpEnter, fade]
})
export class RolePermissionComponent implements OnInit {

  @Input() public activeRole;
  @Output() public outputEvent = new EventEmitter();

  public selectedCheckBoxCount = 0;
  public roleActionList = [];
  public filteredModulesList = [];
  public viewRole;
  public roleForUpdate = [];
  public activeTabIndex = 0;
  public displayBlock = true;
  public ecosystemProfile;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private dialog: MatDialog,
    public helperService: HelperService,
    private roleService: RoleService,
    private ecoSystemService: EcoSystemService,
    private crossPlatformService: CrossPlatformService
  ) { }

  public ngOnInit() {
    this.ecosystemProfile = this.crossPlatformService.getEcoSystemProfile();
    this.viewRole = JSON.parse(JSON.stringify(this.activeRole));
    console.log(this.ecosystemProfile);
    this.filteredModulesList = this.roleService.getFilteredActionByRoleAndProfile(this.ecosystemProfile, this.viewRole);

  }

  public tabChanged(tabChangeEvent: MatTabChangeEvent) {
    this.activeTabIndex = tabChangeEvent.index;
    this.displayBlock = false;
    setTimeout(() => {
      this.activeTabIndex === tabChangeEvent.index ? this.displayBlock = true : this.displayBlock = false;
    }, 0);
  }

  public masterToggle(func) {
    func.actionList.forEach((action) => {
      if (action.isMapped) {
        this.slideToggle(action);
      }
    });
  }
  public getSelectedCount(func) {
    let count = 0;
    func.actionList.forEach((action) => {
      if (action.isSelected) {
        count++;
      }
    });
    return count;
  }

  public masterToggleAutoSelect(func) {
    let check = false;
    func.actionList.map((act) => {
      if (act.isSelected) {
        check = true;
      }
    });
    return check;
  }

  public slideToggle(action) {
    action.isSelected = !action.isSelected;
    const index = this.viewRole.actionsList.findIndex((act) => act.actionId === action.actionId);
    if (action.isSelected) {
      let newAction = {
        actionId: action.actionId,
        actionLabel: action.actionLabel,
        actionVersion: action.actionVersion.toString()
      };
      if (index === -1) {
        this.viewRole.actionsList.push(newAction);
      }
    } else {
      if (index > -1) {
        this.viewRole.actionsList.splice(index, 1);
      }
    }
  }

  public onClose() {
    this.outputEvent.emit('exit');
  }

  public onSave() {
    this.roleForUpdate = [];
    this.roleForUpdate.push(this.viewRole);
    const previewData = [];
    this.filteredModulesList.forEach((mod) => {
      let previewOptions = [];
      mod.functionList.forEach((permissionData) => {
        permissionData.actionList.forEach((option) => {
          if (option.isSelected === true) {
            previewOptions.push(option);
          }
        });
      });
      if (previewOptions.length > 0) {
        previewData.push({ title: mod.moduleLabel, previewOptions: previewOptions.map((ac) => ac.actionLabel) });
      }
    });

    const buttonDialog = this.dialog.open(DialogWithButtonsComponent, {
      width: '80%',
      height: '70%',
      maxWidth: '80%',
      data: {
        config: { button: true, input: false, cancelButton: true, markUp: true },
        for: 'Roles',
        title: this.activeRole.name + ' Key Actions',
        button: { text: 'OK', for: 'confirm' },
        markUpData: previewData
      }
    });
    buttonDialog.afterClosed().subscribe((done) => {
      if (done !== undefined && done === 'OK') {
        console.log('done', done);
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          this.roleService.updateRole(this.roleForUpdate, token).subscribe((result) => {
            if (result.success) {
              this.helperService.openSnackBar('Role updated successfully', 'OK');
              this.outputEvent.emit('reload');
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    });
    // } else {
    // this.helperService.openSnackBar('Please Select Some Actions', 'OK');
    // }
    console.log('viewROle', this.viewRole);
  }

}
