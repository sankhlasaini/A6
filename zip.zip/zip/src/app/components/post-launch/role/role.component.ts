import { UserSetupService } from './../../../services/postLaunch/user-setup.service';
import { EcoSystemService } from './../../../services/eco-system.service';
import { RoleService } from './../../../services/role.service';
import { DialogWithButtonsComponent } from './../common/dialog-with-buttons/dialog-with-buttons.component';
import { MatDialog } from '@angular/material';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { CrossPlatformService } from '../../../services/postLaunch/cross-platform.service';
import { slideUp, slideDown, slideUpEnter } from '../../../animations';
import { HelperService } from '../../../services/helper.service';
import { ViewListDialogComponent } from '../common/view-list-dialog/view-list-dialog.component';
import { UserListDialogComponent } from '../common/user-list-dialog/user-list-dialog.component';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css'],
  animations: [slideUp, slideDown, slideUpEnter]
})
export class RoleComponent implements OnInit {

  public activeRole;

  public listCardConfig = {
    image: false,
    menu: true,
    footer: true,
    multiSelect: false
  };
  public listData = [];
  public tempListData = [];
  public roleList = [];
  public filteredModuleList = [];
  public keyActionsData = [];
  public orgId;
  public loading = true;

  constructor(
    private dialog: MatDialog,
    private router: Router,
    private roleService: RoleService,
    private crossPlatformService: CrossPlatformService,
    private ecoSystemService: EcoSystemService,
    private userSetupService: UserSetupService,
    private helperService: HelperService
  ) {
  }

  public ngOnInit() {
    this.orgId = this.crossPlatformService.getOrgId().orgId;
    this.checkForGlobalModules();
  }

  public checkForGlobalModules() {
    const modulesList = this.ecoSystemService.getLocalModulesAction();
    if (modulesList && modulesList.length > 0) {
      this.setFilterModuleList(modulesList);
      this.getRoleList();
    }
  }

  public getUserListDB() {
    const usersListLocal = this.userSetupService.getUsersListLocal();
    if (usersListLocal) {
      console.log('userslist getting from local', usersListLocal);
      this.loading = false;
      this.initUsersList(usersListLocal);
    } else {
      console.log('userslist getting from db');
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.userSetupService.getUserList(token, this.orgId, '').subscribe((res) => {
          console.log('res for userInvite', res);
          this.loading = false;
          if (res.success) {
            this.userSetupService.setUsersListLocal(res.result);
            this.initUsersList(res.result);
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public initUsersList(list) {
    list.forEach((user) => { if (!user.roles) { user.roles = []; }; });
    this.listData.map((roleItem) => {
      roleItem.userList = list.filter((user) => user.roles.map((r) => r.roleId).indexOf(roleItem.id) > -1);
      roleItem.footer[1].value = roleItem.userList.length;
    });
    console.log(this.listData);
  }

  public setFilterModuleList(modulesList) {
    this.filteredModuleList = [];
    console.log(modulesList);
    if (modulesList) {
      modulesList.forEach((module, index) => {
        let actionsList = [];
        module.functionList.forEach((func) => {
          func.actionList.forEach((action) => {
            actionsList.push(action);
          });
        });
        this.filteredModuleList.push({
          moduleId: module.moduleId,
          moduleLabel: module.moduleLabel,
          actionsList
        });
      });
    }
  }

  public getRoleList() {
    this.loading = true;
    this.listData = [];
    if (this.crossPlatformService.getEcoSystemProfile()) {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.roleService.getRoleByProfileId(this.crossPlatformService.getEcoSystemProfile().id, this.crossPlatformService.getOrgId().user.orgId, token).subscribe((roleResult) => {
          console.log('roles :', roleResult);
          if (roleResult.success) {
            this.roleList = roleResult.result;
            console.log(this.filteredModuleList);
            roleResult.result.forEach((role) => {
              let moduleArray = [];
              this.filteredModuleList.forEach((module) => {
                module.actionsList.forEach((element) => {
                  const index = role.actionsList.findIndex((act) => act.actionId === element.actionId);
                  if (index > -1) {
                    if (moduleArray.indexOf(module.moduleLabel) === -1) {
                      moduleArray.push(module.moduleLabel);
                    }
                  }
                });
              });
              this.createListData(role, [], moduleArray);
            });
            this.getUserListDB();
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public createListData(role, userList, moduleArray) {
    let menuData = ['Edit Permission', 'Assign Users', 'Invite Users', 'Clone', 'Re-name'];
    // menuData = role.isDefault ? menuData : menuData = menuData.push('Delete');
    this.listData.push({
      default: role.isDefault,
      title: role.name,
      id: role.id,
      userList,
      initialData: role,
      subTitle: moduleArray,
      subTitle1: [],
      menuData: role.isDefault ? menuData : menuData = menuData.concat(['Delete']),
      footer: [{ placeholder: 'Key Actions', value: role.actionsList.length, clickable: true },
      { placeholder: 'Users', value: userList.length, clickable: true }]
    });
    this.listData.sort((a, b) => a.title.toLowerCase() < b.title.toLowerCase() ? -1 : a.title.toLowerCase() > b.title.toLowerCase() ? 1 : 0);
  }

  public responseFromList(response) {
    console.log(response);
    if (response.eventFrom === 'menu') {
      console.log('role id is ', response);
      switch (response.eventData) {
        case 'Edit Permission':
          this.activeRole = response.initialData;
          // this.router.navigate(['/postLaunch/role/rolePermission', response.reference]);
          break;
        case 'Clone':
          this.menuAction('Role Name', 'CLONE', 'Clone Role', 'cloneRole', response.initialData, this.roleList.map((role) => role.name.trim().toLowerCase()));
          break;
        case 'Re-name':
          let labelList = this.roleList.map((role) => role.name.trim().toLowerCase());
          labelList.splice(labelList.indexOf(response.initialData.name.trim().toLowerCase()), 1);
          console.log(labelList);
          this.menuAction('Role Name', 'PROCEED', 'Rename Role', 'renameRole', response.initialData, labelList);
          break;
        case 'Assign Users':
          const usersListLocal = this.userSetupService.getUsersListLocal();
          this.usersListForRole(usersListLocal, response.initialData, true);
          break;
        case 'Invite Users':
          this.userSetupService.setInviteuserForRole(response.initialData);
          this.router.navigate(['/postLaunch/user/inviteUser']);
          break;
        default:
          break;
      }
    }

    if (response.eventFrom === 'footer') {
      if (response.eventData === 'Key Actions') {
        let param = { data: [], title: 'Key Actions', type: 'partnerInfo' };
        param.data = response.initialData.actionsList.map((act) => { return { line1: this.ecoSystemService.getActionLabelById(act.actionId) }; });
        this.openListDialog(param);
      } else if (response.eventData === 'Users') {
        if (response.dataLength > 0) {
          this.usersListForRole(response.userList, response.initialData, false);
        }
      }
    }
    console.log('outputResponse', response);
  }

  public openListDialog(param) {
    if (param.data.length > 0) {
      const dialogRef = this.dialog.open(ViewListDialogComponent, {
        height: '60%',
        width: '80%',
        data: { data: param.data, type: param.type, title: param.title, selectable: false }
      });
    }
  }

  public usersListForRole(users, role, selectable) {
    console.log(users);
    if (users) {

      users.forEach((user) => {
        if (user.roles && user.roles.find((rl) => rl.roleId === role.id)) {
          user.isSelected = true;
        } else {
          user.isSelected = false;
        }
      });
      const dialogRef = this.dialog.open(UserListDialogComponent, {
        maxWidth: '100%',
        height: '100%',
        width: '100%',
        autoFocus: false,
        data: { users: JSON.parse(JSON.stringify(users)), role, selectable }
      });
      dialogRef.afterClosed().subscribe((result) => {
        console.log('data from dialog', result);
        if (selectable && result) {
          let usersUpdateList = [];
          users.forEach((old) => {
            let userObj = { partyId: old.partyId, addEnableRoles: [], removeRoles: [] };
            const newUser = result.find((u) => u.initialData.partyId === old.partyId);
            if (old.isSelected) {
              if (!newUser.isSelected) {
                userObj.removeRoles = [role.id];
              }
            } else {
              if (newUser.isSelected) {
                userObj.addEnableRoles = [{
                  roleId: role.id,
                  roleLabel: role.name,
                  version: role.version.toString(),
                  enabledActions: this.getEnabledActions(role)
                }];
              }
            }
            if (userObj.addEnableRoles.length > 0 || userObj.removeRoles.length > 0) {
              usersUpdateList.push(userObj);
            }
          });
          console.log('FINAL : ', usersUpdateList);
          this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
            this.userSetupService.updateUser(token, usersUpdateList).subscribe((res) => {
              console.log('response for update User', res);
              if (res.success && res.result) {
                this.userSetupService.setUsersListLocal(undefined);
                this.getUserListDB();
                this.helperService.openSnackBar('User Updated Successfully', 'OK');
              }
            }, (err) => {
              console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
            });
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }
      });
    }
  }

  public menuAction(inputPlaceholder, buttonText, dialogTitle, actionFor, roleData, labelList) {
    const dialogRef = this.dialog.open(DialogWithButtonsComponent, {
      width: '80%',
      disableClose: true,
      data: {
        config: { button: true, input: true },
        for: 'role',
        title: dialogTitle,
        input: { placeholder: inputPlaceholder, labelList },
        button: { text: buttonText, for: 'newRole' }
      }
    });
    dialogRef.afterClosed().subscribe((roleName) => {
      if (roleName) {
        let role = JSON.parse(JSON.stringify(roleData));
        console.log('newroleName', roleName, role);
        if (actionFor === 'renameRole') {
          role.name = roleName;
          this.updateRole(role);
        } else if (actionFor === 'cloneRole') {
          delete role.id;
          role.name = roleName;
          role.isDefault = false;
          this.createRoles([role]);
          // this.router.navigate(['/postLaunch/role/rolePermission', roleName]);
        }
      }
    });
  }

  public updateRole(role) {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.roleService.updateRole([role], token).subscribe((updateRes) => {
        this.helperService.openSnackBar('Roles Name Updated', 'OK');
        console.log(updateRes);
        this.getRoleList();
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public createRoles(roleList) {
    console.log('CREATE ROLE REQ :: ', roleList);
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.roleService.createRole(roleList, token).subscribe((createRoleRes) => {
        console.log('CREATE ROLE RES :: ', createRoleRes);
        if (createRoleRes.success) {
          this.getRoleList();
          this.helperService.openSnackBar('ROLE Cloned', 'OK');
        } else {
          this.helperService.openSnackBar('ROLE Clone Failed', 'Try Again');
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getEnabledActions(role) {
    let actionsArr = [];
    const globalActions = this.ecoSystemService.getGlobalActionList();
    role.actionsList.forEach((at) => {
      const act = globalActions.find((ga) => ga.actionId === at.actionId);
      if (act) {
        actionsArr.push({
          actionId: act.actionId,
          actionLabel: act.actionLabel,
          actionVersion: act.actionVersion.toString(),
          mappedEndpointCanUris: act.linkedApiIds.map((api) => api.endpointCannonicalUniqueUri)
        });
      }
    });
    return actionsArr;
  }

  public closePermission(event) {
    this.activeRole = undefined;
    if (event === 'reload') {
      this.getRoleList();
    }
  }

}
