import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TerritorySelectionDialogComponent } from './territory-selection-dialog.component';

describe('TerritorySelectionDialogComponent', () => {
  let component: TerritorySelectionDialogComponent;
  let fixture: ComponentFixture<TerritorySelectionDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TerritorySelectionDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TerritorySelectionDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
