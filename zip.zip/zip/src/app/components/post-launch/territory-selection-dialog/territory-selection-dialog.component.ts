import { slideUpEnter } from './../../../animations';
import { HelperService } from './../../../services/helper.service';
import { TerritoryService } from './../../../services/postLaunch/territory.service';
import { CrossPlatformService } from './../../../services/postLaunch/cross-platform.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Component, OnInit, Inject } from '@angular/core';

@Component({
  selector: 'app-territory-selection-dialog',
  templateUrl: './territory-selection-dialog.component.html',
  styleUrls: ['./territory-selection-dialog.component.css'],
  animations: [slideUpEnter]
})
export class TerritorySelectionDialogComponent implements OnInit {
  public loading = true;
  public wholeList = [];
  public orgId;
  public territoryPageSize = 20;
  public selectedItemCount = 0;
  public activeTabIndex = 0;
  public selectAllFlag = false;
  public firstLevelFlag = true;
  public territoryLevelArray = [{ title: 'Select Territory' }];
  public selectedTerritory;
  public tempTerritoryLevelArray = [];
  public finalArray = [];
  public clickedTerritoryLevel = { nodeId: '', levelType: '' };
  public finalTerritoryObjectArray = [];
  public intermidiateFlag = false;
  public leafNodeFlag = false;
  public backBtnLabel = 'CANCEL';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<TerritorySelectionDialogComponent>,
    private crossPlatformService: CrossPlatformService,
    private territoryService: TerritoryService,
    private helperService: HelperService
  ) {
    this.orgId = this.crossPlatformService.getOrgId().orgId;
  }

  public ngOnInit() {
    this.dialogRef.afterOpen().subscribe(() => {
      console.log(this.data);
      this.data.globalTerritoryList.forEach((territory) => {
        territory['isSelected'] = false;
        territory['accessFlag'] = false;
        territory['isClicked'] = false;
        territory['count'] = 0;
        territory['levelName'] = territory.territoryName;
        this.assignFieldToTerritory(territory.territoryLevel, false, 'isSelected');
        this.assignFieldToTerritory(territory.territoryLevel, false, 'accessFlag');
        this.assignFieldToTerritory(territory.territoryLevel, false, 'isClicked');
        this.assignFieldToTerritory(territory.territoryLevel, 0, 'count');
      });

      this.wholeList = this.data.globalTerritoryList;
      console.log('wholeList', this.wholeList);
      this.tempTerritoryLevelArray.push(this.data.globalTerritoryList);
      this.loading = false;
      console.log('DATA TO EDIT', this.data);
      if (this.data.existingTerritoryList !== undefined && this.data.existingTerritoryList.length > 0) {
        this.editTerritorySelection();
        this.wholeList.forEach((territoryData) => {
          this.territoryService.addIntermidiateFlag(territoryData.territoryLevel);
        });
        console.log('wholeList', this.wholeList);
      }
    });
  }

  public editTerritorySelection() {
    this.tempTerritoryLevelArray[0].forEach((territory, i) => {
      this.data.existingTerritoryList.forEach((existingTerritory) => {
        if (territory.territoryId === existingTerritory.id) {
          territory.count = existingTerritory.territoryCount;
          existingTerritory.territoryTree.forEach((leafNode) => {
            // if (leafNode.selectedNodeId === territory.territoryId) {
            // this.tempTerritoryLevelArray[0][i].isSelected = true;
            // this.tempTerritoryLevelArray[0][i].isClicked = true;
            // this.assignFieldToTerritory(this.tempTerritoryLevelArray[0][i].territoryLevel, true, 'isSelected');
            // this.setSubLevelCount(this.tempTerritoryLevelArray[0][i].territoryLevel);
            // } else {
            this.traverseForEdit(leafNode.selectedNodeId, leafNode.nodeId, this.tempTerritoryLevelArray[0][i].territoryLevel);
            // }
          });
        }
      });
      this.setFirstLevelCount();
    });
  }

  // public setSubLevelCount(mainLevel) {
  //   if (mainLevel !== undefined && mainLevel.length > 0) {
  //     mainLevel.forEach((subLevelData) => {
  //       subLevelData.count = subLevelData.subTerritoryLevel.length;
  //       this.setSubLevelCount(subLevelData.subTerritoryLevel);
  //     });
  //   }
  // }

  public traverseForEdit(selectedNodeId, nodeId, mainLevel) {
    if (mainLevel !== undefined && mainLevel.length > 0) {
      mainLevel.forEach((subLevelData) => {
        if (subLevelData.id === selectedNodeId) {
          subLevelData.isClicked = true;

          if (subLevelData.subTerritoryLevel.length > 0) {
            subLevelData.subTerritoryLevel.forEach((subLevel) => {
              this.leafNodeFlag = false;
              if (subLevel.subTerritoryLevel.length > 0) {
                this.checkParentByLeafNode(subLevel.subTerritoryLevel, nodeId);
                if (this.leafNodeFlag) {
                  this.assignFieldToTerritory(subLevel.subTerritoryLevel, true, 'isSelected');
                }
              } else if (subLevel.subTerritoryLevel.length === 0) {
                if (subLevel.id === nodeId) { subLevel.isSelected = true; this.leafNodeFlag = true; }
              }
            });
          } else { subLevelData.isSelected = true; }
        }

        this.traverseForEdit(selectedNodeId, nodeId, subLevelData.subTerritoryLevel);
        if (subLevelData.subTerritoryLevel.length > 0) {
          let count = 0;
          subLevelData.subTerritoryLevel.forEach((subData) => {
            if (subData.isSelected === true) { count++; }
          });
          if (subLevelData.subTerritoryLevel.length > 0) {
            if (count === subLevelData.subTerritoryLevel.length) { subLevelData.isSelected = true; }
          }
          subLevelData.count = count;
        }
      });
    }
  }

  public checkParentByLeafNode(mainLevel, nodeId) {
    mainLevel.forEach((subLevelData) => {
      if (subLevelData.id === nodeId) { this.leafNodeFlag = true; }
      this.checkParentByLeafNode(subLevelData.subTerritoryLevel, nodeId);
    });
  }

  public assignFieldToTerritory(mainLevel, value, field) {
    mainLevel.forEach((subLevelData) => {
      subLevelData[field] = value;
      this.assignFieldToTerritory(subLevelData.subTerritoryLevel, value, field);
    });
  }

  // public toggleAllData(selectAllFlag) {
  //   this.wholeList.forEach((item) => {
  //     item.isSelected = !selectAllFlag;
  //     selectAllFlag ? this.selectedItemCount = 0 : this.selectedItemCount = this.wholeList.length;
  //   });
  //   this.selectAllFlag = !selectAllFlag;
  // }

  public removeAllSelection(list) {
    list.forEach((ele) => {
      ele.isSelected = false;
      if (ele.subTerritoryLevel.length > 0) {
        this.removeAllSelection(ele.subTerritoryLevel);
      }
    });
  }

  public selectedData(mainIndex, selectedIndex, event) {
    if (this.data.singleLeafSelection === true) {
      this.tempTerritoryLevelArray[0].forEach((ter) => {
        this.removeAllSelection(ter.territoryLevel);
      });
    }

    console.log(mainIndex, selectedIndex);
    if (this.firstLevelFlag === true) { this.selectedTerritory = this.tempTerritoryLevelArray[mainIndex][selectedIndex]; }
    this.wholeList[selectedIndex].isSelected = event.checked;
    this.tempTerritoryLevelArray[mainIndex][selectedIndex]['isSelected'] = event.checked;
    this.tempTerritoryLevelArray[mainIndex][selectedIndex]['isClicked'] = !this.tempTerritoryLevelArray[mainIndex][selectedIndex]['isClicked'];
    if (mainIndex > 0) { this.markTerritorySelection(mainIndex, selectedIndex, event, 'subTerritoryLevel'); }
    if (mainIndex === 0) { this.markTerritorySelection(mainIndex, selectedIndex, event, 'territoryLevel'); }
    // this.setIntermidiateFlag()
    // console.log('----- SET ----', this.tempTerritoryLevelArray);
  }

  public markTerritorySelection(mainIndex, selectedIndex, event, selectionFor) {
    console.log('tempTerritoryLevelArray[mainIndex]', this.tempTerritoryLevelArray[mainIndex][selectedIndex], event);

    this.assignFieldToTerritory(this.tempTerritoryLevelArray[mainIndex][selectedIndex][selectionFor], event.checked, 'isSelected');
    if (event.checked === true) {
      this.territoryCount(this.tempTerritoryLevelArray[mainIndex][selectedIndex][selectionFor], 'set');
      this.tempTerritoryLevelArray[mainIndex][selectedIndex].count = this.tempTerritoryLevelArray[mainIndex][selectedIndex][selectionFor].length;
    } else if (event.checked === false) {
      this.territoryCount(this.tempTerritoryLevelArray[mainIndex][selectedIndex][selectionFor], 'reset');
      this.tempTerritoryLevelArray[mainIndex][selectedIndex].count = 0;
    }

    this.previousLevelSelection(mainIndex);
    this.setPreviousLevelCount(this.tempTerritoryLevelArray);
    this.setFirstLevelCount();
  }

  public previousLevelSelection(mainIndex) {
    let levelCount = 0;
    this.tempTerritoryLevelArray[mainIndex].forEach((territoryLevel) => {
      if (territoryLevel.isSelected === true) { levelCount++; }
    });
    if (mainIndex > 1) {
      if (levelCount === this.tempTerritoryLevelArray[mainIndex].length) { this.assignSelectionToPreviousLevel(mainIndex, true); }
      if (levelCount !== this.tempTerritoryLevelArray[mainIndex].length) { this.assignSelectionToPreviousLevel(mainIndex, false); }
    } else {
      if (levelCount === this.tempTerritoryLevelArray[mainIndex].length) { this.firstLevelSelection(true); }
      if (levelCount !== this.tempTerritoryLevelArray[mainIndex].length) { this.firstLevelSelection(false); }
    }
  }

  public assignSelectionToPreviousLevel(mainIndex, value) {
    this.tempTerritoryLevelArray[mainIndex - 1].forEach((subLevel) => {
      subLevel.subTerritoryLevel.forEach((innerLevel) => {
        if (innerLevel.id === this.tempTerritoryLevelArray[mainIndex][0].id) { subLevel.isSelected = value; }
      });
    });
    this.previousLevelSelection(mainIndex - 1);
  }

  public firstLevelSelection(value) {
    this.tempTerritoryLevelArray[0].forEach((territory) => {
      if (territory.levelName === this.selectedTerritory.levelName) { territory.isSelected = value; }
    });
  }

  public territoryCount(mainLevel, whatToDo) {
    mainLevel.forEach((subLevelData) => {
      if (whatToDo === 'set') { subLevelData['count'] = subLevelData.subTerritoryLevel.length; }
      if (whatToDo === 'reset') { subLevelData['count'] = 0; }
      this.territoryCount(subLevelData.subTerritoryLevel, whatToDo);
    });
  }

  public setPreviousLevelCount(mainLevel) {
    let count = 0;
    mainLevel.forEach((subLevelData) => {
      if (subLevelData.accessFlag === undefined) { this.setPreviousLevelCount(subLevelData); }
      if (subLevelData.accessFlag === true) {
        if (subLevelData.territoryLevel === undefined) {
          count = this.determineCount(subLevelData, 'subTerritoryLevel');
          subLevelData['count'] = count;
          this.setPreviousLevelCount(subLevelData.subTerritoryLevel);
        }
        if (subLevelData.territoryLevel !== undefined) {
          count = this.determineCount(subLevelData, 'territoryLevel');
          subLevelData['count'] = count;
          this.setPreviousLevelCount(subLevelData.territoryLevel);
        }
      }
    });
    this.setFirstLevelCount();
  }

  public setFirstLevelCount() {
    this.tempTerritoryLevelArray[0].forEach((territory) => {
      let selectionCount = 0;
      territory.territoryLevel.forEach((subTerritory) => {
        if (subTerritory.isSelected === true) { selectionCount++; }
      });
      this.finalArray = [];
      this.createFinalTerritoryArray(territory.territoryLevel);
      territory.count = this.finalArray.length;
      if (territory.territoryLevel.length === selectionCount) { territory.isSelected = true; }
    });
  }

  public determineCount(subLevelData, countFor) {
    let count = 0;
    subLevelData[countFor].forEach((data) => {
      if (data.isSelected === true) { count++; }
    });
    return count;
  }

  public goToPreviousLevel() {
    this.activeTabIndex--;
    if (this.activeTabIndex > 0) {
      this.firstLevelFlag = false;
      this.backBtnLabel = 'BACK';
    } else {
      this.backBtnLabel = 'CANCEL';
      this.firstLevelFlag = true;
    }
    this.tempTerritoryLevelArray.pop();
    this.territoryLevelArray.pop();
    this.wholeList = this.tempTerritoryLevelArray[this.tempTerritoryLevelArray.length - 1];
    if (this.activeTabIndex > 0) { this.checkForIntermidiate(); }
  }

  public goToNextLevel(territoryData) {
    console.log(territoryData);
    territoryData.accessFlag = true;
    let levelData;
    if (this.firstLevelFlag) {
      this.selectedTerritory = territoryData;
      levelData = territoryData.territoryLevel;
    } else {
      levelData = territoryData.subTerritoryLevel;
    }
    this.assignDatatoWholeList(levelData, territoryData);

    if (levelData.length > 0) {
      this.activeTabIndex++;
      if (this.activeTabIndex > 0) {
        this.firstLevelFlag = false;
        this.backBtnLabel = 'BACK';
      } else {
        this.backBtnLabel = 'CANCEL';
        this.firstLevelFlag = true;
      }
      this.checkForIntermidiate();
    }

  }

  public assignDatatoWholeList(subLevelData, territoryData) {
    let title;
    if (territoryData.subTerritoryLevel && territoryData.subTerritoryLevel.length > 0) {
      title = territoryData.levelName + ' - ' + this.selectedTerritory.levelName;
    } else { title = this.selectedTerritory.levelName; }

    if (subLevelData.length > 0) {
      this.wholeList = subLevelData;
      this.territoryLevelArray.push({ title });
      this.tempTerritoryLevelArray.push(subLevelData);
    } else {
      this.helperService.openSnackBar('This is Last Node of this level', 'OK');
    }
  }

  public checkForIntermidiate() {
    console.log('------ WHOLE DATA ------', this.wholeList);
    this.wholeList.forEach((data) => {
      if (data.subTerritoryLevel.length > 0) {
        let count = 0;
        data.subTerritoryLevel.forEach((subLevel) => {
          if (subLevel.isSelected === true) { count++; }
          if (subLevel['isIntermidiate'] === true) { data['isIntermidiate'] = true; }
        });
        count > 0 && count !== data.subTerritoryLevel.length ? data['isIntermidiate'] = true : data['isIntermidiate'] = false;
      }
      this.territoryService.finalDataCheck(data);
    });
  }

  public onBack() {
    this.firstLevelFlag ? this.dialogRef.close() : this.goToPreviousLevel();
  }

  public onAssign() {
    this.finalTerritoryObjectArray = [];
    this.tempTerritoryLevelArray[0].forEach((territory) => {
      this.finalArray = [];
      this.createFinalTerritoryArray(territory.territoryLevel);
      if (this.finalArray.length > 0) {
        this.finalTerritoryObjectArray.push({
          id: territory.territoryId,
          territoryTree: this.finalArray,
        });
      }
      if (territory.isClicked === true) {
        this.finalTerritoryObjectArray.forEach((territoryObject) => {
          if (territoryObject.id === territory.territoryId) {
            territoryObject.territoryTree.forEach((leafNode) => {
              leafNode.selectedNodeId = territory.territoryId;
              leafNode.selectedNodeLevelType = 'territory';
            });
          }
        });
      }
    });
    this.dialogRef.close({ mapping: this.finalTerritoryObjectArray });
  }

  public createFinalTerritoryArray(mainLevel) {
    if (mainLevel !== undefined) {
      mainLevel.forEach((subLevelData) => {
        if (subLevelData.isClicked === true && subLevelData.isSelected === true) {
          this.clickedTerritoryLevel.nodeId = subLevelData.id;
          this.clickedTerritoryLevel.levelType = subLevelData.levelType;
        }
        if (subLevelData.isSelected === true) {
          if (subLevelData.subTerritoryLevel.length === 0) {
            this.finalArray.push({
              nodeId: subLevelData.id,
              nodeLevelType: subLevelData.levelType,
              selectedNodeId: this.clickedTerritoryLevel.nodeId,
              selectedNodeLevelType: this.clickedTerritoryLevel.levelType
            });
          }
        }
        this.createFinalTerritoryArray(subLevelData.subTerritoryLevel);
      });
    }
  }

}
