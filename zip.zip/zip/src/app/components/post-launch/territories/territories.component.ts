import { Router } from '@angular/router';
import { DialogWithButtonsComponent } from './../common/dialog-with-buttons/dialog-with-buttons.component';
import { BottomSheetDialogComponent } from './../common/bottom-sheet-dialog/bottom-sheet-dialog.component';
import { MatDialog } from '@angular/material';
import { Component } from '@angular/core';
import { CrossPlatformService } from '../../../services/postLaunch/cross-platform.service';
import { TerritoryService } from './../../../services/postLaunch/territory.service';

@Component({
  selector: 'app-territories',
  templateUrl: './territories.component.html',
  styleUrls: ['./territories.component.css']
})
export class TerritoriesComponent {

  constructor(
    public dialog: MatDialog,
    private router: Router,
  ) { }

  public createTerritory() {
    const dialogRef = this.dialog.open(DialogWithButtonsComponent, {
      width: '80%',
      maxWidth: '80%',
      disableClose: true,
      data: {
        config: { button: true, input: true },
        for: 'addTerritory',
        title: 'Create New Territory',
        input: { placeholder: 'Territory Name' },
        button: { text: 'PROCEED', for: 'newTerritory' }
      }
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result !== undefined) {
        this.router.navigate(['postLaunch/territory/newTerritory', result]);
      }
    });
  }
}
