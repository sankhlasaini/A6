import { MatDialog } from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { HelperService } from '../../../../services/helper.service';
import { TerritoryService } from '../../../../services/postLaunch/territory.service';
import { CrossPlatformService } from '../../../../services/postLaunch/cross-platform.service';
import { CustomLevelSelectionSmDialogComponent } from './custom-level-selection-sm-dialog/custom-level-selection-sm-dialog.component';
import { slideUpEnter } from '../../../../animations';

@Component({
  selector: 'app-custom-level-list-sm',
  templateUrl: './custom-level-list-sm.component.html',
  styleUrls: ['./custom-level-list-sm.component.css'],
  animations: [slideUpEnter]
})
export class CustomLevelListSmComponent implements OnChanges {
  @Input() public inputData;
  @Output() public outputEvent = new EventEmitter();

  public defaultNode = {
    levelType: '',
    levelCategory: 'CUSTOM',
    value: '',
    levelName: '',
    parentId: '',
    parentType: '',
    orgId: '',
    customLevelKey: 'CUSTOMKEY',
    isSelected: false,
    error: { error: false, type: '' }
  };

  public levelName = new FormControl('', [Validators.required]);
  public customLevel: FormGroup;
  public filteredLevel: Observable<any[]>;
  public levels = [];
  public nodeList = [];
  public saveDisabled = false;
  public loading = true;
  public notAllowedLevels = [];

  constructor(
    private dialog: MatDialog,
    private helperService: HelperService,
    private territoryService: TerritoryService,
    private crossPlatformService: CrossPlatformService,
  ) { }

  public ngOnChanges() {
    console.log('---inputData---', this.inputData);
    this.levels = [];
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.territoryService.retrieveTerritoryMasterData(this.crossPlatformService.getOrgId().user.orgId, token).subscribe((res) => {
        this.loading = false;
        console.log('res for retrieveTerritoryMasterData', res);
        if (res.success) {
          this.levelName = new FormControl('', [Validators.required]);
          this.initLevelList(res.result);
          this.filteredLevel = this.levelName.valueChanges.pipe(startWith(''), map((level) => level ? this.filterLevels(level) : this.levels.slice()));
          if (this.inputData.type === 'edit') {
            this.enableEditMode();
          }
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public initLevelList(itemList) {
    let levelList = [];
    itemList.forEach((item) => {
      const index = levelList.findIndex((itemGrp) => itemGrp.name === item.levelType);
      index > -1 ? levelList[index].nodes.push(item) : levelList.push({ name: item.levelType, nodes: [item] });
    });
    if (this.inputData.levelTypeAllowed && this.inputData.levelTypeAllowed !== '') {
      levelList = levelList.filter((level) => level.name === this.inputData.levelTypeAllowed);
      this.levels = levelList;
      this.levelName.patchValue(this.inputData.levelTypeAllowed);
      this.levelName.disable();
      this.selectlevel(this.inputData.levelTypeAllowed);
    } else {
      console.log(levelList);
      console.log(this.inputData.existingLevels);
      this.levels = levelList.filter((lvl) => !this.inputData.existingLevels.find((l) => l === lvl.name));
      if (this.inputData.type === 'edit') {
        this.levels.push(levelList.find((lvl) => lvl.name === this.inputData.parent.subTerritoryLevel[0].levelType));
      }
      console.log(this.levels);
    }
    this.levels = this.helperService.sortByKey(this.levels, 'name');
    levelList.forEach((lvl) => {
      if (!this.levels.find((l) => l.name === lvl.name)) {
        this.notAllowedLevels.push(lvl.name);
      }
    });
    console.log('notAllowedLevels', this.notAllowedLevels);
  }

  public enableEditMode() {
    let level = this.levels.find((lvl) => lvl.name === this.inputData.parent.subTerritoryLevel[0].levelType);
    console.log('PRE SELECTED LEVEL', level);
    if (level) {
      this.levelName.patchValue(level.name);
      this.selectlevel(level.name);
    }
  }

  public selectlevel(levelName) {
    this.levelName.setErrors(null);
    let level = this.levels.find((lvl) => lvl.name.toLowerCase().trim() === levelName.toLowerCase().trim());
    this.nodeList = [];
    this.saveDisabled = false;
    if (this.notAllowedLevels.find((lvl) => lvl.toLowerCase().trim() === levelName.toLowerCase().trim())) {
      this.levelName.setErrors({ alreadyInUse: true });
      this.saveDisabled = true;
      this.helperService.openSnackBar('Level Type Already in Use', 'Try Another');
    } else {
      if (level) {
        level.nodes.forEach((label) => {
          if (this.inputData.type === 'edit') {
            label.isSelected = this.inputData.parent.subTerritoryLevel.find((n) => n.id === label.customLevelId) ? true : false;
          } else {
            label.isSelected = false;
          }
          this.nodeList.push(label);
        });
        console.log(level.nodes);
        console.log(this.nodeList);
      }
    }
  }

  public filterLevels(name: string) {
    return this.levels.filter((level) =>
      level.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  public addNode() {
    let newNode = JSON.parse(JSON.stringify(this.defaultNode));
    newNode.orgId = this.crossPlatformService.getOrgId().user.orgId;
    newNode.parentId = this.inputData.standardParent.id;
    newNode.parentType = this.inputData.standardParent.levelType;
    newNode.isSelected = true;
    newNode.levelType = this.levelName.value.trim();
    this.nodeList.push(newNode);
    setTimeout(() => {
      document.getElementById('labelContainer').scrollTop = document.getElementById('labelContainer').scrollHeight;
      document.getElementById('labelInput' + (this.nodeList.length - 1)).focus();
    }, 20);
    this.validateLabel();
  }

  public deleteNode(index) {
    this.nodeList.splice(index, 1);
  }

  public validateLabel() {
    this.saveDisabled = false;
    this.nodeList.forEach((rl, index) => {
      rl.error = { error: false, type: '' };
      if (rl.value.trim() === '') {
        rl.error = { error: true, type: 'required' };
        this.saveDisabled = true;
      } else {
        this.nodeList.forEach((rl2, index2) => {
          if (index !== index2 && rl.value.toLowerCase().trim() === rl2.value.toLowerCase().trim()) {
            rl.error = { error: true, type: 'duplicate' };
            this.saveDisabled = true;
          }
        });
      }
    });
    // this.updateLevelFlag = true;
  }

  public cancelCustomLabel() {
    this.outputEvent.emit(undefined);
  }

  public saveCustomLabel() {
    console.log(this.nodeList);
    console.log(this.inputData);
    if (this.saveDisabled) {
      this.helperService.openSnackBar('Invalid Custom Level', 'OK');
    } else {
      if (this.nodeList.filter((n) => n.isSelected).length > 0) {
        let nodesForUpdate = this.nodeList.filter((n) => n.customLevelId);
        let nodesForCreate = this.nodeList.filter((n) => !n.customLevelId);
        this.helperService.openSnackBar('Checking Levels', 'Please Wait');
        if (nodesForCreate.length > 0) {
          this.createTerritoryMasterData(nodesForCreate, nodesForUpdate);
        } else {
          this.updateTerritoryMasterData(nodesForUpdate);
        }
      } else {
        this.helperService.openSnackBar('Please Select a Node', 'OK');
      }
    }
  }

  public createTerritoryMasterData(nodesForCreate, nodesForUpdate) {
    console.log('createTerritoryMasterData Request :', nodesForCreate);
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.territoryService.createTerritoryMasterData(token, nodesForCreate).subscribe((res) => {
        console.log('res for TerritoryMasterData', res);
        if (res.success) {
          this.helperService.openSnackBar('TerritoryMasterData Successfully Added', 'OK');
          res.result.forEach((label) => {
            let newNode = nodesForCreate.find((n) => n.value === label.value);
            newNode.customLevelId = label.customLevelId;
          });
          this.updateTerritoryMasterData(nodesForUpdate);
        } else {
          this.helperService.openSnackBar('TerritoryMasterData Creation Failed', 'OK');
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public updateTerritoryMasterData(list) {
    if (list.length > 0) {
      const updatedMasterData = { customLevelDeleteIds: [], customLevelDTOList: list, addCustomLevelDTOList: [] };
      console.log('UpdateTerritoryMasterData Request :', updatedMasterData);
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.territoryService.updateTerritoryMasterData(token, updatedMasterData).subscribe((res) => {
          console.log('res for UpdateTerritoryMasterData', res);
          if (res.success && res.result) {
            this.helperService.openSnackBar('TerritoryMasterData Successfully Update', 'OK');
            this.checkParent();
          } else {
            this.helperService.openSnackBar('TerritoryMasterData Updatation Failed', 'OK');
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    } else {
      this.checkParent();
    }
  }

  public checkParent() {
    let finalNodeList = this.modifyLevelJson(this.nodeList.filter((n) => n.isSelected));
    if (this.inputData.type === 'edit') {
      let mappingData = [];
      this.inputData.parent.subTerritoryLevel.forEach((node) => {
        if (node.subTerritoryLevel.length > 0) {
          mappingData.push({
            oldParent: node, newParent: finalNodeList.find((n) => n.id === node.id)
          });
        }
      });
      if (mappingData.length > 0) {
        this.openLevelSelection(this.inputData.parent, finalNodeList, mappingData);
      } else {
        this.inputData.parent.subTerritoryLevel = finalNodeList;
        this.outputEvent.emit(undefined);
      }
    } else {
      // New Levels Without Child Data.
      if (this.inputData.parent.subTerritoryLevel.length === 0) {
        this.inputData.parent.subTerritoryLevel = finalNodeList;
        this.outputEvent.emit(undefined);
      } else {
        // New Levels With Child Data.
        this.openLevelSelection(this.inputData.parent, finalNodeList, []);
      }
    }
  }

  public modifyLevelJson(list) {
    let finalNodeList = [];
    list.forEach((node) => {
      let obj = {
        code: '',
        id: node.customLevelId,
        isEditable: true,
        isExpandable: true,
        isSelected: false,
        levelCategory: node.levelCategory,
        levelName: node.value,
        levelType: node.levelType,
        subTerritoryLevel: []
      };
      finalNodeList.push(obj);
    });
    return finalNodeList;
  }

  public openLevelSelection(parent, selectedNodes, mappingData) {
    const dialogRef = this.dialog.open(CustomLevelSelectionSmDialogComponent, {
      height: '100%',
      width: '100%',
      maxWidth: '100%',
      data: {
        type: this.inputData.type,
        title: 'Select the Level value to inherit',
        selectedNodes,
        parent,
        mappingData
      }
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
      if (result) {
        this.outputEvent.emit(undefined);
      }
    });
  }

}
