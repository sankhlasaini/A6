import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomLevelListComponent } from './custom-level-list.component';

describe('CustomLevelListComponent', () => {
  let component: CustomLevelListComponent;
  let fixture: ComponentFixture<CustomLevelListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomLevelListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomLevelListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
