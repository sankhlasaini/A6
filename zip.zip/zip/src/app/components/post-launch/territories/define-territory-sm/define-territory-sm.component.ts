import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { HelperService } from '../../../../services/helper.service';
import { LoginService } from '../../../../services/login.service';
import { PartnerService } from '../../../../services/postLaunch/partner.service';
import { MasterPartyService } from '../../../../services/master-party.service';
import { TerritoryService } from '../../../../services/postLaunch/territory.service';
import { DialogWithButtonsComponent } from '../../common/dialog-with-buttons/dialog-with-buttons.component';

@Component({
  selector: 'app-define-territory-sm',
  templateUrl: './define-territory-sm.component.html',
  styleUrls: ['./define-territory-sm.component.css']
})
export class DefineTerritorySmComponent {

  public loading = true;
  public enableEdit = false;
  public territoryData = {
    orgId: '',
    territoryName: '',
    territoryId: null,
    territoryLabelName: null,
    territoryLevel: [],
    supportedCurrency: 'INR',
    supportedTimeZone: 'IST'
  };
  public terrtioryDefaultName = '';
  public showLevelList = false;
  public listInputData;
  public urlArray = [];
  public editMode = false;
  public partyList = [];
  public activeTabIndex = 0;

  constructor(
    private helperService: HelperService,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private partnerService: PartnerService,
    private router: Router,
    private territoryService: TerritoryService,
    private crossPlatformService: CrossPlatformService,
  ) {
    this.urlArray = decodeURI(this.router.url).split('/');
    this.territoryData.territoryName = this.route.snapshot.paramMap.get('id');
    console.log(this.urlArray);
    console.log(this.route.snapshot.url);
    if (this.route.snapshot.url[0].path === 'edit') {
      const dataForEdit = this.territoryService.getTerritoryData();
      this.territoryService.saveTerritoryData(undefined);
      console.log('Territory Data For Edit : ', this.territoryData);
      if (dataForEdit && dataForEdit.territoryId) {
        this.editMode = true;
        this.terrtioryDefaultName = JSON.parse(JSON.stringify(dataForEdit.territoryName));
        this.territoryData = dataForEdit;
        this.findAllParty();
        this.loading = false;
      } else {
        this.redirectToList();
      }
    } else {
      if (this.territoryService.getTerritoryData() && this.territoryService.getTerritoryData().add) {

        this.findAllParty();
        this.territoryData.orgId = this.crossPlatformService.getOrgId().user.orgId;
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          this.territoryService.retrieveAllCountries(token).subscribe((countryResult) => {
            console.log('---countryResult---', countryResult);
            if (countryResult.success) {
              countryResult.result.forEach((country) => {
                this.territoryData.territoryLevel.push({
                  levelName: country.countryName,
                  id: country.placeId,
                  levelType: 'country',
                  code: country.code,
                  levelCategory: 'STANDARD',
                  isExpandable: true,
                  isEditable: true,
                  isSelected: true,
                  accessFlag: true,
                  subTerritoryLevel: []
                });
              });
            }
            this.loading = false;
            console.log('add country', this.territoryData);
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      } else {
        this.redirectToList();
      }
    }
  }
  public findAllParty() {
    const accountId = this.crossPlatformService.getOrgId().user.accountId;
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.partnerService.findOrg([{ accountId, orgType: 'ROOT_ORG' }], token).subscribe((partyListRes) => {
        console.log('result for Party setup', partyListRes);
        if (partyListRes.success && partyListRes.result.length > 0) {
          this.partyList = partyListRes.result;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public editTerritoryName() {
    const dialogRef = this.dialog.open(DialogWithButtonsComponent, {
      width: '80%',
      maxWidth: '80%',
      disableClose: true,
      data: {
        config: { button: true, input: true },
        for: 'addTerritory',
        title: 'Edit Territory Name',
        input: { placeholder: 'Territory Name', label: this.territoryData.territoryName, defaultLabel: this.terrtioryDefaultName.trim().toLowerCase() },
        button: { text: 'PROCEED', for: 'newTerritory' }
      }
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
      if (result) { this.territoryData.territoryName = result; }
    });
  }

  public createTerritoryResponse(response) {
    console.log('response ::: ', response);
    this.showLevelList = true;
    this.activeTabIndex = 1;
    this.listInputData = response;
  }

  public levelListResponse(response, listType) {
    this.showLevelList = false;
    this.activeTabIndex = 0;
  }

  public redirectToList() {
    this.router.navigate(['/postLaunch/territory']);
  }

  public onSave() {
    console.log('Territory Data For Service FINAL', this.territoryData);
    if (this.editMode === false) {
      // delete this.territoryData.territoryId;
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.territoryService.createTerritory(token, this.territoryData).subscribe((result) => {
          console.log('Territory Create Res : ', result);
          if (result.success && result.result.territoryId) {
            this.territoryService.setPrimaryOrgTerritoryListLocal(undefined);
            this.helperService.openSnackBar(this.territoryData.territoryName + ' Territory Created', 'OK');
            this.updateOrgTerritoryMapping(result.result.territoryId, this.territoryData.territoryLevel);
          } else {
            this.helperService.openSnackBar(this.territoryData.territoryName + ' Territory Creation Failed', 'Try Again');
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    } else {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.territoryService.updateTerritory(token, this.territoryData).subscribe((result) => {
          console.log('result', result);
          if (result.success && result.result === true) {
            this.territoryService.setPrimaryOrgTerritoryListLocal(undefined);
            this.helperService.openSnackBar(this.territoryData.territoryName + ' Territory Updated', 'OK');
            this.updateOrgTerritoryMapping(this.territoryData.territoryId, this.territoryData.territoryLevel);
          } else {
            this.helperService.openSnackBar(this.territoryData.territoryName + ' Territory Update Failed', 'Try Again');
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public updateOrgTerritoryMapping(territoryId, territoryData) {
    console.log('Territory Mapping Data :', territoryId, territoryData);
    let terObj = { id: territoryId, territoryTree: [] };
    console.log(territoryData);
    territoryData.forEach((root) => {
      this.createLeafNode(root, terObj, root.id, root.levelType);
    });
    console.log(terObj);
    if (this.partyList && this.partyList.length > 0) {
      const rootParty = this.partyList.find((p) => p.orgType === 'ROOT_ORG');
      console.log('ROOT PARTY : ', rootParty);
      if (rootParty) {
        if (!rootParty.territories) { rootParty.territories = []; }
        const index = rootParty.territories.findIndex((ter) => ter.id === territoryId);
        if (index > -1) {
          rootParty.territories[index] = terObj;
        } else {
          rootParty.territories.push(terObj);
        }
      }
      console.log(rootParty);
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.partnerService.updateOrg(rootParty, token).subscribe((partyUpdateRes) => {
          console.log(partyUpdateRes);
          if (partyUpdateRes.success) {
            this.helperService.openSnackBar('Territory Mapped to Party', 'OK');
          } else {
            this.helperService.openSnackBar('Territory Mapping Failed', 'OK');
          }
          this.redirectToList();
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public createLeafNode(node, terObj, selectedNodeId, selectedNodeLevelType) {
    if (node.subTerritoryLevel.length > 0) {
      node.subTerritoryLevel.forEach((n) => {
        this.createLeafNode(n, terObj, selectedNodeId, selectedNodeLevelType);
      });
    } else {
      let obj = {
        nodeId: node.id,
        nodeLevelType: node.levelType,
        selectedNodeId,
        selectedNodeLevelType
      };
      const index = terObj.territoryTree.findIndex((ter) => ter.nodeId === obj.nodeId);
      if (index !== -1) {
        terObj.territoryTree[index] = obj;
      } else {
        terObj.territoryTree.push(obj);
      }
    }
  }

}
