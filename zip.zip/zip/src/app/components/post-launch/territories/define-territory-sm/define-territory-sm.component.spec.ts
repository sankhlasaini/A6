import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefineTerritoryComponent } from './define-territory.component';

describe('DefineTerritoryComponent', () => {
  let component: DefineTerritoryComponent;
  let fixture: ComponentFixture<DefineTerritoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefineTerritoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefineTerritoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
