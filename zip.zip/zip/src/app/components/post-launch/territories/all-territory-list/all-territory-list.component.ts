import { Router } from '@angular/router';
import { slideUp, slideDown } from './../../../../animations';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { Component, OnInit } from '@angular/core';
import { TerritoryService } from './../../../../services/postLaunch/territory.service';
import { InfiniteScroll } from './../../../../angular2-infinitescroll';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-all-territory-list',
  templateUrl: './all-territory-list.component.html',
  styleUrls: ['./all-territory-list.component.css'],
  animations: [slideUp, slideDown]
})
export class AllTerritoryListComponent implements OnInit {

  public orgId;
  public listData = [];
  public territoryList = [];
  public totalTerritoryCount;
  public territoryPageSize = 100;
  public loadMore = true;
  public listCardConfig;

  constructor(
    private territoryService: TerritoryService,
    private crossPlatformService: CrossPlatformService,
    private router: Router,
    private dialog: MatDialog
  ) {
    this.orgId = this.crossPlatformService.getOrgId().orgId;
  }

  public ngOnInit() {
    this.listCardConfig = {
      image: false,
      menu: false,
      footer: false,
      multiSelect: false,
      from: 'territory'
    };
    this.getTerritoryList(0);
  }

  public getTerritoryList(pageStartIndex) {
    console.log('hit : ' + pageStartIndex);
    if (this.loadMore) {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.territoryService.retrieveTerritoriesByOrgId(token, this.orgId, pageStartIndex, this.territoryPageSize).subscribe((result) => {
          console.log('result', result);
          if (result.success && result.result && result.result.territoryList) {
            this.territoryList = this.territoryList.concat(result.result.territoryList);
            result.result.territoryList.forEach((territory) => {
              let levelAllowedGrp = [];
              this.checkLevelTree(territory.territoryLevel, -1, levelAllowedGrp);
              this.listData.push({
                title: territory.territoryName,
                subTitle: [levelAllowedGrp.length + ' Levels'],
                subTitle1: [],
              });
            });
            this.totalTerritoryCount = result.result.count.count;
            if (this.listData.length >= this.totalTerritoryCount) {
              this.loadMore = false;
            }
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public checkLevelTree(lvl, count, levelAllowedGrp) {
    count++;
    levelAllowedGrp[count] = lvl[0].levelType;
    lvl.forEach((ele, i) => {
      if (ele.subTerritoryLevel.length > 0) {
        this.checkLevelTree(ele.subTerritoryLevel, count, levelAllowedGrp);
      }
    });
  }

  public responseFromList(response) {
    if (response.eventFrom === 'menu') {
      console.log('menu');
    }
    if (response.eventFrom === 'card') {
      this.territoryList.forEach((territory) => {
        if (territory.territoryName === response.eventData.title) {
          this.openViewTerritoryDialog(territory);
        }
      });
    }
    console.log('outputResponse', response);
  }

  public openViewTerritoryDialog(ter) {
    // const dialogRef = this.dialog.open(ViewTerritoryComponent, {
    //   height: '100%',
    //   width: '100%',
    //   autoFocus: false,
    //   maxWidth: '100%',
    //   data: { territory }
    // });
    // dialogRef.afterClosed().subscribe((result) => {
    //   if (result) {
    //     this.listData = [];
    //     this.loadMore = true;
    //     this.getTerritoryList(0);
    //   }
    // });
    console.log('OPEN Territory ::: ', ter);
    this.territoryService.saveTerritoryData(ter);
    this.router.navigate(['/postLaunch/territory/edit', ter.territoryName]);
  }

  // public editTerritory(ter) {
  //   console.log('Edit Territory ::: ', ter);
  //   this.territoryService.saveTerritoryData(ter);
  //   this.router.navigate([decodeURI(this.router.url) + '/edit', ter.territoryName]);
  // }
}
