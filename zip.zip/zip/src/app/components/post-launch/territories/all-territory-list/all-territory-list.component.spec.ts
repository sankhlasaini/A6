// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AllTerritoryListComponent } from './all-territory-list.component';

// describe('AllTerritoryListComponent', () => {
//   let component: AllTerritoryListComponent;
//   let fixture: ComponentFixture<AllTerritoryListComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AllTerritoryListComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AllTerritoryListComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
