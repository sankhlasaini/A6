import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandardLevelListComponent } from './standard-level-list.component';

describe('StandardLevelListComponent', () => {
  let component: StandardLevelListComponent;
  let fixture: ComponentFixture<StandardLevelListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandardLevelListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandardLevelListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
