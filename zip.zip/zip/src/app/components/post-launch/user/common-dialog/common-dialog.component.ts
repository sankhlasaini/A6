import { EcoSystemService } from './../../../../services/eco-system.service';
import { Router } from '@angular/router';
import { UserSetupService } from './../../../../services/postLaunch/user-setup.service';
import { Component, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HelperService } from '../../../../services/helper.service';
import { CrossPlatformService } from '../../../../services/postLaunch/cross-platform.service';
import { RoleService } from '../../../../services/role.service';
@Component({
  selector: 'app-common-dialog',
  templateUrl: './common-dialog.component.html',
  styleUrls: ['./common-dialog.component.css']
})
export class CommonDialogComponent {
  public roleList = [];
  public keyActions = [];
  public selectedRoles = [];
  public selectedRolesArray = [];
  public preSelectedRoles = [];
  public roleActionData;

  constructor(
    public dialogRef: MatDialogRef<CommonDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialog: MatDialog,
    public helperService: HelperService,
    private crossPlatformService: CrossPlatformService,
    private userSetupService: UserSetupService,
    private ecoSystemService: EcoSystemService,
    private router: Router,
    private roleService: RoleService,
  ) {
    console.log('data in commonDialogList +++++++++', this.data.data);
    this.getRoleList();
    if (this.data.data.currentUserList.length === 1) {
      this.preSelectedRoles = this.data.data.currentUserList[0].roles;
      this.selectedRoles = this.preSelectedRoles.map((rl) => rl.roleId);
      console.log(this.selectedRoles);
    }
  }

  public getRoleList() {
    if (this.crossPlatformService.getEcoSystemProfile()) {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.roleService.getRoleByProfileId(this.crossPlatformService.getEcoSystemProfile().id, this.crossPlatformService.getOrgId().user.orgId, token).subscribe((roleResult) => {
          console.log('roles :', roleResult);
          if (roleResult.success) {
            this.roleList = roleResult.result.filter((rl) => rl.actionsList.length > 0);
            this.selectRoles();
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public selectRoles() {
    if (this.selectedRoles) {
      this.selectedRoles.forEach((rlId) => {
        if (!this.selectedRolesArray.find((rl) => rl.roleId === rlId)) {
          let temp = this.roleList.find((rl) => rl.id === rlId);
          if (temp) {
            let selectedActions = [];
            let role = JSON.parse(JSON.stringify(temp));
            console.log(role)
            if (this.preSelectedRoles.length > 0) {
              let existingRole = this.preSelectedRoles.find((r) => r.roleId === role.id);
              if (existingRole) {
                selectedActions = existingRole.enabledActions;
              }
            }
            this.selectedRolesArray.push({
              roleId: role.id,
              roleLabel: role.name,
              version: role.version,
              enabledActions: role.actionsList.map((act) => {
                if (selectedActions.length > 0) {
                  act.active = selectedActions.find((a) => a.actionId === act.actionId) ? true : false;
                } else {
                  act.active = true;
                }
                return act;
              })
            });
          }
        }
      });
      this.selectedRolesArray.forEach((rl, i) => {
        if (!this.selectedRoles.find((rlId) => rlId === rl.roleId)) {
          this.selectedRolesArray.splice(i, 1);
        }
      });
    }
    console.log(this.selectedRoles);
    console.log(this.selectedRolesArray);
    console.log('updating');
    this.roleActionData = { roles: this.selectedRolesArray, keyActions: [] };
  }




  public outputEvent(event, from) {

    if (event.event === 'save') {
      let filteredModulesList = event.data;
      this.keyActions = [];
      filteredModulesList.forEach((module) => {
        module.functionList.forEach((func) => {
          func.actionList.forEach((action) => {
            let orphan = true;
            this.selectedRolesArray.forEach((parentRole) => {
              let parAction = parentRole.enabledActions.find((act) => act.actionId === action.actionId);
              if (parAction) {
                orphan = false;
                parAction.active = action.isSelected;
              }
            });
            if (orphan && action.isSelected) {
              this.keyActions.push(action);
              console.log(action);
            }
          });
        });
      });

      const updatedUsersList = [];
      this.data.data.currentUserList.forEach((user) => {
        console.log(this.selectedRolesArray);
        console.log(this.keyActions);
        let addEnableRoles = [];
        this.selectedRolesArray.forEach((role) => {
          let actions = [];
          role.enabledActions.forEach((act) => {
            if (act.active) {
              actions.push(this.updateActionForUser(JSON.parse(JSON.stringify(act))));
            }
          });
          if (actions.length > 0) {
            let finalRole = JSON.parse(JSON.stringify(role));
            finalRole.enabledActions = actions;
            addEnableRoles.push(finalRole);
          }
        });
        console.log(addEnableRoles);
        updatedUsersList.push({
          partyId: user.partyId,
          addEnableRoles,
          keyActions: this.keyActions.map((act) => { return this.updateActionForUser(act); }),
          removeRoles: this.removeRoles(user.roles, addEnableRoles)
        });
      });
      console.log('FINAL DATA :: ', updatedUsersList);

      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.userSetupService.updateUser(token, updatedUsersList).subscribe((res) => {
          console.log('response for update User', res);
          if (res.success) {
            if (res.result) {
              this.helperService.openSnackBar('User Updated Successfully', 'OK');
              this.dialogRef.close('OK');
              this.userSetupService.setUsersListLocal(undefined);
              this.router.navigate(['/postLaunch/user/reload']);
            }
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    } else {
      this.close();
    }
  }


  public close() {
    this.dialogRef.close();
  }



  public updateActionForUser(action) {
    const masterList = this.ecoSystemService.getGlobalActionList();
    const masterAction = masterList.find((act) => act.actionId === action.actionId);
    if (masterAction) {
      let userAction = {
        actionId: masterAction.actionId,
        actionLabel: masterAction.actionLabel,
        actionVersion: masterAction.actionVersion.toString(),
        mappedEndpointCanUris: masterAction.linkedApiIds.map((api) => api.endpointCannonicalUniqueUri)
      };
      return userAction;
    } else {
      return undefined;
    }
  }

  public removeRoles(oldList, newList) {
    let removedList = [];
    oldList.forEach((role) => {
      if (!newList.find((rl) => rl.roleId === role.roleId)) {
        removedList.push(role.roleId);
      }
    });
    return removedList;
  }

}
