import { MatDialog } from '@angular/material';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { RoleService } from './../../../../services/role.service';
import { HelperService } from './../../../../services/helper.service';
import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { slideUpEnter } from '../../../../animations';
import { DialogWithButtonsComponent } from '../../common/dialog-with-buttons/dialog-with-buttons.component';

@Component({
  selector: 'app-role-action',
  templateUrl: './role-action.component.html',
  styleUrls: ['./role-action.component.css'],
  animations: [slideUpEnter]
})
export class RoleActionComponent implements OnChanges {

  @Input() public inputData;
  @Output() public outputData = new EventEmitter();

  public parentData;
  public activeTab = true;
  public selectedRoles = [];
  public loading = true;
  public checkSelected = true;
  public selectedCheckBoxCount = 0;
  public iconShowFlag = false;
  public ecosystemProfile;
  public filteredModulesList = [];
  constructor(
    private dialog: MatDialog,
    public helperService: HelperService,
    private roleService: RoleService,
    private crossPlatformService: CrossPlatformService,
  ) {
  }

  public ngOnChanges() {
    console.log('---InputData---', this.inputData);
    this.parentData = JSON.parse(JSON.stringify(this.inputData));
    const currentEcoProfile = this.crossPlatformService.getEcoSystemProfile();
    console.log('', currentEcoProfile);
    if (currentEcoProfile) {
      this.ecosystemProfile = JSON.parse(JSON.stringify(currentEcoProfile));

      const role = { actionsList: [] };
      this.parentData.roles.forEach((rl) => {
        rl.enabledActions.forEach((act) => {
          if (!role.actionsList.find((action) => action.actionId === act.actionId) && act.active) {
            role.actionsList.push(act);
          }
        });
      });
      this.parentData.keyActions.forEach((act) => {
        role.actionsList.push(act);
      });
      this.filteredModulesList = this.roleService.getFilteredActionByRoleAndProfile(this.ecosystemProfile, role);
      console.log(this.filteredModulesList);
      setTimeout(() => { this.loading = false; }, 0);
    }
  }

  public tabChange() {
    this.activeTab = false;
    setTimeout(() => { this.activeTab = true; }, 0);
  }

  public getSelectedCount(func) {
    let count = 0;
    func.actionList.forEach((action) => {
      if (action.isSelected) {
        count++;
      }
    });
    return count;
  }

  public close() {
    this.outputData.emit({ event: 'cancel', data: null });
  }

  public onSave() {
    console.log(this.filteredModulesList);
    console.log(this.parentData);
    const previewData = [];
    this.filteredModulesList.forEach((mod) => {
      let previewOptions = [];
      mod.functionList.forEach((permissionData) => {
        permissionData.actionList.forEach((option) => {
          if (option.isSelected === true) {
            previewOptions.push(option);
          }
        });
      });
      if (previewOptions.length > 0) {
        previewData.push({ title: mod.moduleLabel, previewOptions: previewOptions.map((ac) => ac.actionLabel) });
      }
    });

    const buttonDialog = this.dialog.open(DialogWithButtonsComponent, {
      width: '80%',
      height: '70%',
      maxWidth: '80%',
      data: {
        config: { button: true, input: false, cancelButton: true, markUp: true },
        for: 'Roles',
        title: 'User Actions',
        button: { text: 'OK', for: 'confirm' },
        markUpData: previewData
      }
    });
    buttonDialog.afterClosed().subscribe((done) => {
      if (done !== undefined && done === 'OK') {
        console.log('done', done);
        this.outputData.emit({ event: 'save', data: this.filteredModulesList });
      }
    });

  }

}
