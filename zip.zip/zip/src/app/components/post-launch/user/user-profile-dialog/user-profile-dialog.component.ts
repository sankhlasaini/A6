import { AssetService } from './../../../../services/postLaunch/asset.service';
import { UserSetupService } from './../../../../services/postLaunch/user-setup.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Router } from '@angular/router';
import { Component, OnInit, Inject } from '@angular/core';
import { ViewListDialogComponent } from '../../common/view-list-dialog/view-list-dialog.component';
import { TerritoryService } from '../../../../services/postLaunch/territory.service';
import { ProfileSetupService } from '../../../../services/postLaunch/profile-setup.service';
import { slideUpEnter } from '../../../../animations';

@Component({
  selector: 'app-user-profile-dialog',
  templateUrl: './user-profile-dialog.component.html',
  styleUrls: ['./user-profile-dialog.component.css'],
  animations: [slideUpEnter]
})
export class UserProfileDialogComponent {

  public user;
  public orgId;
  public hideEdit = false;
  public meFlag;
  public avatar = '../../../../../assets/images/user-default.png';
  public managerAvatar = '../../../../../assets/images/user-default.png';

  constructor(
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<UserProfileDialogComponent>,
    private dialog: MatDialog,
    private assetService: AssetService,
    private crossPlatformService: CrossPlatformService,
    private userSetupService: UserSetupService,
    private territoryService: TerritoryService,
    private profileSetupService: ProfileSetupService
  ) {
    this.dialogRef.afterOpen().subscribe(() => {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        if (data.user.userProfile.avatar && data.user.userProfile.avatar.gridFSid) {
          this.avatar = this.profileSetupService.getDownloadFileUrl([data.user.userProfile.avatar.gridFSid], token)[0];
        }
        if (data.user.supervisorId) {
          const usersListLocal = this.userSetupService.getUsersListLocal();
          const manager = usersListLocal.find((user) => user.partyId === data.user.supervisorId);
          if (manager && manager.userProfile.avatar && manager.userProfile.avatar.gridFSid) {
            this.managerAvatar = this.profileSetupService.getDownloadFileUrl([manager.userProfile.avatar.gridFSid], token)[0];
          }
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
      console.log('data in dialog', data);
      this.meFlag = this.crossPlatformService.getOrgId().user_details['userTenancyIdentityId'] === data.user.partyId ? true : false;
      if (data.user.isDefaultUser && !this.meFlag) { this.hideEdit = true; }
      this.user = {
        name: data.user.name,
        role: data.user.roles.map((role) => role.roleLabel),
        email: data.user.email,
        mobile: data.user.mobile,
        supervisor: {
          name: data.user.supervisorName ? data.user.supervisorName : 'NA',
          role: data.user.supervisorRoleLabels,
        },
        keyAction: data.user.actionList.map((act) => { return { line1: act }; }),
        reportees: data.user.reportee,
        beat: [],
        serviceLine: [],
        territories: []
      };
      this.setGlobalDapFilter(data.user.globalDapFilterRules);
      this.getBeat(data.user);
    });

  }

  public setGlobalDapFilter(filterData) {
    let terList = [];
    let serLineList = [];
    if (filterData) {
      const ter = filterData.find((ele) => ele.filterKey === 'territory');
      const serLine = filterData.find((ele) => ele.filterKey === 'serviceLine');
      if (serLine) {
        serLineList = JSON.parse(serLine.filterValue);
        console.log('ser lines', serLineList);
        if (serLineList) {
          const serLinesAll = this.assetService.getServiceLinesLocal();
          serLineList.forEach((ser) => {
            const serName = serLinesAll.categories.find((s) => s.id === ser);
            if (serName) {
              this.user.serviceLine.push({ line1: serName.name });
            }
          });
        }
      }
      if (ter) {
        terList = JSON.parse(ter.filterValue).map((territory) => territory.id);
        console.log(terList);
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          this.territoryService.getTerritoriesNameByIds(terList, token).subscribe((idsRes) => {
            console.log(idsRes);
            if (idsRes.success) {
              this.user.territories = idsRes.result.map((t) => { return { line1: t.name }; });
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    }
    console.log(filterData);
  }

  public getBeat(user) {
    this.crossPlatformService.checkPartyAccessToken().subscribe((at) => {
      this.userSetupService.getBeatList(at, user.partyId).subscribe((res) => {
        console.log('res for BeatList', res);
        if (res.success) {
          let today = [];
          let upcoming = [];
          if (res.result.messageCode === 'SUCCESS_REQUESTED_DATA_EXIST') {
            today = res.result.todayBeats.map((beatList) => {
              return { line1: beatList.beatInstId, line2: 'Today'};
            });
            upcoming = res.result.upcomingBeats.map((beatList) => {
              return { line1: beatList.beatInstId , line2: new Date(beatList.beatDate).toDateString() };
            });
          }
          this.user.beat = today.concat(upcoming);
        } else {
          this.user.beat = [];
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public editProfile() {
    this.dialogRef.close();
    this.router.navigate(['/postLaunch/user/edit', this.data.user.mobile]);
  }

  public openListDialog(param) {
    if (param.data.length > 0) {
      const dialogRef = this.dialog.open(ViewListDialogComponent, {
        height: '60%',
        width: '80%',
        data: { data: param.data, type: param.type, title: param.title, selectable: false }
      });
    }
  }

  public listDialog(type, data) {
    console.log('type', type, data);
    switch (type) {
      case 'keyAction':
        if (data && data.length > 0) {
          let param = { data, title: 'Key Actions', type: 'partnerInfo' };
          this.openListDialog(param);
        }
        break;

      case 'reportees':
        if (data && data.length > 0) {
          let param = {
            data: data.map((r) => { return { line1: r.name, line2: r.roles.map((rl) => rl.roleLabel) }; }),
            title: 'Reportees', type: 'partnerInfo'
          };
          this.openListDialog(param);
        }
        break;
      case 'territories':
        if (data && data.length > 0) {
          let param = { data, title: 'Territories', type: 'partnerInfo' };
          this.openListDialog(param);
        }
        break;

      case 'serviceLine':
        if (data && data.length > 0) {
          let param = { data, title: 'Service Lines', type: 'partnerInfo' };
          this.openListDialog(param);
        }
        break;

      case 'beat':
        {
          if (data && data.length > 0) {
            let param = { data, title: 'Beats', type: 'partnerInfo' };
            this.openListDialog(param);
          }
          break;
        }
      default:
        break;
    }

  }

}
