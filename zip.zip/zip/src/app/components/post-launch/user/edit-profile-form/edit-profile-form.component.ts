import { slideUpEnter } from './../../../../animations';
import { TerritorySelectionDialogComponent } from './../../territory-selection-dialog/territory-selection-dialog.component';
import { Router, ActivatedRoute } from '@angular/router';
import { UserSetupService } from './../../../../services/postLaunch/user-setup.service';
import { TerritoryService } from './../../../../services/postLaunch/territory.service';
import { AssetService } from './../../../../services/postLaunch/asset.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { EcoSystemService } from './../../../../services/eco-system.service';
import { MatDialog } from '@angular/material';
import { HelperService } from './../../../../services/helper.service';
import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { UserListDialogComponent } from '../../common/user-list-dialog/user-list-dialog.component';
import { ProfileSetupService } from '../../../../services/postLaunch/profile-setup.service';
import { OptionDialogComponent } from '../../common/option-dialog/option-dialog.component';
import { CropImageDialogComponent } from '../../common/crop-image-dialog/crop-image-dialog.component';
import { RoleService } from '../../../../services/role.service';
import { ImageResize } from '../../../../services/postLaunch/image-resize.service';

@Component({
  selector: 'app-edit-profile-form',
  templateUrl: './edit-profile-form.component.html',
  styleUrls: ['./edit-profile-form.component.css'],
  animations: [slideUpEnter]
})
export class EditProfileFormComponent {

  public defaultAvatar = '../../../../../assets/images/user-default.png';
  public loading = true;
  public serviceLineIds = [];
  public activeTabIndex = 0;
  public secondSection = '';
  public secondSectionData;
  public userAvatar;
  public managerAvatar = '../../../../../assets/images/user-default.png';
  public selectedRoles = [];
  public myForm: FormGroup;
  public roleValues;
  public placeholders = {
    firstNameLabel: 'First Name',
    lastNameLabel: 'Last Name',
    mobileNOLabel: 'Mobile No.',
    emailIDLabel: 'Email ID',
    selectRolesLabel: 'Select Role',
    keyActionsLabel: 'Key Actions',
    selectManagerLabel: 'Select Manager',
    servicesLabel: 'Services Lines',
    territoriesLabel: 'Territories'
  };
  public dataForEdit;
  public globalTerritoryList = [];
  public territoryList = [];
  public territoryDataManager = [];
  public territoryPageSize = 10;
  public templateType = 'serviceCatagory';
  public serviceLineList = [];
  public serviceLineData = [];
  public selectedKeyActionList = [];
  public allGlobalActions = [];
  public selectedManager;
  public territorySelection = [];
  public serviceLineOfManager = [];
  public allUsersList = [];
  public roleList = [];

  public selectedRolesArray = [];
  public keyActions = [];

  constructor(
    @Inject(FormBuilder) public fb: FormBuilder,
    private helperService: HelperService,
    private ecoSystemService: EcoSystemService,
    private dialog: MatDialog,
    private crossPlatformService: CrossPlatformService,
    private assetService: AssetService,
    private profileSetupService: ProfileSetupService,
    private territoryService: TerritoryService,
    private userSetupService: UserSetupService,
    private router: Router,
    private imageResize: ImageResize,
    private route: ActivatedRoute,
    private roleService: RoleService,
  ) {
    console.log(this.router.url);
    const mobile = this.route.snapshot.paramMap.get('mobile');
    console.log('User : ', mobile);
    // EDIT MODE
    this.allUsersList = this.userSetupService.getUsersListLocal();
    this.dataForEdit = this.allUsersList.find((user) => user.mobile === mobile);
    if (!this.dataForEdit) {
      this.helperService.openSnackBar('User Not Found', 'OK');
    } else {
      this.setUserAvatar(this.dataForEdit.userProfile.avatar);
      this.keyActions = JSON.parse(JSON.stringify(this.dataForEdit.keyActions));
      this.myForm = this.fb.group({
        fname: [{ value: this.dataForEdit.name, disabled: true }],
        mobileNo: [{ value: this.dataForEdit.mobile, disabled: true }],
        emailID: [{ value: this.dataForEdit.email, disabled: true }],
        selectRoles: [this.dataForEdit.roles.map((role) => role.roleId)],
        keyActions: [this.dataForEdit.keyActions.map((act) => act.actionLabel)],
        manager: [''],
        serviceLines: [''],
        territory: ['', [Validators.required]]
      });
      this.getServiceLineList();
      this.getTerritoryList();
      this.setManagerAvatar();
      this.getRoleList();
      this.selectedManager = this.dataForEdit.supervisorId;
      if (this.dataForEdit && this.dataForEdit.globalDapFilterRules && this.dataForEdit.globalDapFilterRules.length > 0) {
        const terData = this.dataForEdit.globalDapFilterRules.find((gd) => gd.filterKey === 'territory');
        const serLineData = this.dataForEdit.globalDapFilterRules.find((gd) => gd.filterKey === 'serviceLine');
        if (terData) { this.territoryList = JSON.parse(terData.filterValue); }
        if (serLineData) {
          console.log('serviceLines : ', JSON.parse(serLineData.filterValue));
          this.myForm.patchValue({ serviceLines: JSON.parse(serLineData.filterValue) });
        }
      }
    }
  }

  public getRoleList() {
    if (this.crossPlatformService.getEcoSystemProfile()) {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.roleService.getRoleByProfileId(this.crossPlatformService.getEcoSystemProfile().id, this.crossPlatformService.getOrgId().user.orgId, token).subscribe((roleResult) => {
          console.log('roles :', roleResult);
          if (roleResult.success) {
            this.roleList = roleResult.result.filter((rl) => rl.actionsList.length > 0);
            this.selectRoles();
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public setManagerAvatar() {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      if (this.selectedManager) {
        const manager = this.allUsersList.find((user) => user.partyId === this.selectedManager);
        if (manager && manager.userProfile.avatar && manager.userProfile.avatar.gridFSid) {
          this.managerAvatar = this.profileSetupService.getDownloadFileUrl([manager.userProfile.avatar.gridFSid], token)[0];
        } else {
          this.managerAvatar = this.defaultAvatar;
        }
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public setUserAvatar(logo) {
    if (logo && logo.gridFSid) {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.userAvatar = this.profileSetupService.getDownloadFileUrl([logo.gridFSid], token);
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public openImageCropDialog(event) {
    console.log(event);
    let dialogRef;
    if (event) {
      if (event.type === 'image/jpeg' || event.type === 'image/jpg' || event.type === 'image/png') {
        dialogRef = this.dialog.open(CropImageDialogComponent, {
          maxWidth: '100%',
          width: '100%',
          height: '100%',
          data: event,
          disableClose: true
        });
        dialogRef.afterClosed().subscribe((result) => {
          if (result) {
            this.userAvatar = result.image;
            this.uploadLogo(result.cropedImageFileObj);
          }
        });
      } else {
        this.helperService.openSnackBar('Only .jpg, .jpeg, .png Allowed', 'Try Again');
      }
    }
  }

  public logoChange() {
    const dialogRef = this.dialog.open(OptionDialogComponent, {
      data: [{ option: 'Take New Logo', icon: 'camera_enhance' },
      { option: 'Remove Logo', icon: 'delete' }],
      disableClose: false
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result === 'delete') {
          this.dataForEdit.userProfile.avatar = { gridFSid: '', gridFsFileName: '' };
          this.userAvatar = undefined;
        } else {
          this.openImageCropDialog(result);
        }
      }
    });
  }

  public uploadLogo(logoFile) {
    this.loading = true;
    this.imageResize.imageReducerNew(logoFile).then((imgRes) => {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.profileSetupService.uploadFile([imgRes], token).subscribe((response) => {
          console.log('LOGO Upload res : ', response);
          this.loading = false;
          if (response) {
            this.dataForEdit.userProfile.avatar = { gridFSid: response.result[0].gridFSid, gridFsFileName: response.result[0].fileName };
            this.setUserAvatar(this.dataForEdit.userProfile.avatar);
          }
        }, (err) => {
          this.loading = false;
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    });
  }

  public getSerLineForManager(supervisorId) {
    let managerObj = this.allUsersList.find((u) => u.partyId === supervisorId);
    console.log('manager : ', managerObj);
    this.serviceLineOfManager = [];
    if (managerObj && managerObj.globalDapFilterRules && managerObj.globalDapFilterRules.length > 0) {
      const serLines = managerObj.globalDapFilterRules.find((gd) => gd.filterKey === 'serviceLine');
      if (serLines) {
        const ser = JSON.parse(serLines.filterValue);
        if (ser) { this.serviceLineOfManager = ser; }
      }
      console.log('this.serviceLineOfManager', this.serviceLineOfManager);
    } else {
      this.myForm.patchValue({ territory: '' });
    }
  }

  public getServiceLineList() {
    const serLinesLocal = this.assetService.getServiceLinesLocal();
    console.log(serLinesLocal);
    if (serLinesLocal) {
      serLinesLocal.categories == null ? serLinesLocal.categories = [] : serLinesLocal.categories = serLinesLocal.categories;
      this.serviceLineList = serLinesLocal.categories;
      console.log('serviceLineList', this.serviceLineList);
    } else {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.assetService.getGetCategoryByLevel(this.templateType, token).subscribe((res) => {
          console.log('GetCategoryByLevel : ', res);
          if (res.success) {
            this.assetService.setServiceLinesLocal(res.result);
            res.result.categories == null ? res.result.categories = [] : res.result.categories = res.result.categories;
            this.serviceLineList = res.result.categories;
            console.log('serviceLineList', this.serviceLineList);
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
    if (!this.dataForEdit.isDefaultUser) {
      this.getSerLineForManager(this.dataForEdit.supervisorId);
    }
  }

  public getTerritoryList() {
    const pageStartIndex = 0;
    console.log('this.crossPlatformService.getOrgId().orgId', this.crossPlatformService.getOrgId().orgId);
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.territoryService.retrieveTerritoriesByOrgId(token, this.crossPlatformService.getOrgId().orgId, pageStartIndex, this.territoryPageSize).subscribe((result) => {
        console.log('res is ', result);
        this.loading = false;
        if (result.success) {
          this.globalTerritoryList = result.result.territoryList;
          if (!this.dataForEdit.isDefaultUser) {
            this.getTerritoriesByManagerId(this.dataForEdit.supervisorId);
          } else {
            this.territorySelection = this.globalTerritoryList;
            this.createTerritoryData(this.territoryList);
          }
        }
        console.log('global Territory List', this.globalTerritoryList);
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getTerritoriesByManagerId(selectedManager) {
    let managerObj = this.allUsersList.find((u) => u.partyId === selectedManager);
    console.log('selected Manager response ', managerObj);
    if (managerObj) {
      this.territoryDataManager = [];
      const terData = managerObj.globalDapFilterRules.find((gd) => gd.filterKey === 'territory');

      if (terData) {
        const ter = JSON.parse(terData.filterValue);
        this.territoryDataManager = ter;
        console.log(ter);
      }
      console.log('Global Dap Filter Territroy ::', this.territoryDataManager);
      this.createTerritoryData(this.territoryList);
    }
  }

  public selectManagerEvent() {
    if (!this.dataForEdit.isDefaultUser) {
      let filteredUserList = this.allUsersList.filter((user) => user.partyId !== this.dataForEdit.partyId);
      console.log(filteredUserList);
      filteredUserList.forEach((user) => {
        if (this.dataForEdit.supervisorId === user.partyId) {
          user.isSelected = true;
        } else {
          user.isSelected = false;
        }
      });
      const dialogRef = this.dialog.open(UserListDialogComponent, {
        maxWidth: '100%',
        height: '100%',
        width: '100%',
        autoFocus: false,
        data: { users: JSON.parse(JSON.stringify(filteredUserList)), selectable: true, multi: false }
      });
      dialogRef.afterClosed().subscribe((result) => {
        console.log('data from dialog', result);
        if (result) {
          let manager = result.find((u) => u.isSelected);
          console.log(manager);
          let updateList = [];
          console.log('userList data in invite user', event);
          this.selectedManager = manager.initialData.partyId;
          this.setManagerAvatar();
          this.dataForEdit.supervisorName = manager.initialData.name;
          this.dataForEdit.supervisorRoleLabels = manager.initialData.roles.map((role) => role.roleLabel);
          this.getTerritoriesByManagerId(this.selectedManager);
          this.getSerLineForManager(this.selectedManager);
          this.myForm.patchValue({ territory: '' });
          this.myForm.patchValue({ serviceLines: '' });
          this.territoryList = [];
        }
      });
    }
  }

  public selectTerritory() {
    let globalTerritoryList;
    if (!this.dataForEdit.isDefaultUser) {
      this.getTerritoriesByManagerId(this.selectedManager);
      globalTerritoryList = this.territoryService.mappingToDefination(this.globalTerritoryList, this.territoryDataManager);
    } else {
      globalTerritoryList = this.globalTerritoryList;
    }
    const dialogRef = this.dialog.open(TerritorySelectionDialogComponent, {
      maxWidth: '100%',
      width: '100%',
      height: '100%',
      data: { invokeFrom: 'service', globalTerritoryList, existingTerritoryList: this.territoryList },
    });
    dialogRef.afterClosed().subscribe((territoryResult) => {
      if (territoryResult) {
        this.createTerritoryData(territoryResult.mapping);
      }
    });
  }

  public createTerritoryData(selectedTerritory) {
    console.log('selectedTerritory', selectedTerritory);
    console.log(this.globalTerritoryList);
    if (selectedTerritory && selectedTerritory.length > 0) {
      let showTerritoryList = [];
      this.territoryList = selectedTerritory;
      let tempterritoryArray = JSON.parse(JSON.stringify(this.territoryList));
      this.territoryList.forEach((territory, i) => {
        const temp = this.globalTerritoryList.find((ter) => ter.territoryId === territory.id);
        if (temp) { showTerritoryList.push(temp.territoryName + ' (' + territory.territoryTree.length + ')'); }
      });
      this.myForm.patchValue({ territory: showTerritoryList });
      if (this.myForm.value.territory) {
        this.serviceLineIds = [];
        this.serviceLineData = [];
        const serviceData = this.userSetupService.getAllServiceData();
        console.log('serviceData in userForm', serviceData);
        console.log('territoryList in userForm', this.territoryList);
        this.territoryList.forEach((terr) => {
          terr.territoryTree.forEach((territoryTree) => {
            serviceData.service.forEach((service) => {
              service.prices.forEach((price) => {
                if (!price.territories) { price.territories = []; }
                price.territories.forEach((territory) => {
                  territory.territoryTree.map((tTree) => {
                    if (tTree.nodeId === territoryTree.nodeId) {
                      const index = this.serviceLineIds.indexOf(service.referenceIds.categoryCode);
                      if (index === -1) {
                        this.serviceLineIds.push(service.referenceIds.categoryCode);
                      }
                    }
                  });
                });
              });
            });
          });
        });
        console.log('this.serviceLineIds', this.serviceLineIds);
        let serLineIds = [];
        if (!this.dataForEdit.isDefaultUser) {
          serLineIds = this.serviceLineIds.filter((serviceLineId) => this.serviceLineOfManager.find((serLine) => serLine === serviceLineId));
        } else {
          serLineIds = this.serviceLineIds;
        }
        // this.serviceLineData = serLineIds.map((sl) => this.serviceLineList.find((serviceLine) => serviceLine.id === sl));
        this.serviceLineData = this.serviceLineList.filter((serviceLine) => serLineIds.find((s1) => s1 === serviceLine.id));
        console.log('this.serviceLineList', this.serviceLineList);
        console.log('this.serviceLineData', this.serviceLineData);
      }
    } else {
      this.myForm.patchValue({ territory: '' });
      this.myForm.patchValue({ serviceLines: '' });
      this.territoryList = [];
    }
  }

  public serviceLines() {
    if (this.serviceLineData.length === 0) {
      this.helperService.openSnackBar('No service associated with Territory', 'Try Another');
    }
  }

  public selectKeyActions() {
    console.log(this.selectedRolesArray);
    console.log(this.keyActions);
    this.secondSection = 'roleAction';
    this.secondSectionData = { roles: this.selectedRolesArray, keyActions: this.keyActions };
    this.activeTabIndex = 1;
  }

  public tabChange(event, from) {
    this.secondSectionData = {};
    this.secondSection = '';
    this.activeTabIndex = 0;
    switch (from) {
      case 'roleAction':
        if (event.event === 'save') {
          this.updateRoleAndActions(event.data);
        }
        break;

      default:
        break;
    }
  }

  public updateRoleAndActions(filteredModulesList) {
    this.keyActions = [];
    filteredModulesList.forEach((module) => {
      module.functionList.forEach((func) => {
        func.actionList.forEach((action) => {
          let orphan = true;
          this.selectedRolesArray.forEach((parentRole) => {
            let parAction = parentRole.enabledActions.find((act) => act.actionId === action.actionId);
            if (parAction) {
              orphan = false;
              parAction.active = action.isSelected;
            }
          });
          if (orphan && action.isSelected) {
            this.keyActions.push(action);
            console.log(action);
          }
        });
      });
    });
    this.myForm.patchValue({ keyActions: this.keyActions.map((act) => act.actionLabel) });
  }

  public selectRoles() {
    if (this.myForm.value.selectRoles) {
      this.myForm.value.selectRoles.forEach((rlId) => {
        if (!this.selectedRolesArray.find((rl) => rl.roleId === rlId)) {
          let temp = this.roleList.find((rl) => rl.id === rlId);
          if (temp) {
            let selectedActions = [];
            let role = JSON.parse(JSON.stringify(temp));
            if (this.dataForEdit.roles) {
              let existingRole = this.dataForEdit.roles.find((r) => r.roleId === role.id);
              if (existingRole) {
                selectedActions = existingRole.enabledActions;
              }
            }
            this.selectedRolesArray.push({
              roleId: role.id,
              roleLabel: role.name,
              version: role.version,
              enabledActions: role.actionsList.map((act) => {
                if (selectedActions.length > 0) {
                  act.active = selectedActions.find((a) => a.actionId === act.actionId) ? true : false;
                } else {
                  act.active = true;
                }
                return act;
              })
            });
          }
        }
      });
      this.selectedRolesArray.forEach((rl, i) => {
        if (!this.myForm.value.selectRoles.find((rlId) => rlId === rl.roleId)) {
          this.selectedRolesArray.splice(i, 1);
        }
      });
    }
    console.log(this.myForm.value.selectRoles);
    console.log(this.selectedRolesArray);
    console.log('updating');
    const currentEcoProfile = this.crossPlatformService.getEcoSystemProfile();
    const role = { actionsList: [] };
    this.selectedRolesArray.forEach((rl) => {
      rl.enabledActions.forEach((act) => {
        if (!role.actionsList.find((action) => action.actionId === act.actionId) && act.active) {
          role.actionsList.push(act);
        }
      });
    });
    this.keyActions.forEach((act) => {
      role.actionsList.push(act);
    });
    let filteredModulesList = this.roleService.getFilteredActionByRoleAndProfile(currentEcoProfile, role);
    this.updateRoleAndActions(filteredModulesList);

  }

  public updateActionForUser(action) {
    const masterList = this.ecoSystemService.getGlobalActionList();
    const masterAction = masterList.find((act) => act.actionId === action.actionId);
    if (masterAction) {
      let userAction = {
        actionId: masterAction.actionId,
        actionLabel: masterAction.actionLabel,
        actionVersion: masterAction.actionVersion.toString(),
        mappedEndpointCanUris: masterAction.linkedApiIds.map((api) => api.endpointCannonicalUniqueUri)
      };
      return userAction;
    } else {
      return undefined;
    }
  }

  public removeRoles(oldList, newList) {
    let removedList = [];
    oldList.forEach((role) => {
      if (!newList.find((rl) => rl.roleId === role.roleId)) {
        removedList.push(role.roleId);
      }
    });
    return removedList;
  }

  public onSave() {
    console.log(this.myForm.value);
    if (this.myForm.valid) {
      console.log(this.dataForEdit.roles);
      console.log(this.selectedRolesArray);
      console.log(this.keyActions);
      let addEnableRoles = [];
      this.selectedRolesArray.forEach((role) => {
        let actions = [];
        role.enabledActions.forEach((act) => {
          if (act.active) {
            actions.push(this.updateActionForUser(JSON.parse(JSON.stringify(act))));
          }
        });
        if (actions.length > 0) {
          let finalRole = JSON.parse(JSON.stringify(role));
          finalRole.enabledActions = actions;
          addEnableRoles.push(finalRole);
        }
      });
      console.log(addEnableRoles);

      const userDataForUpdate = {
        userProfile: this.dataForEdit.userProfile,
        partyId: this.dataForEdit.partyId,
        // name: this.dataForEdit.name,
        addEnableRoles,
        removeRoles: this.removeRoles(this.dataForEdit.roles, addEnableRoles),
        keyActions: this.keyActions.map((act) => { return this.updateActionForUser(act); }),
        supervisorId: this.selectedManager,
        globalDapFilterRules: [
          { filterKey: 'serviceLine', filterValue: JSON.stringify(this.myForm.value.serviceLines), filterOperator: 'EQUAL' },
          { filterKey: 'territory', filterValue: JSON.stringify(this.territoryList), filterOperator: 'EQUAL' }
        ]
      };
      console.log('Final Data', this.dataForEdit);
      console.log('userDataForUpdate', userDataForUpdate);
      if (userDataForUpdate.addEnableRoles.length === 0 && userDataForUpdate.keyActions.length === 0) {
        this.helperService.openSnackBar('Please Select a Role OR Action', 'OK');
      } else {
        this.helperService.openSnackBar('Updating User', 'Please Wait');
        this.loading = true;
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          console.log('token is ', token);
          this.userSetupService.updateUser(token, [userDataForUpdate]).subscribe((res) => {
            console.log('response for update User', res);
            this.loading = false;
            if (res.success && res.result) {
              console.log(this.crossPlatformService.currentUserParty.expires_in);
              if (this.dataForEdit.isDefaultUser) {
                this.crossPlatformService.currentUserParty.expires_in = 0;
              }
              console.log(this.crossPlatformService.currentUserParty.expires_in);
              this.userSetupService.setUsersListLocal(undefined);
              this.helperService.openSnackBar('User Updated Successfully', 'OK');
              this.router.navigate(['/postLaunch/user']);
            }
          }, (err) => {
            this.loading = false;
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    } else {
      this.helperService.openSnackBar('Please Fill all Required Details', 'OK');
    }
  }

}
