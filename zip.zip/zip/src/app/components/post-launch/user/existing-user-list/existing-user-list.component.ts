import { slideUp } from './../../../../animations';
import { ListDialogComponent } from './../../common/list-dialog/list-dialog.component';
import { DialogWithButtonsComponent } from './../../common/dialog-with-buttons/dialog-with-buttons.component';
import { UserSetupService } from './../../../../services/postLaunch/user-setup.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { UserProfileDialogComponent } from '../user-profile-dialog/user-profile-dialog.component';
import { CommonDialogComponent } from '../common-dialog/common-dialog.component';
import { ViewListDialogComponent } from '../../common/view-list-dialog/view-list-dialog.component';
import { UserListDialogComponent } from '../../common/user-list-dialog/user-list-dialog.component';
import { HelperService } from '../../../../services/helper.service';

@Component({
  selector: 'app-existing-user-list',
  templateUrl: './existing-user-list.component.html',
  styleUrls: ['./existing-user-list.component.css'],
  animations: [slideUp]

})
export class ExistingUserListComponent {
  public listCardConfig = {
    image: true,
    menu: true,
    footer: true,
    multiSelect: false
  };
  public listData = [];
  public selectAll = false;
  public extraDiv = false;
  public selectedListData = [];
  public selectedCount = 0;
  public indeterminateFlag = false;
  public loading = false;
  public meFlag = false;
  constructor(
    private router: Router,
    private dialog: MatDialog,
    private crossPlatformService: CrossPlatformService,
    private userSetupService: UserSetupService,
    private helperService: HelperService,
  ) {
    this.getUserList();
  }

  public getUserList() {
    this.listData.forEach((element) => {
      if (element.isSelected === true) {
        this.selectedCount++;
      }
    });
    const orgId = JSON.parse(JSON.stringify(this.crossPlatformService.getOrgId().user.orgId));
    const usersListLocal = this.userSetupService.getUsersListLocal();
    if (usersListLocal) { this.initUsersList(usersListLocal); }
  }

  public initUsersList(usersList) {
    this.listData = [];
    console.log(usersList);
    usersList.forEach((user) => {
      this.meFlag = this.crossPlatformService.getOrgId().user_details['userTenancyIdentityId'] === user.partyId ? true : false;
      user.roles = user.roles ? user.roles : [];
      user.actionList = [];
      user.roles.forEach((role) => {
        if (role.enabledActions && role.enabledActions.length > 0) {
          role.enabledActions.forEach((action) => {
            if (user.actionList.indexOf(action.actionLabel) === -1) { user.actionList.push(action.actionLabel); }
          });
        }
      });
      user.keyActions.forEach((action) => {
        if (user.actionList.indexOf(action.actionLabel) === -1) { user.actionList.push(action.actionLabel); }
      });

      if (!user.reportee) { user.reportee = []; }
      this.listData.push({
        imageId: user.userProfile.avatar ? user.userProfile.avatar.gridFSid : '',
        meFlag: this.meFlag,
        default: user.isDefaultUser,
        title: user.name,
        isSelected: false,
        initialData: user,
        userList: user,
        menuData: this.createMenuActions(user.isDefaultUser, this.meFlag),
        subTitle: user.roles.length > 0 ? user.roles.map((role) => role.roleLabel) : '-',
        subTitle1: user.actionList,
        footer: [{ placeholder: 'Supervisor', value: user.supervisorName ? user.supervisorName : 'NA', clickable: false },
        { placeholder: 'Reportees', value: user.reportee.length, clickable: true }]
      });
      this.loading = false;
    });
  }

  public createMenuActions(isDefaultUser, isMe) {
    if (isDefaultUser) {
      if (isMe) { return ['Edit']; } else { return []; }
    } else {
      return ['Edit', 'Assign Manager', 'Map Role', 'Select'];
    }
  }

  public openListDialog(param) {
    if (param.data.length > 0) {
      const dialogRef = this.dialog.open(ViewListDialogComponent, {
        height: '60%',
        width: '80%',
        data: { data: param.data, type: param.type, title: param.title, selectable: false }
      });
    }
  }

  public responseFromList(event, user) {
    console.log('response is ', event);
    switch (event.eventFrom) {
      case 'card':
        this.showUserProfile(user.userList);
        break;

      case 'footer':
        if (event.eventData === 'Reportees') {
          let param = { data: [], title: 'Reportees', type: 'partnerInfo' };
          if (event.initialData.reportee) {
            event.initialData.reportee.forEach((rep) => {
              param.data.push({
                line1: rep.name,
                line2: rep.roles.map((r) => r.roleLabel)
              });
            });
            this.openListDialog(param);
          }
        }
        break;

      case 'multiSelect':
        let countFlag = 0;
        this.selectAll = false;
        this.indeterminateFlag = false;
        this.extraDiv = true;
        this.listData.find((u) => u.initialData.isDefaultUser === true).hide = true;
        this.listData.forEach((data) => {
          if (data.isSelected === true) { countFlag++; }
        });
        console.log(countFlag);
        if (countFlag === this.listData.length - 1) {
          this.selectAll = true;
        }
        if (0 < countFlag && countFlag < this.listData.length - 1) {
          this.indeterminateFlag = true;
        }
        this.selectedCount = countFlag;
        // this.checkSelectAll();
        this.extraDiv = true;
        break;

      case 'menu':
        const configData = { image: true, menu: false, footer: true, multiSelect: true };
        switch (event.eventData) {
          case 'Edit':
            this.router.navigate(['/postLaunch/user/edit', event.initialData.mobile]);
            break;
          case 'Assign Manager':
            const usersListLocal = this.userSetupService.getUsersListLocal();
            this.assignManager(usersListLocal, [user]);
            break;
          case 'Map Role':
            const selectedRoleData = [];
            event.userList.roles.forEach((role) => {
              selectedRoleData.push({
                id: role.roleId,
                name: role.roleLabel,
                actionsList: role.enabledActions
              });
            });
            console.log('selectedRoleData', selectedRoleData);
            const roleData = {
              componentName: 'roleAction',
              data: { data: selectedRoleData, type: '', title: 'Select Role', selectable: true, configData, multi: false, currentUserList: [event.userList] }
            };
            this.mapRoleDialog(roleData);
            break;
          case 'Select':
            this.listData[0].defaultItem = true;
            break;
          default:
            break;
        }
        break;

      default:
        break;
    }
  }

  public showDialog(dialogData) {
    console.log(dialogData.data);
    const dialogRef = this.dialog.open(ListDialogComponent, {
      height: '60%',
      width: '80%',
      data: {
        title: dialogData.title, selectable: false, data: dialogData.data, type: dialogData.type
      }
    });
  }

  public mapRoleDialog(data) {
    const dialogRef = this.dialog.open(CommonDialogComponent, {
      height: '100%',
      maxHeight: '100%',
      width: '100%',
      maxWidth: '100%',
      panelClass: 'backgroundColor',
      data
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('data from dialog', result);
      if (result === 'OK') {
        this.cancelExtraDiv();
        this.getUserList();
      }
    });
    // this.router.navigate(['/postLaunch/user/editProfile']);
  }

  public selectAllRecord(selectAll) {
    this.indeterminateFlag = false;
    this.selectAll = !selectAll;
    this.selectAll === true ? this.selectedCount = this.listData.length - 1 : this.selectedCount = 0;
    this.selectToggle(this.selectAll);
  }

  public cancelExtraDiv() {
    this.extraDiv = false;
    this.selectAll = false;
    this.indeterminateFlag = false;
    this.selectToggle(this.extraDiv);
    this.listCardConfig.menu = true;
    this.listCardConfig.multiSelect = false;
    // this.selectedListData = [];
    this.selectedCount = 0;
    this.listData.find((u) => u.initialData.isDefaultUser === true).hide = false;
  }

  public selectToggle(data) {
    console.log('selected value before', data);
    this.listData.forEach((element) => {
      if (!element.hide) {
        element.isSelected = data;
      }
    });
    console.log('listData for Assign', this.listData);
  }

  public asignUsersTo() {
    let selectedUsers = this.listData.filter((user) => user.isSelected === true);
    if (selectedUsers.length > 0) {
      const dialogRef = this.dialog.open(DialogWithButtonsComponent, {
        width: '80%',
        data: {
          config: { button: true, input: false, singleSelect: true },
          for: 'user',
          title: 'Assign Users To',
          button: { text: 'PROCEED', for: 'asignUsersTo' },
          multiSelectArray: [{ fieldName: 'Manager', isSelected: false }, { fieldName: 'Role', isSelected: false }]
        },
        disableClose: true
      });
      dialogRef.afterClosed().subscribe((resFromDialog) => {
        console.log('resFromDialog : ', resFromDialog);
        if (resFromDialog) {
          const usersListLocal = this.userSetupService.getUsersListLocal();
          console.log('Selected USERS : ', selectedUsers);
          if (resFromDialog[0].fieldName === 'Manager') {
            this.assignManager(usersListLocal, selectedUsers);
          } else {
            this.assignRoles(usersListLocal, selectedUsers);
          }
        }
      });
    } else {
      this.helperService.openSnackBar('No User Selected', 'Please Select');
    }
  }

  public assignRoles(userList, selectedUsers) {
    const configData = { image: true, menu: false, footer: true, multiSelect: true };
    const roleData = {
      componentName: 'roleAction',
      data: { data: [], type: '', title: 'Select Role', selectable: true, configData, multi: true, currentUserList: selectedUsers.map((user) => user.initialData) }
    };
    this.mapRoleDialog(roleData);
  }

  public assignManager(userList, selectedUsers) {
    console.log(selectedUsers);
    let filteredUserList = [];
    if (userList) {
      userList.forEach((user) => {
        if (!selectedUsers.find((u) => u.initialData.partyId === user.partyId)) {
          filteredUserList.push(user);
        }
      });
      console.log(filteredUserList);
      if (selectedUsers.length === 1) {
        filteredUserList.forEach((user) => {
          if (selectedUsers[0].initialData.supervisorId === user.partyId) {
            user.isSelected = true;
          } else {
            user.isSelected = false;
          }
        });
      }
      const dialogRef = this.dialog.open(UserListDialogComponent, {
        maxWidth: '100%',
        height: '100%',
        width: '100%',
        autoFocus: false,
        data: { users: JSON.parse(JSON.stringify(filteredUserList)), selectable: true, multi: false }
      });
      dialogRef.afterClosed().subscribe((result) => {
        console.log('data from dialog', result);
        if (result) {
          this.cancelExtraDiv();
          let manager = result.find((u) => u.isSelected);
          console.log(manager);
          let updateList = [];
          selectedUsers.forEach((su) => {
            updateList.push({ partyId: su.initialData.partyId, supervisorId: manager.initialData.partyId });
          });
          this.updateUsers(updateList);
        }
      });
    }
  }

  public updateUsers(usersUpdateList) {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.userSetupService.updateUser(token, usersUpdateList).subscribe((res) => {
        console.log('response for update User', res);
        if (res.success && res.result) {
          this.userSetupService.setUsersListLocal(undefined);
          this.router.navigate(['/postLaunch/user/reload']);
          this.getUserList();
          this.helperService.openSnackBar('User Updated Successfully', 'OK');
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public showUserProfile(user) {
    console.log('user is ', user);
    const dialogRef = this.dialog.open(UserProfileDialogComponent, {
      width: '100%',
      height: '100%',
      maxWidth: '100%',
      data: { user },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
    });
  }
}
