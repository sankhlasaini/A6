import { Router, NavigationEnd } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { UserSetupService } from '../../../services/postLaunch/user-setup.service';
import { CrossPlatformService } from '../../../services/postLaunch/cross-platform.service';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {

  public loading = false;

  constructor(
    private router: Router,
    private userSetupService: UserSetupService,
    private crossPlatformService: CrossPlatformService
  ) {
    router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loading = true;
        console.log('=============================== route Changed ROUTER ===========================');
        this.getUserList();
      }
    });
  }

  public getUserList() {
    const usersListLocal = this.userSetupService.getUsersListLocal();
    if (usersListLocal) {
      this.loading = false;
      console.log('userslist getting from local', usersListLocal);
    } else {
      console.log('userslist getting from db');
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.userSetupService.getUserList(token, this.crossPlatformService.getOrgId().user.orgId, '').subscribe((res) => {
          console.log('res for user List', res);
          this.loading = false;
          if (res.success) {
            this.userSetupService.setUsersListLocal(res.result);
          }
        }, (err) => {
          this.loading = false;
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

}
