import { slideUp } from './../../../../animations';
import { Router } from '@angular/router';
import { HelperService } from './../../../../services/helper.service';
import { UserSetupService } from './../../../../services/postLaunch/user-setup.service';
import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invite-user',
  templateUrl: './invite-user.component.html',
  styleUrls: ['./invite-user.component.css'],
  animations: [slideUp]
})
export class InviteUserComponent {
  public activeTabIndex = 0;
  public loading = false;
  public status = true;
  public dataFromInviteForm = {
    fname: '',
    lname: '',
    emailID: '',
    mobileNo: '',
    selectRoles: [],
    keyActions: [],
    selectManager: '',
    services: [],
    territories: [],
    imAmManager: ''
  };
  public inviteBy;
  public inviteFormData = {
    accountId: '',
    accountName: '',
    orgId: '',
    orgName: '',
    contactDetails: {
      firstName: '',
      middleName: '',
      lastName: '',
      contactAddress: {
        firstName: '',
        middleName: '',
        lastName: '',
        email: '',
        mobile: '',
        addressType: 'Home',
        addressLabel: '',
        line1: '',
        line2: '',
        line3: '',
        district: '',
        city: '',
        state: '',
        country: '',
        landmark: '',
        pincode: '',
        isDefaultAddress: true,
        images: [{ gridFsid: '', gridFsFileName: '' }],
        gpsLocation: { latitude: '', longitude: '' }
      }
    },
    roles: [{ roleId: '', roleLabel: '', version: '', enabledActions: [{ actionId: '', actionLabel: '', mappedEndpointCanUris: [] }] }],
    globalDapFilterRules: [
      {
        filterKey: 'serviceLine',
        filterValue: '',
        filterOperator: 'EQUAL'
      },
      {
        filterKey: 'territory',
        filterValue: [{ nodeId: '', levelType: '' }],
        filterOperator: 'EQUAL'
      }
    ],
    messageMode: 'BOTH',
    supervisorId: ''
  };
  public messageMode;
  public selectedRole;

  constructor(
    private crossPlatformService: CrossPlatformService,
    private router: Router,
    private userSetupService: UserSetupService,
    private helperService: HelperService
  ) {
    const currentParty = JSON.parse(JSON.stringify(this.crossPlatformService.getOrgId().user));
    // console.log('orgDetails', currentParty);
    this.inviteFormData.orgId = currentParty.orgId;
    this.inviteFormData.orgName = currentParty.orgLabel;
    this.inviteFormData.accountId = currentParty.accountId;
    this.inviteFormData.accountName = currentParty.accountLabel;

    this.selectedRole = this.userSetupService.getInviteuserForRole();
    this.userSetupService.setInviteuserForRole(undefined);
  };

  public selectedTab() {
    console.log('selected tab is ', this.activeTabIndex);
    this.status = false;
  };
  public sendInvite() {
    this.inviteFormData.globalDapFilterRules = [];
    console.log('Invite', this.dataFromInviteForm, this.inviteBy);
    if (!this.inviteBy[0].isSelected && !this.inviteBy[1].isSelected) {
      this.helperService.openSnackBar('Please select atleast one option', 'OK');
    } else {
      this.inviteFormData.contactDetails.firstName = this.dataFromInviteForm.fname;
      this.inviteFormData.contactDetails.lastName = this.dataFromInviteForm.lname;
      this.inviteFormData.contactDetails.contactAddress.firstName = this.dataFromInviteForm.fname;
      this.inviteFormData.contactDetails.contactAddress.lastName = this.dataFromInviteForm.lname;
      this.inviteFormData.supervisorId = this.dataFromInviteForm.selectManager;
      this.inviteFormData.contactDetails.contactAddress.email = this.dataFromInviteForm.emailID;
      this.inviteFormData.contactDetails.contactAddress.mobile = this.dataFromInviteForm.mobileNo;
      this.inviteFormData.roles = this.dataFromInviteForm['selectedRoles'];
      this.inviteFormData.messageMode = this.messageMode;
      this.inviteFormData.globalDapFilterRules.push({ filterKey: 'serviceLine', filterValue: JSON.stringify(this.dataFromInviteForm.services), filterOperator: 'EQUAL' });
      this.inviteFormData.globalDapFilterRules.push({ filterKey: 'territory', filterValue: JSON.stringify(this.dataFromInviteForm.territories), filterOperator: 'EQUAL' });
      console.log('this.inviteFormData', this.inviteFormData);
      this.loading = true;
      this.helperService.openSnackBar('Inviting ' + this.inviteFormData.contactDetails.firstName, 'Please Wait');
      this.crossPlatformService.checkPartyAccessToken().subscribe((at) => {
        this.userSetupService.userInvite(at, this.inviteFormData).subscribe((res) => {
          this.loading = false;
          console.log('res for userInvite', res);
          if (res.success) {
            this.userSetupService.setUsersListLocal(undefined);
            this.helperService.openSnackBar('User Invite sent', 'OK');
            if (this.selectedRole) {
              this.router.navigate(['/postLaunch/role']);
            } else {
              this.router.navigate(['/postLaunch/user']);
            }
          }
        }, (err) => {
          this.loading = false;
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }
  public responseFromInviteUser(res) {
    this.dataFromInviteForm = null;
    this.dataFromInviteForm = res;
    console.log('res from invite form is ', res);
    if (this.dataFromInviteForm) {
      this.activeTabIndex = 1;
    }
  };
  public responseFromInviteBy(res) {
    this.inviteBy = res;
    console.log('res from inviteBy is ', res);
    if (res[0].isSelected === true && res[1].isSelected === true) {
      this.messageMode = 'BOTH';
    } else if (res[0].isSelected === true && res[1].isSelected === false) {
      this.messageMode = 'SMS';
    } else if (res[0].isSelected === false && res[1].isSelected === false) {
      this.messageMode = 'EMAIL';
    }
  }
}
