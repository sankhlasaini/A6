import { Router } from '@angular/router';
import { UserSetupService } from './../../../../../services/postLaunch/user-setup.service';
import { TerritoryService } from './../../../../../services/postLaunch/territory.service';
import { CrossPlatformService } from './../../../../../services/postLaunch/cross-platform.service';
import { AssetService } from './../../../../../services/postLaunch/asset.service';
import { TerritorySelectionDialogComponent } from './../../../territory-selection-dialog/territory-selection-dialog.component';
import { EcoSystemService } from './../../../../../services/eco-system.service';
import { HelperService } from './../../../../../services/helper.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Component, OnInit, Inject, EventEmitter, Output, Input, OnChanges } from '@angular/core';
import { MatDialog } from '@angular/material';
import { UserListDialogComponent } from '../../../common/user-list-dialog/user-list-dialog.component';
import { RoleService } from '../../../../../services/role.service';

@Component({
  selector: 'app-invite-user-form',
  templateUrl: './invite-user-form.component.html',
  styleUrls: ['./invite-user-form.component.css']
})
export class InviteUserFormComponent implements OnChanges {
  @Output() public outputEvent = new EventEmitter();
  @Input() public autoSelectRole;

  public loading = true;
  public activeTabIndex = 0;
  public secondSection = '';
  public secondSectionData;
  public myForm: FormGroup;
  public roleValues = [];
  public roles = [];
  public keyActionValues = [];
  public iAmManager = false;
  public allGlobalActions = [];
  public selectedManager;
  public selectedRoles = [];
  public placeholders = {
    firstNameLabel: 'First Name',
    lastNameLabel: 'Last Name',
    mobileNOLabel: 'Mobile No.',
    emailIDLabel: 'Email ID',
    selectRolesLabel: 'Select Role',
    keyActionsLabel: 'Key Actions',
    selectManagerLabel: 'Select Manager',
    servicesLabel: 'Services Lines',
    territoriesLabel: 'Territories'
  };
  public templateType = 'serviceCatagory';
  public serviceLineList = [];
  public serviceLineData = [];
  public territoryList = [];
  public territoryDataManager = [];
  public showTerritoryList = [];
  public territoryTree = [];
  public selectedTerritoryTree;
  public globalTerritoryList = [];
  public territoryPageSize = 20;
  public hint = false;
  public serviceLineIds = [];
  public serviceLineOfManager = [];
  public globalTerritoryTemp;
  public allUsersList = [];
  public roleList = [];

  public selectedRolesArray = [];
  public keyActions = [];

  constructor(
    @Inject(FormBuilder) public fb: FormBuilder,
    private helperService: HelperService,
    private ecoSystemService: EcoSystemService,
    private dialog: MatDialog,
    private crossPlatformService: CrossPlatformService,
    private assetService: AssetService,
    private roleService: RoleService,
    private territoryService: TerritoryService,
    private userSetupService: UserSetupService,
    private router: Router
  ) {
  }

  public ngOnChanges() {
    this.myForm = this.fb.group({
      fname: (['', [Validators.required, Validators.minLength(1)]]),
      lname: (['', [Validators.required, Validators.minLength(1)]]),
      mobileNo: (['', [Validators.required, Validators.pattern(this.helperService.mobileRegex)]]),
      emailID: (['', [Validators.required, Validators.pattern(this.helperService.emailRegex)]]),
      selectRoles: (['', [Validators.required]]),
      keyActions: (['']),
      manager: new FormControl({ value: '', disabled: this.iAmManager }),
      serviceLines: (['', []]),
      territory: (['', [Validators.required]])
    });
    this.allUsersList = this.userSetupService.getUsersListLocal();
    console.log(this.autoSelectRole);
    this.getServiceLineList();
    this.getTerritoryList();
    this.getRoleList();
  }

  public getServiceLineList() {
    const serLinesLocal = this.assetService.getServiceLinesLocal();
    console.log(serLinesLocal);
    if (serLinesLocal) {
      serLinesLocal.categories == null ? serLinesLocal.categories = [] : serLinesLocal.categories = serLinesLocal.categories;
      this.serviceLineList = serLinesLocal.categories;
      console.log('serviceLineList', this.serviceLineList);
    } else {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.assetService.getGetCategoryByLevel(this.templateType, token).subscribe((res) => {
          console.log('GetCategoryByLevel : ', res);
          if (res.success) {
            this.assetService.setServiceLinesLocal(res.result);
            res.result.categories == null ? res.result.categories = [] : res.result.categories = res.result.categories;
            this.serviceLineList = res.result.categories;
            console.log('serviceLineList', this.serviceLineList);
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public getTerritoryList() {
    console.log('-----------------------', this.crossPlatformService.getOrgId().user.userTenancyIdentityId);
    const pageStartIndex = 0;
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.territoryService.retrieveTerritoriesByOrgId(token, this.crossPlatformService.getOrgId().orgId, pageStartIndex, this.territoryPageSize).subscribe((result) => {
        this.loading = false;
        if (result.success && result.result  && result.result.territoryList) {
          console.log('Territory List Result :: ', result.result);
          this.globalTerritoryList = result.result.territoryList;
          // this.globalTerritoryTemp = JSON.parse(JSON.stringify(this.globalTerritoryList));
        }
        this.toggleManager();
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public toggleManager() {
    this.iAmManager = !this.iAmManager;
    console.log(this.iAmManager);
    if (this.iAmManager) {
      this.myForm.get('manager').disable();
      // this.globalTerritoryList = this.globalTerritoryTemp;
      console.log('this.globalTerritoryList in toggle manager : ', this.globalTerritoryList);
      this.myForm.patchValue({ territory: '' });
      this.myForm.patchValue({ serviceLines: '' });
      this.selectedManager = JSON.parse(JSON.stringify(this.crossPlatformService.getOrgId().user.userTenancyIdentityId));
      this.myForm.patchValue({ manager: this.crossPlatformService.getOrgId().user.userName });
      this.getSerLineForManager(this.selectedManager);
    } else {
      this.selectedManager = undefined;
      this.serviceLineData = [];
      this.myForm.get('manager').enable();
      this.myForm.patchValue({ manager: '' });
      this.myForm.patchValue({ territory: '' });
      this.myForm.patchValue({ serviceLines: '' });
    }
    console.log(this.selectedManager);
  }

  public selectManagerEvent() {
    if (this.allUsersList.length > 0) {
      if (!this.iAmManager) {
        const primaryUser = this.crossPlatformService.getOrgId().user.userTenancyIdentityId;
        let filteredUserList = this.allUsersList.filter((user) => user.partyId !== primaryUser);
        console.log(filteredUserList);
        const dialogRef = this.dialog.open(UserListDialogComponent, {
          maxWidth: '100%',
          height: '100%',
          width: '100%',
          autoFocus: false,
          data: { users: JSON.parse(JSON.stringify(filteredUserList)), selectable: true, multi: false }
        });
        dialogRef.afterClosed().subscribe((result) => {
          console.log('data from dialog', result);
          if (result) {
            let manager = result.find((u) => u.isSelected);
            console.log(manager);
            let updateList = [];
            this.myForm.patchValue({ manager: manager.initialData.name });
            this.selectedManager = manager.initialData.partyId;
            this.getSerLineForManager(this.selectedManager);
          }
        });
      }
    } else {
      this.helperService.openSnackBar('Getting Users', 'Please Wait');
    }
  }

  public getRoleList() {
    if (this.crossPlatformService.getEcoSystemProfile()) {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.roleService.getRoleByProfileId(this.crossPlatformService.getEcoSystemProfile().id, this.crossPlatformService.getOrgId().user.orgId, token).subscribe((roleResult) => {
          console.log('roles :', roleResult);
          if (roleResult.success) {
            this.roleList = roleResult.result.filter((rl) => rl.actionsList.length > 0);
            if (this.autoSelectRole) {
              this.myForm.patchValue({
                selectRoles: [this.autoSelectRole.id]
              });
              this.selectRoles();
            }
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public selectTerritory() {
    console.log('Territory Selection', this.territoryList);
    if (!this.selectedManager) {
      this.helperService.openSnackBar('Please select manager first', 'OK');
    } else {
      if (this.territoryDataManager.length === 0) {
        this.helperService.openSnackBar('No territory associated with this Manager', 'Try Another');
      } else {
        const dialogRef = this.dialog.open(TerritorySelectionDialogComponent, {
          maxWidth: '100%',
          width: '100%',
          height: '100%',
          data: {
            invokeFrom: 'service',
            globalTerritoryList: this.territoryService.mappingToDefination(this.globalTerritoryList, this.territoryDataManager),
            existingTerritoryList: this.territoryList
          },
        });
        dialogRef.afterClosed().subscribe((territoryResult) => {
          if (territoryResult) {
            this.createTerritoryData(territoryResult.mapping);
          }
        });
      }
    }
  }

  public createTerritoryData(mappingData) {
    this.myForm.patchValue({ serviceLines: '' });
    this.serviceLineData = [];
    console.log('territoryResult', mappingData);
    if (mappingData) {
      let showTerritoryList = [];
      this.territoryList = mappingData;
      this.territoryList.forEach((territory, i) => {
        const temp = this.globalTerritoryList.find((ter) => ter.territoryId === territory.id);
        if (temp) { showTerritoryList.push(temp.territoryName + ' (' + territory.territoryTree.length + ')'); }
      });
      this.myForm.patchValue({ territory: showTerritoryList });
      if (this.myForm.value.territory.length > 0) {
        this.serviceLineIds = [];
        this.serviceLineData = [];
        const serviceData = this.userSetupService.getAllServiceData();
        console.log('serviceData in userForm', serviceData);
        console.log('territoryList in userForm', this.territoryList);
        this.territoryList.forEach((terr) => {
          terr.territoryTree.forEach((territoryTree) => {
            serviceData.service.forEach((service) => {
              service.prices.forEach((price) => {
                if (!price.territories) { price.territories = []; }
                price.territories.forEach((territory) => {
                  territory.territoryTree.map((tTree) => {
                    if (tTree.nodeId === territoryTree.nodeId) {
                      const index = this.serviceLineIds.indexOf(service.referenceIds.categoryCode);
                      if (index === -1) {
                        this.serviceLineIds.push(service.referenceIds.categoryCode);
                      }
                    }
                  });
                });
              });
            });
          });
        });
        console.log('Service Lines Filtered By Territory : ', this.serviceLineIds);
        const serLineIds = this.serviceLineIds.filter((serviceLineId) => this.serviceLineOfManager.find((serLine) => serLine === serviceLineId));
        this.serviceLineData = serLineIds.map((sl) => this.serviceLineList.find((serviceLine) => serviceLine.id === sl));
        console.log('Service Lines Filtered By Manager', this.serviceLineData);
        this.myForm.patchValue({ serviceLines: this.serviceLineData.map((ser) => ser.id) });
      }
    }
  }

  public getSerLineForManager(supervisorId) {
    let managerObj = this.allUsersList.find((u) => u.partyId === supervisorId);
    console.log('Selected Manager DATA : ', managerObj);
    this.serviceLineOfManager = [];
    if (managerObj && managerObj.globalDapFilterRules && managerObj.globalDapFilterRules.length > 0) {
      const serLines = managerObj.globalDapFilterRules.find((gd) => gd.filterKey === 'serviceLine');
      if (serLines) {
        const ser = JSON.parse(serLines.filterValue);
        if (ser) { this.serviceLineOfManager = ser; }
      }
      console.log('Service Lines For ' + managerObj.name, this.serviceLineOfManager);
      this.getTerritoriesForManager(managerObj);
    } else {
      this.myForm.patchValue({ territory: '' });
    }
  }

  public getTerritoriesForManager(managerObj) {
    this.territoryDataManager = [];
    const terData = managerObj.globalDapFilterRules.find((gd) => gd.filterKey === 'territory');
    if (terData) {
      const ter = JSON.parse(terData.filterValue);
      this.territoryDataManager = ter;
      console.log(ter);
    }
    console.log('Global Dap Filter Territroy ::', this.territoryDataManager);
    this.territoryList = JSON.parse(JSON.stringify(this.territoryDataManager));
    this.createTerritoryData(this.territoryDataManager);
  }

  public serviceLines() {
    if (!this.myForm.value.territory) {
      this.hint = true;
    }
    if (this.serviceLineData.length === 0) {
      this.helperService.openSnackBar('No service associated with Territory', 'Try Another');
    }
  }

  public selectKeyActions() {
    console.log(this.selectedRolesArray);
    console.log(this.keyActions);
    this.secondSection = 'roleAction';
    this.secondSectionData = { roles: this.selectedRolesArray, keyActions: this.keyActions };
    this.activeTabIndex = 1;
  }

  public tabChange(event, from) {
    this.secondSectionData = {};
    this.secondSection = '';
    this.activeTabIndex = 0;
    switch (from) {
      case 'roleAction':
        if (event.event === 'save') {
          this.updateRoleAndActions(event.data);
        }
        break;
      default:
        break;
    }
  }

  public updateRoleAndActions(filteredModulesList) {
    this.keyActions = [];
    filteredModulesList.forEach((module) => {
      module.functionList.forEach((func) => {
        func.actionList.forEach((action) => {
          let orphan = true;
          this.selectedRolesArray.forEach((parentRole) => {
            let parAction = parentRole.enabledActions.find((act) => act.actionId === action.actionId);
            if (parAction) {
              orphan = false;
              parAction.active = action.isSelected;
            }
          });
          if (orphan && action.isSelected) {
            this.keyActions.push(action);
            console.log(action);
          }
        });
      });
    });
    this.myForm.patchValue({ keyActions: this.keyActions.map((act) => act.actionLabel) });
  }

  public selectRoles() {
    if (this.myForm.value.selectRoles) {
      this.myForm.value.selectRoles.forEach((rlId) => {
        if (!this.selectedRolesArray.find((rl) => rl.roleId === rlId)) {
          let temp = this.roleList.find((rl) => rl.id === rlId);
          if (temp) {
            let selectedActions = [];
            let role = JSON.parse(JSON.stringify(temp));
            // if (this.dataForEdit.roles) {
            //   let existingRole = this.dataForEdit.roles.find((r) => r.roleId === role.id);
            //   if (existingRole) {
            //     selectedActions = existingRole.enabledActions;
            //   }
            // }
            this.selectedRolesArray.push({
              roleId: role.id,
              roleLabel: role.name,
              version: role.version,
              enabledActions: role.actionsList.map((act) => {
                if (selectedActions.length > 0) {
                  act.active = selectedActions.find((a) => a.actionId === act.actionId) ? true : false;
                } else {
                  act.active = true;
                }
                return act;
              })
            });
          }
        }
      });
      this.selectedRolesArray.forEach((rl, i) => {
        if (!this.myForm.value.selectRoles.find((rlId) => rlId === rl.roleId)) {
          this.selectedRolesArray.splice(i, 1);
        }
      });
    }
    console.log(this.myForm.value.selectRoles);
    console.log(this.selectedRolesArray);
    console.log('updating')
    const currentEcoProfile = this.crossPlatformService.getEcoSystemProfile();
    const role = { actionsList: [] };
    this.selectedRolesArray.forEach((rl) => {
      rl.enabledActions.forEach((act) => {
        if (!role.actionsList.find((action) => action.actionId === act.actionId) && act.active) {
          role.actionsList.push(act);
        }
      });
    });
    this.keyActions.forEach((act) => {
      role.actionsList.push(act);
    });
    let filteredModulesList = this.roleService.getFilteredActionByRoleAndProfile(currentEcoProfile, role);
    this.updateRoleAndActions(filteredModulesList);
  }

  public updateActionForUser(action) {
    const masterList = this.ecoSystemService.getGlobalActionList();
    const masterAction = masterList.find((act) => act.actionId === action.actionId);
    if (masterAction) {
      let userAction = {
        actionId: masterAction.actionId,
        actionLabel: masterAction.actionLabel,
        actionVersion: masterAction.actionVersion.toString(),
        mappedEndpointCanUris: masterAction.linkedApiIds.map((api) => api.endpointCannonicalUniqueUri)
      };
      return userAction;
    } else {
      return undefined;
    }
  }

  public inviteUser() {
    console.log(this.myForm);
    if (this.myForm.valid) {
      console.log(this.selectedRolesArray);
      console.log(this.keyActions);
      let addEnableRoles = [];
      this.selectedRolesArray.forEach((role) => {
        let actions = [];
        role.enabledActions.forEach((act) => {
          if (act.active) {
            actions.push(this.updateActionForUser(JSON.parse(JSON.stringify(act))));
          }
        });
        if (actions.length > 0) {
          let finalRole = JSON.parse(JSON.stringify(role));
          finalRole.enabledActions = actions;
          addEnableRoles.push(finalRole);
        }
      });
      console.log(addEnableRoles);
      const inviteUser = {
        iAmManager: this.iAmManager,
        fname: this.myForm.value.fname,
        lname: this.myForm.value.lname,
        mobileNo: this.myForm.value.mobileNo.toString(),
        emailID: this.myForm.value.emailID.toLowerCase(),
        selectedRoles: addEnableRoles,
        keyActions: this.keyActions.map((act) => { return this.updateActionForUser(act); }),
        selectManager: this.selectedManager,
        services: this.myForm.value.serviceLines,
        territories: this.territoryList,
      };
      console.log('true');
      this.outputEvent.emit(inviteUser);
    } else {
      this.helperService.openSnackBar('Please fill all the required field', 'OK');
    }
  }

  public back() {
    if (this.autoSelectRole) {
      this.router.navigate(['/postLaunch/role']);
    } else {
      this.router.navigate(['/postLaunch/user']);
    }
  }
}
