import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvitationMessageComponent } from './invitation-message.component';

describe('InvitationMessageComponent', () => {
  let component: InvitationMessageComponent;
  let fixture: ComponentFixture<InvitationMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvitationMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvitationMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
