import { CrossPlatformService } from './../../../../../services/postLaunch/cross-platform.service';
import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'user-invitation-message',
  templateUrl: './invitation-message.component.html',
  styleUrls: ['./invitation-message.component.css']
})
export class InvitationMessageComponent implements OnInit {
  @Output() public outputEvent = new EventEmitter();
  @Input() public data;
  public inviteBySms = { name: 'SMS', isSelected: true };
  public inviteByMail = { name: 'Email', isSelected: true };
  public loggedUserData;
  constructor(private crossPlatformService: CrossPlatformService) {
    this.loggedUserData = this.crossPlatformService.getOrgId();
  }

  public selectedData(data) {
    if (data === 'SMS') {
      this.inviteBySms.isSelected = !this.inviteBySms.isSelected;
    } else {
      this.inviteByMail.isSelected = !this.inviteByMail.isSelected;
    }
    // this.wholeList[index].isSelected === true ? this.selectedItemCount++ : this.selectedItemCount--;
    console.log('SMS :', this.inviteBySms.isSelected + 'EMAIL :' + this.inviteByMail.isSelected);
    const InviteBy = this.inviteBy();
    this.outputEvent.emit(InviteBy);
  }

  public ngOnInit() {
    if (this.inviteBySms.isSelected && this.inviteByMail.isSelected) {
      const InviteBy = this.inviteBy();
      this.outputEvent.emit(InviteBy);
    }
  }

  public inviteBy() {
    const InviteBy = [{
      name: this.inviteBySms.name,
      isSelected: this.inviteBySms.isSelected
    }, {
      name: this.inviteByMail.name,
      isSelected: this.inviteByMail.isSelected
    }];
    return InviteBy;
  }
}
