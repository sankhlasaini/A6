import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetTypeDialogComponent } from './asset-type-dialog.component';

describe('AssetTypeDialogComponent', () => {
  let component: AssetTypeDialogComponent;
  let fixture: ComponentFixture<AssetTypeDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetTypeDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetTypeDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
