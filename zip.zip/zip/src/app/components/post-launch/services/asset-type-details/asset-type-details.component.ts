import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { Component, OnInit, Output, Input, EventEmitter, OnChanges } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ServiceCatalogService } from '../../../../services/postLaunch/service-catalog.service';
@Component({
  selector: 'service-asset-type-details',
  templateUrl: './asset-type-details.component.html',
  styleUrls: ['./asset-type-details.component.css']
})
export class AssetTypeDetailsComponent implements OnChanges {

  @Input() public asset;
  @Output() public output = new EventEmitter();

  public assetdata;

  public imageswidth;
  public assetImages = [];

  constructor(
    private crossPlatformService: CrossPlatformService,
    private serviceCatalogService: ServiceCatalogService
  ) { }

  public ngOnChanges() {
    console.log(this.asset);
    this.assetImages = this.asset.images ? this.asset.images : [];
    console.log('ASSET', this.asset);
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      if (this.asset.specification) {
        this.asset.specification.forEach((file) => {
          file.url = file.id;
        });
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public downloadFile(id) {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.serviceCatalogService.downloadFile(id, token).subscribe((fileRes) => {
        console.log(fileRes);
        if (fileRes.success) {
          let link = document.createElement('a');
          link.href = 'data:' + fileRes.result.fileType + ';base64,' + fileRes.result.fileContent;
          link.download = fileRes.result.fileName;
          link.click();
        }
      });
    });
  }

  public close() {
    this.output.emit({ event: 'cancel' });
  }
}
