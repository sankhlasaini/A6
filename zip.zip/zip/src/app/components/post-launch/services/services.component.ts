import { HelperService } from './../../../services/helper.service';
import { TerritoryService } from './../../../services/postLaunch/territory.service';
import { ServiceCatalogService } from './../../../services/postLaunch/service-catalog.service';
import { CrossPlatformService } from './../../../services/postLaunch/cross-platform.service';
import { AssetService } from './../../../services/postLaunch/asset.service';
import { ServiceViewDialogComponent } from './service-view-dialog/service-view-dialog.component';
import { MatDialog } from '@angular/material';
import { slideUpEnter, slideDown, slideUp } from './../../../animations';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css'],
  animations: [slideUpEnter, slideDown, slideUp]
})

export class ServicesComponent implements OnInit {

  public servicesList = [];

  public totalServicesCount = 0;

  public pageSize = 10;

  public loadMore = true;

  public templateType = 'serviceCatagory';

  public serviceLineList = [];

  public assetsTypeList = [];

  public waitForResponse = false;

  public territoryNodeList = [];

  public nodeId = '';

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private assetService: AssetService,
    private territoryService: TerritoryService,
    private crossPlatformService: CrossPlatformService,
    private helperService: HelperService,
    private serviceCatalogService: ServiceCatalogService
  ) {
    // document.getElementById('mainContainer').scrollTop = 0;
    // this.getServiceLineList();
    this.getAssetTypesList();
  }

  public ngOnInit() {
    // this.getServiceList(0);
  }

  public getAssetTypesList() {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.assetService.getMasterListAssetTypes(0, 0, token).subscribe((res) => {
        this.getNodeIdsByDapFilter();
        console.log('Asset Type List Res', res);
        if (res.success) {
          this.assetsTypeList = res.result.assetType;
          this.assetsTypeList.forEach((assetType) => {
            if (assetType.images && assetType.images.length > 0) {
              assetType.images.forEach((atImg) => {
                const image = this.serviceCatalogService.findImage(atImg.id);
                if (image) {
                  atImg.image = image.base64;
                } else {
                  this.serviceCatalogService.downloadFile(atImg.id, token).subscribe((imgRes) => {
                    this.serviceCatalogService.storeImage(atImg.id, imgRes.result);
                    atImg.image = this.serviceCatalogService.findImage(atImg.id).base64;
                  });
                }
              });
            }
          });
          res.result.assetType.forEach((at) => {
            console.log(at);

          });
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getNodeIdsByDapFilter() {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      const user_details = this.crossPlatformService.getOrgId().user_details;
      console.log(user_details);
      this.territoryService.getNodeNamesByIds(user_details, token).subscribe((res) => {
        console.log('--------------getNodeIdsByDapFilter--------------', res);
        if (res.success && res.result.length > 0) {
          let objArray = [];
          res.result.forEach((n) => {
            if (!objArray.find((n2) => n2.nodeId === n.nodeId)) { objArray.push(n); }
          });
          this.territoryNodeList = this.helperService.sortByKey(objArray, 'name');
          const selectedNodeId = this.serviceCatalogService.getSelectedNodeId();
          if (selectedNodeId && this.territoryNodeList.find((node) => node.nodeId === selectedNodeId)) {
            this.nodeId = selectedNodeId;
          } else {
            this.nodeId = this.territoryNodeList[0].nodeId;
          }
          // this.getServiceListByNodeId("ChIJ-S5XHThwrzsRbTn4wOjsiSs");
          this.getServiceListByNodeId(this.nodeId);
        } else {
          this.helperService.openSnackBar('No Territory is Mapped to User', 'OK');
          this.loadMore = false;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getServiceListByNodeId(nodeId) {
    this.serviceCatalogService.setSelectedNodeId(nodeId);
    this.loadMore = true;
    this.servicesList = [];
    console.log('getting services for :: ', nodeId);
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.serviceCatalogService.getServicesByTerritoryId(nodeId, this.crossPlatformService.getOrgId().orgId, token).subscribe((res) => {
        this.loadMore = false;
        console.log('services for ::', res);
        if (res.success) {
          res.result.serviceLine.forEach((serLine) => {
            serLine.services.forEach((ser) => {
              ser.serviceLineName = serLine.name;
              this.servicesList.push(ser);
            });
          });
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getServiceList(pageStartIndex) {
    if (!this.waitForResponse) {
      console.log('hit : ' + pageStartIndex);
      if (this.loadMore) {
        this.waitForResponse = true;
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          this.serviceCatalogService.getMasterListServices(pageStartIndex, this.pageSize, this.crossPlatformService.getOrgId().orgId, token).subscribe((serviceRes) => {
            console.log(serviceRes);
            if (serviceRes.success) {
              console.log('Services List Res : ', serviceRes);
              // this.servicesList = this.servicesList.concat(serviceRes.result.service);
              // this.totalServicesCount = serviceRes.result.totalServicesCount.count;
              // if (this.servicesList.length >= this.totalServicesCount) {
              //   this.loadMore = false;
              // }
              this.waitForResponse = false;
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    }
  }

  public serviceCardEvent(cardEvent) {
    switch (cardEvent.action) {
      case 'edit':
        this.editService(cardEvent.data);
        break;
      case 'view':
        this.viewService(cardEvent.data);
        break;
      default:
        break;
    }
  }

  public editService(service) {
    console.log('in EDIT :', service);
    this.serviceCatalogService.setServiceObj(service.id);
    this.router.navigate(['/postLaunch/services/edit']);
  }

  public viewService(service) {
    const dialogRef = this.dialog.open(ServiceViewDialogComponent, {
      width: '100%',
      height: '100%',
      autoFocus: false,
      maxWidth: '100%',
      data: { service, serviceLine: service.serviceLineName, assetsTypeList: this.assetsTypeList },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
    });
    console.log('in View :', service);

  }
}
