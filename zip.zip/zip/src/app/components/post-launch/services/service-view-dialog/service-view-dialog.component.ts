import { ServiceCatalogService } from './../../../../services/postLaunch/service-catalog.service';
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HelperService } from '../../../../services/helper.service';
import { CrossPlatformService } from '../../../../services/postLaunch/cross-platform.service';
import { AssetService } from '../../../../services/postLaunch/asset.service';
@Component({
  selector: 'app-service-view-dialog',
  templateUrl: './service-view-dialog.component.html',
  styleUrls: ['./service-view-dialog.component.css']
})
export class ServiceViewDialogComponent {

  public activeTabIndex = 0;

  public selectedAsset;

  public imageswidth;

  public serviceImages = [];

  public activeImage;

  public defaultImage = {
    image: '../../assets/images/product.png',
    name: 'default Image'
  };

  public assetTypeList = [];

  public templateType = 'assetTypeCatagory';

  public assetCatagoryList = [];

  constructor(
    public dialogRef: MatDialogRef<ServiceViewDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialog: MatDialog,
    private serviceCatalogService: ServiceCatalogService,
    public helperService: HelperService,
    private assetService: AssetService,
    private crossPlatformService: CrossPlatformService
  ) {
    console.log(this.data);
    this.serviceImages = this.data.service.images ? this.data.service.images : [];
    this.activeImage = this.serviceImages.length > 0 ? this.serviceImages[0] : this.defaultImage;
    if (this.data.service.equipments) {
      this.data.assetsTypeList.forEach((assetType) => {
        if (this.data.service.equipments.map((eq) => { return eq.id; }).indexOf(assetType.id) !== -1) {
          this.assetTypeList.push(assetType);
        }
      });
    }
    this.getAssetCatagoryList();
  }

  public getAssetCatagoryList() {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      if (this.data.service.specification) {
        this.data.service.specification.forEach((file) => {
          file.url = file.id;
        });
      }
      this.assetService.getGetCategoryByLevel(this.templateType, token).subscribe((res) => {
        console.log('getGetCategoryByLevel : ', res);
        if (res.success) {
          res.result.categories == null ? res.result.categories = [] : res.result.categories = res.result.categories;
          this.assetCatagoryList = res.result.categories;
          this.assetTypeList.forEach((assetType) => {
            assetType.catagory = this.assetCatagoryList.find((cat) => cat.id === assetType.referenceIds.categoryCode);
          });
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public viewAsset(asset) {
    console.log(asset);
    this.selectedAsset = asset;
    this.activeTabIndex = 1;
  }

  public eventFromAsset(event) {
    if (event.event === 'cancel') {
      this.activeTabIndex = 0;
      this.selectedAsset = undefined;
    }
  }

  public downloadFile(id) {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.serviceCatalogService.downloadFile(id, token).subscribe((fileRes) => {
        console.log(fileRes);
        if (fileRes.success) {
          let link = document.createElement('a');
          link.href = 'data:' + fileRes.result.fileType + ';base64,' + fileRes.result.fileContent;
          link.download = fileRes.result.fileName;
          link.click();
        }
      });
    });
  }

  public close() {
    if (this.activeTabIndex > 0) {
      this.activeTabIndex--;
    } else {
      this.dialogRef.close();
    }
  }

}
