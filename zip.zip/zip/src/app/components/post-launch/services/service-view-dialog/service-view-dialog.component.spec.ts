import { ServiceViewDialogComponent } from './service-view-dialog.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

describe('ServiceLineDialogComponent', () => {
  let component: ServiceViewDialogComponent;
  let fixture: ComponentFixture<ServiceViewDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ServiceViewDialogComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceViewDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
