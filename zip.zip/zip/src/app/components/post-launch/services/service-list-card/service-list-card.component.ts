import { CrossPlatformService } from './../../../../services/postLaunch/cross-platform.service';
import { HelperService } from './../../../../services/helper.service';
import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { ServiceCatalogService } from '../../../../services/postLaunch/service-catalog.service';

@Component({
  selector: 'service-list-card',
  templateUrl: './service-list-card.component.html',
  styleUrls: ['./service-list-card.component.css']
})
export class ServiceListCardComponent implements OnChanges {

  @Input() public inputData;
  @Input() public serviceLine;
  @Input() public assetsTypeList;
  @Output() public outputData = new EventEmitter();

  public assetTypes = [];
  public defaultImage = {
    image: '../../assets/images/product.png',
    name: 'default Image'
  };
  public activeServiceImage;

  constructor(
    public helperService: HelperService,
    private crossPlatformService: CrossPlatformService,
    private serviceCatalogService: ServiceCatalogService
  ) { }

  public ngOnChanges() {
    if (this.inputData.images && this.inputData.images.length > 0) {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.inputData.images.forEach((serImg) => {
          const image = this.serviceCatalogService.findImage(serImg.id);
          if (image) {
            serImg.image = image.base64;
          } else {
            this.serviceCatalogService.downloadFile(serImg.id, token).subscribe((imgRes) => {
              this.serviceCatalogService.storeImage(serImg.id, imgRes.result);
              serImg.image = this.serviceCatalogService.findImage(serImg.id).base64;
            });
          }
        });
        this.activeServiceImage = this.inputData.images[0];
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    } else {
      this.activeServiceImage = this.defaultImage;
    }
    if (this.inputData.equipments) {
      this.assetsTypeList.forEach((assetType) => {
        if (this.inputData.equipments.map((eq) => { return eq.id; }).indexOf(assetType.id) !== -1) {
          if (assetType.images && assetType.images.length > 0) {
            assetType.activeAssetImage = assetType.images[0];
          } else {
            assetType.activeAssetImage = this.defaultImage;
          }
          console.log(assetType);
          this.assetTypes.push(assetType);
        }

      });
    }
    // console.log(this.inputData, this.assetsTypeList);
  }

  // public getAssetById(id){
  //   this..forEach(element => {

  //   });
  // }

  // public outputResponse() {
  //   this.outputEvent.emit('IN LIST CARD');
  // }

  // public footerClickEvent(placeholder, value, clickable) {
  //   if (clickable) {
  //     this.inputData.footer.forEach((footer) => {
  //       if (placeholder === footer.placeholder) {
  //         this.outputEvent.emit({ eventFrom: 'footer', eventData: placeholder });
  //         console.log(placeholder, value);
  //       }
  //     });
  //   }
  // }

  // public menuClickEvent(option, index) {
  //   this.outputEvent.emit({ eventFrom: 'menu', eventData: option, reference: this.inputData.title });
  //   console.log(option);
  // }

  // public cardClickEvent(cardData) {
  //   this.outputEvent.emit({ eventFrom: 'card', eventData: cardData });
  // }

  public menuAction1() {
    this.outputData.emit({ action: 'edit', data: this.inputData });
  }
  public cardClick() {
    this.outputData.emit({ action: 'view', data: this.inputData });
  }

}
