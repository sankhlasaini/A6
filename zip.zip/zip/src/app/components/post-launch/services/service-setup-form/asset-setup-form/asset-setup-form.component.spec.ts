import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetSetupFormComponent } from './asset-setup-form.component';

describe('AssetSetupFormComponent', () => {
  let component: AssetSetupFormComponent;
  let fixture: ComponentFixture<AssetSetupFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetSetupFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetSetupFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
