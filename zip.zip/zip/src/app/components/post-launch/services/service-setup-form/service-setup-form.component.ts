import { UserSetupService } from './../../../../services/postLaunch/user-setup.service';
import { PostLaunchComponent } from './../../post-launch.component';
import { TerritorySelectionDialogComponent } from './../../territory-selection-dialog/territory-selection-dialog.component';
import { Router, ActivatedRoute } from '@angular/router';
import { ServiceCatalogService } from './../../../../services/postLaunch/service-catalog.service';
import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AssetService } from '../../../../services/postLaunch/asset.service';
import { CrossPlatformService } from '../../../../services/postLaunch/cross-platform.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatAutocompleteTrigger } from '@angular/material';
import { startWith, map } from 'rxjs/operators';
import { HelperService } from '../../../../services/helper.service';
import { ConfirmLabelDialogComponent } from '../../../postLogin/common/confirm-label-dialog/confirm-label-dialog.component';
import { TerritoryService } from '../../../../services/postLaunch/territory.service';
import { ConfirmationDialogComponent } from '../../common/confirmation-dialog/confirmation-dialog.component';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-service-setup-form',
  templateUrl: './service-setup-form.component.html',
  styleUrls: ['./service-setup-form.component.css']
})

export class ServiceSetupFormComponent {

  @ViewChild('autoCompleteInput', { read: MatAutocompleteTrigger })
  public autoComplete: MatAutocompleteTrigger;

  public activeTabIndex = 0;

  public secondSection = '';

  public editPriceIndex = -1;

  public serviceSetupForm: FormGroup;

  public prices = [];

  public tags = [];

  public loading = true;

  public placeholders = {
    serviceLabel: 'Service Name',
    serviceCodeLabel: 'Service Code',
    serviceLineLabel: 'Service Line',
    territoryLabel: 'Select Territory',
    descriptionLabel: 'Service Description',
    AssetsLabel: 'Select Asset Type'
  };
  public territoryList = [];

  public assetsTypeList = [];

  public templateType = 'serviceCatagory';

  public serviceLine: FormControl;

  public selectedServiceLine;

  public filteredServiceLine: Observable<any[]>;

  public serviceLineList = [];

  public serviceId = '';

  public editService;

  public territoryPageSize = 50;

  public globalTerritoryList = [];

  public territorylistLoading = true;

  public images = [];

  public documents = [];

  constructor(
    private fb: FormBuilder,
    public dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private assetService: AssetService,
    public helperService: HelperService,
    private territoryService: TerritoryService,
    private crossPlatformService: CrossPlatformService,
    private userSetupService: UserSetupService,
    private serviceCatalogService: ServiceCatalogService,
    private postLaunchComponent: PostLaunchComponent
  ) {
    console.log('-----------------------', this.crossPlatformService.getEcosystem());

    this.serviceSetupForm = this.fb.group({
      serviceName: new FormControl('', [Validators.required, Validators.maxLength(20)]),
      serviceCode: new FormControl('', [Validators.required]),
      territory: new FormControl('', [Validators.required]),
      description: new FormControl('', [Validators.required, Validators.maxLength(160)]),
      assetType: new FormControl('', [Validators.required]),
    });
    this.serviceLine = new FormControl('', [Validators.required]);

    this.activatedRoute.data.subscribe((routeData) => {
      if (routeData['type'] === 'edit') {
        const serviceId = this.serviceCatalogService.getServiceObj();
        if (serviceId) {
          const serviceList = this.userSetupService.getAllServiceData();
          if (serviceList) {
            const service = serviceList.service.find((ser) => ser.id === serviceId);
            this.serviceId = serviceId;
            console.log('got service id for Edit : ', this.serviceId, service);
            this.enableEditMode(JSON.parse(JSON.stringify(service)));
            // localStorage.removeItem('partyServiceId');
          }

        } else {
          console.log('NO service id for Edit : ');
          this.router.navigate(['/postLaunch/services']);
        }
      } else {
        console.log('add Mode in Form');
        this.getAssetTypesList();
        this.getServiceLineList(undefined);
        this.getTerritoryList();
      }
    });
  }

  public enableEditMode(service) {
    console.log(service);
    this.getTerritoryList();
    this.editService = service;
    this.tags = service.tags.split(',');
    this.prices = service.prices;
    this.images = service.images;
    this.documents = service.specification;
    this.serviceSetupForm.patchValue({
      serviceName: service.displayName,
      serviceCode: service.code,
      // serviceLine: service.referenceIds.categoryCode,
      // territory: '',
      description: service.longBanner,
      assetType: service.equipments.map((eq) => { return eq.id; }),
    });
    this.getAssetTypesList();
    this.getServiceLineList(undefined);
  }

  public getServiceLineList(preSelected) {
    const serLinesLocal = this.assetService.getServiceLinesLocal();
    console.log(serLinesLocal);
    if (serLinesLocal) {
      this.setUpServiceLines(serLinesLocal, preSelected);
    } else {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.assetService.getGetCategoryByLevel(this.templateType, token).subscribe((res) => {
          console.log('getGetCategoryByLevel : ', res);
          if (res.success) {
            this.assetService.setServiceLinesLocal(res.result);
            this.setUpServiceLines(res.result, preSelected);
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public setUpServiceLines(lines, preSelected) {
    lines.categories == null ? lines.categories = [] : lines.categories = lines.categories;
    this.serviceLineList = lines.categories;
    this.filteredServiceLine = this.serviceLine.valueChanges.pipe(startWith(''), map((cat) => cat ? this.filterCat(cat) : this.serviceLineList.slice()));
    if (this.serviceId) {
      console.log('edit mode', this.editService);
      this.serviceLineList.forEach((serLine) => {
        if (serLine.id === this.editService.referenceIds.categoryCode) {
          this.serviceLine.patchValue(serLine.displayName);
          this.serLineSelection(serLine);
        }
      });
    }
    if (preSelected) {
      this.serviceLine.patchValue(preSelected);
      this.serLineType();
    }
  }

  public filterCat(name: string) {
    return this.serviceLineList.filter((cat) => cat.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  public getAssetTypesList() {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.assetService.getMasterListAssetTypes(0, 0, token).subscribe((res) => {
        console.log('Asset Type List Res', res);
        if (res.success) {
          this.assetsTypeList = res.result.assetType;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getTerritoryList() {
    this.territorylistLoading = true;
    const pageStartIndex = 0;
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.territoryService.retrieveTerritoriesByOrgId(token, this.crossPlatformService.getOrgId().orgId, pageStartIndex, this.territoryPageSize).subscribe((result) => {
        console.log('result', result);
        this.loading = false;
        if (result.success && result.result && result.result.territoryList) {
          this.globalTerritoryList = result.result.territoryList;
          if (this.serviceId && this.editService.territories) {
            this.createTerritoryData(this.editService.territories);
          }
          this.territorylistLoading = false;
        } else {
          this.helperService.openSnackBar('Please Create Territory to Proceed.', 'OK');
          this.router.navigate(['/postLaunch/services']);
          this.territorylistLoading = false;
        }
      }, (err) => {
        this.territorylistLoading = false;
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public addServiceLine() {
    setTimeout(() => {
      console.log(this.autoComplete);
      this.autoComplete.closePanel();
    });
    const dialogRef = this.dialog.open(ConfirmLabelDialogComponent, {
      data: {
        labelList: this.serviceLineList.map((cat) => cat.name.trim().toLowerCase()),
        title: 'Add Service Line',
        input: this.serviceLine.value
      },
      position: { top: '150px' },
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('data from dialog', result);
      if (result) {
        this.loading = true;
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          // token.tenantToken = 'system';
          this.assetService.addCategory(result, this.templateType, token).subscribe((res) => {
            console.log('addCategory Result : ', res);
            this.loading = false;
            if (res.success) {
              this.assetService.setServiceLinesLocal(undefined);
              this.helperService.openSnackBar(res.result.messageCode, 'OK');
              this.getServiceLineList(result);
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    });
  }

  public duplicateNameCheck(name, invokedFrom) {
    if (this.serviceSetupForm.get('serviceName').valid) {
      if (invokedFrom === 'finalSubmit') { this.loading = true; }
      console.log(name);
      if (this.serviceId && this.editService.name === name) {
        if (invokedFrom === 'finalSubmit') {
          this.duplicateCodeCheck(this.serviceSetupForm.value.serviceCode.trim(), invokedFrom);
        }
      } else {
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          this.serviceCatalogService.duplicateServiceNameCheck(name, token).subscribe((nameRes) => {
            this.loading = false;
            console.log(nameRes);
            if (nameRes.success) {
              nameRes.result.isExist ? this.serviceSetupForm.controls.serviceName.setErrors({ duplicate: true }) : this.serviceSetupForm.controls.serviceName.setErrors(null);
              if (invokedFrom === 'finalSubmit') {
                this.duplicateCodeCheck(this.serviceSetupForm.value.serviceCode.trim(), invokedFrom);
              }
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    } else {
      this.helperService.openSnackBar('Please Enter Valid Service Name', 'OK');
    }
  }

  public duplicateCodeCheck(code, invokedFrom) {
    if (code !== '') {
      if (invokedFrom === 'finalSubmit') { this.loading = true; }
      if (this.serviceId && this.editService.code === code) {
        if (invokedFrom === 'finalSubmit') {
          this.onSubmit();
        }
      } else {
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          this.serviceCatalogService.duplicateServiceCodeCheck(code, token).subscribe((codeRes) => {
            this.loading = false;
            console.log(codeRes);
            if (codeRes.success) {
              codeRes.result.isExist ? this.serviceSetupForm.controls.serviceCode.setErrors({ duplicate: true }) : this.serviceSetupForm.controls.serviceCode.setErrors(null);
              if (invokedFrom === 'finalSubmit') {
                this.onSubmit();
              }
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    } else {
      this.helperService.openSnackBar('Please Enter Service Code', 'OK');
    }
  }

  public serLineType() {
    setTimeout(() => {
      const serLine = this.serviceLineList.find((ser) => ser.name.toLowerCase() === this.serviceLine.value.toLowerCase().trim());
      this.serLineSelection(serLine);
    });
  }

  public serLineSelection(cat) {
    console.log(cat);
    if (cat) {
      this.serviceLine.patchValue(cat.name);
      this.selectedServiceLine = cat;
      console.log(cat);
      console.log(this.serviceLine.value);
    } else {
      // this.helperService.openSnackBar('Please Select Service Line From Suggestions', 'OK');
      this.selectedServiceLine = undefined;
      this.serviceLine.patchValue('');
    }
  }

  public addAsset() {
    if (!this.territorylistLoading) {
      this.secondSection = 'asset';
      this.activeTabIndex = 1;
    } else {
      this.helperService.openSnackBar('Loading Territory Data', 'Try Again');
    }
  }

  public addAssetOutput(event) {
    event.event === 'submit' ? this.getAssetTypesList() : console.log('asset close');
    this.secondSection = '';
    this.activeTabIndex = 0;
  }

  public addPricingSlab() {
    if (this.territoryList.length > 0) {
      this.secondSection = 'price';
      this.activeTabIndex = 1;
      this.editPriceIndex = -1;
    } else {
      this.helperService.openSnackBar('Please Select Territory', 'OK');
    }

  }
  public addPriceSlabOutput(event) {
    event.event === 'submit' ? this.prices = event.data : console.log('price close');
    this.secondSection = '';
    this.activeTabIndex = 0;
  }

  public editPricingSlab(index) {
    if (this.territoryList.length > 0) {
      this.secondSection = 'price';
      this.activeTabIndex = 1;
      this.editPriceIndex = index;
    } else {
      this.helperService.openSnackBar('Please Select Territory', 'OK');
    }
  }

  public deletePricingSlab(index) {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        discardAction: 'CANCEL',
        autoFocus: false,
        submitAction: 'REMOVE',
        title: 'Are You Sure ?',
        subTitle: this.helperService.getSymbolByCurrencyCode(this.prices[index].baseCurrency) +
          this.prices[index].measuringUnit.measureValue + '/' + this.prices[index].measuringUnit.measureUnit + ' Price will be Removed.'
      }
    });
    dialogRef.afterClosed().subscribe((selectedPoc) => {
      console.log('ConfirmationDialogComponent Result : ', selectedPoc);
      if (selectedPoc) {
        this.prices.splice(index, 1);
      }
    });
  }

  // Final submit
  public onSubmit() {
    console.log(this.serviceSetupForm.value);
    console.log(this.serviceLine.value);
    console.log(this.serviceLine.valid);
    if (this.serviceSetupForm.valid && this.serviceLine.valid) {
      let serviceObj = {
        service: {
          code: this.serviceSetupForm.value.serviceCode, // service code
          displayName: this.serviceSetupForm.value.serviceName, // service Name
          equipments: this.serviceSetupForm.value.assetType.map((id) => { return { id }; }), // asset Ids
          images: this.images,
          longBanner: this.serviceSetupForm.value.description,
          name: this.serviceSetupForm.value.serviceName, // service Name
          prices: this.prices,
          referenceIds: {
            categoryCode: this.selectedServiceLine.id, // service line id
            orgId: this.crossPlatformService.getOrgId().orgId
          },
          shortBanner: this.serviceSetupForm.value.serviceName, // service Name
          specification: this.documents, // Files
          tags: this.tags.toString(),
          territories: this.territoryList
        }
      };
      console.log(serviceObj);
      this.helperService.openSnackBar('Please wait..', 'Validating Service');

      if (this.prices.length > 0) {
        if (this.prices.findIndex((p) => p.invalid === true) === -1) {
          if (this.serviceSetupForm.valid) {
            this.loading = true;
            this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
              this.serviceId ? this.updateService(serviceObj, token) : this.addService(serviceObj, token);
            }, (err) => {
              console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
            });
          } else {
            this.helperService.openSnackBar('Please Fill Valid Data', 'OK');
          }
        } else {
          this.helperService.openSnackBar('Invalid Pricing Slab', 'OK');
        }
      } else {
        this.helperService.openSnackBar('Please Add Pricing Slab', 'OK');
      }
    } else {
      this.helperService.openSnackBar('Please Fill Valid Data', 'OK');
    }
  }
  public addService(serviceObj, token) {
    console.log('FINAL SERVICE CREATE :: ', serviceObj);
    this.serviceCatalogService.addService(serviceObj, token).subscribe((res) => {
      console.log('CREATE SERVICE RES ::', res);
      this.loading = false;
      this.helperService.openSnackBar('Service Added', 'OK');
      this.postLaunchComponent.getMasterServiceList();
      this.router.navigate(['/postLaunch/services']);
    }, (err) => {
      this.loading = false;
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public updateService(serviceObj, token) {
    let updatedObj = JSON.parse(JSON.stringify(this.editService));
    updatedObj.code = serviceObj.service.code;  // service code
    updatedObj.displayName = serviceObj.service.displayName; // service Name
    updatedObj.equipments = serviceObj.service.equipments;  // asset Ids
    updatedObj.longBanner = serviceObj.service.longBanner;
    updatedObj.name = serviceObj.service.name; // service Name
    updatedObj.prices = serviceObj.service.prices;
    updatedObj.referenceIds = serviceObj.service.referenceIds;
    updatedObj.shortBanner = serviceObj.service.shortBanner; // service Name
    updatedObj.specification = serviceObj.service.specification; // Files
    updatedObj.tags = serviceObj.service.tags;
    updatedObj.territories = this.territoryList;
    updatedObj.images = this.images;
    updatedObj.specification = this.documents;
    // territory DATA

    let finalObj = { orgId: this.crossPlatformService.getOrgId().orgId, service: updatedObj };
    console.log('FINAL SERVICE UPDATE :: ', finalObj);
    this.serviceCatalogService.updateService(finalObj, token).subscribe((res) => {
      this.postLaunchComponent.getMasterServiceList();
      console.log('UPDATE SERVICE RES ::', res);
      this.loading = false;
      if (res.success && res.result.messageCode === 'Unable to update Service') {
        this.helperService.openSnackBar('Service Updation Failed', 'OK');
      } else {
        this.helperService.openSnackBar('Service Updated', 'OK');
        this.router.navigate(['/postLaunch/services']);
      }
    }, (err) => {
      this.loading = false;
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public selectTerritory() {
    if (!this.territorylistLoading) {
      const dialogRef = this.dialog.open(TerritorySelectionDialogComponent, {
        maxWidth: '100%',
        width: '100%',
        height: '100%',
        data: { invokeFrom: 'service', globalTerritoryList: this.globalTerritoryList, existingTerritoryList: this.territoryList },
      });

      dialogRef.afterClosed().subscribe((territoryResult) => {
        console.log('territoryResult from dialog', territoryResult);
        if (territoryResult) {
          this.checkForInvalidPriceSlab(territoryResult.mapping);
          this.createTerritoryData(territoryResult.mapping);
        }
      });
    } else {
      this.helperService.openSnackBar('Loading Territory Data', 'Try Again');
    }
  }

  public createTerritoryData(territoryResult) {
    console.log('territoryResult', territoryResult);
    console.log(this.globalTerritoryList);
    if (territoryResult !== '') {
      let showTerritoryList = [];
      this.territoryList = territoryResult;
      let tempterritoryArray = JSON.parse(JSON.stringify(this.territoryList));
      // if (showTerritoryList.length === 0) {
      this.territoryList.forEach((territory, i) => {
        const terObj = this.globalTerritoryList.find((ter) => ter.territoryId === territory.id);
        if (terObj) { showTerritoryList.push(terObj.territoryName + ' (' + territory.territoryTree.length + ')'); }
      });
      // } else { this.exixtingTerritoryCheck(tempterritoryArray, showTerritoryList); }
      this.serviceSetupForm.patchValue({ territory: showTerritoryList });
    }
  }

  public checkForInvalidPriceSlab(territoryData) {
    console.log(territoryData);
    console.log('OLD : ', JSON.parse(JSON.stringify(this.prices)));
    this.prices.forEach((price) => {
      let newTerritoryArray = [];
      price.territories.forEach((priTer, i) => {
        const terDataObj = territoryData.find((t) => t.id === priTer.id);
        if (terDataObj) {
          priTer.territoryTree = priTer.territoryTree.filter((tTree) => terDataObj.territoryTree.findIndex((tObj) => tObj.nodeId === tTree.nodeId) > -1);
          if (priTer.territoryTree.length > 0) {
            // price.territories.splice(i, 1);
            newTerritoryArray.push(priTer);
          }
        } else {
          // price.territories.splice(i, 1);
        }
      });
      price.territories = newTerritoryArray;
      if (price.territories.length === 0) {
        price.invalid = true;
        this.helperService.openSnackBar('Invalid Price Due to Territory Changed', 'Please Update');
      } else {
        price.invalid = false;
      }
    });
    console.log('NEW : ', JSON.parse(JSON.stringify(this.prices)));
  }

}
