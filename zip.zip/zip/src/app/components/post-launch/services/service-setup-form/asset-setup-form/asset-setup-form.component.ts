import { TerritorySelectionDialogComponent } from './../../../territory-selection-dialog/territory-selection-dialog.component';
import { HelperService } from './../../../../../services/helper.service';
import { AssetService } from './../../../../../services/postLaunch/asset.service';
import { CrossPlatformService } from './../../../../../services/postLaunch/cross-platform.service';
import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog, MatAutocompleteTrigger } from '@angular/material';
import { ConfirmLabelDialogComponent } from '../../../../postLogin/common/confirm-label-dialog/confirm-label-dialog.component';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';

@Component({
  selector: 'service-asset-setup-form',
  templateUrl: './asset-setup-form.component.html',
  styleUrls: ['./asset-setup-form.component.css']
})
export class AssetSetupFormComponent implements OnInit {

  @Input() public globalTerritoryList;
  @Output() public outputData = new EventEmitter();

  @ViewChild('autoCompleteInput', { read: MatAutocompleteTrigger })
  public autoComplete: MatAutocompleteTrigger;

  public territoryListList = ['territory1', 'territory2', 'territory3', 'territory4'];
  public placeholders = {
    assetType: 'Asset Type',
    territoryLabel: 'Assign Territory',
    assetCatagory: 'Asset Category',
    assetTypeCode: 'Asset Type Code',
    description: 'Asset Type Description'
  };

  public templateType = 'assetTypeCatagory';

  public assetCatagory: FormControl;

  public selectedAssetCat;

  public filteredCats: Observable<any[]>;

  public assetCatagoryList = [];

  public assetsetupForm: FormGroup;

  public territoryList = [];

  public loading = true;

  public images = [];

  public documents = [];

  constructor(
    private fb: FormBuilder,
    public dialog: MatDialog,
    private crossPlatformService: CrossPlatformService,
    private assetService: AssetService,
    private helperService: HelperService
  ) {
    this.assetsetupForm = this.fb.group({
      assetType: new FormControl('', [Validators.required, Validators.maxLength(20)]),
      assetTypeCode: new FormControl(''),
      territory: new FormControl('', [Validators.required]),
      description: new FormControl('', [Validators.required, Validators.maxLength(160)])
    });
    this.assetCatagory = new FormControl('', [Validators.required]);
  }

  public ngOnInit() {
    this.getAssetCatagoryList(undefined);
  }

  public getAssetCatagoryList(preSelected) {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.assetService.getGetCategoryByLevel(this.templateType, token).subscribe((res) => {
        console.log('getGetCategoryByLevel : ', res);
        this.loading = false;
        if (res.success) {
          res.result.categories == null ? res.result.categories = [] : res.result.categories = res.result.categories;
          this.assetCatagoryList = res.result.categories;
          this.filteredCats = this.assetCatagory.valueChanges.pipe(startWith(''), map((cat) => cat ? this.filterCat(cat) : this.assetCatagoryList.slice()));
          if (preSelected) {
            this.assetCatagory.patchValue(preSelected);
            this.assetCatType();
          }
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public filterCat(name: string) {
    return this.assetCatagoryList.filter((cat) => cat.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  public assetCatType() {
    setTimeout(() => {
      const cat = this.assetCatagoryList.find((ser) => ser.name.toLowerCase() === this.assetCatagory.value.toLowerCase().trim());
      this.catSelection(cat);
    });
  }

  public catSelection(cat) {
    console.log(cat);
    if (cat) {
      this.assetCatagory.patchValue(cat.name);
      this.selectedAssetCat = cat;
      console.log(cat);
      console.log(this.assetCatagory.value);
    } else {
      // this.helperService.openSnackBar('Please Select Service Line From Suggestions', 'OK');
      this.selectedAssetCat = undefined;
      this.assetCatagory.patchValue('');
    }
  }

  public addAssetCatagory() {
    setTimeout(() => {
      console.log(this.autoComplete);
      this.autoComplete.closePanel();
    });
    const dialogRef = this.dialog.open(ConfirmLabelDialogComponent, {
      data: {
        labelList: this.assetCatagoryList.map((cat) => cat.name.trim().toLowerCase()),
        title: 'Asset Category',
        input: this.assetCatagory.value
      },
      position: { top: '150px' },
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('data from dialog', result);
      if (result) {
        this.loading = true;
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          // token.tenantToken = 'system';
          this.assetService.addCategory(result, this.templateType, token).subscribe((res) => {
            console.log('addCategory Result : ', res);
            this.loading = false;
            if (res.success) {
              this.helperService.openSnackBar(res.result.messageCode, 'OK');
              this.getAssetCatagoryList(result);
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    });
  }

  public duplicateNameCheck(name, invokedFrom) {
    if (this.assetsetupForm.get('assetType').valid) {
      if (invokedFrom === 'finalSubmit') { this.loading = true; }
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.assetService.duplicateAssetTypeNameCheck(name, token).subscribe((nameRes) => {
          this.loading = false;
          console.log(nameRes);
          if (nameRes.success) {
            nameRes.result.isExist ? this.assetsetupForm.controls.assetType.setErrors({ duplicate: true }) : this.assetsetupForm.controls.assetType.setErrors(null);
            if (invokedFrom === 'finalSubmit') {
              if (this.assetsetupForm.value.assetTypeCode !== '') {
                this.duplicateCodeCheck(this.assetsetupForm.value.assetTypeCode, 'finalSubmit');
              } else {
                this.onSubmit();
              }
            }
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public duplicateCodeCheck(code, invokedFrom) {
    if (invokedFrom === 'finalSubmit') { this.loading = true; }
    if (code !== '') {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.assetService.duplicateAssetTypeCodeCheck(code, token).subscribe((codeRes) => {
          this.loading = false;
          console.log(codeRes);
          if (codeRes.success) {
            codeRes.result.isExist ? this.assetsetupForm.controls.assetTypeCode.setErrors({ duplicate: true }) : this.assetsetupForm.controls.assetTypeCode.setErrors(null);
          }
          if (invokedFrom === 'finalSubmit') {
            this.onSubmit();
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public selectTerritory() {
    const dialogRef = this.dialog.open(TerritorySelectionDialogComponent, {
      maxWidth: '100%',
      width: '100%',
      height: '100%',
      data: { invokeFrom: 'service', globalTerritoryList: this.globalTerritoryList, existingTerritoryList: this.territoryList },
    });

    dialogRef.afterClosed().subscribe((territoryResult) => {
      if (territoryResult && territoryResult.mapping !== '') {
        let showTerritoryList = [];
        console.log('territoryResult', territoryResult);

        this.territoryList = territoryResult.mapping;
        let tempterritoryArray = JSON.parse(JSON.stringify(this.territoryList));
        // if (showTerritoryList.length === 0) {
        this.territoryList.forEach((territory, i) => {
          showTerritoryList.push(this.globalTerritoryList.find((ter) => ter.territoryId === territory.id).territoryName + ' (' + territory.territoryTree.length + ')');
        });
        // } else { this.exixtingTerritoryCheck(tempterritoryArray, showTerritoryList); }
        this.assetsetupForm.patchValue({ territory: showTerritoryList });
      }
    });
  }

  // public exixtingTerritoryCheck(tempTerritoryArray, showTerritoryList) {

  //   console.log(showTerritoryList);

  //   // tslint:disable-next-line:prefer-for-of
  //   for (let j = 0; j < showTerritoryList.length; j) {
  //     let isExistFlag = false;
  //     // tslint:disable-next-line:prefer-for-of
  //     for (let i = 0; i < tempTerritoryArray.length; i++) {
  //       if (showTerritoryList[j].includes(tempTerritoryArray[i].territoryName) === true) {
  //         showTerritoryList[j] = tempTerritoryArray[i].territoryName + ' (' + tempTerritoryArray[i].territoryCount + ')';
  //         isExistFlag = true;
  //         tempTerritoryArray.splice(i, 1); break;
  //       }
  //     }

  //     if (isExistFlag === false) {
  //       showTerritoryList.splice(j, 1);
  //     } else { j++; }
  //   }

  //   if (tempTerritoryArray.length > 0) {
  //     tempTerritoryArray.forEach((territory) => {
  //       showTerritoryList.push(territory.territoryName + ' (' + territory.territoryCount + ')');
  //     });
  //   }
  // }

  // description TO BE ADD
  public onSubmit() {
    console.log(this.assetsetupForm.value);
    console.log(this.assetCatagory.value);
    if (this.assetsetupForm.valid && this.assetCatagory.valid) {
      let assetBody = {
        assetType: {
          code: this.assetsetupForm.value.assetTypeCode, // asset type Code
          displayName: this.assetsetupForm.value.assetType, // asset type Name
          name: this.assetsetupForm.value.assetType, // asset type Name
          longBanner: this.assetsetupForm.value.description,
          shortBanner: this.assetsetupForm.value.assetType,
          territories: this.territoryList,
          referenceIds: {
            categoryCode: this.selectedAssetCat.id, // asset catagory ID
            orgId: this.crossPlatformService.getOrgId().orgId
          },
          images: this.images,
          specification: this.documents
        }
      };
      console.log('FINAL ASSET TYPE :::', assetBody);
      this.loading = true;
      this.helperService.openSnackBar('Adding Asset Type', 'Please Wait');
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.assetService.addAssetType(assetBody, token).subscribe((res) => {
          this.loading = false;
          console.log(res);
          if (res.success) {
            this.helperService.openSnackBar('Asset Type Added', 'OK');
            this.outputData.emit({ event: 'submit', data: null });
          } else {
            this.helperService.openSnackBar('Asset Type Addition Failed', 'OK');
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    } else {
      this.helperService.openSnackBar('Please Fill Valid Data', 'OK');
    }
  }

  public cancel() {
    this.outputData.emit({ event: 'cancel', data: null });
  }
}
