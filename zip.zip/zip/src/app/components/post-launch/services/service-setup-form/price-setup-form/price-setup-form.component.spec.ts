import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PriceSetupDialogComponent } from './price-setup-dialog.component';

describe('PriceSetupDialogComponent', () => {
  let component: PriceSetupDialogComponent;
  let fixture: ComponentFixture<PriceSetupDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PriceSetupDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PriceSetupDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
