import { TerritoryService } from './../../../../../services/postLaunch/territory.service';
import { HelperService } from './../../../../../services/helper.service';
import { MatDialog } from '@angular/material';
import { TerritorySelectionDialogComponent } from './../../../territory-selection-dialog/territory-selection-dialog.component';
import { Component, OnInit, Inject, Output, EventEmitter, Input, OnChanges } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'service-price-setup-form',
  templateUrl: './price-setup-form.component.html',
  styleUrls: ['./price-setup-form.component.css']
})
export class PriceSetupFormComponent implements OnChanges {

  @Input() public pricesSlabList;
  @Input() public serviceTerritorySelection;
  @Input() public editPriceIndex: number;
  @Input() public globalTerritoryList;
  @Output() public outputData = new EventEmitter();

  public prices = [];

  public placeholders = {
    UomCategoryLabel: 'UOM Category',
    UomLabel: 'UOM',
    UomValueLabel: 'UOM Value',
    CurrencyLabel: 'Currency',
    TerritoryLabel: 'Assign Territory',
    ValidFromLabel: 'Valid From',
    ValidToLabel: 'Valid To',
    IgstLabel: 'Enter Rate',
    CgstLabel: 'Enter Rate',
    SgstLabel: 'Enter Rate'
  };
  public servicesList = ['Service1', 'Service2', 'Service3', 'Service4'];

  public territoryList = [];

  public currency = ['INR'];

  public uomCatList = [{
    name: 'Area', uom: ['Acre']
  }, {
    name: 'Time', uom: ['Hour']
  }];

  public selectedUOMCat;
  public pricesetupForm: FormGroup;

  public validTill;

  constructor(
    private fb: FormBuilder,
    public dialog: MatDialog,
    private territoryService: TerritoryService,
    private helperService: HelperService,
  ) { }

  public ngOnChanges() {
    this.prices = JSON.parse(JSON.stringify(this.pricesSlabList));
    this.pricesetupForm = this.fb.group({
      uomCategory: new FormControl('', [Validators.required]),
      uom: new FormControl('', [Validators.required]),
      uomValue: new FormControl('', [Validators.required, Validators.pattern(/^(\d+)(?:\.\d{1,2})?$/)]),
      currency: new FormControl(this.currency[0], [Validators.required]),
      territory: new FormControl('', [Validators.required]),
      validFrom: new FormControl('', [Validators.required]),
      // validTo: new FormControl('', [Validators.required]),
      validTo: new FormControl({ value: '', disabled: true }, [Validators.required]),
      igst: new FormControl('', [Validators.required, Validators.pattern(/^(\d{1,2})(?:\.\d{1,2})?$/)]),
      cgst: new FormControl('', [Validators.required, Validators.pattern(/^(\d{1,2})(?:\.\d{1,2})?$/)]),
      sgst: new FormControl('', [Validators.required, Validators.pattern(/^(\d{1,2})(?:\.\d{1,2})?$/)]),
    });

    console.log(this.editPriceIndex, this.prices[this.editPriceIndex]);
    if (this.editPriceIndex >= 0) {
      this.prices[this.editPriceIndex].validFrom = new Date(this.prices[this.editPriceIndex].validFrom);
      this.prices[this.editPriceIndex].validTo = new Date(this.prices[this.editPriceIndex].validTo);

      this.getuom(this.prices[this.editPriceIndex].measuringUnit.measureType);
      this.createTerritoryData(this.prices[this.editPriceIndex].territories);

      this.pricesetupForm.get('validTo').enable();
      this.pricesetupForm.patchValue({
        uomCategory: this.prices[this.editPriceIndex].measuringUnit.measureType,
        uom: this.prices[this.editPriceIndex].measuringUnit.measureUnit,
        uomValue: this.prices[this.editPriceIndex].measuringUnit.measureValue,
        currency: this.prices[this.editPriceIndex].baseCurrency,
        validFrom: this.prices[this.editPriceIndex].validFrom,
        validTo: this.prices[this.editPriceIndex].validTo,
        igst: this.prices[this.editPriceIndex].igst,
        cgst: this.prices[this.editPriceIndex].cgst,
        sgst: this.prices[this.editPriceIndex].sgst
      });
    }
  }

  public validFromChange(validFrom) {
    console.log(validFrom);
    if (validFrom !== '') {
      this.pricesetupForm.get('validTo').enable();
    } else {
      this.pricesetupForm.get('validTo').disable();
    }
  }

  public getuom(value) {
    this.uomCatList.forEach((element) => {
      if (element.name === value) { this.selectedUOMCat = element.uom; }
    });
  }

  public selectTerritory() {
    const dialogRef = this.dialog.open(TerritorySelectionDialogComponent, {
      maxWidth: '100%',
      width: '100%',
      height: '100%',
      data: {
        invokeFrom: 'service',
        globalTerritoryList: this.territoryService.mappingToDefination(this.globalTerritoryList, this.serviceTerritorySelection),
        existingTerritoryList: this.territoryList
      },
    });

    dialogRef.afterClosed().subscribe((territoryResult) => {
      if (territoryResult) {
        this.createTerritoryData(territoryResult.mapping);
      }
    });
  }

  public createTerritoryData(territoryResult) {
    if (territoryResult !== '') {
      let showTerritoryList = [];
      console.log('territoryResult', territoryResult);

      this.territoryList = territoryResult;
      let tempterritoryArray = JSON.parse(JSON.stringify(this.territoryList));
      // if (showTerritoryList.length === 0) {
      this.territoryList.forEach((territory, i) => {
        showTerritoryList.push(this.globalTerritoryList.find((ter) => ter.territoryId === territory.id).territoryName + ' (' + territory.territoryTree.length + ')');
      });
      // } else { this.exixtingTerritoryCheck(tempterritoryArray, showTerritoryList); }
      this.pricesetupForm.patchValue({ territory: showTerritoryList });
    }
  }

  public onSubmit() {
    let priceObj = {
      baseCurrency: this.pricesetupForm.value.currency,
      pricingType: 'string',
      validFrom: this.pricesetupForm.value.validFrom.getTime(),
      validTo: this.pricesetupForm.value.validTo.getTime(),
      igst: this.pricesetupForm.value.igst,
      cgst: this.pricesetupForm.value.cgst,
      sgst: this.pricesetupForm.value.sgst,
      territories: this.territoryList,
      measuringUnit: {
        measureType: this.pricesetupForm.value.uomCategory,
        measureUnit: this.pricesetupForm.value.uom,
        measureValue: this.pricesetupForm.value.uomValue
      }
    };
    console.log(this.prices);
    console.log(this.pricesetupForm.valid);
    console.log(this.editPriceIndex);
    if (this.pricesetupForm.valid) {
      if (this.editPriceIndex >= 0) {
        this.prices[this.editPriceIndex] = priceObj;
      } else {
        this.prices.push(priceObj);
      }
      console.log(this.prices);
      if (this.priceDateValidation(this.prices)) {
        console.log(this.prices);
        this.outputData.emit({ event: 'submit', data: this.prices });
      } else {
        if (this.editPriceIndex === -1) { this.prices.pop(); }
        this.helperService.openSnackBar('Another price already exits with the same Time Slot with same Area', 'OK');
      }
    }
    console.log(this.pricesetupForm.value);
  }

  public priceDateValidation(list) {
    let validPrice = true;
    let priceList = [];
    list.forEach((price) => {
      let obj = { from: price.validFrom, to: price.validTo, territories: [] };
      price.territories.forEach((ter) => {
        ter.territoryTree.forEach((node) => { if (obj.territories.indexOf(node.nodeId) === -1) { obj.territories.push(node.nodeId); } });
      });
      priceList.push(obj);
    });
    for (let i = 0; i < priceList.length; i++) {
      const pi = priceList[i];
      for (let j = 0; j < priceList.length; j++) {
        const pj = priceList[j];
        console.log('i - ' + i + '   , j - ' + j);
        if (i === j) {
          console.log('skip');
          continue;
        } else {
          if (((pj.from < pi.from) || (pj.from > pi.to)) && ((pj.to < pi.from) || (pj.to > pi.to))) {
            console.log('j valid');
          } else {
            console.log(i + ' -' + j, ' INVALID');
            pj.territories.forEach((node) => {
              if (pi.territories.indexOf(node) > -1) {
                validPrice = false;
                console.log(node, '    ---------- ID MATCH');
              }
            });
          }
        }
      }
    }
    console.log(priceList);
    return validPrice;
  }

  public cancel() {
    this.outputData.emit({ event: 'cancel', data: null });
  }
}
