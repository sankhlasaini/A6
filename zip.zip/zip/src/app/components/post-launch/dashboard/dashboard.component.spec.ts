// import { DashboardComponent } from './dashboard.component';
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { NO_ERRORS_SCHEMA } from '@angular/core';
// import { CrossPlatformService } from './../../../services/postLaunch/cross-platform.service';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { MaterialModule } from './../../../material.module';
// // import { Router } from '@angular/router';
// import { RouterLintStubDirective } from './../../../../../testing/routerStubs';

// describe('DashboardComponent', () => {
//     let component: DashboardComponent;
//     let fixture: ComponentFixture<DashboardComponent>;
//     let crossPlatformService;
//     let crossPlatformServiceStub: any;
//     // class RouterStub {
//     //     public navigateByUrl(url: string) {
//     //         return url;
//     //     }
//     // }

//     beforeEach(async(() => {
//         crossPlatformServiceStub = {
//             getOrgId: () => ({ orgId: 'e8eeb6c4-4ad7-4a4a-bc88-c102b7c3518e' })
//         };
//         TestBed.configureTestingModule({
//             imports: [BrowserAnimationsModule, MaterialModule],
//             declarations: [DashboardComponent, RouterLintStubDirective],
//             providers: [{ provide: CrossPlatformService, useValue: crossPlatformServiceStub }],
//         })
//             .compileComponents();
//     }));

//     beforeEach(() => {
//         fixture = TestBed.createComponent(DashboardComponent);
//         component = fixture.componentInstance;
//         crossPlatformService = fixture.debugElement.injector.get(CrossPlatformService);
//         fixture.detectChanges();
//     });

//     it('should be created', () => {
//         crossPlatformService.getOrgId();
//         fixture.detectChanges();
//         expect(component).toBeTruthy();
//     });
// });
