import { EcoSystemService } from './../../../services/eco-system.service';
import { UserSetupService } from './../../../services/postLaunch/user-setup.service';
import { UserComponent } from './../user/user.component';
import { flyIn, fade, slideUp, slideUpEnter, flip, fadeEnter } from './../../../animations';
import { CrossPlatformService } from './../../../services/postLaunch/cross-platform.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'post-launch-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  animations: [flyIn, fade, slideUp, slideUpEnter, flip, fadeEnter]
})
export class DashboardComponent {

  public webMode;

  public dashboardAppsTemp = [
    { name: 'PROFILE', icon: '../../assets/images/svg/profile.svg', link: '/postLaunch/profile', active: true, actionRequired: ['Profile Details'] },
    { name: 'PARTNERS', icon: '../../assets/images/svg/partners.svg', link: '/postLaunch/partner', active: true, actionRequired: ['Manage Partners'] },
    // { name: 'PRODUCTS', icon: '../../assets/images/svg/product-service.svg', link: '/postLaunch/productBrandDashboard' , active : true },
    { name: 'TERRITORIES', icon: '../../assets/images/svg/territories.svg', link: '/postLaunch/territory', active: true, actionRequired: ['Manage Operating Territory'] },
    // { name: 'MY SELLERS', icon: '../../assets/images/svg/sellers.svg', link: '/postLaunch/mysellers' , active : true, actionRequired :[]  },
    // { name: 'MY BUYERS', icon: '../../assets/images/svg/buyers.svg', link: '/postLaunch/mybuyers'  , active : true, actionRequired :[] },
    { name: 'SERVICES', icon: '../../assets/images/svg/service.svg', link: '/postLaunch/services', active: true, actionRequired: ['Manage Services'] },
    { name: 'ASSETS', icon: '../../assets/images/svg/assets.svg', link: '/postLaunch/asset', active: true, actionRequired: ['Manage Assets'] },
    { name: 'ROLES', icon: '../../assets/images/svg/roles.svg', link: '/postLaunch/role', active: true, actionRequired: ['Manage Roles'] },
    { name: 'USERS', icon: '../../assets/images/svg/users.svg', link: '/postLaunch/user', active: true, actionRequired: ['Manage Users'] },
    // { name: 'DOCUMENTS', icon: '../../assets/images/svg/documents.svg', link: '/postLaunch' },
    // { name: 'SUBSCRIBE', icon: '../../assets/images/svg/subscription.svg', link: '/postLaunch' },
  ];

  public dashboardApps = [];
  public animationCount;

  constructor(
    private ecoSystemService: EcoSystemService,
    private crossPlatformService: CrossPlatformService,
    private userSetupService: UserSetupService
  ) {
    // this.dashboardAppsTemp.reverse();
    this.dashboardAppsAnimation(this.crossPlatformService.getOrgId(), this.dashboardAppsTemp);
    console.log('ID Object for this Profile', this.crossPlatformService.getOrgId());

    this.webMode = this.crossPlatformService.getWebMode();
    if (this.crossPlatformService.getWebMode() === undefined) {
      setTimeout(() => {
        this.webMode = this.crossPlatformService.getWebMode();
      }, 1500);
    }
  }

  public dashboardAppsAnimation(orgObj, modules) {
    const userListLocal = this.userSetupService.getUsersListLocal();

    if (userListLocal) {
      const loggedInUser = userListLocal.find((user) => user.partyId === orgObj.user_details.userTenancyIdentityId);
      console.log('loggedInUser :::; ', loggedInUser);
      if (loggedInUser) {
        let actions = [];
        loggedInUser.keyActions.forEach((act) => {
          // console.log(this.ecoSystemService.getActionLabelById(act.actionId));
          act.actionLabel ? actions.push(act.actionLabel) : actions.push(this.ecoSystemService.getActionLabelById(act.actionId));
        });
        loggedInUser.roles.forEach((rl) => {
          rl.enabledActions.forEach((act) => {
          // console.log(this.ecoSystemService.getActionLabelById(act.actionId));
          act.actionLabel ? actions.push(act.actionLabel) : actions.push(this.ecoSystemService.getActionLabelById(act.actionId));
          });
        });

        // console.log(actions);

        modules.forEach((app) => {
          app.active = true;
          // console.log(app.actionRequired);
          app.actionRequired.forEach((actionLabel) => {
            if (!actions.find((act) => act === actionLabel)) {
              app.active = false;
            }
          });

          //   if (orgObj.user.roles.includes('Account Admin') || orgObj.user.roles.includes('Account Support Admin')) {
          //     if (app.name !== 'TERRITORIES') {
          //       this.dashboardApps.push(app);
          //     }
          //   } else {
          //     if (app.name !== 'SERVICES' && app.name !== 'ASSETS' && app.name !== 'PRODUCTS') {
          //       this.dashboardApps.push(app);
          //     }
          //   }
        });
      }
    }
  }

}
