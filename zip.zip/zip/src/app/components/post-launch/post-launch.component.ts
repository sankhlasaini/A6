import { flyIn, slideUpEnter, fadeEnter, slideUp, flip } from './../../animations';
import { ErrorDialogComponent } from './common/error-dialog/error-dialog.component';
import { MatDialog } from '@angular/material';
import { ProfileService } from './../../services/profile.service';
import { PartnerService } from './../../services/postLaunch/partner.service';
import { HelperService } from './../../services/helper.service';
import { ProfileSetupService } from './../../services/postLaunch/profile-setup.service';
import { CrossPlatformService } from './../../services/postLaunch/cross-platform.service';
import { Component } from '@angular/core';
import { EcoSystemService } from '../../services/eco-system.service';
import { TerritoryService } from '../../services/postLaunch/territory.service';
import { AssetService } from '../../services/postLaunch/asset.service';
import { UserSetupService } from '../../services/postLaunch/user-setup.service';
import { ServiceCatalogService } from '../../services/postLaunch/service-catalog.service';

@Component({
  selector: 'app-post-launch',
  templateUrl: './post-launch.component.html',
  styleUrls: ['./post-launch.component.css'],
  animations: [flyIn, slideUpEnter, fadeEnter, slideUp, flip]
})
export class PostLaunchComponent {

  public orgID;
  public loadingOrg = true;
  public loadingTiles = true;
  public gotOrgId = false;
  public ecosystemHitCount = 0;

  // This is HARDCODED Ecosystem Id and will be Used only when No Ecosystem found for Given Ecosystem Id by APP
  public HARDCODED_DEFAULT_ECOSYSTEM_ID = 'ca42df72-3749-46c1-a92e-1a83d3d6a5af';

  constructor(
    private crossPlatformService: CrossPlatformService,
    private profileSetupService: ProfileSetupService,
    private helperService: HelperService,
    private partnerService: PartnerService,
    private ecoSystemService: EcoSystemService,
    private profileService: ProfileService,
    private territoryService: TerritoryService,
    private assetService: AssetService,
    private serviceCatalogService: ServiceCatalogService,
    private userSetupService: UserSetupService,
    public dialog: MatDialog) {

    const interval = setInterval(() => {
      // console.log('checking');
      if (localStorage.getItem('currentUserParty')) {
        clearInterval(interval);
        this.gotOrgId = true;
        console.log('App Mode : ', localStorage.getItem('mode'));
        if (localStorage.getItem('mode') !== 'web') {
          this.crossPlatformService.orgIdCheck(localStorage.getItem('currentUserParty')).subscribe((res) => {
            console.log('ORG ID CHECK : ', res);
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
          this.helperService.openSnackBar('Welcome', '');
        }
        this.crossPlatformService.setOrgId(JSON.parse(localStorage.getItem('currentUserParty')));
        this.orgID = this.crossPlatformService.getOrgId();
        this.crossPlatformService.setWebMode(false);
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          this.getServiceLines(token);
          this.getOrgProfile(this.orgID.orgId, token);
          this.getUsersList(this.orgID.orgId, token);
          // this.getPrimaryOrgTerritoryList(this.orgID.orgId, token);
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    }, 200);

    // setTimeout(() => {
    //   if (!this.gotOrgId) {
    //     this.orgID = this.crossPlatformService.getOrgId();
    //     console.log('\nTimeout for App. Loading Default OrgId', this.orgID.orgId);
    //     this.crossPlatformService.setWebMode(true);
    //     this.getOrgProfile(this.orgID.orgId);
    //   }
    // }, 1500);
  }

  public getOrgProfile(orgId, token) {
    if (token) {
      this.partnerService.findOrg([{ partyId: orgId }], token).subscribe((profileRes) => {
        console.log('Org Profile Result ', profileRes);
        if (profileRes.success && profileRes.result.length > 0) {
          if (profileRes.result[0].orgType === 'ROOT_ORG') {
            this.crossPlatformService.setRootOrgData(profileRes.result[0]);
            this.getMasterServiceList();
          } else {
            this.getRootOrg(profileRes.result[0].accountId, token);
          }
          this.crossPlatformService.setEcoProfileIds(profileRes.result[0].ecosystemId, profileRes.result[0].orgProfile.profileTemplateId);
          this.profileSetupService.setProfileSetup(profileRes.result, true);
          this.getEcosystemData(profileRes.result[0].ecosystemId, profileRes.result[0].orgProfile.profileTemplateId, token);
        } else {
          console.log('Organization Id is invalid');
          this.getOrgProfile(orgId, token);
          this.loadingOrg = false;
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    } else {
      this.openErrorDialog('Session Expired');
    }
  }

  public getUsersList(orgId, token) {
    this.userSetupService.getUserList(token, orgId, '').subscribe((userRes) => {
      if (userRes.success && userRes.result.length > 0) {
        console.log('USER LIST :: ', userRes.result);
        this.userSetupService.setUsersListLocal(userRes.result);
        this.getModulesActionData();
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getRootOrg(accountId, token) {
    this.partnerService.findOrg([{ accountId }], token).subscribe((res) => {
      console.log('getRootOrg RES : ', res);
      if (res.success) {
        this.crossPlatformService.setRootOrgData(res.result.find((party) => party.orgType === 'ROOT_ORG'));
        this.getMasterServiceList();
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getMasterServiceList() {
    const rootOrgObj = this.crossPlatformService.getRootOrgData();
    console.log('rootOrg from Local', rootOrgObj);
    if (rootOrgObj) {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.serviceCatalogService.getMasterListServices(0, 1000, rootOrgObj.partyId, token).subscribe((serviceRes) => {
          console.log('Master Services List Res : ', serviceRes.result);
          this.userSetupService.setAllServiceData(serviceRes.result);
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public getEcosystemData(ecosystemId, profileId, token) {
    this.ecoSystemService.getEcoSystemById(ecosystemId, token).subscribe((ecoRes) => {
      console.log('Ecosystem in Post Launch : ', ecoRes);
      this.ecosystemHitCount++;
      if (ecoRes.success) {
        if (ecoRes.result.length > 0) {
          this.crossPlatformService.setEcosystem(ecoRes.result[0]);
          this.profileService.getProfilesByEcoId(ecosystemId, token).subscribe((ecoProfileRes) => {
            console.log(ecoProfileRes);
            if (ecoProfileRes.success) {
              const profile = ecoProfileRes.result.find((p) => p.id === profileId);
              if (profile) {
                console.log('Ecosystem Profile in Post Launch : ', profile);
                this.crossPlatformService.setEcoSystemProfile(profile);
                this.loadingOrg = false;
              } else {
                console.log('Ecosystem Profile Not found in DV Admin Profile List');
                this.helperService.openSnackBar('No Profile Found', 'OK');
                this.openErrorDialog('No Profile Found');
              }
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        } else {
          console.log('Ecosystem Not found in DV Admin Ecosystem List');
          this.helperService.openSnackBar('No System Found', 'OK');
          if (this.ecosystemHitCount < 3) {
            this.getEcosystemData(ecosystemId, profileId, token);
          } else {
            this.openErrorDialog('No System Found');
          }
        }
      } else {
        if (this.ecosystemHitCount < 3) {
          this.getEcosystemData(ecosystemId, profileId, token);
        } else {
          this.openErrorDialog('No System Found');
        }
        console.log('Ecosystem Not found in DV Admin Ecosystem List');
        this.helperService.openSnackBar('No System Found', 'OK');

      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getModulesActionData() {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      token.tenantToken = 'system';
      this.ecoSystemService.getGlobalModulesAction(token).subscribe((res) => {
        console.log('Global Module Action Data', res);
        this.loadingTiles = false;
      }, (err) => {
        this.loadingTiles = false;
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getPrimaryOrgTerritoryList(orgId, token) {
    this.territoryService.retrieveTerritoriesByOrgId(token, orgId, 0, 100).subscribe((result) => {
      console.log('Primary Org Territory', result);
      if (result.success && result.result && result.result.territoryList) {
        this.territoryService.setPrimaryOrgTerritoryListLocal(result.result);
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getServiceLines(token) {
    this.assetService.getGetCategoryByLevel('serviceCatagory', token).subscribe((res) => {
      console.log('ServiceLines for Tenant : ', res);
      if (res.success) {
        this.assetService.setServiceLinesLocal(res.result);
      }
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public openErrorDialog(msg) {
    const dialogRef = this.dialog.open(ErrorDialogComponent, {
      data: [msg],
      disableClose: true,
      position: {
        top: '150px'
      }
    });
  }
}
