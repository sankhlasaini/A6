import { Router, ActivatedRoute } from '@angular/router';
import { ServiceCatalogService } from './../../../../services/postLaunch/service-catalog.service';
import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AssetService } from '../../../../services/postLaunch/asset.service';
import { CrossPlatformService } from '../../../../services/postLaunch/cross-platform.service';
import { MatDialog } from '@angular/material';
import { HelperService } from '../../../../services/helper.service';
import { UserSetupService } from '../../../../services/postLaunch/user-setup.service';
import { ProfileSetupService } from '../../../../services/postLaunch/profile-setup.service';

@Component({
  selector: 'asset-form',
  templateUrl: './asset-form.component.html',
  styleUrls: ['./asset-form.component.css']
})

export class AssetFormComponent {

  public assetForm: FormGroup;

  public placeholders = {
    assetIdLabel: 'Asset ID',
    assetTypeLabel: 'Asset Type',
    assetLocationLabel: 'Asset Current Location',
    assetOwnerLabel: 'Asset Owner',
    operatorNameLabel: 'Operator Name',
    workingConditionLabel: 'Working Condition',
    descriptionLabel: 'Asset Description',
    availableCapacity: 'Available Capacity'
  };

  public assetsTypeList = [];

  public assetsLocationList = [];

  public operatorList = [];

  public editAsset = false;

  public loading = true;

  public editAssetObj;

  constructor(
    private fb: FormBuilder,
    public dialog: MatDialog,
    private router: Router,
    private route: ActivatedRoute,
    private assetService: AssetService,
    public helperService: HelperService,
    private crossPlatformService: CrossPlatformService,
    private userSetupService: UserSetupService,
    private profileSetupService: ProfileSetupService
  ) {
    this.assetForm = this.fb.group({
      assetId: ['', [Validators.required, Validators.maxLength(20)]],
      assetType: ['', [Validators.required]],
      assetLocation: ['', [Validators.required]],
      assetOwner: ['', [Validators.maxLength(20)]],
      operator: ['', [Validators.required]],
      availableCapacity: ['', [Validators.required, Validators.max(24), Validators.pattern(/^[0-9]+$/)]],
      workingCondition: ['', [Validators.required]],
      description: ['', [Validators.maxLength(160)]],
    });

    console.log(this.assetForm.get('assetId'))

    if (this.route.snapshot.url[0].path === 'edit') {
      this.editAssetObj = this.assetService.getEditAsset();
      if (this.editAssetObj) {
        console.log('got asset for Edit : ', this.editAssetObj);
        this.editAsset = true;
        this.enableEditMode(this.editAssetObj);
      } else {
        console.log('NO asset for Edit');
        this.router.navigate(['/postLaunch/asset']);
      }
    } else {
      console.log('add Mode in Form');
    }
    this.getAssetTypesList();
    this.getOperatorList();
    this.getAssetLocations();
  }

  public enableEditMode(asset) {
    this.assetForm.patchValue({
      assetId: asset.assetId,
      assetOwner: asset.assetOwner,
      workingCondition: asset.workingCondition,
      description: asset.description,
      availableCapacity: asset.availableCapacity
    });
    this.assetForm.get('assetId').disable();
    this.assetForm.get('assetType').disable();
  }

  public getAssetTypesList() {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.assetService.getMasterListAssetTypes(0, 0, token).subscribe((res) => {
        console.log('Asset Type List Res', res);
        if (res.success) {
          this.assetsTypeList = res.result.assetType;
          if (this.editAsset && this.editAssetObj && this.editAssetObj.assetType) {
            let assetType = this.assetsTypeList.find((at) => at.id === this.editAssetObj.assetType);
            if (assetType) { this.assetForm.patchValue({ assetType: assetType.id }); }
          }
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getOperatorList() {
    const usersListLocal = this.userSetupService.getUsersListLocal();
    if (usersListLocal) {
      this.loading = false;
      this.operatorList = usersListLocal;
      if (this.editAsset && this.editAssetObj && this.editAssetObj.operator) {
        this.assetForm.patchValue({ operator: this.operatorList.find((user) => user.partyId === this.editAssetObj.operator.id) });
        console.log(this.assetForm.value);
      }
      console.log('userslist getting from local', usersListLocal);
    } else {
      console.log('userslist getting from db');
      const orgId = this.crossPlatformService.getOrgId().orgId;
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.userSetupService.getUserList(token, orgId, '').subscribe((res: any) => {
          console.log('operator', res);
          this.loading = false;
          if (res.success) {
            this.operatorList = res.result;
            if (this.editAsset && this.editAssetObj && this.editAssetObj.operator) {
              this.assetForm.patchValue({ operator: this.operatorList.find((user) => user.partyId === this.editAssetObj.operator.id) });
            }
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public getAssetLocations() {
    const profileRes = JSON.parse(JSON.stringify(this.profileSetupService.getProfileSetup().data));
    console.log(profileRes);
    if (profileRes[0]) {
      this.assetsLocationList = profileRes[0].orgProfile.contactPersons.map((loc) => loc.contactAddress.addressLabel);
      if (this.editAsset && this.editAssetObj && this.editAssetObj.currentLocation) {
        this.assetForm.patchValue({ assetLocation: this.assetsLocationList.find((loc) => loc === this.editAssetObj.currentLocation) });
      }
    }
  }

  public duplicateAssetCheck(assetId, invokedFrom) {
    console.log(this.assetForm.value);
    if (this.editAsset) {
      this.submitAsset();
    } else {
      if (assetId !== '' && assetId.length <= 20 && assetId.toLowerCase().trim() !== '') {
        if (invokedFrom === 'finalSubmit') { this.loading = true; }
        this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
          this.assetService.getAssetById(assetId.trim(), token).subscribe((asset) => {
            this.loading = false;
            console.log(asset);
            if (asset.success && asset.result.asset === null) {
              this.assetForm.controls.assetId.setErrors(null);
              if (assetId && invokedFrom === 'finalSubmit') {
                this.submitAsset();
              }
            } else {
              this.assetForm.controls.assetId.setErrors({ duplicate: true });
            }
          }, (err) => {
            console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
          });
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }
    }
  }

  public submitAsset() {
    const profileRes = JSON.parse(JSON.stringify(this.profileSetupService.getProfileSetup().data));
    console.log(profileRes[0]);
    if (this.assetForm.valid) {

      let finalObj;
      let obj;
      if (this.editAsset) {
        // EDIT MODE
        this.editAssetObj.assetOwner = this.assetForm.value.assetOwner;
        this.editAssetObj.availableCapacity = this.assetForm.value.availableCapacity;
        this.editAssetObj.currentLocation = this.assetForm.value.assetLocation;
        // this.editAssetObj.assetType = this.assetForm.value.assetType;
        this.editAssetObj.operator = { id: this.assetForm.value.operator.partyId, mobileNo: this.assetForm.value.operator.mobile, name: this.assetForm.value.operator.name };
        this.editAssetObj.workingCondition = this.assetForm.value.workingCondition;
        this.editAssetObj.manager = { id: profileRes[0].partyId, mobileNo: profileRes[0].mobile, name: profileRes[0].name };
        this.editAssetObj.description = this.assetForm.value.description;
        delete this.editAssetObj.image;
        finalObj = this.editAssetObj;
      } else {
        // NEW ASSET SAVE MODE
        obj = {
          allocatedDates: [],
          assetId: this.assetForm.value.assetId,
          assetImage: '',
          assetOwner: this.assetForm.value.assetOwner,
          assetStatus: 'ACTIVE',
          assetType: this.assetForm.value.assetType,
          availableCapacity: this.assetForm.value.availableCapacity,
          currentLocation: this.assetForm.value.assetLocation,
          description: this.assetForm.value.description,
          manager: { id: profileRes[0].partyId, mobileNo: profileRes[0].mobile, name: profileRes[0].name },
          operator: { id: this.assetForm.value.operator.partyId, mobileNo: this.assetForm.value.operator.mobile, name: this.assetForm.value.operator.name },
          workingCondition: this.assetForm.value.workingCondition
        };
        finalObj = obj;
      }
      console.log('Asset Obj Final : ', finalObj);
      this.loading = true;
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.assetService.saveAsset(finalObj, token).subscribe((res) => {
          console.log('saveAsset', res);
          this.loading = false;
          if (res.success && res.result.body === 'SUCCESS_ASSET_SAVED') {
            this.helperService.openSnackBar('Asset Saved sucessfully', 'OK');
            this.router.navigate(['/postLaunch/asset']);
          } else {
            this.helperService.openSnackBar('Something went wrong while creating asset', 'Try Again');
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    } else {
      //  form is not valid
      this.helperService.openSnackBar('Please Fill Valid Details', 'OK');
    }
  }

}
