import { HelperService } from './../../../../services/helper.service';
import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';

@Component({
  selector: 'asset-list-card',
  templateUrl: './asset-list-card.component.html',
  styleUrls: ['./asset-list-card.component.css']
})
export class AssetListCardComponent implements OnChanges {

  @Input() public inputData;
  @Output() public outputData = new EventEmitter();

  public assetTypes = [];

  constructor(
    public helperService: HelperService
  ) { }

  public myFilter = (d: Date): boolean => {
    const day = d.getTime();
    return !this.containsObject(day, this.inputData.allocatedDates);
  }

  public ngOnChanges() {
    if (this.inputData.allocatedDates == null) { this.inputData.allocatedDates = []; }
    console.log(this.inputData, );
  }

  public menuAction1() {
    this.outputData.emit({ action: 'edit', data: this.inputData });
  }
  public cardClick() {
    this.outputData.emit({ action: 'view', data: this.inputData });
  }

  public containsObject(obj, list) {
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < list.length; i++) {
      const val1 = new Date(list[i].value);
      const val2 = new Date(obj);
      if ('' + val1.getDate() + val1.getMonth() + val1.getFullYear() === '' + val2.getDate() + val2.getMonth() + val2.getFullYear()) {
        return true;
      }
    }
    return false;
  }
}
