import { ServiceCatalogService } from './../../../services/postLaunch/service-catalog.service';
import { CrossPlatformService } from './../../../services/postLaunch/cross-platform.service';
import { AssetService } from './../../../services/postLaunch/asset.service';
import { MatDialog } from '@angular/material';
import { slideUp, slideDown } from './../../../animations';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services',
  templateUrl: './asset.component.html',
  styleUrls: ['./asset.component.css'],
  animations: [slideUp, slideDown]
})

export class AssetComponent implements OnInit {

  public assetsList = [];

  public pageSize = 100;

  public loadMore = true;

  public assetsTypeList = [];

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private assetService: AssetService,
    private crossPlatformService: CrossPlatformService,
    private serviceCatalogService: ServiceCatalogService
  ) { }

  public ngOnInit() {
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.assetService.getMasterListAssetTypes(0, 0, token).subscribe((res) => {
        console.log('Asset Type List Res', res);
        if (res.success) {
          this.assetsTypeList = res.result.assetType;
          this.getAssetList(0);
        }
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }, (err) => {
      console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
    });
  }

  public getAssetList(pageStartIdx) {
    console.log(pageStartIdx, ' - ', this.pageSize + pageStartIdx);
    const paramObject = {
      workingCondition: 'BOTH',
      managerId: null,
      assetType: null,
      pageStartIdx,
      pageSize: this.pageSize
    };

    if (this.loadMore) {
      this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
        this.assetService.getAllAsset(paramObject, token).subscribe((res: any) => {
          console.log(res);
          if (res.success && res.result.assets !== null) {
            res.result.assets.forEach((asset) => {
              const assetType = this.assetsTypeList.find((at) => at.id === asset.assetType);
              if (assetType) {
                asset.assetTypeLabel = assetType.name;
                if (assetType.images && assetType.images.length > 0) {
                  console.log(assetType.images);

                  const image = this.serviceCatalogService.findImage(assetType.images[0].id);
                  if (image) {
                    asset.image = image.base64;
                  } else {
                    this.serviceCatalogService.downloadFile(assetType.images[0].id, token).subscribe((imgRes) => {
                      this.serviceCatalogService.storeImage(assetType.images[0].id, imgRes.result);
                      asset.image = this.serviceCatalogService.findImage(assetType.images[0].id).base64;
                    });
                  }
                }
              }
              this.assetsList.push(asset);
            });
            if (this.assetsList.length < this.pageSize) {
              this.loadMore = false;
            }
          } else {
            this.loadMore = false;
          }
        }, (err) => {
          console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
        });
      }, (err) => {
        console.log('ERRRRRRRRRRRRRRR', JSON.parse(err.message));
      });
    }
  }

  public assetCardEvent(cardEvent) {
    switch (cardEvent.action) {
      case 'edit':
        this.editAsset(cardEvent.data);
        break;
      case 'view':
        // this.viewService(cardEvent.data);
        break;
      default:
        break;
    }
  }

  public editAsset(asset) {
    this.assetService.setEditAsset(asset);
    this.router.navigate(['/postLaunch/asset/edit']);
  }
}
