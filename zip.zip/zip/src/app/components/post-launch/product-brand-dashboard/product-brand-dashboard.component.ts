import { BottomSheetDialogComponent } from './../common/bottom-sheet-dialog/bottom-sheet-dialog.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-product-brand-dashboard',
  templateUrl: './product-brand-dashboard.component.html',
  styleUrls: ['./product-brand-dashboard.component.css']
})
export class ProductBrandDashboardComponent implements OnInit {
  public showList = true;
  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }
  public openDialog() {
    const dialogRef = this.dialog.open(BottomSheetDialogComponent, {
      width: '100%',
      maxWidth: '100%',
      data: {
        title: 'Add By Form',
        title1: 'Add From DV MasterList',
        action1: { label: 'Product Form ', icon: 'fa fa-file-text', color: '#0b89d1', action: '' },
        action2: { label: 'Brand Org Form', icon: 'fa fa-file-text', color: '#4ba205', action: '', type: 'excel' },
        action3: { label: 'Product', icon: 'fa fa-plus-circle', color: '#0b89d1', action: '' },
        action4: { label: 'Brand', icon: 'fa fa-plus-circle', color: '#0b89d1', action: '' },
        type: 'products and Brands',
        downloadTemplate: false,
        selection: false
      },
      position: { bottom: '0' },
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('Result from MAP', result);
      if (result) {
        this.showList = false;
        setTimeout(() => {
          this.showList = true;
        }, 100);
      }
    });
  }

}
