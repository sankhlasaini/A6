import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductBrandDashboardComponent } from './product-brand-dashboard.component';

describe('ProductBrandDashboardComponent', () => {
  let component: ProductBrandDashboardComponent;
  let fixture: ComponentFixture<ProductBrandDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductBrandDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductBrandDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
