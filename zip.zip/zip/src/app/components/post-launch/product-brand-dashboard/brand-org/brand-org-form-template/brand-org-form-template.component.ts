import { Component, OnInit, ViewEncapsulation, Inject, OnChanges } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validator, Validators } from '@angular/forms';

@Component({
  selector: 'app-brand-org-form-template',
  templateUrl: './brand-org-form-template.component.html',
  styleUrls: ['./brand-org-form-template.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class BrandOrgFormTemplateComponent implements OnInit, OnChanges {
  public brandLoading: boolean;
  public brand: FormControl;
  public brandOrgForm: FormGroup;
  public brandTouched = false;
  public selectedBrand;
  public filteredBrands;
  public addBrand;
  public brandOrgFormData;
  constructor( @Inject(FormBuilder) public fb: FormBuilder,
  ) {
  }
  public ngOnInit() {
    this.brandOrgForm = this.fb.group({
      brandOrganisation: ['', [Validators.required]],
      brand: '',
      code: '',
      description: '',
      margin: ''

    });
  }
  public ngOnChanges() { }
  public onSave() {
    this.brandOrgFormData = {
      brandOrgName: this.brandOrgForm.value.brandOrganisation,
      brandNames: [{ brandName: this.brandOrgForm.value.brand }],
      code: this.brandOrgForm.value.code,
      margin: this.brandOrgForm.value.margin,
      // fileAttachments: [{this.brandOrgForm.value}],
      description: this.brandOrgForm.value.description
    };
    this.brandTouched = true;
    console.log(this.brandOrgFormData);

  }

  public imageReducer(val) {
    console.log();
  };

  public fileUpload(val) {
    console.log();
  }

}
