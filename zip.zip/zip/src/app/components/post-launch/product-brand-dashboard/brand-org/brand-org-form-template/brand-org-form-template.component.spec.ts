import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrandOrgFormTemplateComponent } from './brand-org-form-template.component';

describe('BrandOrgFormTemplateComponent', () => {
  let component: BrandOrgFormTemplateComponent;
  let fixture: ComponentFixture<BrandOrgFormTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrandOrgFormTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrandOrgFormTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
