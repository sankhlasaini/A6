import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllBrandOrgListComponent } from './all-brand-org-list.component';

describe('AllBrandOrgListComponent', () => {
  let component: AllBrandOrgListComponent;
  let fixture: ComponentFixture<AllBrandOrgListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllBrandOrgListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllBrandOrgListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
