import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrandOrgComponent } from './brand-org.component';

describe('BrandOrgComponent', () => {
  let component: BrandOrgComponent;
  let fixture: ComponentFixture<BrandOrgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrandOrgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrandOrgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
