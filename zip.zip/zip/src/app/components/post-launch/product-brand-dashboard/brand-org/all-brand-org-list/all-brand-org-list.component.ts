import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-all-brand-org-list',
  templateUrl: './all-brand-org-list.component.html',
  styleUrls: ['./all-brand-org-list.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AllBrandOrgListComponent {

  public overlapTrigger = false;

  public config: SwiperOptions = {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    spaceBetween: 0,
    slidesPerView: 'auto',
    grabCursor: true,
  };
  public brandOrgList = [
    {
      brandOrgName: 'HeroMotors',
      brandName: ['A', 'B'],
      currencyIcon: 'fa fa-inr',
      amount: 14000, UPCImage: ''
    }];
  public sortList = ['Newest First', 'Oldest First', 'Highest Order Amount', 'Lowest Order Amount'];

  constructor() { }

}
