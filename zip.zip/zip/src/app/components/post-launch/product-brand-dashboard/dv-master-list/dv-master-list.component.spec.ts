import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DvMasterListComponent } from './dv-master-list.component';

describe('DvMasterListComponent', () => {
  let component: DvMasterListComponent;
  let fixture: ComponentFixture<DvMasterListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DvMasterListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DvMasterListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
