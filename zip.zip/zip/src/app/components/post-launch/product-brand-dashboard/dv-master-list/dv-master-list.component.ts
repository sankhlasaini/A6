import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-dv-master-list',
  templateUrl: './dv-master-list.component.html',
  styleUrls: ['./dv-master-list.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DvMasterListComponent {
  public brandOrgList = [
    {
      bOrgName: 'ITC',
      brand: [
        { name: 'A', prodcut: ['B', 'C'] },
        { name: 'A11', prodcut: ['B11', '11C'] },
        { name: 'A12', prodcut: ['B12', 'C23'] },
        { name: 'A13', prodcut: ['B13', 'C34'] }
      ]
    },
    {
      bOrgName: 'ITC1', brand: [{ name: 'A1', prodcut: ['B1', 'C1'] }]
    },
    {
      bOrgName: 'ITC2', brand: [{ name: 'A2', prodcut: ['B2', 'C2'] }]
    },
    {
      bOrgName: 'ITC3', brand: [{ name: 'A3', prodcut: ['B3', 'C3'] }]
    },
    {
      bOrgName: 'ITC4', brand: [{ name: 'A4', prodcut: ['B3', 'C3'] }]
    },
    {
      bOrgName: 'ITC5', brand: [{ name: 'A5', prodcut: ['B3', 'C3'] }]
    },
    {
      bOrgName: 'ITC6', brand: [{ name: 'A6', prodcut: ['B3', 'C3'] }]
    },
    {
      bOrgName: 'ITC7', brand: [{ name: 'A7', prodcut: ['B3', 'C3'] }]
    },
    {
      bOrgName: 'ITC8', brand: [{ name: 'A8', prodcut: ['B3', 'C3'] }]
    },
    {
      bOrgName: 'ITC9', brand: [{ name: 'A9', prodcut: ['B3', 'C3'] }]
    },
  ];

}
