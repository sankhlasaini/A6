import { BottomSheetDialogComponent } from './../../common/bottom-sheet-dialog/bottom-sheet-dialog.component';
import { Component } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {

  public showList = true;

  constructor(public dialog: MatDialog) { }
  // dialog
  public openDialog() {
    let dialogWidth;
    Number(window.screen.width) > 450 ? dialogWidth = '40%' : dialogWidth = '100%';

    const dialogRef = this.dialog.open(BottomSheetDialogComponent, {
      width: dialogWidth,
      maxWidth: '100%',
      data: {
        title: 'Add Product Using :',
        action1: { label: 'Product Form', icon: 'fa fa-file-text', color: '#0b89d1', action: '' },
        action2: { label: 'Excel Upload', icon: 'fa fa-file-excel-o', color: '#4ba205', action: '', type: 'excel' },
        type: 'product',
        downloadTemplate: true,
        selection: true
      },
      position: { bottom: '0' },
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('Result from MAP', result);
      if (result) {
        this.showList = false;
        setTimeout(() => {
          this.showList = true;
        }, 100);
      }
    });
  }
}
