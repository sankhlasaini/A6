import { ImageFullViewDialogComponent } from './../../../common/image-full-view-dialog/image-full-view-dialog.component';
import { ProductTemplateService } from './../../../../../services/product-template.service';
import { HelperService } from './../../../../../services/helper.service';
import { CrossPlatformService } from './../../../../../services/postLaunch/cross-platform.service';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { EcoSystemService } from './../../../../../services/eco-system.service';
import { Component, ViewChild, OnInit, Inject, ElementRef, AfterViewChecked } from '@angular/core';
import { ProductService } from './../../../../../services/postLaunch/product.service';

@Component({
  selector: 'app-view-product-dialog',
  templateUrl: './view-product-dialog.component.html',
  styleUrls: ['./view-product-dialog.component.css']
})
export class ViewProductDialogComponent {

  public selectedImg: any;
  public description = [];
  public active1: any;
  public active: any;
  public product: any;
  public documents = [];
  public loading = true;
  public imageSize = {};
  public placeholders = {
    unitsLabel: 'unit',
    descriptionLabel: 'description',
  };
  public imageUrl;
  public fileUrl;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ViewProductDialogComponent>,
    private dialog: MatDialog,
    private productService: ProductService,
    private productTemplateService: ProductTemplateService,
    private ecoSystemService: EcoSystemService,
    private crossPlatformService: CrossPlatformService,
    private helperService: HelperService
  ) {
    const orgIdObj = this.crossPlatformService.getOrgId();
    this.productService.getTemplateById(this.data.productId).subscribe((result) => {
      console.log('Product Result JSON : ', result);
      this.product = result.result.productCatalog;
      // Testing
      const sentense = 'snbdjsdjsdjsdhsmndksjd. hdsushdushdushudhds? jhdjshdjshdhdisdhsidsid! hdusgdusgdusdgusdusgdusgd.';
      const pattern = new RegExp('[.!?\\s][.!?]*(?:[.!?](?![\'"]?\\s|$)[.!?]*)*[.!?]?[\'"]?(?=\\s|$)');
      this.description = this.product.description.split(pattern);
      if (this.product.attachments !== null) {
        this.imageUrl = '/productCatalogue/downloadFile/?fileId=' + this.product.attachments[0].attachmentId;
      }
      console.log(this.imageUrl);

      if (this.product.documentReferenceId != null && this.product.documentReferenceId !== '') {
        this.documents.push({
          productDocumentId: this.product.documentReferenceId
        });
      }
      // const data = this.getimage();
      if (this.product.templateId) {
        this.productTemplateGetServiceCall(orgIdObj.ecoSystemId, this.product.templateId);
      }
    });
  }

  public changeimage(image) {
    this.selectedImg = image;
    this.active1 = 'active';
  }

  public productTemplateGetServiceCall(ecoSystemRefId, templateId) {
    console.log('body in  product-form ', ecoSystemRefId, templateId);
    this.productTemplateService.getProductTemplateFromDB(ecoSystemRefId, templateId).subscribe((res) => {
      console.log('getProductTemplateFromDB in VIEW PRODUCT RES : ', res);
      if (res == null || res.result.error) {
        console.log('Template Error Redireting to Product List');
        this.helperService.openSnackBar('Template Error', 'Try Another');
        this.close();
      } else {
        // const productTemp =
        const attributes = res.result.attributes;
        attributes.forEach((element) => {
          switch (element.name) {
            case 'Product Description':
              this.placeholders.descriptionLabel = element.fieldLabel;
              break;
            default:
              break;
          }
          this.loading = false;
        });
      }
    });
  }

  public downloadDocument(id) {
    console.log(id);
    const url = this.fileUrl + '/' + id;
    window.location.href = url;
  }

  public viewFullImage() {
    let dialogRef;
    const image = new Image();
    // tslint:disable-next-line:max-line-length
    const path = '/productCatalogue/downloadFile/?fileId=' + this.product.attachments[0].attachmentId;
    console.log(path);
    if (path) {
      dialogRef = this.dialog.open(ImageFullViewDialogComponent, {
        width: '100%',
        height: '100%',
        data: path,
        disableClose: false
      });
    }
  }

  public close() {
    this.dialogRef.close();
  }

  // getimage() {
  //   const image = new Image();
  //   // tslint:disable-next-line:max-line-length
  //   const path = 'https://testprofacade.apps.platform.deltaverge.com/api/product/getFile/' + this.product.UPCImage;
  //   // console.log(path);
  //   image.src = path;

  //   const promise = new Promise((resolve, reject) => {
  //     image.onload = function () {
  //       const imgHeight = image.height;
  //       const imgWidth = image.width;
  //       const imageSize = { imgHeight: imgHeight, imgWidth: imgWidth }
  //       if (imageSize != null) { resolve(imageSize); } else { reject('ERROR'); }
  //     };
  //   })
  //     .then(
  //     (data) => {
  //       // console.log(data);
  //       this.imageSize = data;
  //       return data;
  //     },
  //     (err) => { console.log(err); }
  //     );
  // }
}
