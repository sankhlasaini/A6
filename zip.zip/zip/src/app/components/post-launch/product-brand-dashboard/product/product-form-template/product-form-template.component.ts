import { CropImageDialogComponent } from './../../../common/crop-image-dialog/crop-image-dialog.component';
import { BrandOrgDialogComponent } from './../brand-org-dialog/brand-org-dialog.component';
import { HelperService } from './../../../../../services/helper.service';
import { CrossPlatformService } from './../../../../../services/postLaunch/cross-platform.service';
import { TerritoryService } from './../../../../../services/postLaunch/territory.service';
import { EcoSystemService } from './../../../../../services/eco-system.service';
import { ProductTemplateService } from './../../../../../services/product-template.service';
import { ProductService } from './../../../../../services/postLaunch/product.service';

import { Logger } from 'protractor/built/logger';
import { log } from 'util';
import { element } from 'protractor';
import { forEach } from '@angular/router/src/utils/collection';
import { Router, ActivatedRoute } from '@angular/router';
import { Attribute, Component, Input, OnChanges, OnInit } from '@angular/core';
import { Inject, Injectable } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validator, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { startWith, map } from 'rxjs/operators';

@Component({
  selector: 'app-product-form-template',
  templateUrl: './product-form-template.component.html',
  styleUrls: ['./product-form-template.component.css']
})
export class ProductFormTemplateComponent implements OnInit, OnChanges {
  public flag = 0;
  @Input() public productTemp;
  public userForm: FormGroup;
  public nameError = false;
  public productCodeError = false;
  public uomCategoryTouched = false;
  public uomTouched = false;
  public productIdValue;
  public decodedString;
  public dialogResult;
  public productImages = [];
  public productDocuments = [];
  public brandLoading = false;
  public imageName;
  public documentName;
  public tags = [];
  public uploadedFileId;
  public uploadedImageId;
  public imageId;
  public fileId;
  public showImage = true;
  public showFile = true;
  public products = {
    productTemplates: []
  };
  public fileUrl;
  public categoryLevel = 1;
  public selectedUOM;
  public selectedBrand;
  public touch = true;
  public loading = true;
  public currency = ['INR', 'USD'];
  public uomCat = [
    {
      name: 'Volume',
      uom: ['Litre', 'Gallons', 'Cusecs']
    },
    {
      name: 'Weight',
      uom: ['Kgs', 'Lbs', 'Ounces', 'Gms']
    },
    {
      name: 'Length',
      uom: ['Meters', 'Feet', 'Inches']
    },
    {
      name: 'Area',
      uom: ['Sqmt', 'Sqft', 'Acre']
    },
    {
      name: 'Count',
      uom: ['Nos', 'Pair', 'Dozen']
    },
    {
      name: 'Time',
      uom: ['Seconds', 'Minutes', 'Hours']
    },
    {
      name: 'Storage',
      uom: ['GB', 'MB', 'KB']
    }
  ];
  public BrandDetails = [
    {
      bOrgName: 'Samsung',
      brandName: ['mobile', 'Laptop']
    },
    {
      bOrgName: 'Sony',
      brandName: ['sony1', 'sony2', 'sony3', 'sony3']
    }
  ];

  public validFrom;
  public validTill;

  public tagName = '';
  public placeholders = {
    productLabel: 'Product/Service',
    categoryL1Label: 'Category L1',
    categoryL2Label: 'Category L2',
    categoryL3Label: 'Category L3',
    categoryL4Label: 'Category L4',
    categoryL5Label: 'Category L5',
    categoryCodeLabel: 'Category Code',
    productCodeLabel: 'Product/Service Code',
    descriptionLabel: 'Description',
    brandOrgLabel: 'Brand Organisation Name',
    brandLabel: 'Brand',
    uomCategoryLabel: 'UOM Category',
    unitsLabel: 'Units',
    uomLabel: 'UOM',
    igstLabel: 'Enter Rate',
    cgstLabel: 'Enter Rate',
    sgstLabel: 'Enter Rate',
    marginLabel: 'Margin',
    rateLabel: 'Rate',
    currencyLabel: 'Currency',
    validFromLabel: 'Valid From',
    validTillLabel: 'Valid Till',
    productImagesLabel: 'Images',
    productDocumentsLabel: 'Documents',
    typeLabel: 'Type',
    tagsLabel: 'Tags'
  };

  public addBrand = false;
  public brandCtrl: FormControl;
  public brandOrganisation: FormControl;
  public filteredBrands: any;
  public filteredBrandsOrgs: any;
  public brandOrgName = [];
  public brandTouched = false;
  public companyId;
  public brands = [];
  public brandFullList = [];
  public templateId;
  public ecosystemId;
  public addBrandFilter = [];
  public imageCount;
  public imageArray = [];
  public showImageArray = [];

  constructor(
    public dialog: MatDialog,
    private router: Router,
    private route: ActivatedRoute,
    @Inject(FormBuilder) public fb: FormBuilder,
    public productService: ProductService,
    public productTemplateService: ProductTemplateService,
    private ecoSystemService: EcoSystemService,
    private territoryService: TerritoryService,
    private crossPlatformService: CrossPlatformService,
    private helperService: HelperService
  ) {
    const orgIdObj = this.crossPlatformService.getOrgId();
    this.companyId = orgIdObj.orgId;
    this.ecosystemId = orgIdObj.ecoSystemId;
    console.log('companyId', this.companyId);
    this.BrandDetails.forEach((brandOrg) => {
      this.brandOrgName.push(brandOrg.bOrgName);
      console.log('brandOrg', this.brandOrgName);

    });
    this.uomCat = this.uomCat.sort((a, b) => (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0));
    this.getBrandsList();
    this.brandCtrl = new FormControl();
    this.brandOrganisation = new FormControl();
    this.filteredBrandsOrgs = this.brandOrganisation.valueChanges.pipe(startWith(null),
      map((brandOrg) => this.addBrandFilter = this.filterBrandOrgs(brandOrg)));

    console.log('this.filteredBrandsOrgs.length', this.filteredBrandsOrgs);

    this.productTemplateGetServiceCall(this.ecosystemId);
  }

  public ngOnInit() {
    console.log('Template ID : ', this.route.snapshot.params['templateId']);
  }
  // Add tags in Product
  public addTag() {
    let exist = false;
    this.tags.forEach((tag) => {
      if (tag.toLowerCase() === this.tagName.toLowerCase()) {
        this.helperService.openSnackBar('Tag Already Exists', 'Try Another');
        exist = true;
      }
    });
    if (!exist) {
      this.tags.push(this.tagName);
      this.tagName = '';
      // console.log(this.tags);
      this.helperService.openSnackBar('Tag Created', 'OK');
    }
  }

  // Delete tags in Product
  public delTag(tag) {
    this.tags.splice(this.tags.indexOf(tag), 1);
    this.helperService.openSnackBar('Tag Removed', 'OK');
  }
  public brandOrgForm() {
    const dialogRef = this.dialog.open(BrandOrgDialogComponent, {
      width: '90%',
      height: '50%',
      data: {
        title: 'NEW BRAND',
        bOrg: 'Brand Organisation name',
        brand: 'Brand Name',
        code: 'Code',
        image: ''
      },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      // this.dialogResult = result.image;
      console.log('in componnent', result);
      // this.imageUpload(result.cropedImageFileObj);
    });
  }

  // filter brands
  public filterBrands(brand: string) {
    let result = [];
    let val = brand;
    if (val) { val = val.trim(); }
    result = val ?
      this.selectedBrand.filter((s) => s.toLowerCase().indexOf(val.toLowerCase()) === 0)
      : this.selectedBrand;
    // if (result.length >= 0 && val != null) {
    //   this.addBrand = true;
    //   for (const res of result) {
    //     console.log(res.toLowerCase().trim() === (val.toLowerCase().trim()));
    //     if (res.toLowerCase().trim() === (val.toLowerCase().trim())) {
    //       this.addBrand = false;
    //     }
    //     break;
    //   }
    // }
    console.log('result for brand filter', result);

    return result;
  }
  public filterBrandOrgs(brandOrgs: string) {
    let result1 = [];
    console.log('brandOrgName', this.brandOrgName);

    let val = brandOrgs;
    console.log('val is ', val);
    if (val) { val = val.trim(); }
    result1 = val ?
      this.brandOrgName.filter((s) => s.toLowerCase().indexOf(val.toLowerCase()) === 0)
      : this.brandOrgName;
    console.log('result is ', result1);
    console.log('result is ', result1.length);
    return result1;
  }

  // update brand
  public updateBrand(val) {
    this.brandLoading = true;
    this.productService.addBrand(val.trim(), this.companyId).subscribe((result) => {
      console.log('Add brand result', result);
      this.helperService.openSnackBar('Brand Created', val.trim());
      this.getBrandsList();
      this.addBrand = false;
    });
  }

  // get brand List
  public getBrandsList() {
    this.brandFullList = [];
    this.brands = [];
    this.productService.getBrandsForProduct(this.companyId).subscribe((result1) => {
      console.log('Brand List RES :: ', result1);
      result1.result.forEach((element) => {
        if (element.name) {
          this.brands.push(element.name);
          this.brandFullList.push(element);
        }
      });
      this.brandLoading = false;
    });
  }

  // get UOM for selected UOM category
  public getUOM(val) {
    this.uomCat.forEach((element) => {
      if (element.name === val) {
        this.selectedUOM = element.uom;
      }
    });
  }

  public getBrand(val) {
    // this.userForm.value.brandCtrl = '';
    this.brandCtrl.setValue('');
    this.selectedBrand = [];
    console.log('val is brand ', val);
    this.BrandDetails.forEach((element) => {
      if (element.bOrgName === val) {
        this.selectedBrand = element.brandName;
      }
    });
    console.log('selectedBrand', this.selectedBrand);
    this.filteredBrands = this.brandCtrl.valueChanges.pipe(startWith(null),
      map((brand) => this.filterBrands(brand)));
    console.log('selectedBrand', this.filteredBrands.length);
  }

  public openDialog(event) {
    if (event.srcElement.files[0]) {
      const dialogRef = this.dialog.open(CropImageDialogComponent, {
        width: '100%',
        height: '100%',
        data: event,
        disableClose: true
      });
      dialogRef.afterClosed().subscribe((result) => {
        this.dialogResult = result.image;
        console.log('in componnent', result);
        // this.imageUpload(result.cropedImageFileObj);
      });
    }
  }

  public imageUpload(files) {
    this.imageCount = files.length;
    console.log('files', files);
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < files.length; i++) {
      this.imageReducer(files[i]);
    }
  }

  public imageReducer(originalImage) {
    // this.productImages = [];
    if (originalImage.type === 'image/jpeg' || originalImage.type === 'image/jpg' || originalImage.type === 'image/png') {
      this.brandLoading = true;
      console.log('Original Image in ProductFormTemplate ', originalImage);
      // Read in file
      const file = originalImage;
      // Load the image
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (red: any) => {
        const image = new Image();
        image.src = red.target.result;
        image.onload = (imgResult: any) => {
          const canvas = document.createElement('canvas');
          const maxImagewidth = 414; // TODO : pull max size from a site config
          const maxImageHeight = 736;
          let originalImageWidth = image.width;
          let originalImageHeight = image.height;
          const ratio = originalImageHeight / originalImageWidth;
          if (originalImageWidth > originalImageHeight) {
            if (originalImageWidth > maxImagewidth) {
              originalImageHeight *= maxImagewidth / originalImageWidth;
              originalImageWidth = maxImagewidth;
            }
          } else {
            if (originalImageHeight > maxImageHeight) {
              originalImageWidth *= maxImageHeight / originalImageHeight;
              originalImageHeight = maxImageHeight;
            }
          }
          canvas.width = originalImageWidth;
          canvas.height = originalImageHeight;
          // console.log(originalImageWidth, originalImageHeight);
          // tslint:disable-next-line:max-line-length
          canvas.getContext('2d').drawImage(image, 0, 0, originalImageWidth, originalImageHeight);
          const imageUrl = canvas.toDataURL('image/jpeg');
          // Convertion to Blob;
          const imgB64 = imageUrl;
          const img = imgB64.split(',')[1];
          const byteCharacters = atob(img);
          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);
          const blob = new Blob([byteArray], { type: file.type });
          // tslint:disable-next-line:max-line-length
          const newResizedImage = new File([blob], file.name, { type: file.type, lastModified: Date.now() });
          console.log('newResizedImage', newResizedImage);

          if (this.imageArray.length === 0) {
            this.imageArray.push(newResizedImage);
          } else {
            if (this.imageCount > 0) {
              this.imageArray.push(newResizedImage);
              this.imageCount--;
              console.log('imagecount', this.imageCount);
              console.log('array', this.imageArray);
            }
          }

          if (this.imageCount === 1) {
            this.productService.uploadImage(this.imageArray).subscribe((result) => {
              console.log(result);
              this.imageArray = [];
              this.showImageArray = result['attachments'];
              console.log(this.showImageArray);
            });
          }
        };
      };
    } else {
      this.helperService.openSnackBar('Image Format is not correct', 'OK');
    }
  }

  public fileUpload(event) {
    if (event.srcElement.files.length !== 0) {
      this.brandLoading = true;
      console.log('event', event.srcElement.files);
      this.productService.uploadDocument(event.srcElement.files[0]).subscribe((result) => {
        this.brandLoading = false;
        this.uploadedFileId = result.result.referenceId;
        if (result) {
          this.helperService.openSnackBar('File Uploaded Successfully', 'OK');
        } else {
          this.helperService.openSnackBar('File Not Uploaded', 'Try Again');
        }
      });
    }
  }

  public validateProductName(productName) {
    console.log('this.productTemp.name', this.productTemp.name);
    this.nameError = false;
    if (productName.trim().length > 0) {
      this.nameError = false;
      if (productName.trim() === this.productTemp.name) {
        this.nameError = false;
      } else {
        const body = {
          productName: productName.trim(),
          ecosystemId: this.ecosystemId, companyId: this.companyId
        };
        this.productService.duplicateNameCheck(body).subscribe((result) => {
          console.log(result);
          if (result.result.messageCode === 'Success' && result.result.isExist === true) {
            // this.userForm.get('product').setErrors;
            console.log('already exist');
            this.helperService.openSnackBar('Product Name already exist!', 'Try Another');
            this.nameError = true;
          } else {
            this.nameError = false;
          }
        });
      }
    }
    // this.products.productTemplates.forEach((element) => {
    //   if (product.toLowerCase().trim() === element.name.toLowerCase().trim()) {
    //     this.nameError = true;
    //   }
    // });
  }

  public validateProductCode(productCode) {
    // console.log('productCode', productCode);
    console.log('this.productTemp.EAN13Code', this.productTemp.EAN13Code);
    this.productCodeError = false;
    if (productCode.trim().length > 0) {
      this.productCodeError = false;
      if (productCode.trim() === this.productTemp.EAN13Code) {
        this.productCodeError = false;
      } else {
        const body = { productCode: productCode.trim(), companyId: this.companyId };
        this.productService.duplicateProductCodeCheck(body).subscribe((result) => {
          console.log(result);
          if (result.result.messageCode === 'Success' && result.result.isExist === true) {
            // this.userForm.get('product').setErrors;
            console.log('already exist');
            this.helperService.openSnackBar('Product Code already exist!', 'Try Another');
            this.productCodeError = true;
          } else {
            this.productCodeError = false;
          }
        });
      }
    }
    // this.products.productTemplates.forEach((element) => {
    //   if (product.toLowerCase().trim() === element.name.toLowerCase().trim()) {
    //     this.nameError = true;
    //   }
    // });
  }

  public removeImage() {
    this.uploadedImageId = '';
    this.showImage = false;
  }

  public removeFile() {
    console.log('inside file');
    this.uploadedFileId = '';
    this.showFile = false;
  }

  // public validateProductCode(productCode) {
  //   this.productCodeError = false;
  //   this.products.productTemplates.forEach((element) => {
  //     if (productCode.toLowerCase().trim() === element.EAN13Code.toLowerCase().trim()) {
  //       this.productCodeError = true;
  //     }
  //   });
  // }

  public productTemplateGetServiceCall(ecoId) {
    if (!ecoId) {
      this.router.navigate(['/postLaunch/productBrandDashboard/product']);
    } else {
      console.log('getProductTemplateFromDB BODY : ',
        ecoId, this.route.snapshot.params['templateId']);
      this.productTemplateService.getProductTemplateFromDB(ecoId, this.route.snapshot.params['templateId'])
        .subscribe((res) => {
          console.log('Product Template Result : ', res);

          if (res == null || res.result.error) {
            console.log('Template Error Redireting to Product List');
            this.helperService.openSnackBar('Template Error', 'Try Another');
            this.router.navigate(['/postLaunch/productBrandDashboard/product']);
          } else {
            // const productTemp =
            const attributes = res.result.attributes;
            attributes.forEach((element) => {
              switch (element.name) {
                case 'Product Name':
                  this.placeholders.productLabel = element.fieldLabel;
                  break;
                case 'Product Code':
                  this.placeholders.productCodeLabel = element.fieldLabel;
                  break;
                case 'Product Description':
                  this.placeholders.descriptionLabel = element.fieldLabel;
                  break;
                case 'Brand Name':
                  this.placeholders.brandLabel = element.fieldLabel;
                  break;
                case 'Type':
                  this.placeholders.typeLabel = element.fieldLabel;
                  break;
                case 'Tags':
                  this.placeholders.tagsLabel = element.fieldLabel;
                  break;
                case 'Category L1':
                  this.placeholders.categoryL1Label = element.fieldLabel;
                  break;
                case 'Category L2':
                  this.placeholders.categoryL2Label = element.fieldLabel;
                  break;
                case 'Category L3':
                  this.placeholders.categoryL3Label = element.fieldLabel;
                  break;
                case 'Valid From':
                  this.placeholders.validFromLabel = element.fieldLabel;
                  break;
                case 'Valid Till':
                  this.placeholders.validTillLabel = element.fieldLabel;
                  break;
                case 'Product Image(s)':
                  this.placeholders.productImagesLabel = element.fieldLabel;
                  break;
                case 'Price':
                  this.placeholders.rateLabel = element.fieldLabel;
                  break;
                case 'Currency':
                  this.placeholders.currencyLabel = element.fieldLabel;
                  break;
                case 'UOM Category':
                  this.placeholders.uomCategoryLabel = element.fieldLabel;
                  break;
                case 'UOM':
                  this.placeholders.uomLabel = element.fieldLabel;
                  break;
                case 'UOM Value':
                  this.placeholders.unitsLabel = element.fieldLabel;
                  break;
                default:
                  break;
              }
              this.loading = false;
            });
          }
        });
    }
  }

  public ngOnChanges() {
    this.showImageArray = [];
    console.log('Product JSON for EDIT :: ', this.productTemp);
    if (!this.productTemp.UOM) {
      this.productTemp.UOM = { category: '', value: '', units: '' };
    }

    this.productIdValue = this.productTemp.productId;
    // console.log('data', this.productTemp.templateId);
    this.imageId = this.productTemp.UPCImage;
    this.fileId = this.productTemp.documentReferenceId;
    let splittedTag = [];
    if (this.productTemp.tags) {
      splittedTag = this.productTemp.tags.split(',');
      this.tags = splittedTag;
    }
    if (this.productTemp.validFrom === undefined || this.productTemp.validFrom == null) {
      this.validFrom = undefined;
    } else {
      this.validFrom = new Date(this.productTemp.validFrom);
    }
    if (this.productTemp.validTill === undefined || this.productTemp.validTill == null) {
      this.validTill = undefined;
    } else {
      this.validTill = new Date(this.productTemp.validTill);
    }
    console.log('Valid Form : ', this.productTemp.validFrom);

    if (!this.productTemp.currency) {
      this.productTemp.currency = 'INR';
    }
    this.getUOM(this.productTemp.UOM.category);
    this.userForm = this.fb.group({
      product: [this.productTemp.name, [Validators.required]],
      categoryL1: this.productTemp.category,
      categoryL2: this.productTemp.categoryL2,
      categoryL3: this.productTemp.categoryL3,
      categoryL4: this.productTemp.categoryL4,
      categoryL5: this.productTemp.categoryL5,
      categoryCode: this.productTemp.categoryCode,
      productCode: this.productTemp.EAN13Code,
      description: this.productTemp.description,
      // brand: this.productTemp.specification.companyName,
      uomCategory: [this.productTemp.UOM.category, [Validators.required]],
      units: [this.productTemp.UOM.units,
      [Validators.required, Validators.pattern('[0-9]+(\.\[0-9]{2})?')]],
      uom: [this.productTemp.UOM.value, [Validators.required]],
      rate: [this.productTemp.price,
      [Validators.required, Validators.pattern('[0-9]+(\.\[0-9]{2})?')]],
      currency: this.productTemp.currency,
      igst: this.productTemp.igst,
      cgst: this.productTemp.cgst,
      sgst: this.productTemp.sgst,
      margin: this.productTemp.margin,
      brandOrganisation: this.productTemp.brandOrganisation,
      tags: [this.tags],
      // poductImage: [this.productTemp.productImage],
      // productDocument: [this.productTemp.productDocument]
    });
    this.brandCtrl.setValue(this.productTemp.specification.companyName);
    if (this.productTemp.UPCImage) {
      this.productImages.push(this.productTemp.UPCImage);
      // this.uploadedImageId = this.productTemp.UPCImage;
    }
    if (this.productTemp.attachments.length > 0) {
      this.showImageArray = this.productTemp.attachments;
    }
    if (this.productTemp.documentReferenceId) {
      this.productDocuments.push(this.productTemp.documentReferenceId);
    }
    console.log(this.productDocuments);
  }

  public getBrandId(brandName) {
    let result = '';
    this.brandFullList.forEach((brand) => {
      if (brandName === brand.name) {
        result = brand.id;
      }
    });
    return result;
  }

  // THIS is FINAL SAVE BTN
  public onSave() {
    console.log('userForm', this.userForm.value.validFrom);
    const orgId = this.crossPlatformService.getOrgId().orgId;
    this.brandTouched = true;
    this.uomCategoryTouched = true;
    this.uomTouched = true;
    let brandError = true;
    // console.log(this.productIdValue);
    // console.log(this.brandCtrl.value);
    this.userForm.value.tags = this.tags;
    this.userForm.value.brand = this.brandCtrl.value;
    let TagsAsString = '';
    if (this.userForm.value.tags) {
      TagsAsString = this.userForm.value.tags.toString();
    }
    if (!this.userForm.valid || this.nameError || this.brandCtrl.value.length === 0) {
      this.helperService.openSnackBar('Please Fill Required Fields', 'OK');
    } else {
      console.log('BRAND NAME :::::', this.brandCtrl.value);
      console.log(this.brands);
      this.brands.forEach((brand) => {
        // console.log(brand);
        if (brand.toLowerCase().trim() === this.brandCtrl.value.toLowerCase().trim()) {
          brandError = false;
        }
      });
      // console.log('BRAND NAME ::', this.brandCtrl.value);
      if (true) {
        const newProduct = {
          ecosystemId: this.ecosystemId,
          templateId: this.route.snapshot.params['templateId'],
          EAN13BarcodeImage: '',
          EAN13Code: this.userForm.value.productCode,
          UOM: {
            category: this.userForm.value.uomCategory,
            value: this.userForm.value.uom,
            units: this.userForm.value.units
          },
          UNSPSC: '',
          UPCImage: this.uploadedImageId,
          UPCNumber: '',
          category: this.userForm.value.categoryL1,
          categoryCode: this.userForm.value.categoryCode,
          categoryLevels: '',
          code: this.route.snapshot.params['templateId'],
          countryOfOrigin: '',
          currency: this.userForm.value.currency,
          description: this.userForm.value.description,
          features: '',
          documentReferenceId: this.uploadedFileId,
          inStock: true,
          name: this.userForm.value.product,
          price: this.userForm.value.rate,
          productId: '',
          attachments: this.showImageArray,
          specification: {
            companyId: orgId,
            companyName: this.userForm.value.brand,
            brandId: this.getBrandId(this.userForm.value.brand),
            consumerRating: '',
            height: '',
            length: '',
            specificationId: '',
            website: '',
            weight: '',
            width: '',
          },
          subCategory: '',
          validFrom: this.validFrom,
          validTill: this.validTill,
          variants: '',
          tags: TagsAsString,
          igst: this.userForm.value.igst,
          cgst: this.userForm.value.cgst,
          sgst: this.userForm.value.sgst,
          margin: this.userForm.value.margin,
          brandOrganisation: this.userForm.value.brandOrganisation
        };
        console.log('new product', newProduct);
        if (this.productIdValue.length === 0) {
          this.productService.addProduct(newProduct).subscribe((result) => {
            this.helperService.openSnackBar('Product Created', 'OK');
            this.router.navigate(['/postLaunch/productBrandDashboard/product']);
            console.log('my result', result);
          });
        } else {
          console.log('With Product Id on Edit', this.productIdValue.length);
          newProduct.productId = this.productIdValue;
          if (newProduct.UPCImage === undefined) {
            newProduct.UPCImage = this.imageId;
          }
          if (newProduct.documentReferenceId === null ||
            newProduct.documentReferenceId === undefined) {
            newProduct.documentReferenceId = this.fileId;
          }
          console.log('With Product on Edit', newProduct);
          this.productService.updateProduct(newProduct).subscribe((result) => {
            this.helperService.openSnackBar('Product Updated', 'OK');
            this.router.navigate(['/postLaunch/productBrandDashboard/product']);
            console.log('my result', result);
          });
        }
      } else {
        // this.helperService.openSnackBar('Please Select OR ADD Brand', 'OK');
      }
    }
  }
}
