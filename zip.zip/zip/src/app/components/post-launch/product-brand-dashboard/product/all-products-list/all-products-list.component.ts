import { FilterProductDialogComponent } from './../filter-product-dialog/filter-product-dialog.component';
import { CrossPlatformService } from './../../../../../services/postLaunch/cross-platform.service';
import { ProductService } from './../../../../../services/postLaunch/product.service';
import { ViewProductDialogComponent } from './../view-product-dialog/view-product-dialog.component';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-all-products-list',
  templateUrl: './all-products-list.component.html',
  styleUrls: ['./all-products-list.component.css']
})
export class AllProductsListComponent {

  public config: SwiperOptions = {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    spaceBetween: 0,
    slidesPerView: 'auto',
    grabCursor: true,
  };
  public loading = true;
  public totalCount = 0;
  public pageSize = 10;
  public display = [];
  public productImages = [];
  public overlapTrigger = false;
  public sortBy = 'Newest First';
  public sortList = ['Newest First', 'Oldest First', 'Highest Order Amount', 'Lowest Order Amount'];
  public orgId;
  public imageUrl;
  public accessToken;

  constructor(
    public productService: ProductService, private crossPlatformService: CrossPlatformService,
    private router: Router, public dialog: MatDialog) {
    const orgIdObj = this.crossPlatformService.getOrgId();
    console.log('orgIdObj', orgIdObj);
    this.orgId = orgIdObj.orgId;
    this.getProductByPageSize(0);
  }

  public sortByFunc(sortBy) {
    this.sortBy = sortBy;
  }

  // getting list of product based on startIndex and pageSize
  public getProductByPageSize(pageStartIdx) {
    const indexData = { orgId: this.orgId, pageStartIdx, pageSize: this.pageSize };
    this.crossPlatformService.checkPartyAccessToken().subscribe((token) => {
      this.productService.getProductList(indexData, token).subscribe((result) => {
        console.log('---------------------------', result);
        this.accessToken = token.accessToken;
        if (result.success) {
          this.loading = false;
          this.totalCount = result.result.totalProductsCount.count;
          this.display = result.result.product;
        } else {
          console.log('NO RESULT FROM PRODUCT LIST SERVICE');
        }
      });
    });
  }

  // view full detail of product
  public viewProduct(productId) {
    let dialogWidth;
    Number(window.screen.width) > 450 ? dialogWidth = '40%' : dialogWidth = '100%';
    const dialogRef = this.dialog.open(ViewProductDialogComponent, {
      width: dialogWidth,
      height: '100%',
      data: { productId },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
    });
  }

  // navigate to edit product page
  public editProduct(pId) {
    this.productService.getTemplateById(pId).subscribe((res) => {
      const tId = res.result.productCatalog.templateId;
      if (tId !== null) {
        this.router.navigate(['/postLaunch/productBrandDashboard/editProduct', JSON.stringify(pId), tId]);
      } else {
        // this.openSnackBar('This Product do not have Template Id', 'OK');
        this.router.navigate(['/postLaunch/productBrandDashboard/editProduct', JSON.stringify(pId), 'a85e9bc6-9dc7-404e-bc2b-89c520810b8f']);
      }
    });
  }

  public openDialog() {
    const dialogRef = this.dialog.open(FilterProductDialogComponent, {
      width: '100%',
      height: '100%',
      data: '',
      disableClose: true
    });

    // dialogRef.afterClosed().subscribe(result => {
    //   console.log('data from dialog', result);
    //   if (result) {
    //     this.selectedAreas = result;
    //     this.toggleCheckbox();
    //   }
    // });

  }
}
