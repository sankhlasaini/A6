import { Component } from '@angular/core';
@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {

  public productTemp = {
    productId: '',
    name: '',
    category: '',
    subCategory: '',
    price: '',
    currency: '',
    description: '',
    inStock: true,
    countryOfOrigin: '',
    features: '',
    variants: '',
    code: '',
    categoryCode: '',
    categoryLevels: '',
    validFrom: undefined,
    validTill: undefined,
    tags: null,
    specification: {
      specificationId: '',
      companyId: '',
      companyName: '',
      website: '',
      consumerRating: '',
      weight: '',
      width: '',
      length: '',
      height: ''
    },
    attachments: [],
    UNSPSC: '',
    UPCNumber: '',
    UPCImage: '',
    EAN13Code: '',
    EAN13BarcodeImage: '',
    UOM: {
      category: '',
      value: '',
      units: ''
    }
  };
}
