import { ProductService } from './../../../../../services/postLaunch/product.service';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent {

  public id;
  public productTemp;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductService
  ) {
    this.id = JSON.parse(route.snapshot.params['id']);
    console.log('id -------', this.id);
    if (this.id) {
      this.productService.getTemplateById(this.id).subscribe((res) => {
        console.log('Product Template Response for EDIT :', res);
        this.productTemp = res.result.productCatalog;
        if (!this.productTemp) {
          this.router.navigate(['/postLaunch/productBrandDashboard/product']);
        }
      });
    }
  }
}
