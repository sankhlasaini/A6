import { FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Component, OnInit, ViewEncapsulation, Inject } from '@angular/core';

@Component({
  selector: 'app-brand-org-dialog',
  templateUrl: './brand-org-dialog.component.html',
  styleUrls: ['./brand-org-dialog.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class BrandOrgDialogComponent implements OnInit {
  public newBrandOrgForm: FormGroup;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any, private dialogRef: MatDialogRef<BrandOrgDialogComponent>,
    @Inject(FormBuilder) public fb: FormBuilder) { }

  public ngOnInit() {
    this.newBrandOrgForm = this.fb.group({
      brandOrgName: [''],
      brand: [''],
      code: ['']
    });
  }
  public close() {
    this.dialogRef.close();
  }

}
