import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrandOrgDialogComponent } from './brand-org-dialog.component';

describe('BrandOrgDialogComponent', () => {
  let component: BrandOrgDialogComponent;
  let fixture: ComponentFixture<BrandOrgDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrandOrgDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrandOrgDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
