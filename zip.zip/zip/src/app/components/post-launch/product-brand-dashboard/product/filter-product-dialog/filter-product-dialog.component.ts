import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from './../../../../../services/postLaunch/product.service';

@Component({
  selector: 'app-filter-product-dialog',
  templateUrl: './filter-product-dialog.component.html',
  styleUrls: ['./filter-product-dialog.component.css']
})
export class FilterProductDialogComponent {
  public filterTypes = ['Brands', 'Color', 'Coming Soon'];
  public selectedFilterType = 'Brands';
  public brandSelection = [
    { name: 'filter1', checked: false },
    { name: 'filter2', checked: false },
    { name: 'filter3', checked: false },
    { name: 'filter4', checked: false },
    { name: 'filter5', checked: false },
  ];
  public colorSelection = [
    { name: 'color1', checked: false },
    { name: 'color1', checked: false },
    { name: 'color1', checked: false },
  ];
  public filterList = [];

  constructor(
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<FilterProductDialogComponent>, public productService: ProductService) {
    this.filterList.forEach((element) => {
      element.checked = false;
    });
    this.productService.getAllBrandList()
      .subscribe(
      (brandList) => {
        brandList.result.forEach((element) => {
          if (element.name) {
            this.filterList.push({ name: element.name, checked: false });
          }
        });
      });
  }

  public onApply() {
    this.dialogRef.close();
  }
  public toggle(item) {
    if (item.checked) {
      item.checked = false;
    } else {
      item.checked = true;
    }
  }
  public cancel() {
    this.dialogRef.close();
  }
  public clearAll() {
    this.dialogRef.close();
  }
  public selectType(filter) {
    this.selectedFilterType = filter;
    switch (filter) {
      case 'Brands':
        this.filterList = this.brandSelection;
        break;
      case 'Color':
        this.filterList = this.colorSelection;
        break;
    }
  }
}
