import { CrossPlatformService } from './../../services/postLaunch/cross-platform.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component } from '@angular/core';

@Component({
  selector: 'post-launch-url',
  templateUrl: './post-launch-url.component.html',
  styleUrls: ['./post-launch-url.component.css']
})
export class PostLaunchUrlComponent {

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private crossPlatformService: CrossPlatformService
  ) {
    console.log('GOT OrgId From URL :: ', this.route.snapshot.params['orgId']);
    // this.crossPlatformService.setOrgId({ orgId: this.route.snapshot.params['orgId'] });
    localStorage.setItem('orgID', JSON.stringify({ orgId: this.route.snapshot.params['orgId'] }));
    localStorage.setItem('mode', 'web');
    this.router.navigate(['/postLaunch']);
  }

}
