import { Observable } from 'rxjs';
import { LoginService } from './../services/login.service';
import { HelperService } from './../services/helper.service';
import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { of } from 'rxjs';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private router: Router, private helperService: HelperService, private loginService: LoginService) { }

  public canActivate(): Observable<boolean> {
    if (localStorage.getItem('currentUser')) {
      // this.loginService.checkAccessToken().subscribe((res) => {
      //   console.log('CHECK RES :', res);
      // });
      // if (this.loginService.currentUser === undefined) {
      //   return new Observable<boolean>((observer) => {
      //     this.loginService.refreshAccessToken().subscribe((res) => {
      //       console.log(res);
      //       observer.next(true);
      //       observer.complete();
      //     });
      //   });

      //   // this.loginService.refreshAccessToken().subscribe((res) => {
      //   //   console.log(res);
      //   //   return true;
      //   // });
      // } else {
      //   return Observable.of(true);
      // }
      return of(true);
    } else {
      // not logged in so redirect to login page
      this.helperService.openSnackBar('You are not Logged in', 'Please Login');
      this.router.navigate(['/ecosystem/login']);
      return of(false);
    }
  }
}
