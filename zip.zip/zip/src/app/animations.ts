import { AUTO_STYLE, trigger, state, style, transition, animate, keyframes } from '@angular/animations';

export const slideDown = trigger('slideDown', [
    transition(':leave', [
        animate('500ms ease', keyframes([
            style({ opacity: 1, transform: 'translateY(0)', offset: 0 }),
            style({ opacity: 0, transform: 'translateY(50px)', offset: 1 }),
        ]))
    ])
]);

export const slideDownEnter = trigger('slideDownEnter', [
    transition(':enter', [
        animate('500ms ease', keyframes([
            style({ opacity: 0.2, transform: 'translateY(25px)', offset: 0 }),
            style({ opacity: 1, transform: 'translateY(0px)', offset: 1 }),
        ]))
    ])
]);

export const flyIn = trigger('flyIn', [
    transition(':enter', [
        animate('1s ease', keyframes([
            style({ opacity: 0, transform: 'translateY(-100px)', offset: 0 }),
            style({ opacity: 1, transform: 'translateY(0)', offset: 1 })
        ]))
    ])
]);

export const fade = trigger('fade', [
    transition(':enter', [
        animate(200, keyframes([
            style({ opacity: 0 }),
            style({ opacity: 1 }),
        ]))
    ]),
    transition(':leave', [
        animate(200, keyframes([
            style({ opacity: 1 }),
            style({ opacity: 0 }),
        ]))
    ])
]);

export const fadeEnter = trigger('fadeEnter', [
    transition(':enter', [
        animate(200, keyframes([
            style({ opacity: 0 }),
            style({ opacity: 1 }),
        ]))
    ])
]);

export const slideUp = trigger('slideUp', [
    transition(':enter', [
        animate('400ms ease', keyframes([
            style({ opacity: 0, transform: 'translateY(20px)', offset: 0 }),
            style({ opacity: 1, transform: 'translateY(0)', offset: 1 }),
        ]))
    ]),
    transition(':leave', [
        animate('400ms ease', keyframes([
            style({ opacity: 1, transform: 'translateX(0)', offset: 0 }),
            style({ opacity: 0, transform: 'translateX(200px)', offset: 1 }),
        ]))
    ])
]);

export const slideUpEnter = trigger('slideUpEnter', [
    transition(':enter', [
        animate('400ms ease', keyframes([
            style({ opacity: 0, transform: 'translateY(10px)', offset: 0 }),
            style({ opacity: 1, transform: 'translateY(0)', offset: 1 }),
        ]))
    ])
]);

export const flip = trigger('flip', [
    transition(':enter', [
        animate('.5s ease', keyframes([
            style({ opacity: 1, transform: 'rotateY(90deg)', offset: 0 }),
            style({ opacity: 1, transform: 'rotateY(0deg)', offset: 1 }),
        ]))
    ])
]);

export const tags = trigger('tags', [
    transition(':enter', [
        animate('200ms ease', keyframes([
            style({ opacity: 0, transform: 'translateY(20px)', offset: 0 }),
            style({ opacity: 1, transform: 'translateY(0)', offset: 1 }),
        ]))
    ]),
    transition(':leave', [
        animate('200ms ease', keyframes([
            style({ opacity: 1, transform: 'translateY(0)', offset: 0 }),
            style({ opacity: 0, transform: 'translateY(20px)', offset: 1 }),
        ]))
    ])
]);

export const slideLeft = trigger('slideLeft', [
    transition(':enter', [
        animate('250ms ease-out', keyframes([
            style({ opacity: 0, transform: 'translateX(50px)', offset: 0 }),
            style({ opacity: 1, transform: 'translateX(0)', offset: 1 }),
        ]))
    ]),
    transition(':leave', [
        animate('250ms ease-out', keyframes([
            style({ opacity: 1, transform: 'translateX(0)', offset: 0 }),
            style({ opacity: 0, transform: 'translateX(50px)', offset: 1 }),
        ]))
    ])
]);

export const expend = trigger('expend', [
    transition(':enter', [
        animate('400ms ease', keyframes([
            style({ opacity: 0.5, height: '0px', offset: 0 }),
            style({ opacity: 1, height: AUTO_STYLE, offset: 1 }),
        ]))
    ]),
    transition(':leave', [
        animate('400ms ease', keyframes([
            style({ opacity: 1, height: AUTO_STYLE, offset: 0 }),
            style({ opacity: 0, height: '0px', offset: 1 }),
        ]))
    ])
]);
